"""Consolidated services for Prompts 13-32: jobs, clients, vendors, templates,
applications (convert-to-lead), reports, action-required, lead-inbox, integrations,
import batches, settings lists, tags, global search."""
import base64
import csv
import hashlib
import io
from datetime import timedelta
from core.config import settings
from core.errors import AppError
from core.transactions import atomic, transactional
from core.query import ACTIVE, active_filter, literal_search
from core.timeutil import org_day_bounds, org_period_bounds, next_working_day, zone
from pydantic import ValidationError
from models.recruitment import LeadCreate, VendorInput, TemplateInput, JobInput, ClientInput
from models.entities import new_id, now_utc
from models.recruitment import ACTIVE_STATUSES, FUNNEL_ORDER, STATUS_LABELS
from services import scope_service, recruitment_service as rs

# ---------------- crypto for integration secrets ----------------
def _fernet():
    from cryptography.fernet import Fernet
    key = base64.urlsafe_b64encode(hashlib.sha256(settings.jwt_secret.encode()).digest())
    return Fernet(key)


def _encrypt(v):
    return _fernet().encrypt(v.encode()).decode()


def _mask(v):
    if not v:
        return ""
    return "••••" + v[-4:] if len(v) > 4 else "••••"


def validate_payload(model, data):
    try:
        return model.model_validate(data).model_dump()
    except ValidationError as exc:
        fields = ", ".join(".".join(map(str, e["loc"])) for e in exc.errors())
        raise AppError("validation", "Invalid or unsupported fields: " + fields, 422)


def clean(d):
    d = dict(d); d.pop("_id", None); return d


# ======================= JOBS =======================
async def list_jobs(db, actor, perms, *, search="", status=""):
    q = {"archived": {"$ne": True}}
    if status:
        q["status"] = status
    if search:
        q["$or"] = [{"title": {"$regex": literal_search(search), "$options": "i"}},
                    {"client": {"$regex": literal_search(search), "$options": "i"}},
                    {"location": {"$regex": literal_search(search), "$options": "i"}}]
    rows = await db.jobs.find(q, {"_id": 0}).sort("created_at", -1).to_list(500)
    for r in rows:
        r["linked_leads"] = await db.leads.count_documents({**await scope_service.leads_filter(db, actor, perms), "job": r["title"]})
    return rows


async def save_job(db, actor, data, job_id=None):
    data = validate_payload(JobInput, data)
    if not data.get("title") or not data.get("client"):
        raise AppError("bad_request", "Position title and client are required", 400)
    now = now_utc()
    if job_id:
        job = await db.jobs.find_one({"id": job_id})
        if not job:
            raise AppError("not_found", "Job not found", 404)
        data["updated_at"] = now
        await db.jobs.update_one({"id": job_id}, {"$set": data})
        return clean(await db.jobs.find_one({"id": job_id}))
    doc = {"id": new_id(), "status": "active", **data, "archived": False,
           "created_at": now, "updated_at": now, "created_by": actor["id"]}
    await db.jobs.insert_one(doc)
    return clean(doc)


async def archive_job(db, job_id, actor=None):
    res = await db.jobs.update_one({"id": job_id}, {"$set": {"archived": True,
        "archived_at": now_utc(), "archived_by": (actor or {}).get("id")}})
    if not res.matched_count:
        raise AppError("not_found", "Record not found", 404)
    return {"archived": True, "deleted": True}



# ======================= CLIENTS =======================
async def list_clients(db, actor, perms, *, search=""):
    q = {"archived": {"$ne": True}}
    if search:
        q["$or"] = [{"name": {"$regex": literal_search(search), "$options": "i"}},
                    {"company": {"$regex": literal_search(search), "$options": "i"}},
                    {"contact_person": {"$regex": literal_search(search), "$options": "i"}},
                    {"contact_phone": {"$regex": literal_search(search), "$options": "i"}}]
    rows = await db.clients.find(q, {"_id": 0}).sort("created_at", -1).to_list(500)
    for r in rows:
        base = {**await scope_service.leads_filter(db, actor, perms), "client": r["name"]}
        r["stats"] = {
            "submitted": await db.leads.count_documents(base),
            "interviewed": await db.leads.count_documents({**base, "status": {"$in": ["lineup", "selected", "joined"]}}),
            "selected": await db.leads.count_documents({**base, "status": {"$in": ["selected", "joined"]}}),
            "joined": await db.leads.count_documents({**base, "status": "joined"}),
        }
    return rows


async def save_client(db, actor, data, client_id=None):
    data = validate_payload(ClientInput, data)
    if not data.get("name"):
        raise AppError("bad_request", "Client name is required", 400)
    now = now_utc()
    if client_id:
        if not await db.clients.find_one({"id": client_id}):
            raise AppError("not_found", "Client not found", 404)
        data["updated_at"] = now
        await db.clients.update_one({"id": client_id}, {"$set": data})
        return clean(await db.clients.find_one({"id": client_id}))
    doc = {"id": new_id(), **data, "archived": False, "created_at": now, "updated_at": now, "created_by": actor["id"]}
    await db.clients.insert_one(doc)
    return clean(doc)


async def archive_client(db, client_id, actor=None):
    res = await db.clients.update_one({"id": client_id}, {"$set": {"archived": True,
        "archived_at": now_utc(), "archived_by": (actor or {}).get("id")}})
    if not res.matched_count:
        raise AppError("not_found", "Record not found", 404)
    return {"archived": True, "deleted": True}



# ======================= VENDORS =======================
VENDOR_STAGES = ["new", "contacted", "followup", "meeting", "proposal_sent", "negotiation", "empanelled", "rejected"]


async def list_vendors(db, actor, perms, *, search="", stage=""):
    ids = await scope_service.resource_scope_ids(db, actor, perms, "vendors")
    q = {} if ids is None else {"owner_id": {"$in": ids}}
    q.update(ACTIVE)
    if stage:
        q["stage"] = stage
    if search:
        q["$or"] = [{"company": {"$regex": literal_search(search), "$options": "i"}},
                    {"contact_person": {"$regex": literal_search(search), "$options": "i"}},
                    {"phone": {"$regex": literal_search(search), "$options": "i"}}]
    rows = await db.vendors.find(q, {"_id": 0}).sort("created_at", -1).to_list(500)
    return rows


async def vendor_summary(db, actor, perms):
    ids = await scope_service.resource_scope_ids(db, actor, perms, "vendors")
    base = {} if ids is None else {"owner_id": {"$in": ids}}
    base.update(ACTIVE)
    return {
        "empanelled": await db.vendors.count_documents({**base, "stage": "empanelled"}),
        "proposals": await db.vendors.count_documents({**base, "stage": {"$in": ["proposal_sent", "negotiation"]}}),
        "active": await db.vendors.count_documents({**base, "stage": {"$nin": ["empanelled", "rejected"]}}),
    }


async def save_vendor(db, actor, perms, data, vendor_id=None):
    data = validate_payload(VendorInput, data)
    if not data.get("company"):
        raise AppError("bad_request", "Company name is required", 400)
    now = now_utc()
    if vendor_id:
        v = await db.vendors.find_one({"id": vendor_id})
        if not v:
            raise AppError("not_found", "Vendor not found", 404)
        await scope_service.assert_resource_access(db, actor, perms, "vendors", v["owner_id"])
        data["updated_at"] = now
        await db.vendors.update_one({"id": vendor_id}, {"$set": data})
        return clean(await db.vendors.find_one({"id": vendor_id}))
    doc = {"id": new_id(), "stage": data.get("stage") or "new", **data,
           "owner_id": actor["id"], "created_at": now, "updated_at": now, "created_by": actor["id"]}
    await db.vendors.insert_one(doc)
    return clean(doc)


async def delete_vendor(db, actor, perms, vendor_id):
    v = await db.vendors.find_one({"id": vendor_id})
    if not v:
        raise AppError("not_found", "Vendor not found", 404)
    await scope_service.assert_resource_access(db, actor, perms, "vendors", v["owner_id"])
    await db.vendors.update_one({"id": vendor_id}, {"$set": {"archived": True, "archived_at": now_utc(), "archived_by": actor["id"]}})
    return {"deleted": True}


# ======================= TEMPLATES (unified) =======================
async def list_templates(db, *, channel="", search=""):
    q = {"archived": {"$ne": True}}
    if channel:
        q["channel"] = channel
    if search:
        q["$or"] = [{"name": {"$regex": literal_search(search), "$options": "i"}},
                    {"category": {"$regex": literal_search(search), "$options": "i"}},
                    {"body": {"$regex": literal_search(search), "$options": "i"}}]
    return await db.templates.find(q, {"_id": 0}).sort("updated_at", -1).to_list(500)


async def save_template(db, actor, data, tpl_id=None):
    data = validate_payload(TemplateInput, data)
    if not data.get("name") or not data.get("body"):
        raise AppError("bad_request", "Template name and body are required", 400)
    if data.get("channel") not in ("whatsapp", "email"):
        raise AppError("bad_request", "Channel must be whatsapp or email", 400)
    now = now_utc()
    if tpl_id:
        if not await db.templates.find_one({"id": tpl_id}):
            raise AppError("not_found", "Template not found", 404)
        data["updated_at"] = now; data["updated_by"] = actor.get("name")
        await db.templates.update_one({"id": tpl_id}, {"$set": data})
        return clean(await db.templates.find_one({"id": tpl_id}))
    doc = {"id": new_id(), "provider_approved": False, **data, "archived": False,
           "created_at": now, "updated_at": now, "updated_by": actor.get("name"), "created_by": actor["id"]}
    await db.templates.insert_one(doc)
    return clean(doc)


async def delete_template(db, tpl_id, actor=None):
    res = await db.templates.update_one({"id": tpl_id}, {"$set": {"archived": True,
        "archived_at": now_utc(), "archived_by": (actor or {}).get("id")}})
    if not res.matched_count:
        raise AppError("not_found", "Record not found", 404)
    return {"archived": True, "deleted": True}



# ======================= APPLICATIONS =======================
async def _application(db, actor, perms, app_id):
    scope_service.require_lead_view(actor, perms)
    app = await db.applications.find_one({"id": app_id})
    if not app:
        raise AppError("not_found", "Application not found", 404)
    await scope_service.assert_lead_access(db, actor, perms, app)
    return app


async def list_applications(db, actor, perms, *, search="", status=""):
    scope_service.require_lead_view(actor, perms)
    q = await scope_service.leads_filter(db, actor, perms)
    if status and status != "all":
        q["status"] = status
    if search:
        q["$or"] = [{f: {"$regex": literal_search(search), "$options": "i"}} for f in ("name", "phone", "role")]
    return await db.applications.find(q, {"_id": 0}).sort("applied_at", -1).to_list(500)


async def update_application_status(db, actor, perms, app_id, status):
    app = await _application(db, actor, perms, app_id)
    if status not in ("new", "shortlisted") or app.get("status") == "converted":
        raise AppError("invalid_transition", "Use conversion to link applications; converted applications cannot be reset", 422)
    await db.applications.update_one({"id": app_id}, {"$set": {"status": status, "updated_at": now_utc()}})
    return clean(await db.applications.find_one({"id": app_id}))


async def archive_application(db, actor, perms, app_id):
    await _application(db, actor, perms, app_id)
    await db.applications.update_one({"id": app_id}, {"$set": {"archived": True,
        "archived_at": now_utc(), "archived_by": actor["id"]}})
    return {"archived": True}


@transactional
async def convert_application(db, actor, perms, app_id, assign_to=None, create_followup=True):
    app = await _application(db, actor, perms, app_id)
    owner = await rs._resolve_owner(db, actor, perms, assign_to or app.get("owner_id"))
    if app.get("lead_id"):
        lead = await rs.get_lead(db, actor, perms, app["lead_id"])
        return {"converted": False, "already": True, "lead": lead}
    norm = rs._normalize_phone(app.get("phone", ""))
    visible = await scope_service.leads_filter(db, actor, perms)
    existing = await db.leads.find_one({**visible, "phone_normalized": norm}) if norm else None
    if existing:
        await db.applications.update_one({"id": app_id}, {"$set": {"status": "converted", "lead_id": existing["id"]}})
        return {"converted": False, "existing": True, "lead": rs.clean(existing)}
    # Do not look up or expose a different recruiter's matching candidate.
    data = LeadCreate(name=app["name"], phone=app["phone"], email=app.get("email"),
                      city=app.get("city"), experience=app.get("experience"),
                      source=app.get("source") or "application", role_applied=app.get("role"),
                      job=app.get("role"), owner_id=owner,
                      first_followup_at=await next_working_day(db) if create_followup else None)
    meta = {k: app.get(k) for k in ("campaign", "utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content", "provider_lead_id")}
    meta["application_id"] = app_id
    lead = await rs.create_lead(db, actor, perms, data, _metadata=meta)
    await db.applications.update_one({"id": app_id}, {"$set": {"status": "converted", "lead_id": lead["id"], "converted_by": actor["id"], "converted_at": now_utc()}})
    from services import notify_service
    await notify_service.notify(db, recipient_id=owner, type_="lead_assigned", title="New lead from application",
                                message=lead["name"], entity_type="lead", entity_id=lead["id"], action_url=f"/admin/my-leads?open={lead['id']}")
    return {"converted": True, "lead": lead}


# ======================= LEAD INBOX =======================
async def lead_inbox(db, actor, perms, *, search="", source=""):
    scope_q = await scope_service.leads_filter(db, actor, perms, None)
    # source summary
    pipeline = [{"$match": scope_q}, {"$group": {"_id": "$source",
        "total": {"$sum": 1},
        "connected": {"$sum": {"$cond": [{"$gt": ["$call_count", 0]}, 1, 0]}},
        "interview": {"$sum": {"$cond": [{"$in": ["$status", ["lineup", "selected", "joined"]]}, 1, 0]}},
        "selected": {"$sum": {"$cond": [{"$in": ["$status", ["selected", "joined"]]}, 1, 0]}},
        "joined": {"$sum": {"$cond": [{"$eq": ["$status", "joined"]}, 1, 0]}}}}]
    summary = [{"source": r["_id"] or "unknown", **{k: r[k] for k in ("total", "connected", "interview", "selected", "joined")}}
               async for r in db.leads.aggregate(pipeline)]
    q = dict(scope_q)
    if source and source != "all":
        q["source"] = source
    if search:
        q["$or"] = [{"name": {"$regex": literal_search(search), "$options": "i"}},
                    {"phone": {"$regex": literal_search(search), "$options": "i"}},
                    {"email": {"$regex": literal_search(search), "$options": "i"}}]
    rows = await db.leads.find(q, {"_id": 0}).sort("created_at", -1).to_list(300)
    await rs._attach_flags(db, actor, perms, rows, scope_q)
    return {"summary": summary, "items": rows}


# ======================= REPORTS =======================
async def _recruiter_ids(db, actor, perms):
    ids = await scope_service.recruiter_scope_ids(db, actor, perms)
    users = await db.users.find({} if ids is None else {"id": {"$in": ids}},
                                {"_id": 0, "id": 1, "name": 1}).to_list(500)
    return {u["id"]: u["name"] for u in users}


async def reports(db, actor, perms, *, tab="leaderboard"):
    umap = await _recruiter_ids(db, actor, perms)
    rid = list(umap.keys())
    org = await db.organization_settings.find_one({"key": "org"}) or {}
    targets = org.get("targets", {"calls_per_day": 50, "connected_per_day": 20, "lineups_per_day": 3, "joinings_per_month": 5})
    lead_q = await scope_service.leads_filter(db, actor, perms)
    related_q = await scope_service.active_related_filter(db, actor, perms)

    if tab == "funnel":
        out = []
        for st in FUNNEL_ORDER:
            out.append({"stage": st, "label": STATUS_LABELS.get(st, st),
                        "count": await db.leads.count_documents({**lead_q, "status": st})})
        return {"funnel": out}

    if tab == "aging":
        now = now_utc()
        buckets = {"new": 0, "1d": 0, "3d": 0, "7d": 0, "15d+": 0}
        async for l in db.leads.find({**lead_q, "status": {"$in": ACTIVE_STATUSES}}, {"_id": 0, "created_at": 1}):
            age = (now - rs._as_utc(l.get("created_at") or now)).days
            if age < 1:
                buckets["new"] += 1
            elif age < 3:
                buckets["1d"] += 1
            elif age < 7:
                buckets["3d"] += 1
            elif age < 15:
                buckets["7d"] += 1
            else:
                buckets["15d+"] += 1
        return {"aging": buckets}

    if tab == "missed":
        now = now_utc()
        rows = await db.followups.find({**related_q, "recruiter_id": {"$in": rid}, "status": "pending",
                                        "due_at": {"$lt": now}}, {"_id": 0}).sort("due_at", 1).to_list(300)
        for r in rows:
            l = await db.leads.find_one({"id": r["lead_id"]}, {"_id": 0, "phone": 1, "priority": 1, "status": 1})
            r["recruiter"] = umap.get(r["recruiter_id"])
            r["phone"] = (l or {}).get("phone"); r["priority"] = (l or {}).get("priority")
            r["lead_status"] = (l or {}).get("status")
            r["delay_hours"] = round((now - rs._as_utc(r["due_at"])).total_seconds() / 3600, 1)
        return {"missed": rows}

    # leaderboard + targets share per-recruiter aggregation
    today, day_end = await org_day_bounds(db)
    month_start, month_end = await org_period_bounds(db, "month")
    board = []
    for uid, name in umap.items():
        calls = await db.calls.count_documents({**related_q, "recruiter_id": uid, "created_at": {"$gte": today, "$lt": day_end}})
        connected = await db.calls.count_documents({**related_q, "recruiter_id": uid, "connected": True, "created_at": {"$gte": today, "$lt": day_end}})
        lineups = await db.leads.count_documents({**lead_q, "owner_id": uid,
            "status_history": {"$elemMatch": {"status": "lineup", "at": {"$gte": today, "$lt": day_end}}}})
        attended = await db.interviews.count_documents({**related_q, "recruiter_id": uid, "status": "attended"})
        selected = await db.leads.count_documents({**lead_q, "owner_id": uid, "status": "selected"})
        joined = await db.joinings.count_documents({**related_q, "recruiter_id": uid, "status": "joined", "actual_joining_date": {"$gte": month_start, "$lt": month_end}})
        missed = await db.followups.count_documents({**related_q, "recruiter_id": uid, "status": "pending", "due_at": {"$lt": now_utc()}})
        score = calls * 1 + connected * 2 + lineups * 5 + selected * 8 + joined * 15 - missed * 2
        board.append({"recruiter": name, "recruiter_id": uid, "calls": calls, "connected": connected,
                      "lineups": lineups, "attended": attended, "selected": selected, "joined": joined,
                      "missed": missed, "score": score})
    board.sort(key=lambda x: x["score"], reverse=True)
    for i, b in enumerate(board):
        b["rank"] = i + 1
    if tab == "targets":
        cards = []
        for b in board:
            cards.append({"recruiter": b["recruiter"], "metrics": [
                {"metric": "Calls / day", "actual": b["calls"], "target": targets["calls_per_day"]},
                {"metric": "Connected / day", "actual": b["connected"], "target": targets["connected_per_day"]},
                {"metric": "Lineups / day", "actual": b["lineups"], "target": targets["lineups_per_day"]},
                {"metric": "Joinings / month", "actual": b["joined"], "target": targets["joinings_per_month"]},
            ]})
            for m in cards[-1]["metrics"]:
                m["pct"] = round(100 * m["actual"] / m["target"]) if m["target"] else 0
        return {"targets": cards, "score_formula": "calls*1 + connected*2 + lineups*5 + selected*8 + joined*15 - missed*2"}
    return {"leaderboard": board, "score_formula": "calls*1 + connected*2 + lineups*5 + selected*8 + joined*15 - missed*2"}


# ======================= ACTION REQUIRED =======================
async def action_required(db, actor, perms):
    scope_q = await scope_service.leads_filter(db, actor, perms, None)
    ids = await scope_service.recruiter_scope_ids(db, actor, perms)
    fu_scope = await scope_service.active_related_filter(db, actor, perms)
    related_q = fu_scope
    now = now_utc()

    async def sample(coll, q, limit=5, name_field="name"):
        rows = await db[coll].find(q, {"_id": 0}).limit(limit).to_list(limit)
        return rows

    stale_cut = now - timedelta(days=15)
    cards = []
    # 1 overdue followups
    q = {**fu_scope, "status": "pending", "due_at": {"$lt": now}}
    cards.append({"key": "overdue_followups", "title": "Overdue Follow-ups", "tone": "red",
                  "count": await db.followups.count_documents(q), "items": await sample("followups", q, name_field="lead_name")})
    # 2 active no followup
    q = {**scope_q, "status": {"$in": ACTIVE_STATUSES}, "$or": [{"next_followup_at": None}, {"next_followup_at": {"$exists": False}}]}
    cards.append({"key": "no_followup", "title": "Active Leads — No Follow-up", "tone": "amber",
                  "count": await db.leads.count_documents(q), "items": await sample("leads", q)})
    # 3 never called
    q = {**scope_q, "call_count": {"$lte": 0}, "status": {"$in": ACTIVE_STATUSES}}
    cards.append({"key": "never_called", "title": "Never-Called Leads", "tone": "amber",
                  "count": await db.leads.count_documents(q), "items": await sample("leads", q)})
    # 4 unassigned
    q = {"$and": [scope_q, {"owner_id": {"$in": [None, ""]}}]}
    cards.append({"key": "unassigned", "title": "Unassigned Leads", "tone": "red",
                  "count": await db.leads.count_documents(q), "items": await sample("leads", q)})
    # 5 stale
    q = {**scope_q, "status": {"$in": ACTIVE_STATUSES}, "created_at": {"$lt": stale_cut}}
    cards.append({"key": "stale", "title": "Stale Leads (15+ days)", "tone": "amber",
                  "count": await db.leads.count_documents(q), "items": await sample("leads", q)})
    # 6 selected no joining date
    q = {**scope_q, "status": "selected", "$or": [{"expected_joining_at": None}, {"expected_joining_at": {"$exists": False}}]}
    cards.append({"key": "selected_no_joining", "title": "Selected — No Joining Date", "tone": "amber",
                  "count": await db.leads.count_documents(q), "items": await sample("leads", q)})
    # 7 unconfirmed interviews tomorrow
    tom, tom_end = await org_day_bounds(db, now, offset=1)
    q = {**fu_scope, "status": "scheduled", "confirmation": {"$ne": "confirmed"}, "scheduled_at": {"$gte": tom, "$lt": tom_end}}
    cards.append({"key": "unconfirmed_interviews", "title": "Unconfirmed Interviews Tomorrow", "tone": "amber",
                  "count": await db.interviews.count_documents(q), "items": await sample("interviews", q, name_field="lead_name")})
    # 8 unconfirmed joinings
    q = {**fu_scope, "status": {"$nin": ["joined", "dropped", "client_rejected"]}, "confirmation": {"$ne": "confirmed"}}
    cards.append({"key": "unconfirmed_joinings", "title": "Unconfirmed Joinings", "tone": "amber",
                  "count": await db.joinings.count_documents(q), "items": await sample("joinings", q, name_field="lead_name")})
    # 9 recruiters below call target
    org = await db.organization_settings.find_one({"key": "org"}) or {}
    target = (org.get("targets") or {}).get("calls_per_day", 50)
    umap = await _recruiter_ids(db, actor, perms)
    today, day_end = await org_day_bounds(db, now)
    below = []
    for uid, name in umap.items():
        c = await db.calls.count_documents({**related_q, "recruiter_id": uid, "created_at": {"$gte": today, "$lt": day_end}})
        if c < target:
            below.append({"name": name, "calls": c, "target": target})
    cards.append({"key": "below_target", "title": "Recruiters Below Call Target", "tone": "red",
                  "count": len(below), "items": below[:5]})
    links = {"overdue_followups": "/admin/followups?tab=overdue", "no_followup": "/admin/leads?view=no_followup",
             "never_called": "/admin/leads?view=not_called", "unassigned": "/admin/leads?view=unassigned",
             "stale": "/admin/leads?view=stale", "selected_no_joining": "/admin/leads?view=selected_no_joining",
             "unconfirmed_interviews": "/admin/interviews?tab=tomorrow", "unconfirmed_joinings": "/admin/joining",
             "below_target": "/admin/reports?tab=leaderboard"}
    lead_page = "/admin/leads" if "leads.view_all" in perms else "/admin/my-leads"
    module_permissions = {"overdue_followups": "followups.manage", "unconfirmed_interviews": "interviews.manage",
                          "unconfirmed_joinings": "joinings.manage", "below_target": "reports.view"}
    cards = [card for card in cards if actor.get("role") == "admin" or
             module_permissions.get(card["key"]) is None or module_permissions[card["key"]] in perms]
    for card in cards:
        card["action_url"] = links[card["key"]].replace("/admin/leads?", lead_page + "?")
    return {"cards": cards}


# ======================= INTEGRATIONS =======================
INTEGRATIONS = [
    {"key": "whatsapp", "name": "WhatsApp Business API", "fields": ["phone_number_id", "waba_id", "access_token", "webhook_verify_token", "app_secret"]},
    {"key": "instagram", "name": "Instagram / Meta Leads", "fields": ["page_id", "access_token", "webhook_verify_token", "app_secret"]},
    {"key": "facebook", "name": "Facebook Lead Ads", "fields": ["page_id", "access_token", "webhook_verify_token", "app_secret"]},
    {"key": "google_forms", "name": "Google Forms", "fields": ["shared_secret"]},
    {"key": "mobile_calling", "name": "Mobile Calling", "coming_soon": True, "fields": []},
]


async def integration_secrets(db, key):
    rec = await db.integrations.find_one({"key": key})
    if not rec or not rec.get("secrets_enc"):
        raise AppError("not_configured", "Integration is not configured", 503)
    try:
        return {k: _fernet().decrypt(v.encode()).decode() for k, v in rec["secrets_enc"].items()}
    except Exception:
        raise AppError("credential_error", "Stored credentials cannot be decrypted; reconfigure the integration", 503)


async def list_integrations(db):
    out = []
    for meta in INTEGRATIONS:
        rec = await db.integrations.find_one({"key": meta["key"]}) or {}
        out.append({**meta, "configured": bool(rec.get("secrets_enc")), "connected": bool(rec.get("connected")),
                    "status": rec.get("status", "not_connected"), "last_sync": rec.get("last_sync"),
                    "last_test_at": rec.get("last_test_at"), "last_success_at": rec.get("last_success_at"),
                    "last_error": rec.get("last_error"),
                    "test_label": "Verify saved configuration" if meta["key"] == "google_forms" else "Test connection",
                    "masked": {f: "set" for f in rec.get("secrets_enc", {})}})
    return out


async def save_integration(db, actor, key, values):
    import re
    meta = next((m for m in INTEGRATIONS if m["key"] == key), None)
    if not meta or meta.get("coming_soon"):
        raise AppError("bad_request", "Unsupported integration", 422)
    if not isinstance(values, dict) or set(values) - (set(meta["fields"]) | {"clear_fields"}):
        raise AppError("validation", "Unsupported integration fields", 422)
    clear = values.get("clear_fields", [])
    if not isinstance(clear, list) or set(clear) - set(meta["fields"]):
        raise AppError("validation", "Invalid credential removal request", 422)
    rec = await db.integrations.find_one({"key": key}) or {}
    enc = dict(rec.get("secrets_enc", {}))
    for field in clear:
        enc.pop(field, None)
    for field in meta["fields"]:
        value = values.get(field)
        if value is not None and not isinstance(value, str):
            raise AppError("validation", "Credentials must be strings", 422)
        if value and value.strip():
            value = value.strip()
            if len(value) > 8192 or (field.endswith("_id") and not re.fullmatch(r"[0-9]{1,40}", value)):
                raise AppError("validation", "Invalid credential format", 422)
            if field in {"shared_secret", "webhook_verify_token", "app_secret"} and len(value) < 16:
                raise AppError("validation", "Secrets must contain at least 16 characters", 422)
            enc[field] = _encrypt(value)
    if not rec and not set(meta["fields"]) <= set(enc):
        raise AppError("validation", "All credentials are required for first-time setup", 422)
    complete = set(meta["fields"]) <= set(enc)
    await db.integrations.update_one({"key": key}, {"$set": {
        "key": key, "secrets_enc": enc, "fields": {f: "set" for f in enc}, "connected": False,
        "status": "configured" if complete else "incomplete", "last_error": None,
        "updated_at": now_utc(), "updated_by": actor["id"],
    }}, upsert=True)
    return {"ok": True, "status": "configured" if complete else "incomplete"}


async def meta_get(path, credentials, fields=None):
    import httpx
    import re
    if not re.fullmatch(r"v[0-9]+\.[0-9]+", settings.meta_api_version):
        raise AppError("configuration", "Invalid Meta API version", 503)
    if not re.fullmatch(r"[0-9]{1,40}(?:/phone_numbers)?", path):
        raise AppError("validation", "Invalid provider object ID", 422)
    try:
        async with httpx.AsyncClient(timeout=12, follow_redirects=False) as client:
            response = await client.get(f"https://graph.facebook.com/{settings.meta_api_version}/{path}",
                headers={"Authorization": "Bearer " + credentials["access_token"]},
                params={"fields": fields} if fields else None)
        if response.status_code != 200:
            raise AppError("provider_rejected", f"Provider rejected the request (HTTP {response.status_code}); verify token, expiry and permissions", 502)
        return response.json()
    except (httpx.HTTPError, ValueError, KeyError):
        raise AppError("provider_unavailable", "Provider could not be verified; check configuration and retry", 502)


async def test_integration(db, key):
    meta = next((m for m in INTEGRATIONS if m["key"] == key and not m.get("coming_soon")), None)
    if not meta:
        raise AppError("not_found", "Integration not found", 404)
    rec = await db.integrations.find_one({"key": key})
    if not rec:
        raise AppError("not_found", "Integration not found", 404)
    tested = now_utc()
    await db.integrations.update_one({"key": key}, {"$set": {"last_test_at": tested}})
    try:
        creds = await integration_secrets(db, key)
        if not all(creds.get(f) for f in meta["fields"]):
            raise AppError("incomplete", "Required credentials are missing", 422)
        if key == "google_forms":
            await db.integrations.update_one({"key": key}, {"$set": {"connected": False, "status": "configured", "last_error": None}})
            return {"ok": True, "remote_tested": False, "message": "Saved shared-secret configuration verified. No Google remote connection was tested."}
        if key == "whatsapp":
            phones = await meta_get(creds["waba_id"] + "/phone_numbers", creds, "id")
            if creds["phone_number_id"] not in {str(p.get("id")) for p in phones.get("data", [])}:
                raise AppError("provider_mismatch", "Phone number does not belong to the configured WhatsApp account", 422)
            await meta_get(creds["phone_number_id"], creds, "id,verified_name")
        else:
            page = await meta_get(creds["page_id"], creds, "id,name")
            if str(page.get("id")) != creds["page_id"]:
                raise AppError("provider_mismatch", "Configured page could not be verified", 422)
    except AppError as exc:
        await db.integrations.update_one({"key": key}, {"$set": {"connected": False, "status": "error", "last_error": exc.message}})
        raise
    await db.integrations.update_one({"key": key}, {"$set": {"connected": True, "status": "connected", "last_success_at": tested, "last_error": None}})
    return {"ok": True, "remote_tested": True, "message": "Provider credentials and configured account verified"}


async def disconnect_integration(db, key):
    result = await db.integrations.update_one({"key": key}, {"$set": {"connected": False, "status": "not_connected", "secrets_enc": {}, "fields": {}, "last_error": None, "disconnected_at": now_utc()}})
    if not result.matched_count:
        raise AppError("not_found", "Integration not found", 404)
    return {"disconnected": True}


# ======================= SETTINGS: org + lists =======================
DEFAULT_ORG = {
    "key": "org", "company_name": "OAKsphere Recruitment", "agency_name": "OAKsphere Recruitment",
    "timezone": "Asia/Kolkata", "date_format": "YYYY-MM-DD", "working_days": [0, 1, 2, 3, 4],
    "work_start": "10:00", "holidays": [],
    "targets": {"calls_per_day": 50, "connected_per_day": 20, "lineups_per_day": 3,
                "joinings_per_month": 5, "followup_escalation_hours": 24},
    "lead_sources": ["manual", "referral", "meta", "facebook", "instagram", "google_form", "careers", "whatsapp", "application", "import"],
    "priorities": ["low", "medium", "high"], "lead_statuses": list(STATUS_LABELS.keys()),
}


async def get_org_settings(db):
    rec = await db.organization_settings.find_one({"key": "org"}, {"_id": 0}) or {}
    name = rec.get("company_name") or rec.get("agency_name") or DEFAULT_ORG["company_name"]
    result = {**DEFAULT_ORG, **rec, "company_name": name, "agency_name": name,
              "priorities": list(DEFAULT_ORG["priorities"]), "lead_statuses": list(DEFAULT_ORG["lead_statuses"])}
    return result


async def update_org_settings(db, actor, data):
    from datetime import date, time
    if set(data) - (set(DEFAULT_ORG) - {"key"}):
        raise AppError("validation", "Unsupported organization settings", 422)
    cur = await get_org_settings(db)
    if "company_name" in data and "agency_name" in data and data["company_name"] != data["agency_name"]:
        raise AppError("validation", "Company and agency names must agree", 422)
    if "agency_name" in data or "company_name" in data:
        name = str(data.get("company_name", data.get("agency_name")) or "").strip()
        if not name or len(name) > 160:
            raise AppError("validation", "Company name is required (maximum 160 characters)", 422)
        data.update(company_name=name, agency_name=name)
    if "timezone" in data:
        zone(data["timezone"])
    if "working_days" in data and (not isinstance(data["working_days"], list) or not data["working_days"] or any(type(d) is not int or d not in range(7) for d in data["working_days"])):
        raise AppError("validation", "Working days must use Monday=0 through Sunday=6", 422)
    try:
        if "work_start" in data:
            time.fromisoformat(data["work_start"])
        for d in data.get("holidays", []):
            date.fromisoformat(d)
    except (TypeError, ValueError):
        raise AppError("validation", "Invalid work time or holiday date", 422)
    for k in ("priorities", "lead_statuses"):
        if k in data and data[k] != DEFAULT_ORG[k]:
            raise AppError("validation", "Priority and status values use the canonical model", 422)
    if "targets" in data:
        targets = data["targets"]
        if not isinstance(targets, dict) or set(targets) - set(DEFAULT_ORG["targets"]) or any(type(v) is not int or v < 0 or v > 100000 for v in targets.values()):
            raise AppError("validation", "Targets must be non-negative integers", 422)
        data["targets"] = {**cur["targets"], **targets}
    if "lead_sources" in data and (not isinstance(data["lead_sources"], list) or not data["lead_sources"] or any(not isinstance(v,str) or not v.strip() or len(v)>80 for v in data["lead_sources"])):
        raise AppError("validation", "Sources must be nonempty names", 422)
    doc = {**cur, **data, "updated_at": now_utc(), "updated_by": actor["id"]}
    await db.organization_settings.update_one({"key": "org"}, {"$set": doc}, upsert=True)
    return doc


# ======================= TAGS =======================
async def list_tags(db, actor, perms):
    rows = await db.lead_tags.find(ACTIVE, {"_id": 0}).sort("name", 1).to_list(500)
    scope = await scope_service.leads_filter(db, actor, perms)
    for row in rows:
        row["lead_count"] = await db.leads.count_documents({**scope, "tags": row["name"]})
    return rows


@transactional
async def save_tag(db, data, tag_id=None):
    if set(data) - {"name", "color"}:
        raise AppError("validation", "Unsupported tag fields", 422)
    name = str(data.get("name") or "").strip()
    if not name or len(name) > 80:
        raise AppError("validation", "Tag name must contain 1 to 80 characters", 422)
    key = name.casefold()
    duplicate = await db.lead_tags.find_one({**ACTIVE, "name": {"$regex": "^" + literal_search(name) + "$", "$options": "i"}, "id": {"$ne": tag_id}})
    if duplicate:
        raise AppError("duplicate", "A tag with this name already exists", 409)
    doc = {"name": name, "normalized_key": key, "color": data.get("color", "indigo"), "updated_at": now_utc()}
    if tag_id:
        old = await db.lead_tags.find_one({"id": tag_id, **ACTIVE})
        if not old:
            raise AppError("not_found", "Tag not found", 404)
        await db.lead_tags.update_one({"id": tag_id}, {"$set": doc})
        if name != old["name"]:
            # Preserve history and de-duplicate tags if a lead already contains the new name.
            async for lead in db.leads.find({"tags": old["name"]}):
                tags = list(dict.fromkeys(name if t == old["name"] else t for t in lead["tags"]))
                await db.leads.update_one({"id": lead["id"]}, {"$set": {"tags": tags}})
        return clean(await db.lead_tags.find_one({"id": tag_id}))
    doc.update(id=new_id(), created_at=now_utc())
    await db.lead_tags.insert_one(doc)
    return clean(doc)


@transactional
async def delete_tag(db, tag_id):
    tag = await db.lead_tags.find_one({"id": tag_id, **ACTIVE})
    if not tag:
        raise AppError("not_found", "Tag not found", 404)
    await db.leads.update_many({"tags": tag["name"]}, {"$pull": {"tags": tag["name"]}})
    await db.lead_tags.delete_one({"id": tag_id})
    return {"deleted": True}


# ======================= GLOBAL SEARCH =======================
async def global_search(db, actor, perms, q):
    scope_service.require_lead_view(actor, perms)
    if not q or len(q.strip()) < 2:
        return {"results": []}
    scope_q = await scope_service.leads_filter(db, actor, perms, None)
    norm = rs._normalize_phone(q)
    ors = [{"name": {"$regex": literal_search(q), "$options": "i"}}, {"email": {"$regex": literal_search(q), "$options": "i"}},
           {"lead_code": {"$regex": literal_search(q), "$options": "i"}}]
    if norm:
        ors.append({"phone_normalized": {"$regex": norm}})
    query = {**scope_q, "$or": ors}
    rows = await db.leads.find(query, {"_id": 0, "id": 1, "name": 1, "phone": 1, "status": 1,
        "owner_id": 1, "job": 1, "client": 1, "lead_code": 1, "phone_normalized": 1}).limit(20).to_list(20)
    rows.sort(key=lambda r: 0 if r.get("phone_normalized") == norm else 1)
    return {"results": rows}


# ======================= IMPORT =======================
IMPORT_FIELDS = ["name", "phone", "alt_phone", "email", "city", "age", "gender", "qualification",
                 "experience", "current_salary", "expected_salary", "notice_period", "source",
                 "priority", "client", "job", "notes"]


def import_template_xlsx():
    import openpyxl
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Leads"
    ws.append([f.replace("_", " ").title() for f in IMPORT_FIELDS])
    ws.append(["John Doe", "9876543210", "", "john@example.com", "Pune", 28, "Male", "B.Com",
               "3 years", "30000", "40000", "30 days", "referral", "high", "Acme", "Sales Exec", "Warm lead"])
    buf = io.BytesIO(); wb.save(buf); buf.seek(0)
    return buf.getvalue()


def _parse_upload(filename, content):
    name = (filename or "").lower()
    if name.endswith(".csv"):
        text = content.decode("utf-8-sig", errors="replace")
        reader = csv.reader(io.StringIO(text))
        rows = []
        for row in reader:
            rows.append(row)
            if len(rows) > 2001:
                raise AppError("too_large", "Maximum 2,000 rows per import", 413)
    elif name.endswith(".xlsx"):
        import openpyxl
        import zipfile
        try:
            with zipfile.ZipFile(io.BytesIO(content)) as archive:
                if sum(i.file_size for i in archive.infolist()) > 30 * 1024 * 1024:
                    raise AppError("too_large", "Spreadsheet expands beyond 30MB", 413)
            wb = openpyxl.load_workbook(io.BytesIO(content), read_only=True, data_only=True)
        except (zipfile.BadZipFile, ValueError, KeyError):
            raise AppError("invalid_file", "Invalid XLSX file", 422)
        ws = wb.active
        rows = []
        for row in ws.iter_rows(values_only=True):
            if len(row) > 80 or len(rows) >= 2001:
                wb.close()
                raise AppError("too_large", "Maximum 2,000 rows and 80 columns per import", 413)
            rows.append(["" if c is None else str(c) for c in row])
        wb.close()
    else:
        raise AppError("bad_request", "Only CSV and XLSX files are supported", 400)
    if not rows:
        raise AppError("bad_request", "File is empty", 400)
    return rows[0], rows[1:]


async def import_preview(db, actor, perms, filename, content):
    if len(content) > 5 * 1024 * 1024:
        raise AppError("bad_request", "File exceeds 5MB limit", 400)
    header, data_rows = _parse_upload(filename, content)
    if len(data_rows) > 2000 or len(header) > 80 or len(set(header)) != len(header):
        raise AppError("validation", "Import supports 2,000 rows and 80 distinct columns per batch", 422)
    scope_service.require_lead_view(actor, perms)
    visible = await scope_service.leads_filter(db, actor, perms)
    phones_in_file = {}
    invalid = dupes_file = existing_dup = 0
    # tentative phone column guess
    pidx = next((i for i, h in enumerate(header) if "phone" in h.lower()), None)
    for r in data_rows:
        if pidx is not None and pidx < len(r):
            pn = rs._normalize_phone(r[pidx])
            if not 10 <= len(pn) <= 15:
                invalid += 1
            if pn:
                phones_in_file[pn] = phones_in_file.get(pn, 0) + 1
    for pn, c in phones_in_file.items():
        if c > 1:
            dupes_file += c - 1
        if await db.leads.count_documents({**visible, "phone_normalized": pn}):
            existing_dup += 1
    batch_id = new_id()
    await db.import_batches.insert_one({
        "id": batch_id, "actor_id": actor["id"], "header": header, "rows": data_rows,
        "committed": False, "created_at": now_utc(),
        "expires_at": now_utc() + timedelta(hours=2),
    })
    return {"batch_id": batch_id, "columns": header, "row_count": len(data_rows),
            "invalid_phones": invalid, "duplicates_in_file": dupes_file,
            "existing_crm_duplicates": existing_dup,
            "preview": [dict(zip(header, r)) for r in data_rows[:5]],
            "supported_fields": IMPORT_FIELDS}


@transactional
async def import_commit(db, actor, perms, batch_id, mapping, rules):
    scope_service.require_lead_view(actor, perms)
    batch = await db.import_batches.find_one({"id": batch_id, "actor_id": actor["id"]})
    if not batch or rs._as_utc(batch.get("expires_at")) <= now_utc():
        raise AppError("not_found", "Import batch not found or expired", 404)
    if batch.get("committed"):
        return batch["result"]
    if not isinstance(mapping, dict) or not {"name", "phone"} <= set(mapping.values()):
        raise AppError("validation", "Name and phone column mappings are required", 422)
    if set(rules) - {"assign", "duplicates", "invalid", "recruiter_id"}:
        raise AppError("validation", "Unsupported import rules", 422)
    fields = {c: f for c, f in mapping.items() if f and f != "not_mapped"}
    if set(fields) - set(batch["header"]) or set(fields.values()) - set(IMPORT_FIELDS) or len(set(fields.values())) != len(fields):
        raise AppError("validation", "Each supported field must map to exactly one existing column", 422)
    mode = rules.get("assign", "unassigned")
    if mode not in {"unassigned", "auto", "specific"} or rules.get("duplicates", "flag") not in {"flag", "skip"} or rules.get("invalid", "flag") not in {"flag", "skip"}:
        raise AppError("validation", "Invalid import rules", 422)
    from services.user_service import assignable_recruiters
    pool = await assignable_recruiters(db, actor, perms) if mode == "auto" else []
    if mode == "auto" and not pool:
        raise AppError("invalid_owner", "No active assignment targets", 422)
    if mode == "specific" and not rules.get("recruiter_id"):
        raise AppError("invalid_owner", "Select a recruiter", 422)
    fixed_owner = await rs._resolve_owner(db, actor, perms, rules.get("recruiter_id") if mode == "specific" else "", authority="imports.run") if mode != "auto" else None
    res = {"imported": 0, "skipped_duplicates": 0, "skipped_invalid": 0, "flagged_duplicate": 0,
           "flagged_invalid": 0, "auto_distributed": 0, "validation_errors": 0, "row_errors": []}
    index = {h: i for i, h in enumerate(batch["header"])}
    await db.import_batches.update_one({"id": batch_id, "actor_id": actor["id"], "committed": False}, {"$set": {"committing": True}})
    allowed_sources = (await get_org_settings(db))["lead_sources"]
    for row_no, row in enumerate(batch["rows"], start=2):
        data = {f: (str(row[index[c]]).strip() or None) if index[c] < len(row) else None for c, f in fields.items()}
        data["source"] = data.get("source") or "import"
        data["priority"] = str(data.get("priority") or "medium").lower()
        if data.get("gender"):
            data["gender"] = data["gender"].lower()
        pn = rs._normalize_phone(data.get("phone") or "")
        invalid = len(pn) < 10 or len(pn) > 15
        if invalid and rules.get("invalid") == "skip":
            res["skipped_invalid"] += 1
            continue
        dup = await rs.check_duplicate(db, actor, perms, data.get("phone"))
        if dup["duplicate"] and rules.get("duplicates") == "skip":
            res["skipped_duplicates"] += 1
            continue
        owner = pool[res["imported"] % len(pool)]["id"] if mode == "auto" else fixed_owner
        data["owner_id"] = owner or ""
        data["duplicate_ack"] = dup["duplicate"]
        try:
            if data["source"] not in allowed_sources:
                raise ValueError("Source is not configured")
            model = LeadCreate.model_validate(data)
        except (ValidationError, ValueError) as exc:
            res["validation_errors"] += 1
            if len(res["row_errors"]) < 100:
                res["row_errors"].append({"row": row_no, "message": "Invalid candidate fields or unconfigured source"})
            continue
        await rs.create_lead(db, actor, perms, model, _assignment_authority="imports.run",
            _metadata={"import_batch_id": batch_id, "import_row": row_no, "invalid_phone_flag": invalid})
        res["imported"] += 1
        res["flagged_duplicate"] += int(dup["duplicate"])
        res["flagged_invalid"] += int(invalid)
        res["auto_distributed"] += int(mode == "auto")
    await db.import_batches.update_one({"id": batch_id, "actor_id": actor["id"]}, {"$set": {"committed": True, "committing": False, "result": res}})
    return res
