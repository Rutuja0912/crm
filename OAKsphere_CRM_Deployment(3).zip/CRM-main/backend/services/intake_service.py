"""Authenticated, bounded provider intake into the scoped Applications inbox."""
import hashlib
from core.errors import AppError
from core.transactions import transactional
from models.entities import new_id, now_utc
from models.recruitment import ApplicationIntake
from services import audit_service


@transactional
async def ingest(db, data: ApplicationIntake, provider, event_id, actor=None, owner_id=None, team_id=None):
    # No caller-supplied owner/team survives public schema validation.
    event_key = hashlib.sha256((provider + ":" + event_id).encode()).hexdigest()
    existing = await db.webhook_events.find_one({"event_key": event_key})
    if existing:
        return {"accepted": True, "duplicate": True}
    doc = data.model_dump()
    from services.recruitment_service import _normalize_phone
    phone = _normalize_phone(doc["phone"])
    fingerprint = hashlib.sha256((provider + ":" + phone + ":" + doc["role"].casefold()).encode()).hexdigest()
    previous = await db.applications.find_one({"intake_key": fingerprint})
    if previous:
        app_id = previous["id"]
    else:
        app_id = new_id()
        doc.update(id=app_id, phone_normalized=phone, provider=provider, intake_key=fingerprint,
                   provider_lead_id=event_id, owner_id=owner_id, team_id=team_id, status="new",
                   archived=False, applied_at=now_utc(), created_at=now_utc())
        await db.applications.insert_one(doc)
    await db.webhook_events.insert_one({"id": new_id(), "event_key": event_key, "provider": provider,
        "event_id": event_id, "application_id": app_id, "processed_at": now_utc()})
    await audit_service.record(db, actor=actor, action="applications.intake", entity_type="application",
                              entity_id=app_id, details={"provider": provider, "duplicate": bool(previous)})
    await db.integrations.update_one({"key": provider}, {"$set": {"last_sync": now_utc()}})
    return {"accepted": True, "duplicate": bool(previous)}
