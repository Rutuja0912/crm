"""User CRUD with scoping, validation and referenced-record preservation."""
from core.security import hash_password, validate_password_policy
from core.query import literal_search
from core.transactions import transactional
from core.errors import AppError
from models.entities import new_id, now_utc, ROLES
from services import scope_service, permission_service


async def _active_admin_count(db) -> int:
    # Serialize admin removals inside the enclosing transaction. Counting alone
    # permits two admins to deactivate each other under snapshot isolation.
    await db.security_guards.update_one({"_id": "active_admins"}, {"$inc": {"revision": 1}}, upsert=True)
    return await db.users.count_documents({"role": "admin", "is_active": True})


def public(user: dict) -> dict:
    u = dict(user)
    u.pop("_id", None)
    u.pop("password_hash", None)
    u.setdefault("permission_overrides", {"allow": [], "deny": []})
    return u


async def list_users(db, actor: dict, *, search: str = "", role: str = "", status: str = "") -> list[dict]:
    query = await scope_service.user_scope_filter(db, actor)
    if search:
        query["$or"] = [
            {"name": {"$regex": literal_search(search), "$options": "i"}},
            {"email": {"$regex": literal_search(search), "$options": "i"}},
        ]
    if role:
        query["role"] = role
    if status == "active":
        query["is_active"] = True
    elif status == "inactive":
        query["is_active"] = False
    users = await db.users.find(query).sort("created_at", -1).to_list(1000)
    return [public(u) for u in users]


async def get_user(db, actor: dict, user_id: str) -> dict:
    user = await db.users.find_one({"id": user_id})
    if not user:
        raise AppError("not_found", "User not found", 404)
    await scope_service.assert_can_access_user(db, actor, user)
    return public(user)


async def _validate_role(db, role: str) -> None:
    if not await db.roles.find_one({"key": role}):
        raise AppError("invalid_role", f"Unknown role: {role}", 400)


async def create_user(db, actor: dict, data) -> dict:
    await _validate_role(db, data.role)
    validate_password_policy(data.password)
    if actor.get("role") != "admin":
        if actor.get("role") != "team_leader" or data.role == "admin":
            raise AppError("forbidden", "Only admins can create administrators or delegate user management", 403)
        own = await permission_service.get_effective_permissions(db, actor)
        grants = await permission_service.get_role_permissions(db, data.role)
        if not grants <= own:
            raise AppError("forbidden", "Role exceeds your permission authority", 403)
    email = data.email.lower().strip()
    if await db.users.find_one({"email": email}):
        raise AppError("conflict", "A user with this email already exists", 409)

    manager_id = data.manager_id
    team_id = data.team_id
    if actor.get("role") != "admin":
        if manager_id not in (None, actor["id"]) or team_id not in (None, actor.get("team_id")):
            raise AppError("forbidden", "New users must belong to your team", 403)
        manager_id, team_id = actor["id"], actor.get("team_id")
    if manager_id:
        mgr = await db.users.find_one({"id": manager_id, "is_active": True, "role": {"$in": ["team_leader", "admin"]}})
        if not mgr:
            raise AppError("invalid_manager", "Manager must be an active leader or admin", 422)
        team_id = mgr.get("team_id")

    doc = {
        "id": new_id(),
        "email": email,
        "name": data.name.strip(),
        "password_hash": hash_password(data.password),
        "role": data.role,
        "phone": data.phone,
        "team_id": team_id,
        "manager_id": manager_id,
        "is_active": True,
        "permission_overrides": {"allow": [], "deny": []},
        "avatar_url": None,
        "last_login_at": None,
        "created_at": now_utc(),
        "updated_at": now_utc(),
        "created_by": actor["id"],
        "updated_by": actor["id"],
    }
    await db.users.insert_one(doc)
    return public(doc)


@transactional
async def update_user(db, actor: dict, user_id: str, data) -> tuple[dict, dict]:
    user = await db.users.find_one({"id": user_id})
    if not user:
        raise AppError("not_found", "User not found", 404)
    await scope_service.assert_can_access_user(db, actor, user)

    updates = {}
    changes = {}
    payload = data.model_dump(exclude_unset=True)

    if "is_active" in payload and payload["is_active"] is not None:
        if not payload["is_active"] and user_id == actor["id"]:
            raise AppError("invalid_operation", "You cannot deactivate yourself", 400)
        if not payload["is_active"] and user.get("role") == "admin" and await _active_admin_count(db) <= 1:
            raise AppError("invalid_operation", "Cannot deactivate the last active administrator", 400)
    if "manager_id" in payload or "team_id" in payload:
        manager = payload.get("manager_id", user.get("manager_id"))
        if manager == user_id:
            raise AppError("invalid_manager", "A user cannot manage themselves", 422)
        if actor.get("role") != "admin":
            if manager != actor["id"] or payload.get("team_id", user.get("team_id")) != actor.get("team_id"):
                raise AppError("forbidden", "Cannot move a user outside your team", 403)
        if manager:
            mgr = await db.users.find_one({"id": manager, "is_active": True, "role": {"$in": ["team_leader", "admin"]}})
            if not mgr:
                raise AppError("invalid_manager", "Manager must be an active leader or admin", 422)
            payload["team_id"] = mgr.get("team_id")

    # Team leaders may not change roles or elevate; only admin can change role.
    if "role" in payload and payload["role"] is not None:
        if actor.get("role") != "admin":
            raise AppError("forbidden", "Only an admin can change roles", 403)
        if user_id == actor["id"]:
            raise AppError("invalid_operation", "You cannot change your own role", 400)
        await _validate_role(db, payload["role"])
        if user.get("role") == "admin" and payload["role"] != "admin" and await _active_admin_count(db) <= 1:
            raise AppError("invalid_operation", "Cannot demote the last active administrator", 400)

    for field in ("name", "role", "phone", "team_id", "manager_id", "is_active", "avatar_url"):
        if field in payload and payload[field] != user.get(field):
            updates[field] = payload[field]
            changes[field] = {"from": user.get(field), "to": payload[field]}

    if updates:
        updates["updated_at"] = now_utc()
        updates["updated_by"] = actor["id"]
        await db.users.update_one({"id": user_id}, {"$set": updates})
        if "role" in updates or updates.get("is_active") is False:
            # Role changed -> revoke sessions so cached permission scopes cannot outlive it.
            await db.sessions.update_many({"user_id": user_id}, {"$set": {"revoked": True}})
    fresh = await db.users.find_one({"id": user_id})
    return public(fresh), changes


@transactional
async def set_active(db, actor: dict, user_id: str, is_active: bool) -> dict:
    user = await db.users.find_one({"id": user_id})
    if not user:
        raise AppError("not_found", "User not found", 404)
    await scope_service.assert_can_access_user(db, actor, user)
    if user["id"] == actor["id"] and not is_active:
        raise AppError("invalid_operation", "You cannot deactivate your own account", 400)
    if not is_active and user.get("role") == "admin" and await _active_admin_count(db) <= 1:
        raise AppError("invalid_operation", "Cannot deactivate the last active administrator", 400)
    await db.users.update_one(
        {"id": user_id},
        {"$set": {"is_active": is_active, "updated_at": now_utc(), "updated_by": actor["id"]}},
    )
    if not is_active:
        # Deactivation preserves the record; only revoke live sessions.
        await db.sessions.update_many({"user_id": user_id}, {"$set": {"revoked": True}})
    fresh = await db.users.find_one({"id": user_id})
    return public(fresh)


@transactional
async def set_permission_overrides(db, actor: dict, user_id: str, allow, deny) -> dict:
    if user_id == actor["id"]:
        raise AppError("invalid_operation", "You cannot change your own permissions", 400)
    user = await db.users.find_one({"id": user_id})
    if not user:
        raise AppError("not_found", "User not found", 404)
    await scope_service.assert_can_access_user(db, actor, user)
    if user.get("role") == "admin":
        raise AppError("invalid_operation", "Admin permissions cannot be overridden", 400)
    permission_service.validate_permissions(list(allow) + list(deny))
    if actor.get("role") != "admin":
        own = await permission_service.get_effective_permissions(db, actor)
        grants = (await permission_service.get_role_permissions(db, user["role"]) | set(allow)) - set(deny)
        if not grants <= own:
            raise AppError("forbidden", "Cannot grant permissions above your authority", 403)
    await db.sessions.update_many({"user_id": user_id}, {"$set": {"revoked": True}})
    await db.users.update_one(
        {"id": user_id},
        {
            "$set": {
                "permission_overrides": {"allow": list(set(allow)), "deny": list(set(deny))},
                "updated_at": now_utc(),
                "updated_by": actor["id"],
            }
        },
    )
    fresh = await db.users.find_one({"id": user_id})
    return public(fresh)


async def get_effective(db, actor: dict, user_id: str) -> dict:
    user = await db.users.find_one({"id": user_id})
    if not user:
        raise AppError("not_found", "User not found", 404)
    await scope_service.assert_can_access_user(db, actor, user)
    perms = sorted(await permission_service.get_effective_permissions(db, user))
    role_perms = sorted(await permission_service.get_role_permissions(db, user.get("role", "")))
    return {"user_id": user_id, "role": user.get("role"), "role_permissions": role_perms,
            "overrides": user.get("permission_overrides", {"allow": [], "deny": []}),
            "effective": perms}


async def list_sessions(db, actor: dict, user_id: str) -> list:
    await get_user(db, actor, user_id)
    return await db.sessions.find({"user_id": user_id}, {"_id": 0}).sort("created_at", -1).to_list(100)


async def revoke_all_sessions(db, actor: dict, user_id: str) -> int:
    await get_user(db, actor, user_id)
    res = await db.sessions.update_many({"user_id": user_id, "revoked": False}, {"$set": {"revoked": True}})
    return res.modified_count


async def list_recruiters(db, actor: dict) -> list:
    role = actor.get("role")
    if role == "admin":
        q = {"role": {"$in": ["recruiter", "team_leader"]}}
    else:
        q = {"id": {"$in": await scope_service.team_member_ids(db, actor["id"])}}
    users = await db.users.find(q).sort("name", 1).to_list(1000)
    return [public(u) for u in users]


async def assignable_recruiters(db, actor, perms):
    if actor.get("role") != "admin" and not ({"leads.assign", "leads.transfer", "leads.auto_distribute", "imports.run"} & perms):
        raise AppError("forbidden", "Assignment permission required", 403)
    ids = await scope_service.assignment_scope_ids(db, actor)
    q = {"is_active": True}
    if ids is not None:
        q["id"] = {"$in": ids}
    result = []
    async for u in db.users.find(q).sort("name", 1):
        if u.get("role") != "admin" and scope_service.LEAD_VIEW & await permission_service.get_effective_permissions(db, u):
            result.append({"id": u["id"], "name": u["name"], "team_id": u.get("team_id")})
    return result
