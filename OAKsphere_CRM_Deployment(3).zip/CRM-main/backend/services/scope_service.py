"""Central data-scoping service. Builds Mongo filters and enforces record access
based on role: admin = all, team_leader = own team, recruiter = self/owned only."""
from typing import List
from core.errors import AppError


async def team_member_ids(db, leader_id: str) -> List[str]:
    """Ids of a team leader's members (recruiters reporting to them) + themselves."""
    ids = {leader_id}
    async for u in db.users.find({"manager_id": leader_id}, {"id": 1, "_id": 0}):
        ids.add(u["id"])
    return list(ids)


async def user_scope_filter(db, actor: dict) -> dict:
    """Filter for listing *user* records visible to the actor."""
    role = actor.get("role")
    if role == "admin":
        return {}
    if role == "team_leader":
        return {"id": {"$in": await team_member_ids(db, actor["id"])}}
    return {"id": actor["id"]}


async def assert_can_access_user(db, actor: dict, target: dict) -> None:
    """Record-level guard: prevents URL/ID tampering across recruiters/teams."""
    role = actor.get("role")
    if role == "admin":
        return
    if role == "team_leader":
        if target.get("id") == actor["id"] or target.get("manager_id") == actor["id"]:
            return
        raise AppError("forbidden", "Record is outside your team scope", 403)
    # recruiter
    if target.get("id") == actor["id"]:
        return
    raise AppError("forbidden", "Record is outside your scope", 403)


async def audit_scope_filter(db, actor: dict) -> dict:
    """Filter for audit logs visible to the actor."""
    role = actor.get("role")
    if role == "admin":
        return {}
    if role == "team_leader":
        return {"actor_id": {"$in": await team_member_ids(db, actor["id"])}}
    return {"actor_id": actor["id"]}


# Resource scopes never inherit directory/user-administration permissions.
LEAD_VIEW = {"leads.view_all", "leads.view_own"}


def require_lead_view(actor, perms):
    if actor.get("role") != "admin" and not (LEAD_VIEW & set(perms)):
        raise AppError("forbidden", "Candidate view permission is required", 403)


async def recruiter_scope_ids(db, actor, perms):
    """Candidate scope: admin global, permitted leader team, everyone else self."""
    if actor.get("role") == "admin":
        return None
    if not LEAD_VIEW & set(perms):
        return []
    if actor.get("role") == "team_leader" and "leads.view_all" in perms:
        return await team_member_ids(db, actor["id"])
    return [actor["id"]]


async def resource_scope_ids(db, actor, perms, resource):
    if actor.get("role") == "admin":
        return None
    if f"{resource}.manage" not in perms:
        return []
    if actor.get("role") == "team_leader":
        return await team_member_ids(db, actor["id"])
    return [actor["id"]]


async def assignment_scope_ids(db, actor):
    if actor.get("role") == "admin":
        return None
    if actor.get("role") == "team_leader":
        return await team_member_ids(db, actor["id"])
    return [actor["id"]]


async def leads_filter(db, actor, perms, recruiter_id=None):
    from core.query import active_filter
    ids = await recruiter_scope_ids(db, actor, perms)
    scope = {} if ids is None else {"owner_id": {"$in": ids}}
    if (ids and actor.get("role") == "team_leader" and actor.get("team_id")
            and "leads.view_all" in perms and "leads.assign" in perms):
        scope = {"$or": [scope, {"owner_id": {"$in": [None, ""]}, "team_id": actor["team_id"]}]}
    if recruiter_id:
        scope = {"$and": [scope, {"owner_id": recruiter_id}]}
    return active_filter(scope)


async def assert_lead_access(db, actor, perms, lead):
    require_lead_view(actor, perms)
    if not lead or lead.get("archived"):
        raise AppError("not_found", "Active record not found", 404)
    # Use the identical policy for detached records (applications included).
    ids = await recruiter_scope_ids(db, actor, perms)
    if ids is None or lead.get("owner_id") in ids:
        return
    if (actor.get("role") == "team_leader" and "leads.view_all" in perms
            and "leads.assign" in perms and actor.get("team_id")
            and lead.get("team_id") == actor["team_id"] and not lead.get("owner_id")):
        return
    raise AppError("forbidden", "Record is outside your candidate scope", 403)


async def assert_resource_access(db, actor, perms, resource, owner_id):
    ids = await resource_scope_ids(db, actor, perms, resource)
    if ids is not None and owner_id not in ids:
        raise AppError("forbidden", "Record is outside your resource scope", 403)


async def active_related_filter(db, actor, perms):
    """Scope children by their CURRENT parent owner, including after a transfer."""
    q = await leads_filter(db, actor, perms)
    return {"lead_id": {"$in": await db.leads.distinct("id", q)}}
