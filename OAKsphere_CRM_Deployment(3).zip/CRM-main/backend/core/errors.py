from fastapi import Request
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError
from starlette.exceptions import HTTPException as StarletteHTTPException
import logging

logger = logging.getLogger("app.errors")


class AppError(Exception):
    """Domain error with a stable machine code."""

    def __init__(self, code: str, message: str, status_code: int = 400, details=None):
        self.code = code
        self.message = message
        self.status_code = status_code
        self.details = details
        super().__init__(message)


def _body(code: str, message: str, details=None) -> dict:
    return {"error": {"code": code, "message": message, "details": details}}


def register_exception_handlers(app) -> None:
    @app.exception_handler(AppError)
    async def _app_error(request: Request, exc: AppError):
        return JSONResponse(
            status_code=exc.status_code,
            content=_body(exc.code, exc.message, exc.details),
        )

    @app.exception_handler(StarletteHTTPException)
    async def _http_error(request: Request, exc: StarletteHTTPException):
        code = {
            400: "bad_request",
            401: "unauthenticated",
            403: "forbidden",
            404: "not_found",
            409: "conflict",
            429: "rate_limited",
        }.get(exc.status_code, "http_error")
        detail = exc.detail
        message = detail if isinstance(detail, str) else "Request failed"
        return JSONResponse(status_code=exc.status_code, content=_body(code, message, None if isinstance(detail, str) else detail))

    @app.exception_handler(RequestValidationError)
    async def _validation_error(request: Request, exc: RequestValidationError):
        return JSONResponse(
            status_code=422,
            content=_body("validation_error", "; ".join(".".join(map(str,e["loc"])) + ": " + e["msg"] for e in exc.errors()), [{"loc": e["loc"], "type": e["type"]} for e in exc.errors()]),
        )

    from pymongo.errors import DuplicateKeyError, OperationFailure, PyMongoError

    @app.exception_handler(DuplicateKeyError)
    async def _duplicate(request, exc):
        return JSONResponse(status_code=409, content=_body("conflict", "A conflicting record already exists; refresh and retry"))

    @app.exception_handler(OperationFailure)
    async def _database_error(request, exc):
        if exc.has_error_label("TransientTransactionError") or exc.code == 112:
            return JSONResponse(status_code=409, content=_body("write_conflict", "Concurrent update; nothing was partially saved. Refresh and retry"))
        logger.error("Database operation failed: code=%s", exc.code)
        return JSONResponse(status_code=503, content=_body("database_unavailable", "Database operation failed; retry later"))

    @app.exception_handler(PyMongoError)
    async def _database_connection_error(request, exc):
        logger.error("Database unavailable: %s", type(exc).__name__)
        return JSONResponse(status_code=503, content=_body("database_unavailable", "Database is temporarily unavailable; retry later"))

    @app.exception_handler(Exception)
    async def _unhandled(request: Request, exc: Exception):
        logger.exception("Unhandled error: %s", exc)
        return JSONResponse(status_code=500, content=_body("internal_error", "Internal server error"))
