from motor.motor_asyncio import AsyncIOMotorClient
from core.config import settings

client = AsyncIOMotorClient(settings.mongo_url, serverSelectionTimeoutMS=5000,
                           connectTimeoutMS=5000, socketTimeoutMS=30000)
db = client[settings.db_name]


async def ensure_indexes() -> None:
    # Auth / users
    await db.users.create_index("email", unique=True)
    await db.users.create_index("role")
    await db.users.create_index("manager_id")
    await db.users.create_index("team_id")
    await db.users.create_index("is_active")

    # Sessions (revocable) with TTL cleanup
    await db.sessions.create_index("user_id")
    await db.sessions.create_index("expires_at", expireAfterSeconds=0)

    # Password reset tokens (hashed, one-time, TTL)
    await db.password_reset_tokens.create_index("token_hash", unique=True)
    await db.password_reset_tokens.create_index("expires_at", expireAfterSeconds=0)

    # Login attempts (brute force)
    await db.login_attempts.create_index("identifier", unique=True)

    # Roles
    await db.roles.create_index("key", unique=True)

    # Audit logs (immutable, append-only)
    await db.audit_logs.create_index("created_at")
    await db.audit_logs.create_index("actor_id")
    await db.audit_logs.create_index("action")
    await db.audit_logs.create_index("entity_type")
    await db.audit_logs.create_index([("entity_type", 1), ("entity_id", 1)])

    # Org settings singleton
    await db.organization_settings.create_index("key", unique=True)

    # Recruitment
    await db.leads.create_index("owner_id")
    await db.leads.create_index("status")
    await db.leads.create_index("team_id")
    await db.leads.create_index("phone_normalized")
    await db.leads.create_index("last_call_outcome")
    await db.leads.create_index("created_at")
    await db.leads.create_index([("owner_id", 1), ("status", 1)])
    await db.calls.create_index([("recruiter_id", 1), ("created_at", 1)])
    await db.calls.create_index("lead_id")
    await db.followups.create_index([("recruiter_id", 1), ("status", 1), ("due_at", 1)])
    await db.followups.create_index("lead_id")
    await db.tasks.create_index([("owner_id", 1), ("status", 1)])
    await db.interviews.create_index([("recruiter_id", 1), ("status", 1)])
    await db.interviews.create_index("lead_id")
    await db.joinings.create_index([("recruiter_id", 1), ("status", 1)])
    await db.joinings.create_index("lead_id")
    # Upgrade the old non-unique index without deleting historical documents.
    from models.entities import new_id
    seen = set()
    async for lead in db.leads.find({}, {"id": 1, "lead_code": 1}):
        code = lead.get("lead_code")
        if not code or code in seen:
            replacement = "LD-" + new_id().replace("-", "").upper()
            await db.leads.update_one({"_id": lead["_id"]}, {"$set": {"lead_code": replacement, "previous_lead_code": code}})
            code = replacement
        seen.add(code)
    indexes = await db.leads.index_information()
    if "lead_code_1" in indexes and not indexes["lead_code_1"].get("unique"):
        await db.leads.drop_index("lead_code_1")
    await db.leads.create_index("lead_code", unique=True, sparse=True)
    await db.leads.create_index([("archived", 1), ("owner_id", 1), ("status", 1)])
    await db.import_batches.create_index("expires_at", expireAfterSeconds=0)
    await db.import_batches.create_index([("id", 1), ("actor_id", 1)], unique=True)
    await db.integrations.create_index("key", unique=True)
    await db.webhook_events.create_index("event_key", unique=True)
    await db.applications.create_index("intake_key", unique=True, sparse=True)
    await db.applications.create_index([("owner_id", 1), ("archived", 1), ("applied_at", -1)])
    await db.intake_limits.create_index("key", unique=True)
    await db.intake_limits.create_index("expires_at", expireAfterSeconds=0)
    await db.notifications.create_index([("recipient_id", 1), ("read_at", 1), ("created_at", -1)])
    tag_keys = {}
    async for tag in db.lead_tags.find({"archived": {"$ne": True}}).sort("created_at", 1):
        key = tag["name"].strip().casefold()
        if key in tag_keys:
            # Preserve duplicate catalog history; active canonical entry owns key.
            await db.lead_tags.update_one({"_id": tag["_id"]}, {"$set": {"archived": True, "archive_reason": "duplicate catalog name"}, "$unset": {"normalized_key": ""}})
        else:
            await db.lead_tags.update_one({"_id": tag["_id"]}, {"$set": {"normalized_key": key}})
            tag_keys[key] = tag["name"]
    # Historical casing variants must follow the canonical catalog name, so
    # future rename/delete operations reach every reference. Preserve order and
    # unknown historical tags, while removing duplicates of known tags.
    async for lead in db.leads.find({"tags": {"$exists": True}}, {"tags": 1}):
        previous = lead.get("tags")
        if not isinstance(previous, list):
            continue
        tags = []
        for name in previous:
            value = tag_keys.get(name.strip().casefold(), name) if isinstance(name, str) else name
            if value not in tags:
                tags.append(value)
        if tags != previous:
            await db.leads.update_one({"_id": lead["_id"], "tags": previous}, {"$set": {"tags": tags}})
    await db.lead_tags.create_index("normalized_key", unique=True, sparse=True)
    await db.leads.create_index("next_followup_at")
    await db.leads.create_index("source")
    await db.leads.create_index("tags")
    await db.notes.create_index([("lead_id", 1), ("created_at", -1)])
    await db.notes.create_index("author_id")
    await db.activities.create_index([("lead_id", 1), ("created_at", -1)])


async def close() -> None:
    client.close()
