import hashlib
import hmac
import secrets
from core.config import settings


def new_token():
    nonce = secrets.token_urlsafe(32)
    signature = hmac.new(settings.jwt_secret.encode(), nonce.encode(), hashlib.sha256).hexdigest()
    return nonce + "." + signature


def valid_token(token):
    if not token or not isinstance(token, str) or len(token) > 200 or "." not in token:
        return False
    nonce, signature = token.rsplit(".", 1)
    expected = hmac.new(settings.jwt_secret.encode(), nonce.encode(), hashlib.sha256).hexdigest()
    return hmac.compare_digest(signature, expected)


async def csrf_guard(request, call_next):
    from starlette.responses import JSONResponse
    unsafe = request.method not in {"GET", "HEAD", "OPTIONS"}
    bearer = settings.enable_bearer_auth and request.headers.get("authorization", "").startswith("Bearer ")
    machine = request.url.path.startswith(("/api/webhooks/", "/api/intake/"))
    if unsafe and not bearer and not machine:
        origin = request.headers.get("origin")
        if origin and origin not in settings.cors_origins:
            return JSONResponse({"error": {"code": "csrf", "message": "Untrusted request origin"}}, status_code=403)
        if request.cookies.get("access_token") or request.cookies.get("refresh_token") or origin:
            cookie = request.cookies.get("csrf_token", "")
            header = request.headers.get("x-csrf-token", "")
            if not valid_token(cookie) or not hmac.compare_digest(cookie, header):
                return JSONResponse({"error": {"code": "csrf", "message": "CSRF token missing or invalid"}}, status_code=403)
    return await call_next(request)
