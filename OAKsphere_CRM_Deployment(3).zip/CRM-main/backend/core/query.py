"""Shared literal search and archive filters."""
import re
from core.errors import AppError

ACTIVE = {"archived": {"$ne": True}}

def literal_search(value):
    value = str(value or "").strip()
    if len(value) > 160:
        raise AppError("bad_request", "Search is limited to 160 characters", 422)
    return re.escape(value)

def active_filter(query=None):
    return {"$and": [ACTIVE, query or {}]}
