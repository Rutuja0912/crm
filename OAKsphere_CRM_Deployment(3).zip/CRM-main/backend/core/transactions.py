"""Real Mongo transactions. Standalone deployments fail BEFORE workflow writes."""
from contextlib import asynccontextmanager
from contextvars import ContextVar
from functools import wraps
from core.database import client
from core.errors import AppError
from pymongo.errors import DuplicateKeyError

_current = ContextVar("mongo_workflow_session", default=None)


async def supports_transactions():
    hello = await client.admin.command("hello")
    return bool(hello.get("setName") or hello.get("msg") == "isdbgrid")


@asynccontextmanager
async def atomic():
    existing = _current.get()
    if existing is not None:
        yield existing
        return
    if not await supports_transactions():
        raise AppError("transactions_required", "This workflow requires MongoDB configured as a replica set", 503)
    async with await client.start_session() as session:
        async with session.start_transaction():
            token = _current.set(session)
            try:
                yield session
            finally:
                _current.reset(token)


class _Collection:
    def __init__(self, collection, session):
        self.collection, self.session = collection, session

    def __getattr__(self, name):
        attr = getattr(self.collection, name)
        if name in {"find", "find_one", "aggregate", "distinct", "count_documents",
                    "insert_one", "insert_many", "update_one", "update_many",
                    "replace_one", "delete_one", "delete_many", "find_one_and_update"}:
            def call(*args, **kwargs):
                kwargs["session"] = self.session
                return attr(*args, **kwargs)
            return call
        return attr


class _Database:
    def __init__(self, db, session):
        self.db, self.session = db, session

    def __getattr__(self, name):
        return self[name]

    def __getitem__(self, name):
        return _Collection(self.db[name], self.session)


def bind_database(db):
    return db if isinstance(db, _Database) else _Database(db, _current.get())


def transactional_request(fn):
    """Enclose a route's business writes and audit in the same transaction.

    Routes bind their local database with bind_database(); nested services reuse
    the active session. A generated-code conflict restarts the entire request.
    """
    @wraps(fn)
    async def run(*args, **kwargs):
        for attempt in range(3):
            try:
                async with atomic():
                    return await fn(*args, **kwargs)
            except DuplicateKeyError as exc:
                if (exc.details or {}).get("keyPattern") != {"lead_code": 1} or attempt == 2:
                    raise
    return run


def transactional(fn):
    """Bind every read/write, including nested service calls, to one transaction."""
    @wraps(fn)
    async def run(db, *args, **kwargs):
        # A duplicate key aborts Mongo's transaction. Retry the entire workflow
        # only at its outer boundary, and only for a generated lead-code collision.
        attempts = 1 if _current.get() is not None else 3
        for attempt in range(attempts):
            try:
                async with atomic() as session:
                    return await fn(db if isinstance(db, _Database) else _Database(db, session), *args, **kwargs)
            except DuplicateKeyError as exc:
                if (exc.details or {}).get("keyPattern") != {"lead_code": 1} or attempt + 1 == attempts:
                    raise
    return run
