"""Organization calendar boundaries; all persisted instants use UTC."""
from datetime import datetime, timezone, timedelta, time
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
from core.errors import AppError


def zone(tz_name):
    try:
        return ZoneInfo(tz_name or "UTC")
    except (ZoneInfoNotFoundError, ValueError, TypeError):
        raise AppError("invalid_timezone", "Use a valid IANA timezone", 422)


def day_bounds(tz_name="UTC", ref=None, offset=0):
    tz = zone(tz_name)
    local = (ref or datetime.now(timezone.utc)).astimezone(tz)
    start = datetime.combine(local.date() + timedelta(days=offset), time.min, tz)
    end = datetime.combine(start.date() + timedelta(days=1), time.min, tz)
    return start.astimezone(timezone.utc), end.astimezone(timezone.utc)


async def org_calendar(db):
    org = await db.organization_settings.find_one({"key": "org"}) or {}
    return {"timezone": org.get("timezone", "Asia/Kolkata"),
            "working_days": org.get("working_days", [0, 1, 2, 3, 4]),
            "work_start": org.get("work_start", "10:00"),
            "holidays": org.get("holidays", [])}


async def org_day_bounds(db, ref=None, offset=0):
    return day_bounds((await org_calendar(db))["timezone"], ref, offset)


async def org_period_bounds(db, period, ref=None):
    tz = zone((await org_calendar(db))["timezone"])
    local = (ref or datetime.now(timezone.utc)).astimezone(tz)
    if period == "week":
        start = local.replace(hour=0, minute=0, second=0, microsecond=0) - timedelta(days=local.weekday())
        end = start + timedelta(days=7)
    else:
        start = local.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        end = (start.replace(day=28) + timedelta(days=4)).replace(day=1)
    return start.astimezone(timezone.utc), end.astimezone(timezone.utc)


async def next_working_day(db, ref=None):
    cfg = await org_calendar(db)
    tz = zone(cfg["timezone"])
    local = (ref or datetime.now(timezone.utc)).astimezone(tz)
    hour, minute = map(int, cfg["work_start"].split(":"))
    for i in range(1, 367):
        d = local.date() + timedelta(days=i)
        if d.weekday() in cfg["working_days"] and d.isoformat() not in cfg["holidays"]:
            return datetime.combine(d, time(hour, minute), tz).astimezone(timezone.utc)
    raise AppError("invalid_calendar", "No working day found in the next year", 422)


def parse_range(tz_name, date_from, date_to):
    if not date_from and not date_to:
        return day_bounds(tz_name)
    tz = zone(tz_name)
    def parse(value, end=False):
        dt = datetime.fromisoformat(value)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=tz)
        if end and len(value) == 10:
            dt += timedelta(days=1)
        return dt.astimezone(timezone.utc)
    try:
        start = parse(date_from) if date_from else datetime(1970,1,1,tzinfo=timezone.utc)
        end = parse(date_to, True) if date_to else datetime.now(timezone.utc)+timedelta(days=1)
        if end <= start:
            raise ValueError()
        return start, end
    except ValueError:
        raise AppError("invalid_dates", "Enter a valid, ordered date range", 422)
