import os
from pathlib import Path
from dotenv import load_dotenv
from urllib.parse import urlsplit
from ipaddress import ip_network

ROOT_DIR = Path(__file__).resolve().parent.parent
load_dotenv(ROOT_DIR / ".env")


class Settings:
    """Central config. All values sourced from environment only."""

    def __init__(self) -> None:
        self.mongo_url: str = os.environ["MONGO_URL"]
        self.db_name: str = os.environ["DB_NAME"]
        self.jwt_secret: str = os.environ["JWT_SECRET"]
        self.admin_email: str = os.environ["ADMIN_EMAIL"].lower().strip()
        self.admin_password: str = os.environ["ADMIN_PASSWORD"]
        self.cors_origins = [
            o.strip().rstrip("/") for o in os.environ.get("CORS_ORIGINS", "http://localhost:3000").split(",") if o.strip()
        ]
        # Seed demo (non-admin) accounts flag
        self.seed_demo: bool = os.environ.get("SEED_DEMO", "false").lower() == "true"

        self.production = os.environ.get("APP_ENV", "development") == "production"
        self.cookie_secure = self.production or os.environ.get("COOKIE_SECURE", "false") == "true"
        self.cookie_samesite = os.environ.get("COOKIE_SAMESITE", "lax")
        self.enable_bearer_auth = os.environ.get("ENABLE_BEARER_AUTH", "false") == "true"
        self.trusted_proxies = [x.strip() for x in os.environ.get("TRUSTED_PROXY_CIDRS", "").split(",") if x.strip()]
        self.meta_api_version = os.environ.get("META_API_VERSION", "v23.0")
        if "*" in self.cors_origins:
            raise ValueError("CORS_ORIGINS must contain explicit origins when credentials are enabled")
        if self.cookie_samesite not in {"lax", "strict", "none"} or (self.cookie_samesite == "none" and not self.cookie_secure):
            raise ValueError("Invalid cookie configuration; SameSite=None requires Secure")
        if self.production and (len(self.jwt_secret) < 32 or self.seed_demo or not self.cors_origins or not all(x.startswith("https://") for x in self.cors_origins)):
            raise ValueError("Production requires a strong JWT secret, HTTPS origins and SEED_DEMO=false")
        for proxy in self.trusted_proxies:
            ip_network(proxy, strict=False)
        if self.production:
            if any(x in self.jwt_secret.lower() or x in self.admin_password.lower()
                   for x in ("replace-", "change-me", "changeme", "example-secret")):
                raise ValueError("Replace example credentials before starting production")
            if len(self.admin_password) < 12:
                raise ValueError("Production bootstrap admin password must be at least 12 characters")
            for origin in self.cors_origins:
                parsed = urlsplit(origin)
                if (not parsed.hostname or parsed.path or parsed.query or parsed.fragment
                        or parsed.username or parsed.password):
                    raise ValueError("CORS_ORIGINS must contain origins only, without paths or credentials")
        self.jwt_algorithm = "HS256"
        self.access_token_ttl_minutes = 60 * 8  # 8h working session
        self.refresh_token_ttl_days = 7
        self.max_failed_logins = 10
        self.lockout_minutes = 15

        # Public frontend origin for building reset links (email).
        self.frontend_url = (
            os.environ.get("FRONTEND_URL")
            or next((o for o in self.cors_origins if o and o != "*"), "")
        ).rstrip("/")
        if self.production and self.frontend_url not in self.cors_origins:
            raise ValueError("Production FRONTEND_URL must match an allowed HTTPS origin")

        # Email provider (Emergent-managed Resend). Enabled only when key present.
        self.email_key = os.environ.get("EMERGENT_EMAIL_KEY")
        self.email_from_name = os.environ.get("EMAIL_FROM_NAME", "OAKsphere Recruitment CRM")
        self.email_reply_to = os.environ.get("EMAIL_REPLY_TO")
        self.email_enabled = bool(self.email_key)

        # Google OIDC (optional). Enabled only when a client id is configured.
        self.google_client_id = os.environ.get("GOOGLE_CLIENT_ID", "").strip()
        self.google_enabled = bool(self.google_client_id)


settings = Settings()
