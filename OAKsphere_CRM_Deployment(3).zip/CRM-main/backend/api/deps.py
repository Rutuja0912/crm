from fastapi import Request, Depends
from core.security import decode_token
from core.errors import AppError
from core.database import db
from services import auth_service, permission_service
import jwt
import ipaddress
from core.config import settings


def get_client_ip(request: Request) -> str:
    peer = request.client.host if request.client else "unknown"
    def trusted(ip):
        try:
            return any(ipaddress.ip_address(ip) in ipaddress.ip_network(net) for net in settings.trusted_proxies)
        except ValueError:
            return False
    if not trusted(peer):
        return peer
    chain = [x.strip() for x in request.headers.get("x-forwarded-for", "").split(",") if x.strip()]
    for ip in reversed(chain):
        try:
            ipaddress.ip_address(ip)
        except ValueError:
            return peer
        if not trusted(ip):
            return ip
    return chain[0] if chain else peer


def _extract_token(request: Request) -> str | None:
    auth = request.headers.get("Authorization", "")
    if settings.enable_bearer_auth and auth.startswith("Bearer "):
        return auth[7:]
    return request.cookies.get("access_token")


async def get_current_user(request: Request) -> dict:
    token = _extract_token(request)
    if not token:
        raise AppError("unauthenticated", "Not authenticated", 401)
    try:
        payload = decode_token(token)
    except jwt.ExpiredSignatureError:
        raise AppError("token_expired", "Session expired", 401)
    except jwt.InvalidTokenError:
        raise AppError("invalid_token", "Invalid token", 401)

    if payload.get("type") != "access":
        raise AppError("invalid_token", "Invalid token type", 401)

    session_id = payload.get("sid")
    if not session_id or not await auth_service.session_is_valid(db, session_id):
        raise AppError("session_revoked", "Session is no longer valid", 401)

    user = await db.users.find_one({"id": payload.get("sub")})
    if not user:
        raise AppError("unauthenticated", "User not found", 401)
    if not user.get("is_active", True):
        raise AppError("account_disabled", "Account is deactivated", 403)

    user.pop("password_hash", None)
    user["session_id"] = session_id
    return user


def require_permission(permission: str):
    async def _dep(user: dict = Depends(get_current_user)) -> dict:
        await permission_service.require_permission_or_raise(db, user, permission)
        return user

    return _dep


async def require_admin(user: dict = Depends(get_current_user)):
    if user.get("role") != "admin":
        raise AppError("forbidden", "Only administrators can manage roles", 403)
    return user
