from core import transactions
from fastapi import APIRouter, Depends, Request
from core.database import db
from core.logging_config import correlation_id_ctx
from models.entities import OrgSettingsUpdate, now_utc
from services import audit_service
from api.deps import require_permission, get_client_ip

router = APIRouter(prefix="/settings", tags=["settings"])

@router.get("")
async def get_settings(user: dict = Depends(require_permission("settings.manage"))):
    from services.modules_service import get_org_settings
    return await get_org_settings(db)


@router.put("")
@transactions.transactional_request
async def update_settings(payload: dict, request: Request, user=Depends(require_permission("settings.manage"))):
    request_db = transactions.bind_database(db)
    from services.modules_service import update_org_settings
    result = await update_org_settings(request_db, user, payload)
    await audit_service.record(request_db, actor=user, action="settings.update", entity_type="organization_settings",
                               entity_id="org", details={"fields": list(payload)}, ip=get_client_ip(request))
    return result
