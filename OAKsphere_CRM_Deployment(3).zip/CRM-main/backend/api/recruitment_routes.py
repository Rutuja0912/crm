from core import transactions
from fastapi import APIRouter, Depends, Request, Query
from fastapi.responses import Response
import csv
import io
from core.database import db
from models.entities import now_utc
from core.logging_config import correlation_id_ctx
from models.recruitment import (
    LeadCreate, LeadUpdate, StatusChange, CallCreate, DispositionCreate, FollowupCreate,
    FollowupUpdate, FollowupComplete, TagsUpdate, NoteCreate, NoteUpdate, AssignRequest,
    TransferRequest, AutoDistributeRequest, TaskCreate, TaskUpdate, InterviewCreate,
    InterviewUpdate, JoiningCreate, JoiningUpdate,
)
from services import recruitment_service as rs, audit_service, permission_service
from api.deps import get_current_user, require_permission, get_client_ip

router = APIRouter(tags=["recruitment"])


@router.get("/recruiters")
async def list_recruiters(user: dict = Depends(require_permission("recruiters.view"))):
    from services import user_service
    return await user_service.list_recruiters(db, user)


async def _perms(user):
    return await permission_service.get_effective_permissions(db, user)


async def _audit(database, user, request, action, entity_type, entity_id, details=None, severity="info"):
    await audit_service.record(database, actor=user, action=action, entity_type=entity_type,
                               entity_id=entity_id, details=details or {}, severity=severity,
                               ip=get_client_ip(request) if request else None,
                               correlation_id=correlation_id_ctx.get())


def _require(perms, user, perm):
    if perm not in perms and user.get("role") != "admin":
        from core.errors import AppError
        raise AppError("forbidden", f"Missing permission: {perm}", 403)


@router.get("/recruiters/assignable")
async def assignable_recruiters(user=Depends(get_current_user)):
    from services.user_service import assignable_recruiters
    return await assignable_recruiters(db, user, await _perms(user))


@router.get("/scheduling/next-working-day")
async def scheduling(user=Depends(get_current_user)):
    from core.timeutil import next_working_day, org_calendar, org_day_bounds
    start, end = await org_day_bounds(db, offset=1)
    return {**await org_calendar(db), "suggested_at": await next_working_day(db),
            "tomorrow_start": start, "tomorrow_end": end}


# ---------------- Leads: static routes FIRST ----------------
@router.get("/leads")
async def list_leads(
    status: str = Query(""), search: str = Query(""), outcome: str = Query(""),
    priority: str = Query(""), source: str = Query(""), tag: str = Query(""),
    view: str = Query(""), recruiter_id: str = Query(""),
    sort_by: str = Query("last_activity_at"), sort_dir: str = Query("desc"),
    page: int = Query(1, ge=1), page_size: int = Query(50, ge=1, le=200),
    user: dict = Depends(get_current_user),
):
    perms = await _perms(user)
    if not ({"leads.view_all", "leads.view_own"} & perms) and user.get("role") != "admin":
        from core.errors import AppError
        raise AppError("forbidden", "Missing permission: leads.view_own", 403)
    return await rs.list_leads(db, user, perms, status=status, search=search, outcome=outcome,
                               priority=priority, source=source, tag=tag, view=view,
                               recruiter_id=recruiter_id, sort_by=sort_by, sort_dir=sort_dir,
                               page=page, page_size=page_size)


@router.get("/leads/export")
async def export_leads(
    status: str = Query(""), search: str = Query(""), outcome: str = Query(""),
    priority: str = Query(""), source: str = Query(""), tag: str = Query(""),
    view: str = Query(""), recruiter_id: str = Query(""),
    user: dict = Depends(require_permission("leads.export")),
):
    perms = await _perms(user)
    rows = await rs.export_leads(db, user, perms, status=status, search=search, outcome=outcome,
                                 priority=priority, source=source, tag=tag, view=view,
                                 recruiter_id=recruiter_id)
    cols = ["lead_code", "name", "phone", "alt_phone", "email", "city", "status", "priority",
            "source", "role_applied", "client", "job", "call_count", "last_call_outcome",
            "next_followup_at", "created_at"]
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(cols)
    for r in rows:
        w.writerow([r.get(c, "") for c in cols])
    await _audit(db, user, None, "leads.export", "lead", None, {"count": len(rows)})
    return Response(content=buf.getvalue(), media_type="text/csv",
                    headers={"Content-Disposition": "attachment; filename=leads_export.csv"})


@router.post("/leads/check-duplicate")
@transactions.transactional_request
async def check_duplicate(payload: dict, user: dict = Depends(get_current_user)):
    request_db = transactions.bind_database(db)
    perms = await _perms(user)
    return await rs.check_duplicate(request_db, user, perms, payload.get("phone", ""))


@router.post("/leads/assign")
@transactions.transactional_request
async def assign_leads(payload: AssignRequest, request: Request,
                       user: dict = Depends(require_permission("leads.assign"))):
    request_db = transactions.bind_database(db)
    perms = await _perms(user)
    result = await rs.assign_leads(request_db, user, perms, payload.lead_ids, payload.to_owner_id)
    await _audit(request_db, user, request, "leads.assign", "lead", None, result, severity="warning")
    return result


@router.post("/leads/transfer")
@transactions.transactional_request
async def transfer(payload: TransferRequest, request: Request,
                   user: dict = Depends(require_permission("leads.transfer"))):
    request_db = transactions.bind_database(db)
    perms = await _perms(user)
    result = await rs.transfer_leads(request_db, user, perms, payload.lead_ids, payload.to_owner_id)
    await _audit(request_db, user, request, "leads.transfer", "lead", None, result, severity="warning")
    return result


@router.post("/leads/auto-distribute")
@transactions.transactional_request
async def auto_distribute(payload: AutoDistributeRequest, request: Request,
                          user: dict = Depends(require_permission("leads.auto_distribute"))):
    request_db = transactions.bind_database(db)
    perms = await _perms(user)
    result = await rs.auto_distribute(request_db, user, perms, payload.lead_ids, payload.recruiter_ids, payload.confirm_redistribution, payload.preview)
    await _audit(request_db, user, request, "leads.auto_distribute", "lead", None, result, severity="warning")
    return result


@router.post("/leads")
@transactions.transactional_request
async def create_lead(payload: LeadCreate, request: Request,
                      user: dict = Depends(require_permission("leads.create"))):
    request_db = transactions.bind_database(db)
    perms = await _perms(user)
    lead = await rs.create_lead(request_db, user, perms, payload)
    await _audit(request_db, user, request, "leads.create", "lead", lead["id"],
                 {"name": lead["name"], "owner_id": lead["owner_id"], "code": lead.get("lead_code")})
    return lead


# ---------------- Leads: dynamic routes ----------------
@router.get("/leads/{lead_id}")
async def get_lead(lead_id: str, user: dict = Depends(get_current_user)):
    perms = await _perms(user)
    return await rs.get_lead(db, user, perms, lead_id)


@router.patch("/leads/{lead_id}")
@transactions.transactional_request
async def update_lead(lead_id: str, payload: LeadUpdate, request: Request,
                      user: dict = Depends(require_permission("leads.edit"))):
    request_db = transactions.bind_database(db)
    perms = await _perms(user)
    lead, changes = await rs.update_lead(request_db, user, perms, lead_id, payload)
    await _audit(request_db, user, request, "leads.update", "lead", lead_id, {"changes": changes})
    return lead


@router.delete("/leads/{lead_id}")
@transactions.transactional_request
async def delete_lead(lead_id: str, request: Request,
                      user: dict = Depends(require_permission("leads.delete"))):
    request_db = transactions.bind_database(db)
    perms = await _perms(user)
    lead = await rs.archive_lead(request_db, user, perms, lead_id)
    await _audit(request_db, user, request, "leads.delete", "lead", lead_id, {"name": lead["name"]}, severity="warning")
    return {"archived": True}


@router.post("/leads/{lead_id}/status")
@transactions.transactional_request
async def change_status(lead_id: str, payload: StatusChange, request: Request,
                        user: dict = Depends(require_permission("leads.edit"))):
    request_db = transactions.bind_database(db)
    perms = await _perms(user)
    lead, prev = await rs.transition_status(request_db, user, perms, lead_id, payload.status, payload.note,
                                            closure_reason=payload.closure_reason,
                                            expected_joining_date=payload.expected_joining_date)
    await _audit(request_db, user, request, "leads.status", "lead", lead_id, {"from": prev, "to": payload.status})
    return lead


@router.post("/leads/{lead_id}/calls")
@transactions.transactional_request
async def log_call(lead_id: str, payload: CallCreate, request: Request,
                   user: dict = Depends(require_permission("calls.log"))):
    request_db = transactions.bind_database(db)
    perms = await _perms(user)
    call = await rs.log_call(request_db, user, perms, lead_id, payload)
    await _audit(request_db, user, request, "calls.log", "lead", lead_id, {"outcome": payload.outcome})
    return call


@router.post("/leads/{lead_id}/disposition")
@transactions.transactional_request
async def disposition(lead_id: str, payload: DispositionCreate, request: Request,
                      user: dict = Depends(require_permission("calls.log"))):
    request_db = transactions.bind_database(db)
    perms = await _perms(user)
    lead = await rs.dispose(request_db, user, perms, lead_id, payload)
    await _audit(request_db, user, request, "calls.disposition", "lead", lead_id,
                 {"outcome": payload.outcome, "status": lead["status"]})
    return lead


@router.post("/leads/{lead_id}/whatsapp")
@transactions.transactional_request
async def log_whatsapp(lead_id: str, user: dict = Depends(get_current_user)):
    request_db = transactions.bind_database(db)
    perms = await _perms(user)
    return await rs.log_whatsapp(request_db, user, perms, lead_id)


@router.put("/leads/{lead_id}/tags")
@transactions.transactional_request
async def set_tags(lead_id: str, payload: TagsUpdate, request: Request,
                   user: dict = Depends(require_permission("leads.edit"))):
    request_db = transactions.bind_database(db)
    perms = await _perms(user)
    lead = await rs.set_tags(request_db, user, perms, lead_id, payload.tags)
    await _audit(request_db, user, request, "leads.tags", "lead", lead_id, {"tags": lead["tags"]})
    return lead


# ---- Notes ----
@router.get("/leads/{lead_id}/notes")
async def list_notes(lead_id: str, user: dict = Depends(get_current_user)):
    perms = await _perms(user)
    return await rs.list_notes(db, user, perms, lead_id)


@router.post("/leads/{lead_id}/notes")
@transactions.transactional_request
async def add_note(lead_id: str, payload: NoteCreate, request: Request,
                   user: dict = Depends(require_permission("leads.edit"))):
    request_db = transactions.bind_database(db)
    perms = await _perms(user)
    note = await rs.add_note(request_db, user, perms, lead_id, payload.body)
    await _audit(request_db, user, request, "leads.note_add", "lead", lead_id, {"note_id": note["id"]})
    return note


@router.put("/notes/{note_id}")
@transactions.transactional_request
async def update_note(note_id: str, payload: NoteUpdate, request: Request,
                      user: dict = Depends(require_permission("leads.edit"))):
    request_db = transactions.bind_database(db)
    perms = await _perms(user)
    note = await rs.update_note(request_db, user, perms, note_id, payload.body)
    await _audit(request_db, user, request, "leads.note_edit", "note", note_id, {})
    return note


@router.delete("/notes/{note_id}")
@transactions.transactional_request
async def delete_note(note_id: str, request: Request,
                      user: dict = Depends(require_permission("leads.edit"))):
    request_db = transactions.bind_database(db)
    perms = await _perms(user)
    res = await rs.delete_note(request_db, user, perms, note_id)
    await _audit(request_db, user, request, "leads.note_delete", "note", note_id, {}, severity="warning")
    return res


# ---- Activity & follow-up history ----
@router.get("/leads/{lead_id}/activities")
async def list_activities(lead_id: str, user: dict = Depends(get_current_user)):
    perms = await _perms(user)
    return await rs.list_activities(db, user, perms, lead_id)


@router.get("/leads/{lead_id}/followups")
async def lead_followups(lead_id: str, user: dict = Depends(get_current_user)):
    perms = await _perms(user)
    return await rs.list_lead_followups(db, user, perms, lead_id)


# ---------------- Follow-ups ----------------
@router.get("/followups")
async def list_followups(scope: str = Query("all"), user: dict = Depends(require_permission("followups.manage"))):
    perms = await _perms(user)
    return await rs.list_followups(db, user, perms, scope=scope)


@router.get("/followups/board")
async def followup_board(tab: str = Query("due_today"), search: str = Query(""),
                         recruiter_id: str = Query(""),
                         user: dict = Depends(require_permission("followups.manage"))):
    perms = await _perms(user)
    return await rs.followup_board(db, user, perms, tab=tab, search=search, recruiter_id=recruiter_id)


@router.post("/followups/{followup_id}/complete")
@transactions.transactional_request
async def complete_followup(followup_id: str, payload: FollowupComplete, request: Request,
                            user: dict = Depends(require_permission("followups.manage"))):
    request_db = transactions.bind_database(db)
    perms = await _perms(user)
    fu = await rs.complete_followup(request_db, user, perms, followup_id, payload)
    await _audit(request_db, user, request, "followups.complete", "followup", followup_id,
                 {"mode": payload.mode, "outcome": payload.outcome})
    return fu


@router.delete("/followups/{followup_id}")
@transactions.transactional_request
async def delete_followup(followup_id: str, request: Request,
                          user: dict = Depends(require_permission("followups.manage"))):
    request_db = transactions.bind_database(db)
    perms = await _perms(user)
    res = await rs.delete_followup(request_db, user, perms, followup_id)
    await _audit(request_db, user, request, "followups.delete", "followup", followup_id, {}, severity="warning")
    return res


@router.post("/leads/{lead_id}/followups")
@transactions.transactional_request
async def add_followup(lead_id: str, payload: FollowupCreate, request: Request,
                       user: dict = Depends(require_permission("followups.manage"))):
    request_db = transactions.bind_database(db)
    perms = await _perms(user)
    fu = await rs.add_followup(request_db, user, perms, lead_id, payload)
    await _audit(request_db, user, request, "followups.create", "lead", lead_id, {"due_at": str(payload.due_at)})
    return fu


@router.put("/followups/{followup_id}")
@transactions.transactional_request
async def update_followup(followup_id: str, payload: FollowupUpdate, request: Request,
                          user: dict = Depends(require_permission("followups.manage"))):
    request_db = transactions.bind_database(db)
    perms = await _perms(user)
    fu = await rs.update_followup(request_db, user, perms, followup_id, payload)
    await _audit(request_db, user, request, "followups.update", "followup", followup_id, {"status": fu.get("status")})
    return fu


# ---------------- Tasks ----------------
@router.get("/tasks")
async def list_tasks(status: str = Query(""), priority: str = Query(""), search: str = Query(""),
                     user: dict = Depends(require_permission("tasks.manage"))):
    perms = await _perms(user)
    return await rs.list_tasks(db, user, perms, status=status, priority=priority, search=search)


@router.get("/tasks/summary")
async def task_summary(user: dict = Depends(require_permission("tasks.manage"))):
    perms = await _perms(user)
    return await rs.task_summary(db, user, perms)


@router.post("/tasks")
@transactions.transactional_request
async def create_task(payload: TaskCreate, request: Request,
                      user: dict = Depends(require_permission("tasks.manage"))):
    request_db = transactions.bind_database(db)
    perms = await _perms(user)
    task = await rs.create_task(request_db, user, perms, payload)
    await _audit(request_db, user, request, "tasks.create", "task", task["id"], {"title": task["title"]})
    return task


@router.put("/tasks/{task_id}")
@transactions.transactional_request
async def update_task(task_id: str, payload: TaskUpdate, request: Request,
                      user: dict = Depends(require_permission("tasks.manage"))):
    request_db = transactions.bind_database(db)
    perms = await _perms(user)
    task = await rs.update_task(request_db, user, perms, task_id, payload)
    await _audit(request_db, user, request, "tasks.update", "task", task_id, {"status": task.get("status")})
    return task


@router.delete("/tasks/{task_id}")
@transactions.transactional_request
async def delete_task(task_id: str, request: Request,
                      user: dict = Depends(require_permission("tasks.manage"))):
    request_db = transactions.bind_database(db)
    perms = await _perms(user)
    res = await rs.delete_task(request_db, user, perms, task_id)
    await _audit(request_db, user, request, "tasks.delete", "task", task_id, {}, severity="warning")
    return res


# ---------------- Interviews ----------------
@router.get("/interviews")
async def list_interviews(user: dict = Depends(require_permission("interviews.manage"))):
    perms = await _perms(user)
    return await rs.list_interviews(db, user, perms)


@router.post("/leads/{lead_id}/interviews")
@transactions.transactional_request
async def create_interview(lead_id: str, payload: InterviewCreate, request: Request,
                           user: dict = Depends(require_permission("interviews.manage"))):
    request_db = transactions.bind_database(db)
    perms = await _perms(user)
    iv = await rs.create_interview(request_db, user, perms, lead_id, payload)
    await _audit(request_db, user, request, "interviews.create", "lead", lead_id, {"scheduled_at": str(payload.scheduled_at)})
    return iv


@router.put("/interviews/{interview_id}")
@transactions.transactional_request
async def update_interview(interview_id: str, payload: InterviewUpdate, request: Request,
                           user: dict = Depends(require_permission("interviews.manage"))):
    request_db = transactions.bind_database(db)
    perms = await _perms(user)
    iv = await rs.update_interview(request_db, user, perms, interview_id, payload)
    await _audit(request_db, user, request, "interviews.update", "interview", interview_id, {"status": iv.get("status")})
    return iv


# ---------------- Joinings ----------------
@router.get("/joinings")
async def list_joinings(user: dict = Depends(require_permission("joinings.manage"))):
    perms = await _perms(user)
    return await rs.list_joinings(db, user, perms)


@router.post("/leads/{lead_id}/joinings")
@transactions.transactional_request
async def create_joining(lead_id: str, payload: JoiningCreate, request: Request,
                         user: dict = Depends(require_permission("joinings.manage"))):
    request_db = transactions.bind_database(db)
    perms = await _perms(user)
    jn = await rs.create_joining(request_db, user, perms, lead_id, payload)
    await _audit(request_db, user, request, "joinings.create", "lead", lead_id, {})
    return jn


@router.put("/joinings/{joining_id}")
@transactions.transactional_request
async def update_joining(joining_id: str, payload: JoiningUpdate, request: Request,
                         user: dict = Depends(require_permission("joinings.manage"))):
    request_db = transactions.bind_database(db)
    perms = await _perms(user)
    jn = await rs.update_joining(request_db, user, perms, joining_id, payload)
    await _audit(request_db, user, request, "joinings.update", "joining", joining_id, {"status": jn.get("status")})
    return jn
