"""Real Meta verification/signature routes and secret-authenticated forms intake."""
import hashlib
import hmac
import json
import re
from datetime import timedelta
from fastapi import APIRouter, Request, Depends
from fastapi.responses import PlainTextResponse
from pydantic import ValidationError
from pymongo.errors import DuplicateKeyError
from core.database import db
from core.errors import AppError
from models.entities import now_utc
from models.recruitment import ApplicationIntake
from services import modules_service as ms, intake_service, permission_service, recruitment_service as rs
from api.deps import get_client_ip, require_permission

router = APIRouter(tags=["intake"])
PROVIDERS = {"whatsapp", "instagram", "facebook", "google_forms"}


async def body_bytes(request):
    result = bytearray()
    async for chunk in request.stream():
        result.extend(chunk)
        if len(result) > 262144:
            raise AppError("too_large", "Webhook body exceeds 256KB", 413)
    return bytes(result)


def decode(raw):
    try:
        value = json.loads(raw)
        if not isinstance(value, dict):
            raise ValueError()
        return value
    except (ValueError, UnicodeDecodeError):
        raise AppError("invalid_payload", "Expected a JSON object", 422)


def candidate(value):
    try:
        return ApplicationIntake.model_validate(value)
    except ValidationError as exc:
        fields = ", ".join(".".join(map(str, e["loc"])) for e in exc.errors())
        raise AppError("invalid_candidate", "Invalid candidate fields: " + fields, 422)


async def rate_limit(provider, request):
    now = now_utc()
    minute = now.replace(second=0, microsecond=0)
    key = hashlib.sha256((provider + ":" + get_client_ip(request) + ":" + minute.isoformat()).encode()).hexdigest()
    from pymongo import ReturnDocument
    doc = await db.intake_limits.find_one_and_update({"key": key},
        {"$inc": {"count": 1}, "$setOnInsert": {"expires_at": now + timedelta(minutes=2)}},
        upsert=True, return_document=ReturnDocument.AFTER)
    if doc["count"] > 120:
        raise AppError("rate_limited", "Too many intake requests; retry later", 429)


@router.get("/webhooks/{provider}")
async def verify(provider: str, request: Request):
    if provider not in PROVIDERS - {"google_forms"}:
        raise AppError("not_found", "Provider verification route not found", 404)
    creds = await ms.integration_secrets(db, provider)
    params = request.query_params
    token = params.get("hub.verify_token", "")
    if params.get("hub.mode") != "subscribe" or not creds.get("webhook_verify_token") or not hmac.compare_digest(token, creds["webhook_verify_token"]):
        raise AppError("forbidden", "Webhook verification failed", 403)
    challenge = params.get("hub.challenge", "")
    if not re.fullmatch(r"[0-9]{1,200}", challenge):
        raise AppError("invalid_challenge", "Invalid challenge", 422)
    return PlainTextResponse(challenge)


async def ingest_once(data, provider, event_id, **kwargs):
    try:
        return await intake_service.ingest(db, data, provider, event_id, **kwargs)
    except DuplicateKeyError:
        # Concurrent deliveries race on a unique fingerprint/event key. Retry the
        # whole transaction, then read its committed result; no partial record.
        return await intake_service.ingest(db, data, provider, event_id, **kwargs)


async def forms(request, source=None):
    creds = await ms.integration_secrets(db, "google_forms")
    provided = request.headers.get("x-intake-secret", "")
    if not provided or not creds.get("shared_secret") or not hmac.compare_digest(provided, creds["shared_secret"]):
        raise AppError("forbidden", "Invalid intake credential", 403)
    await rate_limit("google_forms", request)
    data = candidate(decode(await body_bytes(request)))
    if source:
        data.source = source
    # Supplying an event ID is recommended. A normalized content hash is an
    # idempotent fallback for integrations without event identifiers.
    event_id = data.provider_lead_id or hashlib.sha256(data.model_dump_json().encode()).hexdigest()
    return await ingest_once(data, "google_forms", event_id)


@router.post("/intake/applications")
async def applications_intake(request: Request):
    return await forms(request)


@router.post("/applications")
async def internal_application(payload: ApplicationIntake, request: Request, user=Depends(require_permission("leads.create"))):
    perms = await permission_service.get_effective_permissions(db, user)
    owner = await rs._resolve_owner(db, user, perms, user["id"])
    event_id = payload.provider_lead_id or hashlib.sha256(payload.model_dump_json().encode()).hexdigest()
    return await ingest_once(payload, "internal:" + user["id"], event_id, actor=user, owner_id=owner, team_id=user.get("team_id"))


@router.post("/webhooks/{provider}")
async def webhook(provider: str, request: Request):
    if provider not in PROVIDERS:
        raise AppError("not_found", "Provider not found", 404)
    if provider == "google_forms":
        return await forms(request, "google_form")
    creds = await ms.integration_secrets(db, provider)
    raw = await body_bytes(request)
    signature = request.headers.get("x-hub-signature-256", "")
    expected = "sha256=" + hmac.new(creds.get("app_secret", "").encode(), raw, hashlib.sha256).hexdigest()
    if not creds.get("app_secret") or not hmac.compare_digest(signature, expected):
        raise AppError("forbidden", "Invalid webhook signature", 403)
    await rate_limit(provider, request)
    payload = decode(raw)
    entries = payload.get("entry", [])
    if not isinstance(entries, list) or len(entries) > 100:
        raise AppError("invalid_payload", "Invalid webhook entries", 422)
    accepted = 0
    for entry in entries:
        if not isinstance(entry, dict):
            raise AppError("invalid_payload", "Malformed webhook entry", 422)
        expected_account = creds.get("waba_id") if provider == "whatsapp" else creds.get("page_id")
        if str(entry.get("id")) != expected_account:
            raise AppError("forbidden", "Webhook account does not match configured account", 403)
        changes = entry.get("changes", [])
        if not isinstance(changes, list) or len(changes) > 100:
            raise AppError("invalid_payload", "Invalid webhook changes", 422)
        for change in changes:
            if not isinstance(change, dict) or not isinstance(change.get("value", {}), dict):
                raise AppError("invalid_payload", "Malformed webhook change", 422)
            value = change.get("value", {})
            if provider == "whatsapp":
                messages = value.get("messages", [])
                if not isinstance(messages, list) or len(messages) > 100:
                    raise AppError("invalid_payload", "Invalid message batch", 422)
                metadata = value.get("metadata", {})
                contacts_data = value.get("contacts", [])
                if not isinstance(metadata, dict) or not isinstance(contacts_data, list) or len(contacts_data) > 100:
                    raise AppError("invalid_payload", "Invalid WhatsApp metadata or contacts", 422)
                if messages and str(metadata.get("phone_number_id")) != creds.get("phone_number_id"):
                    raise AppError("forbidden", "Unexpected WhatsApp phone number", 403)
                contacts = {}
                for contact in contacts_data:
                    if (not isinstance(contact, dict) or not isinstance(contact.get("profile", {}), dict)
                            or not isinstance(contact.get("wa_id"), str)):
                        raise AppError("invalid_payload", "Invalid WhatsApp contact", 422)
                    contacts[contact["wa_id"]] = contact.get("profile", {}).get("name")
                for message in messages:
                    if (not isinstance(message, dict) or not isinstance(message.get("id"), str)
                            or not message.get("id") or not isinstance(message.get("from"), str)):
                        raise AppError("invalid_payload", "Missing WhatsApp message identity", 422)
                    phone = message["from"]
                    data = candidate({"name": contacts.get(phone) or "WhatsApp candidate", "phone": phone,
                                      "role": "WhatsApp enquiry", "source": "whatsapp", "provider_lead_id": message["id"]})
                    await ingest_once(data, provider, message["id"])
                    accepted += 1
            elif change.get("field") == "leadgen":
                event_id = str(value.get("leadgen_id", ""))
                if not re.fullmatch(r"[0-9]{1,40}", event_id):
                    raise AppError("invalid_payload", "Missing provider lead ID", 422)
                event_key = hashlib.sha256((provider + ":" + event_id).encode()).hexdigest()
                if await db.webhook_events.find_one({"event_key": event_key}):
                    continue
                lead = await ms.meta_get(event_id, creds, "id,created_time,field_data,ad_id,form_id")
                if not isinstance(lead, dict) or not isinstance(lead.get("field_data"), list):
                    raise AppError("provider_response", "Provider returned invalid candidate fields", 502)
                fields = {}
                for field in lead["field_data"]:
                    if (not isinstance(field, dict) or not isinstance(field.get("name"), str)
                            or not isinstance(field.get("values"), list)
                            or not all(isinstance(item, str) for item in field["values"])):
                        raise AppError("provider_response", "Provider returned invalid candidate fields", 502)
                    fields[field["name"]] = field["values"][0] if field["values"] else None
                name = fields.get("full_name") or " ".join(filter(None, [fields.get("first_name"), fields.get("last_name")]))
                data = candidate({"name": name, "phone": fields.get("phone_number"), "email": fields.get("email"),
                    "city": fields.get("city"), "role": fields.get("job_title") or fields.get("role") or "Lead ad enquiry",
                    "source": provider, "provider_lead_id": event_id,
                    "campaign": str(value.get("ad_id") or lead.get("ad_id") or ""),
                    **{k: fields.get(k) for k in ("utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content")}})
                await ingest_once(data, provider, event_id)
                accepted += 1
    return {"accepted": True, "processed": accepted}
