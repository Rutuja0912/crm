import uuid
from datetime import datetime, timezone
from typing import Optional, List, Dict
from pydantic import BaseModel, Field, EmailStr, ConfigDict, model_validator

class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    @model_validator(mode="after")
    def nonnull_required_fields(self):
        for field in self.model_fields_set & {"name", "role", "email", "is_active"}:
            if getattr(self, field) is None:
                raise ValueError(f"{field} cannot be null")
        return self



def now_utc() -> datetime:
    return datetime.now(timezone.utc)


def new_id() -> str:
    return str(uuid.uuid4())


ROLES = ("admin", "team_leader", "recruiter")


# ---------- Users ----------
class UserPublic(StrictModel):
    id: str
    email: EmailStr
    name: str
    role: str
    phone: Optional[str] = None
    team_id: Optional[str] = None
    manager_id: Optional[str] = None
    is_active: bool = True
    permission_overrides: Dict[str, List[str]] = Field(default_factory=lambda: {"allow": [], "deny": []})
    avatar_url: Optional[str] = None
    last_login_at: Optional[datetime] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


class UserCreate(StrictModel):
    email: EmailStr
    name: str = Field(min_length=1, max_length=120)
    password: str = Field(min_length=8, max_length=128)
    role: str
    phone: Optional[str] = None
    team_id: Optional[str] = None
    manager_id: Optional[str] = None


class UserUpdate(StrictModel):
    name: Optional[str] = Field(default=None, min_length=1, max_length=120)
    role: Optional[str] = None
    phone: Optional[str] = None
    team_id: Optional[str] = None
    manager_id: Optional[str] = None
    is_active: Optional[bool] = None
    avatar_url: Optional[str] = None


class PermissionOverrideUpdate(StrictModel):
    allow: List[str] = Field(default_factory=list)
    deny: List[str] = Field(default_factory=list)


# ---------- Auth ----------
class LoginRequest(StrictModel):
    email: EmailStr
    password: str


class ForgotPasswordRequest(StrictModel):
    email: EmailStr


class ResetPasswordRequest(StrictModel):
    token: str
    password: str = Field(min_length=8, max_length=128)


class ChangePasswordRequest(StrictModel):
    current_password: str
    new_password: str = Field(min_length=8, max_length=128)


class GoogleAuthRequest(StrictModel):
    id_token: str


# ---------- Roles ----------
class RoleUpdate(StrictModel):
    permissions: List[str]


# ---------- Settings ----------
class OrgSettingsUpdate(StrictModel):
    company_name: Optional[str] = None
    timezone: Optional[str] = None
    date_format: Optional[str] = None
