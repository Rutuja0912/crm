"""Recruitment domain constants + Pydantic models. Single source for statuses."""
from typing import Optional, List, Literal, Annotated
from datetime import datetime
from pydantic import BaseModel, Field, ConfigDict, field_validator, model_validator

# Centralized lead status engine (stage order matters for the funnel).
LEAD_STATUSES = ["new", "contacted", "interested", "lineup", "selected", "joined",
                 "not_interested", "rejected", "invalid"]
FUNNEL_ORDER = ["new", "contacted", "interested", "lineup", "selected", "joined"]
NEGATIVE_STATUSES = ["not_interested", "rejected", "invalid"]
ACTIVE_STATUSES = ["new", "contacted", "interested", "lineup", "selected"]
FINAL_STATUSES = ["joined", "not_interested", "rejected", "invalid"]
# Statuses that demand a closure/lost reason when transitioned into.
REASON_REQUIRED_STATUSES = ["rejected", "not_interested", "invalid"]

STATUS_LABELS = {
    "new": "New", "contacted": "Contacted", "interested": "Interested",
    "lineup": "Interview Lineup", "selected": "Selected", "joined": "Joined",
    "not_interested": "Not Interested", "rejected": "Rejected", "invalid": "Invalid Lead",
}

# Allowed transitions (kept permissive but explicit). Any -> negative always allowed.
ALLOWED_TRANSITIONS = {
    "new": ["contacted", "interested", "not_interested", "rejected", "lineup", "invalid", "selected"],
    "contacted": ["interested", "lineup", "not_interested", "rejected", "new", "invalid", "selected"],
    "interested": ["lineup", "selected", "not_interested", "rejected", "contacted", "invalid"],
    "lineup": ["selected", "rejected", "not_interested", "interested", "invalid"],
    "selected": ["joined", "rejected", "lineup"],
    "joined": ["rejected"],
    "not_interested": ["new", "contacted", "interested"],
    "rejected": ["new", "contacted", "interested"],
    "invalid": ["new", "contacted"],
}

# Legacy simple call outcomes (kept for the lightweight quick-call path).
CALL_OUTCOMES = ["connected", "no_answer", "busy", "wrong_number", "callback",
                 "interested", "not_interested"]

# ---- Disposition engine (Prompt 10) ----
CONNECTED_OUTCOMES = ["connected_interested", "not_interested", "callback_requested",
                      "interview_scheduled", "already_working", "salary_issue",
                      "location_issue", "job_mismatch"]
NOT_CONNECTED_OUTCOMES = ["no_answer", "busy", "switched_off", "unreachable",
                          "invalid_number", "whatsapp_only", "call_back_later"]
DISPOSITION_OUTCOMES = CONNECTED_OUTCOMES + NOT_CONNECTED_OUTCOMES
DISPOSITION_LABELS = {
    "connected_interested": "Connected – Interested", "not_interested": "Not Interested",
    "callback_requested": "Callback Requested", "interview_scheduled": "Interview Scheduled",
    "already_working": "Already Working", "salary_issue": "Salary Issue",
    "location_issue": "Location Issue", "job_mismatch": "Job Mismatch",
    "no_answer": "No Answer", "busy": "Busy", "switched_off": "Switched Off",
    "unreachable": "Unreachable", "invalid_number": "Invalid Number",
    "whatsapp_only": "WhatsApp Only", "call_back_later": "Call Back Later",
}
# Outcomes that make the next follow-up mandatory.
CALLBACK_OUTCOMES = ["callback_requested", "call_back_later"]
# Outcome -> forced final status.
AUTO_FINAL_MAP = {"not_interested": "not_interested", "invalid_number": "invalid"}

LEAD_PRIORITIES = ["low", "medium", "high"]
GENDERS = ["male", "female", "other"]
INTERVIEW_TYPES = ["walkin", "telephonic", "virtual", "f2f"]
FOLLOWUP_STATUS = ["pending", "done", "cancelled", "superseded"]
TASK_STATUS = ["pending", "in_progress", "done", "cancelled"]
TASK_CATEGORIES = ["candidate_followup", "client_followup", "vendor_followup",
                   "interview_prep", "marketing_task", "general_admin"]
INTERVIEW_STATUS = ["scheduled", "confirmed", "attended", "no_show", "selected", "rejected"]
JOINING_STATUS = ["selected", "documents_pending", "offer_pending", "offer_released",
                  "joining_confirmed", "joined", "delayed", "no_show", "dropped",
                  "client_rejected", "pending", "confirmed"]
CONFIRMATION = ["pending", "confirmed", "not_confirmed", "reschedule_requested"]
Priority = Literal["low", "medium", "high"]
LeadStatus = Literal[tuple(LEAD_STATUSES)]
InterviewStage = Literal[tuple(INTERVIEW_STATUS)]
InterviewType = Literal[tuple(INTERVIEW_TYPES)]
JoiningStatus = Literal[tuple(JOINING_STATUS)]
Confirmation = Literal[tuple(CONFIRMATION)]
TaskCategory = Literal[tuple(TASK_CATEGORIES)]
Name = Annotated[str, Field(min_length=1, max_length=160)]
Phone = Annotated[str, Field(min_length=3, max_length=32, pattern=r"^[+()0-9 .-]+$")]

class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True, validate_default=True,
                              str_max_length=4000, allow_inf_nan=False)

    @model_validator(mode="after")
    def nonnull_required_updates(self):
        for name in self.model_fields_set & {"name", "title", "phone", "status", "priority", "category", "confirmation", "mode"}:
            if getattr(self, name) is None:
                raise ValueError(f"{name} cannot be null")
        return self

    @field_validator("*", mode="after")
    @classmethod
    def validate_instant(cls, v):
        if isinstance(v, datetime) and v.tzinfo is None:
            raise ValueError("Datetime must include a timezone offset")
        return v


# Saved-view chips (Prompt 06) resolved server-side.
SAVED_VIEWS = ["all", "fresh", "not_called", "todays_followups", "overdue", "no_followup",
               "no_answer", "interested", "hot", "interviews", "attendance_pending",
               "selected", "joining_this_week", "joined", "rejected_lost"]


class LeadCreate(StrictModel):
    name: Name
    phone: Phone
    alt_phone: Optional[Phone] = None
    email: Optional[str] = None
    city: Optional[str] = None
    age: Optional[int] = Field(default=None, ge=14, le=99)
    gender: Optional[Literal["male", "female", "other"]] = None
    qualification: Optional[str] = None
    experience: Optional[str] = None
    current_salary: Optional[str] = None
    expected_salary: Optional[str] = None
    notice_period: Optional[str] = None
    source: Optional[str] = "manual"
    role_applied: Optional[str] = None
    priority: Priority = "medium"
    owner_id: Optional[str] = None  # admin/TL may assign; else self
    client: Optional[str] = None
    job: Optional[str] = None
    tags: List[str] = Field(default_factory=list)
    notes: Optional[str] = None
    # create-only first follow-up
    first_followup_at: Optional[datetime] = None
    first_followup_reason: Optional[str] = "First call"
    duplicate_ack: bool = False  # create-as-flagged-duplicate acknowledgement


class LeadUpdate(StrictModel):
    name: Optional[Name] = None
    phone: Optional[Phone] = None
    alt_phone: Optional[Phone] = None
    email: Optional[str] = None
    city: Optional[str] = None
    age: Optional[int] = Field(default=None, ge=14, le=99)
    gender: Optional[Literal["male", "female", "other"]] = None
    qualification: Optional[str] = None
    experience: Optional[str] = None
    current_salary: Optional[str] = None
    expected_salary: Optional[str] = None
    notice_period: Optional[str] = None
    source: Optional[str] = None
    role_applied: Optional[str] = None
    priority: Optional[Priority] = None
    owner_id: Optional[str] = None
    client: Optional[str] = None
    job: Optional[str] = None
    tags: Optional[List[str]] = None
    notes: Optional[str] = None


class StatusChange(StrictModel):
    status: LeadStatus
    note: Optional[str] = None
    closure_reason: Optional[str] = None
    expected_joining_date: Optional[datetime] = None


class CallCreate(StrictModel):
    outcome: Literal[tuple(CALL_OUTCOMES)]
    notes: Optional[str] = None
    duration_seconds: int = Field(default=0, ge=0, le=86400)


class InterviewInline(StrictModel):
    scheduled_at: datetime
    client: str = Field(min_length=1)
    job: str = Field(min_length=1)
    type: InterviewType
    location: Optional[str] = None
    contact_person: Optional[str] = None
    notes: Optional[str] = None


class DispositionCreate(StrictModel):
    outcome: Literal[tuple(DISPOSITION_OUTCOMES)]
    notes: Optional[str] = None
    duration_seconds: int = Field(default=0, ge=0, le=86400)
    next_followup_at: Optional[datetime] = None
    next_followup_reason: Optional[str] = None
    status_override: Optional[LeadStatus] = None
    interview: Optional[InterviewInline] = None
    expected_joining_date: Optional[datetime] = None
    closure_reason: Optional[str] = None


class FollowupCreate(StrictModel):
    due_at: datetime
    reason: Optional[str] = None
    notes: Optional[str] = None


class FollowupUpdate(StrictModel):
    status: Optional[Literal[tuple(FOLLOWUP_STATUS)]] = None
    due_at: Optional[datetime] = None
    reason: Optional[str] = None
    notes: Optional[str] = None


class FollowupComplete(StrictModel):
    outcome: Optional[str] = None
    notes: Optional[str] = None
    mode: Literal["next", "final"] = "next"  # "next" | "final"
    next_due_at: Optional[datetime] = None
    next_reason: Optional[str] = None
    final_status: Optional[LeadStatus] = None
    closure_reason: Optional[str] = None
    expected_joining_date: Optional[datetime] = None


class TagsUpdate(StrictModel):
    tags: List[str]


class NoteCreate(StrictModel):
    body: str = Field(min_length=1, max_length=4000)


class NoteUpdate(StrictModel):
    body: str = Field(min_length=1, max_length=4000)


class AssignRequest(StrictModel):
    lead_ids: List[str] = Field(min_length=1, max_length=2000)
    to_owner_id: str


class TransferRequest(StrictModel):
    lead_ids: List[str] = Field(min_length=1, max_length=2000)
    to_owner_id: str


class AutoDistributeRequest(StrictModel):
    lead_ids: Optional[List[str]] = Field(default=None, min_length=1, max_length=2000)  # None => all in scope matching filters
    recruiter_ids: Optional[List[str]] = Field(default=None, min_length=1, max_length=500)
    confirm_redistribution: bool = False
    preview: bool = False


class TaskCreate(StrictModel):
    title: str = Field(min_length=1, max_length=200)
    category: TaskCategory = "general_admin"
    due_at: Optional[datetime] = None
    priority: Priority = "medium"
    lead_id: Optional[str] = None
    related_entity: Optional[str] = None
    notes: Optional[str] = None
    owner_id: Optional[str] = None


class TaskUpdate(StrictModel):
    title: Optional[str] = None
    category: Optional[TaskCategory] = None
    due_at: Optional[datetime] = None
    priority: Optional[Priority] = None
    status: Optional[Literal[tuple(TASK_STATUS)]] = None
    related_entity: Optional[str] = None
    notes: Optional[str] = None


class InterviewCreate(StrictModel):
    scheduled_at: datetime
    mode: InterviewType = "telephonic"
    client: Optional[str] = None
    job: Optional[str] = None
    location: Optional[str] = None
    contact_person: Optional[str] = None
    notes: Optional[str] = None


class InterviewUpdate(StrictModel):
    status: Optional[InterviewStage] = None
    confirmation: Optional[Confirmation] = None
    expected_joining_date: Optional[datetime] = None
    mode: Optional[InterviewType] = None
    client: Optional[str] = None
    job: Optional[str] = None
    location: Optional[str] = None
    contact_person: Optional[str] = None
    scheduled_at: Optional[datetime] = None
    notes: Optional[str] = None


class JoiningCreate(StrictModel):
    joining_date: datetime
    notes: Optional[str] = None


class JoiningUpdate(StrictModel):
    status: Optional[JoiningStatus] = None
    confirmation: Optional[Literal["pending", "confirmed", "not_confirmed"]] = None
    actual_joining_date: Optional[datetime] = None
    salary: Optional[str] = Field(default=None, max_length=80)
    remarks: Optional[str] = None
    joining_date: Optional[datetime] = None
    notes: Optional[str] = None


class ApplicationIntake(StrictModel):
    name: Name
    phone: Phone
    email: Optional[str] = None
    role: Name
    city: Optional[str] = None
    experience: Optional[str] = None
    source: str = Field(default="careers", min_length=1, max_length=80)
    campaign: Optional[str] = None
    utm_source: Optional[str] = None
    utm_medium: Optional[str] = None
    utm_campaign: Optional[str] = None
    utm_term: Optional[str] = None
    utm_content: Optional[str] = None
    provider_lead_id: Optional[str] = Field(default=None, max_length=200)

    @field_validator("phone")
    @classmethod
    def usable_phone(cls, value):
        digits = "".join(x for x in value if x.isdigit())
        if not 10 <= len(digits) <= 15:
            raise ValueError("Phone must contain 10 to 15 digits")
        return value

    @field_validator("email")
    @classmethod
    def valid_email(cls, value):
        if value:
            from email_validator import validate_email
            return validate_email(value, check_deliverability=False).normalized
        return None


class ApplicationStatus(StrictModel):
    status: Literal["new", "shortlisted"]


class ApplicationConvert(StrictModel):
    assign_to: Optional[str] = None
    create_followup: bool = True


class VendorInput(StrictModel):
    company: Name
    stage: Literal["new", "contacted", "followup", "meeting", "proposal_sent", "negotiation", "empanelled", "rejected"] = "new"
    industry: Optional[str] = None
    contact_person: Optional[str] = None
    designation: Optional[str] = None
    phone: Optional[str] = None
    work_email: Optional[str] = None
    linkedin: Optional[str] = None
    commercials: Optional[str] = None
    next_action: Optional[str] = None
    notes: Optional[str] = None


class TemplateInput(StrictModel):
    name: Name
    channel: Literal["whatsapp", "email"]
    body: str = Field(min_length=1, max_length=12000)
    category: Optional[str] = None
    subject: Optional[str] = None
    variables: List[str] = Field(default_factory=list)
    provider_approved: bool = False


class JobInput(StrictModel):
    title: Name
    client: Name
    status: Literal["active", "on_hold", "closed"] = "active"
    location: Optional[str] = None
    openings: int = Field(default=0, ge=0, le=100000)
    salary_min: Optional[str] = None
    salary_max: Optional[str] = None
    experience: Optional[str] = None
    skills: Optional[str] = None
    description: Optional[str] = None


class ClientInput(StrictModel):
    name: Name
    company: Optional[str] = None
    location: Optional[str] = None
    contact_person: Optional[str] = None
    contact_phone: Optional[str] = None
    contact_email: Optional[str] = None
    payment_terms: Optional[str] = None
    replacement_terms: Optional[str] = None
    notes: Optional[str] = None
