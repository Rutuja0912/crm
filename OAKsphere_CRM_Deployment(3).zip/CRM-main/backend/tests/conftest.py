"""Fresh database per API contract; real transactions when enabled in CI.

Default mock runs prove API behavior, not MongoDB transaction guarantees.
"""
import os
import uuid
from contextlib import asynccontextmanager
from functools import lru_cache
import pytest

for key, value in {
    'MONGO_URL': 'mongodb://127.0.0.1:27018/?replicaSet=crmtest',
    'DB_NAME': 'crm_hardening_test',
    'JWT_SECRET': 'isolated-test-only-secret-longer-than-32-characters',
    'ADMIN_EMAIL': 'admin@example.com', 'ADMIN_PASSWORD': 'LocalTest123!',
    'SEED_DEMO': 'false', 'REACT_APP_BACKEND_URL': 'http://testserver',
}.items():
    os.environ.setdefault(key, value)

CONTRACT_FILES = {
    'test_foundation.py', 'test_auth_prompt2.py', 'test_public_api.py',
    'test_recruitment_prompts3to6.py', 'test_recruitment_prompts6to10.py',
    'test_modules_prompts11to34.py',
}


@lru_cache(maxsize=8)
def fixture_password_hash(password):
    from core.security import hash_password
    return hash_password(password)


@pytest.fixture(autouse=True)
def contract_environment(request, monkeypatch):
    if request.path.name not in CONTRACT_FILES:
        yield None
        return

    import server
    from fastapi.testclient import TestClient
    from core import database, transactions as tx
    from core.config import settings
    from services import recruitment_service as rs, modules_service as ms, seed_service
    from api import (deps, auth_routes, user_routes, role_routes, modules_routes,
                     recruitment_routes, dashboard_routes, settings_routes,
                     audit_routes, webhook_routes)
    from tests.api_client import requests, SyncDatabase

    real = os.environ.get('CRM_REAL_MONGO_REGRESSION') == '1'
    if real:
        if os.environ.get('CRM_TEST_DATABASE_CONFIRMED') != '1':
            raise pytest.UsageError('Real Mongo tests require CRM_TEST_DATABASE_CONFIRMED=1 and isolated MongoDB.')
        from motor.motor_asyncio import AsyncIOMotorClient
        mongo = AsyncIOMotorClient(os.environ['MONGO_URL'], tz_aware=True,
                                   serverSelectionTimeoutMS=5000)
    else:
        from mongomock_motor import AsyncMongoMockClient
        mongo = AsyncMongoMockClient(tz_aware=True)

        @asynccontextmanager
        async def no_session():
            yield None

        for module in (tx, rs, ms):
            monkeypatch.setattr(module, 'atomic', no_session)

    name = 'crm_contract_run_' + uuid.uuid4().hex
    database_handle = mongo[name]
    for module in (database, server, deps, auth_routes, user_routes, role_routes,
                   modules_routes, recruitment_routes, dashboard_routes,
                   settings_routes, audit_routes, webhook_routes):
        monkeypatch.setattr(module, 'db', database_handle)
    monkeypatch.setattr(database, 'client', mongo)
    monkeypatch.setattr(tx, 'client', mongo)
    monkeypatch.setattr(settings, 'seed_demo', True)
    monkeypatch.setattr(settings, 'production', False)
    monkeypatch.setattr(settings, 'enable_bearer_auth', False)
    monkeypatch.setattr(settings, 'cookie_secure', False)
    monkeypatch.setattr(settings, 'google_client_id', '')
    monkeypatch.setattr(settings, 'email_key', None)
    monkeypatch.setattr(settings, 'email_enabled', False)
    monkeypatch.setattr(settings, 'google_enabled', False)
    monkeypatch.setattr(seed_service, 'hash_password', fixture_password_hash)
    server.app.dependency_overrides.clear()
    with TestClient(server.app, base_url='http://testserver') as client:
        requests.bind(client)
        sync_db = SyncDatabase(client, database_handle)
        # Deliberately delegated user management; candidate scope stays limited.
        sync_db.users.update_one({'email': seed_service.DEMO_LEAD_EMAIL}, {
            '$set': {'permission_overrides': {'allow': ['users.manage'], 'deny': []}}})
        try:
            yield sync_db
        finally:
            requests.bind(None)
            client.portal.call(mongo.drop_database, name)
    server.app.dependency_overrides.clear()


@pytest.fixture
def db(contract_environment):
    assert contract_environment is not None
    return contract_environment
