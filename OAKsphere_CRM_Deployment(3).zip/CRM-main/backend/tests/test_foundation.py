"""Foundation contracts run with independent data and real cookie sessions."""
import os
from tests.api_client import requests, session_headers
from services.permission_service import ALL_PERMISSIONS, ROLE_DEFAULTS

ADMIN = {'email': os.environ['ADMIN_EMAIL'], 'password': os.environ['ADMIN_PASSWORD']}
LEAD = {'email': 'teamlead@oaksphere.demo', 'password': 'TeamLead@123'}
RECRUITER = {'email': 'recruiter@oaksphere.demo', 'password': 'Recruiter@123'}


def login(creds):
    return session_headers(requests.post('/api/auth/login', json=creds))


def test_effective_permissions_admin_all():
    response = requests.get('/api/auth/me', headers=login(ADMIN))
    assert response.status_code == 200
    assert set(response.json()['permissions']) == set(ALL_PERMISSIONS)


def test_recruiter_defaults():
    response = requests.get('/api/auth/me', headers=login(RECRUITER))
    assert response.status_code == 200
    assert set(response.json()['permissions']) == set(ROLE_DEFAULTS['recruiter'])


def test_login_and_me():
    response = requests.get('/api/auth/me', headers=login(ADMIN))
    assert response.status_code == 200
    assert response.json()['user']['role'] == 'admin'


def test_login_bad_password():
    response = requests.post('/api/auth/login', json={**ADMIN, 'password': 'wrong'})
    assert response.status_code == 401


def test_me_requires_auth():
    assert requests.get('/api/auth/me').status_code == 401


def test_recruiter_cannot_create_user():
    response = requests.post('/api/users', headers=login(RECRUITER), json={
        'email': 'x@y.com', 'name': 'X', 'password': 'Password123', 'role': 'recruiter'})
    assert response.status_code == 403


def test_recruiter_cannot_list_users():
    assert requests.get('/api/users', headers=login(RECRUITER)).status_code == 403


def test_team_leader_cannot_access_admin_record(db):
    admin = db.users.find_one({'email': ADMIN['email']})
    assert requests.get(f"/api/users/{admin['id']}", headers=login(LEAD)).status_code == 403


def test_team_leader_scope():
    response = requests.get('/api/users', headers=login(LEAD))
    assert response.status_code == 200
    emails = {user['email'] for user in response.json()}
    assert LEAD['email'] in emails and ADMIN['email'] not in emails


def test_logout_revokes_session():
    headers = login(ADMIN)
    assert requests.get('/api/auth/me', headers=headers).status_code == 200
    assert requests.post('/api/auth/logout', headers=headers).status_code == 200
    assert requests.get('/api/auth/me', headers=headers).status_code == 401
