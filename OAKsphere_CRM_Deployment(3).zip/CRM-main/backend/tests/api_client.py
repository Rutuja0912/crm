"""HTTP contracts using Starlette's in-process client, without external traffic.

Authentication uses the actual login cookies and signed CSRF endpoint. The
adapter never replaces authentication or alters responses to fit old tests.
"""
from urllib.parse import urlsplit


class ApiRequests:
    client = None

    def bind(self, client):
        self.client = client

    def request(self, method, url, **kwargs):
        assert self.client is not None, 'The isolated API fixture is required'
        parsed = urlsplit(url)
        assert not parsed.netloc or parsed.netloc == 'testserver', 'External URLs are forbidden in isolated contracts'
        path = parsed.path + ('?' + parsed.query if parsed.query else '')
        self.client.cookies.clear()
        kwargs.pop('timeout', None)
        return self.client.request(method, path, **kwargs)

    def __getattr__(self, method):
        if method in {'get', 'post', 'put', 'patch', 'delete', 'options'}:
            return lambda url, **kwargs: self.request(method.upper(), url, **kwargs)
        raise AttributeError(method)


requests = ApiRequests()


def session_headers(response):
    assert response.status_code == 200, response.text
    assert 'access_token' not in response.json(), 'Cookie auth must not return a bearer token'
    csrf = requests.get('/api/auth/csrf')
    assert csrf.status_code == 200
    cookies = dict(response.cookies)
    cookies.update(dict(csrf.cookies))
    assert cookies.get('access_token') and cookies.get('refresh_token')
    return {'Cookie': '; '.join(f'{key}={value}' for key, value in cookies.items()),
            'X-CSRF-Token': csrf.json()['csrf_token']}


class SyncDatabase:
    """Fixture-only setup and verification on the TestClient event loop."""
    def __init__(self, client, db):
        self.client, self.db = client, db

    def __getattr__(self, name):
        return SyncCollection(self.client, self.db[name])


class SyncCollection:
    def __init__(self, client, collection):
        self.client, self.collection = client, collection

    def __getattr__(self, name):
        def call(*args, **kwargs):
            async def run():
                return await getattr(self.collection, name)(*args, **kwargs)
            return self.client.portal.call(run)
        return call
