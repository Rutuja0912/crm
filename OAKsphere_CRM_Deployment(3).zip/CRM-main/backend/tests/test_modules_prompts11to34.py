"""Backend regression tests for OAKsphere Prompts 11-34.

Covers: jobs, clients, vendors, templates, applications (convert idempotent),
followups board + complete, tasks summary + CRUD, interviews, joinings,
lead-inbox, reports (all tabs), action-required (9 cards), integrations
(save encrypted + mask + test + disconnect + recruiter 403), import
(template + preview + commit + idempotent commit), tags, notifications,
global search, and RBAC for recruiter.

Runs in-process against isolated data; CI switches the fixture to real MongoDB.
"""
import os
import time
import pytest
from tests.api_client import requests, session_headers

API = "/api"

ADMIN = {"email": os.environ["ADMIN_EMAIL"], "password": os.environ["ADMIN_PASSWORD"]}
RECRUITER = {"email": "recruiter@oaksphere.demo", "password": "Recruiter@123"}


def _login(creds):
    r = requests.post(f"{API}/auth/login", json=creds, timeout=30)
    assert r.status_code == 200, f"login failed {r.status_code}: {r.text}"
    return session_headers(r)


@pytest.fixture
def admin_headers():
    tok = _login(ADMIN)
    return tok


@pytest.fixture
def recruiter_headers():
    tok = _login(RECRUITER)
    return tok


# ============ Health ============
def test_health():
    r = requests.get(f"{API}/health", timeout=10)
    assert r.status_code == 200


# ============ JOBS ============
class TestJobs:
    def test_crud(self, admin_headers):
        r = requests.post(f"{API}/jobs", headers=admin_headers,
                          json={"title": "TEST_Job11", "client": "TEST_Client_J", "location": "Pune"})
        assert r.status_code in (200, 201), r.text
        job = r.json()
        jid = job["id"]
        # list
        r = requests.get(f"{API}/jobs?search=TEST_Job11", headers=admin_headers)
        assert r.status_code == 200
        items = r.json()
        assert any(j["id"] == jid for j in items)
        assert "linked_leads" in items[0]
        # edit - backend re-validates required fields (title, client) so pass them all
        r = requests.put(f"{API}/jobs/{jid}", headers=admin_headers,
                         json={"title": "TEST_Job11", "client": "TEST_Client_J", "location": "Mumbai"})
        assert r.status_code == 200, r.text
        assert r.json()["location"] == "Mumbai"
        # archive
        r = requests.delete(f"{API}/jobs/{jid}", headers=admin_headers)
        assert r.status_code == 200

    def test_missing_title(self, admin_headers):
        r = requests.post(f"{API}/jobs", headers=admin_headers, json={"client": "Only"})
        assert r.status_code == 422


# ============ CLIENTS ============
class TestClients:
    def test_crud(self, admin_headers):
        r = requests.post(f"{API}/clients", headers=admin_headers,
                          json={"name": "TEST_Client_C1", "company": "ACME"})
        assert r.status_code in (200, 201), r.text
        cid = r.json()["id"]
        r = requests.get(f"{API}/clients?search=TEST_Client_C1", headers=admin_headers)
        assert r.status_code == 200
        row = next(x for x in r.json() if x["id"] == cid)
        assert set(["submitted", "interviewed", "selected", "joined"]).issubset(row["stats"].keys())
        r = requests.put(f"{API}/clients/{cid}", headers=admin_headers,
                         json={"name": "TEST_Client_C1", "company": "ACME2"})
        assert r.status_code == 200 and r.json()["company"] == "ACME2"
        r = requests.delete(f"{API}/clients/{cid}", headers=admin_headers)
        assert r.status_code == 200


# ============ VENDORS ============
class TestVendors:
    def test_summary_and_crud(self, admin_headers):
        r = requests.get(f"{API}/vendors/summary", headers=admin_headers)
        assert r.status_code == 200
        s = r.json()
        for k in ("empanelled", "proposals", "active"):
            assert k in s
        r = requests.post(f"{API}/vendors", headers=admin_headers,
                          json={"company": "TEST_Vendor_V1", "contact_person": "V", "phone": "9999900000",
                                "stage": "contacted"})
        assert r.status_code in (200, 201), r.text
        vid = r.json()["id"]
        r = requests.put(f"{API}/vendors/{vid}", headers=admin_headers,
                         json={"company": "TEST_Vendor_V1", "stage": "empanelled"})
        assert r.status_code == 200 and r.json()["stage"] == "empanelled"
        r = requests.delete(f"{API}/vendors/{vid}", headers=admin_headers)
        assert r.status_code == 200

    def test_recruiter_forbidden(self, recruiter_headers):
        r = requests.get(f"{API}/vendors", headers=recruiter_headers)
        assert r.status_code == 403


# ============ TEMPLATES ============
class TestTemplates:
    def test_crud_and_channel_validation(self, admin_headers):
        r = requests.post(f"{API}/templates", headers=admin_headers,
                          json={"name": "TEST_Tpl1", "channel": "whatsapp", "body": "Hi {{name}}"})
        assert r.status_code in (200, 201), r.text
        tid = r.json()["id"]
        r = requests.get(f"{API}/templates?channel=whatsapp&search=TEST_Tpl1", headers=admin_headers)
        assert r.status_code == 200 and any(t["id"] == tid for t in r.json())
        r = requests.put(f"{API}/templates/{tid}", headers=admin_headers,
                         json={"name": "TEST_Tpl1", "channel": "whatsapp", "body": "Hi {{name}}!"})
        assert r.status_code == 200
        # bad channel
        r = requests.post(f"{API}/templates", headers=admin_headers,
                          json={"name": "TEST_Bad", "channel": "sms", "body": "x"})
        assert r.status_code == 422
        # missing body
        r = requests.post(f"{API}/templates", headers=admin_headers,
                          json={"name": "TEST_Bad", "channel": "email"})
        assert r.status_code == 422
        r = requests.delete(f"{API}/templates/{tid}", headers=admin_headers)
        assert r.status_code == 200


# ============ APPLICATIONS ============
class TestApplications:
    def test_list_all(self, admin_headers):
        r = requests.get(f"{API}/applications?status=all", headers=admin_headers)
        assert r.status_code == 200
        assert isinstance(r.json(), list)

    def test_convert_idempotent(self, admin_headers, db):
        db.applications.insert_one({"id": "test-intake", "name": "Intake candidate",
                                    "phone": "9988776655", "status": "new", "owner_id": None})
        first = requests.post(f"{API}/applications/test-intake/convert", headers=admin_headers, json={})
        assert first.status_code == 200, first.text
        again = requests.post(f"{API}/applications/test-intake/convert", headers=admin_headers, json={})
        assert again.status_code == 200, again.text
        assert again.json()["already"] is True
        assert again.json()["lead"]["id"] == first.json()["lead"]["id"]
        assert db.leads.count_documents({"id": first.json()["lead"]["id"]}) == 1


# ============ LEAD INBOX ============
def test_lead_inbox(admin_headers):
    r = requests.get(f"{API}/lead-inbox", headers=admin_headers)
    assert r.status_code == 200
    body = r.json()
    assert "summary" in body and "items" in body
    assert isinstance(body["summary"], list)


# ============ REPORTS ============
class TestReports:
    def test_leaderboard(self, admin_headers):
        r = requests.get(f"{API}/reports?tab=leaderboard", headers=admin_headers)
        assert r.status_code == 200
        body = r.json()
        assert "leaderboard" in body and "score_formula" in body
        if body["leaderboard"]:
            row = body["leaderboard"][0]
            for k in ("recruiter", "score", "rank", "calls", "connected", "lineups", "joined"):
                assert k in row

    def test_targets(self, admin_headers):
        r = requests.get(f"{API}/reports?tab=targets", headers=admin_headers)
        assert r.status_code == 200
        assert "targets" in r.json()

    def test_funnel(self, admin_headers):
        r = requests.get(f"{API}/reports?tab=funnel", headers=admin_headers)
        assert r.status_code == 200 and "funnel" in r.json()

    def test_aging(self, admin_headers):
        r = requests.get(f"{API}/reports?tab=aging", headers=admin_headers)
        assert r.status_code == 200 and "aging" in r.json()
        assert set(r.json()["aging"].keys()) == {"new", "1d", "3d", "7d", "15d+"}

    def test_missed(self, admin_headers):
        r = requests.get(f"{API}/reports?tab=missed", headers=admin_headers)
        assert r.status_code == 200 and "missed" in r.json()

    def test_recruiter_forbidden(self, recruiter_headers):
        r = requests.get(f"{API}/reports?tab=leaderboard", headers=recruiter_headers)
        assert r.status_code == 403


# ============ ACTION REQUIRED ============
def test_action_required_9_cards(admin_headers):
    r = requests.get(f"{API}/action-required", headers=admin_headers)
    assert r.status_code == 200
    body = r.json()
    assert "cards" in body
    assert len(body["cards"]) == 9
    keys = {c["key"] for c in body["cards"]}
    assert keys == {"overdue_followups", "no_followup", "never_called", "unassigned",
                    "stale", "selected_no_joining", "unconfirmed_interviews",
                    "unconfirmed_joinings", "below_target"}


def test_action_required_recruiter_scoped(recruiter_headers):
    r = requests.get(f"{API}/action-required", headers=recruiter_headers)
    assert r.status_code == 200
    keys = {card["key"] for card in r.json()["cards"]}
    assert "below_target" not in keys
    unassigned = next(card for card in r.json()["cards"] if card["key"] == "unassigned")
    assert unassigned["count"] == 0


# ============ INTEGRATIONS ============
class TestIntegrations:
    def test_list_masked_by_default(self, admin_headers):
        r = requests.get(f"{API}/integrations", headers=admin_headers)
        assert r.status_code == 200
        rows = r.json()
        keys = {row["key"] for row in rows}
        assert {"whatsapp", "instagram", "facebook", "google_forms"}.issubset(keys)

    def test_save_test_disconnect_round_trip(self, admin_headers):
        secret = "AAAABBBBCCCC-1234SECRET"
        r = requests.put(f"{API}/integrations/google_forms", headers=admin_headers,
                         json={"shared_secret": secret})
        assert r.status_code == 200 and r.json().get("ok")
        # verify masking on list
        r = requests.get(f"{API}/integrations", headers=admin_headers)
        gf = next(x for x in r.json() if x["key"] == "google_forms")
        masked = gf["masked"].get("shared_secret", "")
        # Never returns the raw token
        assert secret not in masked
        # test connection
        r = requests.post(f"{API}/integrations/google_forms/test", headers=admin_headers)
        assert r.status_code == 200 and r.json().get("ok")
        assert r.json()["remote_tested"] is False
        rows = requests.get(f"{API}/integrations", headers=admin_headers).json()
        saved = next(row for row in rows if row["key"] == "google_forms")
        assert saved["configured"] is True and saved["connected"] is False
        # disconnect
        r = requests.post(f"{API}/integrations/google_forms/disconnect", headers=admin_headers)
        assert r.status_code == 200 and r.json().get("disconnected")

    def test_recruiter_forbidden(self, recruiter_headers):
        r = requests.get(f"{API}/integrations", headers=recruiter_headers)
        assert r.status_code == 403


# ============ IMPORT ============
class TestImport:
    def test_template_download(self, admin_headers):
        r = requests.get(f"{API}/import/template", headers=admin_headers)
        assert r.status_code == 200
        # Content bytes; xlsx starts with PK zip magic
        assert r.content[:2] == b"PK"

    def test_preview_and_commit_idempotent(self, admin_headers):
        csv_body = (
            "Name,Phone,Email,Source,Priority\n"
            f"TEST_Imp_A,977700{int(time.time()) % 10000:04d},a@t.com,referral,high\n"
            f"TEST_Imp_B,977701{int(time.time()) % 10000:04d},b@t.com,manual,medium\n"
        ).encode()
        files = {"file": ("leads.csv", csv_body, "text/csv")}
        # Do not use the JSON Content-Type header
        h = {k: v for k, v in admin_headers.items() if k != "Content-Type"}
        r = requests.post(f"{API}/import/preview", headers=h, files=files)
        assert r.status_code == 200, r.text
        pv = r.json()
        assert pv["row_count"] == 2 and "batch_id" in pv
        mapping = {"Name": "name", "Phone": "phone", "Email": "email",
                   "Source": "source", "Priority": "priority"}
        r = requests.post(f"{API}/import/commit", headers=admin_headers,
                          json={"batch_id": pv["batch_id"], "mapping": mapping,
                                "rules": {"assign": "unassigned", "duplicates": "flag", "invalid": "flag"}})
        assert r.status_code == 200
        first = r.json()
        assert first["imported"] >= 1
        # Idempotent
        r = requests.post(f"{API}/import/commit", headers=admin_headers,
                          json={"batch_id": pv["batch_id"], "mapping": mapping, "rules": {}})
        assert r.status_code == 200
        second = r.json()
        assert second == first or second.get("note") == "already committed"

    def test_commit_requires_phone_mapping(self, admin_headers):
        csv_body = b"Foo\nbar\n"
        h = {k: v for k, v in admin_headers.items() if k != "Content-Type"}
        r = requests.post(f"{API}/import/preview", headers=h,
                          files={"file": ("x.csv", csv_body, "text/csv")})
        assert r.status_code == 200
        bid = r.json()["batch_id"]
        r = requests.post(f"{API}/import/commit", headers=admin_headers,
                          json={"batch_id": bid, "mapping": {"Foo": "name"}, "rules": {}})
        assert r.status_code == 422

    def test_recruiter_forbidden(self, recruiter_headers):
        r = requests.get(f"{API}/import/template", headers=recruiter_headers)
        assert r.status_code == 403


# ============ TAGS ============
class TestTags:
    def test_crud(self, admin_headers):
        name = f"TEST_Tag_{int(time.time())}"
        r = requests.post(f"{API}/tags", headers=admin_headers, json={"name": name, "color": "red"})
        assert r.status_code in (200, 201), r.text
        tid = r.json()["id"]
        # dup
        r = requests.post(f"{API}/tags", headers=admin_headers, json={"name": name})
        assert r.status_code == 409
        r = requests.get(f"{API}/tags", headers=admin_headers)
        assert r.status_code == 200
        row = next(x for x in r.json() if x["id"] == tid)
        assert "lead_count" in row
        r = requests.put(f"{API}/tags/{tid}", headers=admin_headers, json={"name": name, "color": "blue"})
        assert r.status_code == 200 and r.json()["color"] == "blue"
        r = requests.delete(f"{API}/tags/{tid}", headers=admin_headers)
        assert r.status_code == 200


# ============ NOTIFICATIONS ============
class TestNotifications:
    def test_flow(self, admin_headers):
        r = requests.get(f"{API}/notifications", headers=admin_headers)
        assert r.status_code == 200 and isinstance(r.json(), list)
        r = requests.get(f"{API}/notifications/unread-count", headers=admin_headers)
        assert r.status_code == 200 and "count" in r.json()
        # mark all
        r = requests.post(f"{API}/notifications/read-all", headers=admin_headers)
        assert r.status_code == 200

    def test_isolation(self, admin_headers, recruiter_headers):
        a = requests.get(f"{API}/notifications", headers=admin_headers).json()
        r = requests.get(f"{API}/notifications", headers=recruiter_headers).json()
        # different recipient_id -> no overlap by id
        ids_a = {x.get("id") for x in a}
        ids_r = {x.get("id") for x in r}
        assert not (ids_a & ids_r)


# ============ FOLLOWUPS BOARD ============
class TestFollowupsBoard:
    def test_board_counts_and_tabs(self, admin_headers):
        r = requests.get(f"{API}/followups/board?tab=due_today", headers=admin_headers)
        assert r.status_code == 200
        b = r.json()
        assert "items" in b and "counts" in b
        keys = set(b["counts"].keys())
        assert {"due_today", "overdue", "tomorrow", "upcoming", "missed", "completed"}.issubset(keys)


# ============ TASKS ============
class TestTasks:
    def test_summary_and_crud(self, admin_headers):
        r = requests.get(f"{API}/tasks/summary", headers=admin_headers)
        assert r.status_code == 200
        s = r.json()
        assert set(("pending", "high_priority", "completed")).issubset(s.keys())
        # create
        r = requests.post(f"{API}/tasks", headers=admin_headers,
                          json={"title": "TEST_Task11", "category": "general_admin", "priority": "high"})
        assert r.status_code in (200, 201), r.text
        tid = r.json()["id"]
        # mark done
        r = requests.put(f"{API}/tasks/{tid}", headers=admin_headers, json={"status": "done"})
        assert r.status_code == 200 and r.json()["status"] == "done"
        # reopen
        r = requests.put(f"{API}/tasks/{tid}", headers=admin_headers, json={"status": "pending"})
        assert r.status_code == 200 and r.json()["status"] == "pending"
        # delete
        r = requests.delete(f"{API}/tasks/{tid}", headers=admin_headers)
        assert r.status_code == 200


# ============ INTERVIEWS / JOININGS ============
class TestInterviewsJoinings:
    def test_lists(self, admin_headers):
        for path in ("/interviews", "/joinings"):
            r = requests.get(f"{API}{path}", headers=admin_headers)
            assert r.status_code == 200, f"{path} -> {r.status_code}"
            assert isinstance(r.json(), list)


# ============ GLOBAL SEARCH ============
def test_global_search(admin_headers):
    r = requests.get(f"{API}/search?q=Ra", headers=admin_headers)
    assert r.status_code == 200
    assert "results" in r.json()


# ============ ORG SETTINGS ============
def test_org_settings(admin_headers):
    r = requests.get(f"{API}/org-settings", headers=admin_headers)
    assert r.status_code == 200
    body = r.json()
    for k in ("agency_name", "targets", "lead_sources", "priorities", "lead_statuses"):
        assert k in body
