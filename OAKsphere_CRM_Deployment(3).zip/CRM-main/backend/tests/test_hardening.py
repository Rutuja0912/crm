"""Independent API/service regression tests using mongomock-motor.
Persistence is re-read, not inferred from HTTP 200. Real Mongo transaction behavior
and remote providers must additionally pass the deployment checks.
"""
from contextlib import asynccontextmanager
from datetime import datetime,timezone,timedelta
import hashlib,hmac,json
import pytest
from httpx import AsyncClient,ASGITransport
from mongomock_motor import AsyncMongoMockClient
from pydantic import ValidationError
from starlette.requests import Request
import server
from core import transactions as tx
from core.config import settings
from core.errors import AppError
from core.security import hash_password
from core.query import literal_search
from core.timeutil import day_bounds,next_working_day
from models.entities import UserCreate,UserUpdate,now_utc
from models.recruitment import LeadCreate,LeadUpdate,TaskUpdate,TaskCreate,InterviewUpdate,InterviewCreate,JoiningUpdate,VendorInput,TemplateInput,FollowupComplete
from services import recruitment_service as rs,modules_service as ms,scope_service as ss,user_service as us,permission_service as ps,notify_service
from api import deps,auth_routes,user_routes,role_routes,modules_routes,recruitment_routes,dashboard_routes,settings_routes,audit_routes,webhook_routes
REAL_ATOMIC=tx.atomic
pytestmark=pytest.mark.anyio
@pytest.fixture
def anyio_backend(): return 'asyncio'
@pytest.fixture
async def env(monkeypatch):
    db=AsyncMongoMockClient(tz_aware=True)['hardening']
    @asynccontextmanager
    async def no_session(): yield None
    for module in (tx,rs,ms): monkeypatch.setattr(module,'atomic',no_session)
    for module in (server,deps,auth_routes,user_routes,role_routes,modules_routes,recruitment_routes,dashboard_routes,settings_routes,audit_routes,webhook_routes): monkeypatch.setattr(module,'db',db)
    users={
      'admin':{'id':'admin','name':'Admin','role':'admin','team_id':None},
      'leader':{'id':'leader','name':'Leader','role':'team_leader','team_id':'east','permission_overrides':{'allow':['users.manage','imports.run','leads.auto_distribute']}},
      'otherleader':{'id':'otherleader','name':'Other Leader','role':'team_leader','team_id':'west'},
      'own':{'id':'own','name':'Own','role':'recruiter','manager_id':'leader','team_id':'east'},
      'peer':{'id':'peer','name':'Peer','role':'recruiter','manager_id':'leader','team_id':'east'},
      'foreign':{'id':'foreign','name':'Foreign','role':'recruiter','manager_id':'otherleader','team_id':'west'},
      'restricted':{'id':'restricted','name':'Directory Manager','role':'restricted'},
      'inactive':{'id':'inactive','name':'Inactive','role':'recruiter','is_active':False}}
    for key,user in users.items():
        user.setdefault('is_active',True);user.setdefault('permission_overrides',{'allow':[],'deny':[]});user['email']=key+'@example.com'
        await db.users.insert_one(dict(user))
    await db.roles.insert_one({'key':'restricted','name':'Directory','permissions':['users.manage','recruiters.view']})
    for role,perms in ps.ROLE_DEFAULTS.items(): await db.roles.insert_one({'key':role,'name':role,'permissions':perms,'is_system':True})
    await db.webhook_events.create_index('event_key',unique=True)
    await db.applications.create_index('intake_key',unique=True,sparse=True)
    await db.lead_tags.create_index('normalized_key',unique=True,sparse=True)
    state={'user':users['admin']}
    async def actor(): return state['user']
    server.app.dependency_overrides[deps.get_current_user]=actor
    async with AsyncClient(transport=ASGITransport(app=server.app),base_url='http://test') as client: yield db,users,state,client
    server.app.dependency_overrides.clear()
async def perms(db,users,key='admin'): return await ps.get_effective_permissions(db,users[key])
async def lead(db,users,owner='own',phone='9876543210',**kwargs):
    return await rs.create_lead(db,users['admin'],await perms(db,users),LeadCreate(name='Candidate '+phone,phone=phone,owner_id=owner,**kwargs))

@pytest.mark.parametrize('model,payload',[
 (LeadCreate,{'name':' ','phone':'9876543210'}),(LeadCreate,{'name':'Valid','phone':'abc'}),
 (LeadCreate,{'name':'Valid','phone':'9876543210','priority':'hot'}),(LeadCreate,{'name':'Valid','phone':'9876543210','status':'joined'}),
 (LeadUpdate,{'name':''}),(LeadUpdate,{'phone':None}),(LeadUpdate,{'priority':'hot'}),(LeadUpdate,{'gender':'arbitrary'}),
 (TaskUpdate,{'status':'surprise'}),(TaskCreate,{'title':'T','category':'anything'}),
 (InterviewUpdate,{'confirmation':'unknown'}),(InterviewUpdate,{'confirmation':None}),(InterviewUpdate,{'silent':'field'}),
 (JoiningUpdate,{'status':'fake'}),(JoiningUpdate,{'unrecognized_salary':'123'}),(UserUpdate,{'role':None}),
 (VendorInput,{'company':'V','stage':'fake'}),(TemplateInput,{'name':'T','body':'B','channel':'sms'})])
async def test_strict_models(model,payload):
    with pytest.raises(ValidationError): model(**payload)
async def test_default_interview_type(): assert InterviewCreate(scheduled_at=now_utc()).mode=='telephonic'
@pytest.mark.parametrize('actor',['own','restricted'])
async def test_directory_not_candidate_scope(env,actor):
    db,users,_,_=env
    users[actor]['permission_overrides']['allow']=['users.manage','recruiters.view']
    assert await ss.recruiter_scope_ids(db,users[actor],await perms(db,users,actor))==(['own'] if actor=='own' else [])
@pytest.mark.parametrize('actor',['own','leader','restricted'])
@pytest.mark.parametrize('action',['get_effective','list_sessions','revoke_all_sessions','set_permission_overrides'])
async def test_user_target_scope(env,actor,action):
    db,users,_,_=env;args=(db,users[actor],'foreign')
    if action=='set_permission_overrides': args+=(['leads.view_all'],[])
    with pytest.raises(AppError) as exc: await getattr(us,action)(*args)
    assert exc.value.status_code==403
@pytest.mark.parametrize('actor',['leader','restricted'])
async def test_nonadmin_cannot_create_admin(env,actor):
    db,users,_,_=env
    with pytest.raises(AppError) as exc: await us.create_user(db,users[actor],UserCreate(name='Escalate',email='new@example.com',password='ValidPass123!',role='admin'))
    assert exc.value.status_code==403 and await db.users.count_documents({'email':'new@example.com'})==0
async def test_permission_ceiling_and_last_admin(env):
    db,users,_,_=env
    with pytest.raises(AppError): await us.set_permission_overrides(db,users['leader'],'own',['integrations.manage'],[])
    with pytest.raises(AppError): await us.update_user(db,users['admin'],'admin',UserUpdate(is_active=False))
    with pytest.raises(AppError): await us.update_user(db,users['leader'],'own',UserUpdate(manager_id='otherleader'))
    assert (await db.users.find_one({'id':'admin'}))['is_active']
@pytest.mark.parametrize('method,path,payload',[
 ('POST','/roles',{'key':'escape','name':'Escape','permissions':['integrations.manage']}),('POST','/roles/admin/clone',{'key':'escape','name':'Escape'}),
 ('PUT','/roles/team_leader',{'permissions':['integrations.manage']}),('PUT','/roles/recruiter/rename',{'name':'New'}),('POST','/roles/recruiter/reset',{}),('DELETE','/roles/recruiter',None)])
async def test_role_mutation_admin_only(env,method,path,payload):
    db,users,state,client=env;state['user']=users['leader']
    assert (await client.request(method,'/api'+path,json=payload)).status_code==403
@pytest.mark.parametrize('actor,expected',[('admin',3),('leader',2),('own',1),('restricted',0)])
async def test_application_list_scope(env,actor,expected):
    db,users,state,client=env
    for key in ['own','peer','foreign']: await db.applications.insert_one({'id':key,'name':key,'owner_id':key,'phone':'9876543210','status':'new'})
    state['user']=users[actor];result=await client.get('/api/applications')
    if actor=='restricted': assert result.status_code==403
    else: assert result.status_code==200 and len(result.json())==expected
@pytest.mark.parametrize('action',['shortlist','archive','convert'])
async def test_application_idor(env,action):
    db,users,state,client=env
    await db.applications.insert_one({'id':'app','owner_id':'foreign','status':'new','name':'Candidate','phone':'9876543210'})
    users['leader']['permission_overrides']['allow'].append('leads.delete');state['user']=users['leader']
    if action=='shortlist': result=await client.put('/api/applications/app/status',json={'status':'shortlisted'})
    elif action=='archive': result=await client.delete('/api/applications/app')
    else: result=await client.post('/api/applications/app/convert',json={})
    assert result.status_code==403 and (await db.applications.find_one({'id':'app'}))['status']=='new'
async def test_conversion_canonical_team_private_duplicate(env):
    db,users,state,client=env;hidden=await lead(db,users,'foreign')
    await db.applications.insert_one({'id':'app','owner_id':'own','status':'new','name':'Candidate','phone':'9876543210','role':'Engineer','campaign':'campaign'})
    state['user']=users['own'];result=await client.post('/api/applications/app/convert',json={})
    assert result.status_code==200,result.text
    actual=result.json()['lead'];assert actual['id']!=hidden['id'] and actual['team_id']=='east' and actual['campaign']=='campaign'
    again=await client.post('/api/applications/app/convert',json={})
    assert again.json()['already'] and again.json()['lead']['id']==actual['id'] and await db.leads.count_documents({})==2
async def test_conversion_bad_assignment_no_write(env):
    db,users,state,client=env
    await db.applications.insert_one({'id':'app','owner_id':'own','status':'new','name':'Candidate','phone':'9876543210'})
    state['user']=users['leader'];result=await client.post('/api/applications/app/convert',json={'assign_to':'foreign'})
    assert result.status_code==403 and await db.leads.count_documents({})==0
async def test_archive_operational_exclusion(env):
    db,users,state,client=env;candidate=await lead(db,users,first_followup_at=now_utc()+timedelta(hours=1))
    await db.interviews.insert_one({'id':'iv','lead_id':candidate['id'],'recruiter_id':'own','status':'scheduled','scheduled_at':now_utc()})
    assert (await client.delete('/api/leads/'+candidate['id'])).status_code==200
    saved=await db.leads.find_one({'id':candidate['id']});assert saved['archived'] and saved['archived_by']=='admin' and saved['archived_at']
    assert (await client.get('/api/leads')).json()['total']==0
    assert (await client.get('/api/lead-inbox')).json()['items']==[]
    assert (await client.get('/api/search',params={'q':'Candidate'})).json()['results']==[]
    assert (await client.get('/api/interviews')).json()==[]
    assert (await client.get('/api/followups/board')).json()['items']==[]
    dash=(await client.get('/api/dashboard/overview')).json();assert dash['kpis']['fresh_leads']==0 and dash['kpis']['interviews']==0
    assert (await client.get('/api/leads/'+candidate['id'])).status_code==404
    assert len((await client.get('/api/leads/export')).text.splitlines())==1
async def test_auto_distribution_preview_safe_default(env):
    db,users,state,client=env;owned=await lead(db,users);unassigned=await lead(db,users,'','9876543211');final=await lead(db,users,'','9876543212')
    await db.leads.update_one({'id':final['id']},{'$set':{'status':'joined'}})
    result=await client.post('/api/leads/auto-distribute',json={'preview':True});assert result.status_code==200,result.text
    assert result.json()['lead_ids']==[unassigned['id']]
    assert (await db.leads.find_one({'id':unassigned['id']}))['owner_id'] is None
    result=await client.post('/api/leads/auto-distribute',json={});assert result.status_code==200,result.text
    assert (await db.leads.find_one({'id':owned['id']}))['owner_id']=='own'
    assert (await db.leads.find_one({'id':final['id']}))['owner_id'] is None and await db.notifications.count_documents({})>=1
    assert (await client.post('/api/leads/auto-distribute',json={'lead_ids':[owned['id']]})).status_code==409
    assert (await client.post('/api/leads/auto-distribute',json={'lead_ids':[final['id']],'confirm_redistribution':True})).status_code==422
async def test_assignable_without_directory_permission(env):
    db,users,state,client=env;users['own']['permission_overrides']['allow']=['leads.assign'];state['user']=users['own']
    assert (await client.get('/api/recruiters')).status_code==403
    result=await client.get('/api/recruiters/assignable');assert result.status_code==200 and [x['id'] for x in result.json()]==['own']
async def test_bulk_authorizes_every_record_before_write(env):
    db,users,state,client=env;own=await lead(db,users);foreign=await lead(db,users,'foreign','9876543211');state['user']=users['leader']
    result=await client.post('/api/leads/assign',json={'lead_ids':[own['id'],foreign['id']],'to_owner_id':'peer'})
    assert result.status_code==403 and (await db.leads.find_one({'id':own['id']}))['owner_id']=='own'
async def test_interview_persistence_prevalidation(env):
    db,users,state,client=env;candidate=await lead(db,users)
    created=await client.post(f"/api/leads/{candidate['id']}/interviews",json={'scheduled_at':now_utc().isoformat()});assert created.status_code==200,created.text
    iid=created.json()['id'];result=await client.put('/api/interviews/'+iid,json={'confirmation':'confirmed'})
    assert result.status_code==200 and (await db.interviews.find_one({'id':iid}))['confirmation']=='confirmed'
    assert (await client.put('/api/interviews/'+iid,json={'status':'selected'})).status_code==400
    assert (await db.interviews.find_one({'id':iid}))['status']=='scheduled'
    result=await client.put('/api/interviews/'+iid,json={'status':'selected','expected_joining_date':(now_utc()+timedelta(days=7)).isoformat()});assert result.status_code==200,result.text
    assert (await db.leads.find_one({'id':candidate['id']}))['status']=='selected'
    assert (await client.get('/api/interviews')).json()[0]['phone']=='9876543210'
async def test_joining_contract_persisted(env):
    db,users,state,client=env;candidate=await lead(db,users)
    created=await client.post(f"/api/leads/{candidate['id']}/joinings",json={'joining_date':now_utc().isoformat()});assert created.status_code==200,created.text
    jid=created.json()['id']
    for status in ['documents_pending','offer_pending','offer_released','joining_confirmed']: assert (await client.put('/api/joinings/'+jid,json={'status':status})).status_code==200
    result=await client.put('/api/joinings/'+jid,json={'status':'joined','confirmation':'confirmed','actual_joining_date':now_utc().isoformat(),'salary':'32000','remarks':'Signed','notes':'Verified'});assert result.status_code==200,result.text
    saved=(await client.get('/api/joinings')).json()[0];assert saved['salary']=='32000' and saved['remarks']=='Signed' and saved['notes']=='Verified' and saved['actual_joining_date']
    assert (await db.leads.find_one({'id':candidate['id']}))['status']=='joined'
    assert (await client.put('/api/joinings/'+jid,json={'status':'offer_pending'})).status_code==422
async def test_followup_prevalidation(env):
    db,users,_,_=env;candidate=await lead(db,users,first_followup_at=now_utc());fu=await db.followups.find_one({'lead_id':candidate['id']})
    with pytest.raises(AppError): await rs.complete_followup(db,users['admin'],await perms(db,users),fu['id'],FollowupComplete(mode='final',final_status='joined'))
    assert (await db.followups.find_one({'id':fu['id']}))['status']=='pending'
async def test_standalone_fails_before_writes(env,monkeypatch):
    db,users,_,_=env
    async def unavailable(): return False
    monkeypatch.setattr(tx,'supports_transactions',unavailable);monkeypatch.setattr(tx,'atomic',REAL_ATOMIC)
    with pytest.raises(AppError) as exc: await rs.create_lead(db,users['admin'],await perms(db,users),LeadCreate(name='Test',phone='9876543210'))
    assert exc.value.status_code==503 and await db.leads.count_documents({})==0
@pytest.mark.parametrize('actor',['peer','leader','admin'])
async def test_import_ownership_even_for_admin(env,actor):
    db,users,_,_=env;batch=await ms.import_preview(db,users['own'],await perms(db,users,'own'),'leads.csv',b'Name,Phone\nCandidate,9876543210\n')
    with pytest.raises(AppError) as exc: await ms.import_commit(db,users[actor],await perms(db,users,actor),batch['batch_id'],{'Name':'name','Phone':'phone'},{'assign':'unassigned'})
    assert exc.value.status_code==404
async def test_import_validation_expiry_and_idempotency(env):
    db,users,_,_=env;p=await perms(db,users)
    batch=await ms.import_preview(db,users['admin'],p,'leads.csv',b'Name,Phone,Priority,Gender\nGood,9876543210,high,male\nBad,9876543211,hot,female\nAgain,9876543210,medium,female\n')
    mapping={'Name':'name','Phone':'phone','Priority':'priority','Gender':'gender'};rules={'assign':'specific','recruiter_id':'own','duplicates':'skip','invalid':'flag'}
    result=await ms.import_commit(db,users['admin'],p,batch['batch_id'],mapping,rules)
    assert result['imported']==1 and result['validation_errors']==1 and result['skipped_duplicates']==1
    assert (await db.leads.find_one({}))['team_id']=='east'
    assert await ms.import_commit(db,users['admin'],p,batch['batch_id'],mapping,rules)==result
    await db.import_batches.update_one({'id':batch['batch_id']},{'$set':{'expires_at':now_utc()-timedelta(seconds=1)}})
    with pytest.raises(AppError): await ms.import_commit(db,users['admin'],p,batch['batch_id'],mapping,rules)
async def test_tag_duplicate_rename_cascade(env):
    db,users,_,_=env;candidate=await lead(db,users,tags=['First']);first=await ms.save_tag(db,{'name':'First'});await ms.save_tag(db,{'name':'Second'})
    with pytest.raises(AppError): await ms.save_tag(db,{'name':'SECOND'},first['id'])
    assert (await db.leads.find_one({'id':candidate['id']}))['tags']==['First']
    await ms.save_tag(db,{'name':'Renamed'},first['id']);assert (await db.leads.find_one({'id':candidate['id']}))['tags']==['Renamed']
@pytest.mark.parametrize('path',['/jobs/missing','/clients/missing','/templates/missing','/applications/missing','/vendors/missing'])
async def test_nonexistent_archive_404(env,path): assert (await env[3].delete('/api'+path)).status_code==404
async def test_vendor_soft_archive(env):
    db,users,_,client=env;row=await ms.save_vendor(db,users['admin'],await perms(db,users),{'company':'Vendor'})
    assert (await client.delete('/api/vendors/'+row['id'])).status_code==200 and (await db.vendors.find_one({'id':row['id']}))['archived']
    assert (await client.get('/api/vendors')).json()==[]
@pytest.mark.parametrize('path',['/leads','/jobs','/clients','/vendors','/templates','/applications','/users','/search'])
async def test_literal_regex_search(env,path):
    result=await env[3].get('/api'+path,params={'q':'[[','search':'['});assert result.status_code==200,result.text
    with pytest.raises(AppError): literal_search('x'*161)
async def test_timezone_calendar_settings(env):
    db,users,_,client=env
    result=await client.put('/api/settings',json={'company_name':'One Name','timezone':'Asia/Kolkata','working_days':[0,1,2,3,4],'work_start':'10:00','holidays':[]});assert result.status_code==200,result.text
    org=(await client.get('/api/org-settings')).json();assert org['agency_name']=='One Name' and org['priorities']==['low','medium','high']
    friday=datetime(2026,9,18,12,0,tzinfo=timezone.utc);assert (await next_working_day(db,friday)).isoformat()=='2026-09-21T04:30:00+00:00'
    start,end=day_bounds('Asia/Kolkata',friday);assert start.hour==18 and start.day==17 and end.day==18
    assert (await client.put('/api/settings',json={'timezone':'Mars/Olympus'})).status_code==422
async def test_notification_privacy_and_read_state(env):
    db,users,state,client=env
    await notify_service.notify(db,recipient_id='own',type_='test',title='Private');await notify_service.notify(db,recipient_id='peer',type_='test',title='Other');state['user']=users['own']
    rows=(await client.get('/api/notifications')).json();assert len(rows)==1 and rows[0]['title']=='Private'
    assert (await client.get('/api/notifications/unread-count')).json()['count']==1
    assert (await client.post('/api/notifications/'+rows[0]['id']+'/read')).status_code==200
    assert (await client.get('/api/notifications/unread-count')).json()['count']==0
    assert (await client.post('/api/notifications/missing/read')).status_code==404
META={'page_id':'12345','access_token':'token-value','webhook_verify_token':'verification-123456','app_secret':'secret-value-123456'}
async def test_integration_partial_edits_and_validation(env,monkeypatch):
    db,users,_,client=env;assert (await client.put('/api/integrations/facebook',json=META)).status_code==200
    stored=await db.integrations.find_one({'key':'facebook'});assert not stored['connected'];encrypted=stored['secrets_enc']['access_token']
    await client.put('/api/integrations/facebook',json={'access_token':''});assert (await db.integrations.find_one({'key':'facebook'}))['secrets_enc']['access_token']==encrypted
    async def verified(path,creds,fields=None): return {'id':path}
    monkeypatch.setattr(ms,'meta_get',verified);result=await client.post('/api/integrations/facebook/test');assert result.status_code==200 and result.json()['remote_tested']
    async def rejected(*a,**kw): raise AppError('provider_rejected','Provider rejected credentials',502)
    monkeypatch.setattr(ms,'meta_get',rejected);assert (await client.post('/api/integrations/facebook/test')).status_code==502
    stored=await db.integrations.find_one({'key':'facebook'});assert not stored['connected'] and stored['last_error'] and stored['last_test_at'] and stored['last_success_at']
    public=(await client.get('/api/integrations')).text;assert META['access_token'] not in public and META['app_secret'] not in public and encrypted not in public
    assert (await client.post('/api/integrations/unknown/disconnect')).status_code==404
    await client.post('/api/integrations/facebook/disconnect');assert (await db.integrations.find_one({'key':'facebook'}))['secrets_enc']=={}
async def test_forms_secret_idempotency_and_bounds(env):
    db,users,_,client=env;secret='forms-shared-secret-12345';await client.put('/api/integrations/google_forms',json={'shared_secret':secret})
    tested=await client.post('/api/integrations/google_forms/test');assert tested.status_code==200 and tested.json()['remote_tested'] is False
    data={'name':'Applicant','phone':'9876543210','email':'person@example.com','role':'Engineer','provider_lead_id':'event-1','utm_campaign':'campaign'}
    assert (await client.post('/api/webhooks/google_forms',json=data)).status_code==403
    for _ in range(2):
        result=await client.post('/api/webhooks/google_forms',json=data,headers={'X-Intake-Secret':secret});assert result.status_code==200,result.text
    assert await db.applications.count_documents({})==1
    saved=await db.applications.find_one({});assert saved['owner_id'] is None and saved['source']=='google_form' and saved['utm_campaign']=='campaign'
    assert (await client.post('/api/intake/applications',json={**data,'owner_id':'admin'},headers={'X-Intake-Secret':secret})).status_code==422
    assert (await client.post('/api/webhooks/google_forms',content=b'x'*262145,headers={'X-Intake-Secret':secret})).status_code==413
async def test_meta_signature_challenge_and_deduplication(env,monkeypatch):
    db,users,_,client=env;await client.put('/api/integrations/facebook',json=META)
    challenge=await client.get('/api/webhooks/facebook',params={'hub.mode':'subscribe','hub.verify_token':META['webhook_verify_token'],'hub.challenge':'123'});assert challenge.status_code==200 and challenge.text=='123'
    assert (await client.get('/api/webhooks/facebook',params={'hub.mode':'subscribe','hub.verify_token':'bad','hub.challenge':'123'})).status_code==403
    calls=[]
    async def provider(path,creds,fields=None):
        calls.append(path);return {'id':path,'field_data':[{'name':'full_name','values':['Candidate']},{'name':'phone_number','values':['9876543210']}]}
    monkeypatch.setattr(ms,'meta_get',provider)
    raw=json.dumps({'entry':[{'id':'12345','changes':[{'field':'leadgen','value':{'leadgen_id':'555'}}]}]}).encode()
    assert (await client.post('/api/webhooks/facebook',content=raw)).status_code==403 and await db.applications.count_documents({})==0
    signature='sha256='+hmac.new(META['app_secret'].encode(),raw,hashlib.sha256).hexdigest()
    for _ in range(2):
        result=await client.post('/api/webhooks/facebook',content=raw,headers={'X-Hub-Signature-256':signature});assert result.status_code==200,result.text
    assert calls==['555'] and await db.applications.count_documents({})==1
async def test_cookie_auth_csrf_refresh_logout(env):
    db,users,state,client=env;server.app.dependency_overrides.clear();await db.users.update_one({'id':'admin'},{'$set':{'password_hash':hash_password('ValidPass123!')}})
    csrf=(await client.get('/api/auth/csrf')).json()['csrf_token'];result=await client.post('/api/auth/login',json={'email':'admin@example.com','password':'ValidPass123!'})
    assert result.status_code==200,result.text
    assert 'access_token' not in result.json() and all('HttpOnly' in c for c in result.headers.get_list('set-cookie'))
    assert (await client.get('/api/auth/me')).status_code==200
    assert (await client.post('/api/auth/logout')).status_code==403
    assert (await client.post('/api/auth/refresh',headers={'X-CSRF-Token':csrf})).status_code==200
    assert (await client.post('/api/auth/logout',headers={'X-CSRF-Token':csrf})).status_code==200
    assert (await client.get('/api/auth/me')).status_code==401
async def test_trusted_proxy_headers(monkeypatch):
    monkeypatch.setattr(settings,'trusted_proxies',[])
    request=Request({'type':'http','client':('203.0.113.5',999),'headers':[(b'x-forwarded-for',b'1.2.3.4')]});assert deps.get_client_ip(request)=='203.0.113.5'
    monkeypatch.setattr(settings,'trusted_proxies',['10.0.0.0/8'])
    request=Request({'type':'http','client':('10.0.0.1',999),'headers':[(b'x-forwarded-for',b'1.1.1.1, 203.0.113.5, 10.0.0.2')]});assert deps.get_client_ip(request)=='203.0.113.5'


@pytest.mark.parametrize('authority',['leads.transfer','leads.auto_distribute'])
async def test_create_assignment_does_not_inherit_other_actions(env,authority):
    db,users,state,client=env
    users['leader']['permission_overrides']={'allow':[authority],'deny':['leads.assign']}
    state['user']=users['leader']
    result=await client.post('/api/leads',json={'name':'Denied','phone':'9876543210','owner_id':'peer'})
    assert result.status_code==403 and await db.leads.count_documents({})==0

async def test_lead_clear_optional_fields_persists(env):
    db,users,state,client=env
    candidate=await lead(db,users,email='old@example.com',alt_phone='9876543211',gender='male')
    result=await client.patch('/api/leads/'+candidate['id'],json={'email':None,'alt_phone':None,'gender':None,'city':None})
    assert result.status_code==200,result.text
    saved=(await client.get('/api/leads/'+candidate['id'])).json()
    assert all(saved[key] is None for key in ['email','alt_phone','gender','city'])

async def test_legacy_call_uses_status_engine(env):
    db,users,state,client=env
    candidate=await lead(db,users,first_followup_at=now_utc()+timedelta(days=1))
    path='/api/leads/'+candidate['id']+'/calls'
    rejected=await client.post(path,json={'outcome':'not_interested'})
    assert rejected.status_code==400 and await db.calls.count_documents({})==0
    saved=await client.post(path,json={'outcome':'not_interested','notes':'Candidate declined'})
    assert saved.status_code==200,saved.text
    actual=(await client.get('/api/leads/'+candidate['id'])).json()
    assert actual['status_history'][-1]['status']=='not_interested' and actual['next_followup_at'] is None
    assert await db.followups.count_documents({'status':'pending'})==0

@pytest.mark.parametrize('metadata,contacts',[(None,[]),({},None),({},[{'wa_id':'919876543210','profile':None}])])
async def test_malformed_whatsapp_is_validation_error(env,metadata,contacts):
    db,users,state,client=env
    credentials={'phone_number_id':'123','waba_id':'456','access_token':'x'*40,'webhook_verify_token':'v'*32,'app_secret':'s'*32}
    await ms.save_integration(db,users['admin'],'whatsapp',credentials)
    raw=json.dumps({'entry':[{'id':'456','changes':[{'value':{'metadata':metadata,'contacts':contacts}}]}]}).encode()
    signature='sha256='+hmac.new(credentials['app_secret'].encode(),raw,hashlib.sha256).hexdigest()
    result=await client.post('/api/webhooks/whatsapp',content=raw,headers={'x-hub-signature-256':signature})
    assert result.status_code==422,result.text
    assert await db.applications.count_documents({})==0

async def test_action_cards_follow_candidate_and_module_permissions(env):
    db,users,state,client=env
    state['user']=users['own'];cards=(await client.get('/api/action-required')).json()['cards']
    assert not any(c['key']=='below_target' for c in cards)
    assert all('/admin/leads?' not in c['action_url'] for c in cards)
    users['own']['permission_overrides']['deny']=['followups.manage','interviews.manage','joinings.manage']
    cards=(await client.get('/api/action-required')).json()['cards']
    assert not any(c['key'] in ['overdue_followups','unconfirmed_interviews','unconfirmed_joinings'] for c in cards)

async def test_audit_actor_filter_cannot_expand_self_scope(env):
    db,users,state,client=env
    users['own']['permission_overrides']['allow']=['audit.view'];state['user']=users['own']
    await db.audit_logs.insert_many([{'id':u,'actor_id':u,'action':'view','created_at':now_utc()} for u in ['own','foreign']])
    result=await client.get('/api/audit-logs',params={'actor_id':'foreign'})
    assert result.status_code==200 and result.json()['total']==0
    own=await client.get('/api/audit-logs',params={'actor_id':'own'})
    assert own.json()['total']==1
    exported=await client.get('/api/audit-logs/export',params={'actor_id':'foreign'})
    assert len(exported.text.splitlines())==1

async def test_audit_dates_use_inclusive_org_day_and_reject_invalid(env):
    db,users,state,client=env
    await db.organization_settings.insert_one({'key':'org','timezone':'Asia/Kolkata'})
    await db.audit_logs.insert_many([{'id':str(i),'actor_id':'admin','created_at':datetime.fromisoformat(t)} for i,t in enumerate(['2026-09-18T18:29:59+00:00','2026-09-18T18:30:00+00:00'])])
    result=await client.get('/api/audit-logs',params={'date_from':'2026-09-18','date_to':'2026-09-18'})
    assert result.status_code==200 and result.json()['total']==1,result.text
    assert (await client.get('/api/audit-logs',params={'date_from':'bogus'})).status_code==422

async def test_report_lineups_count_day_history_not_current_inventory(env):
    db,users,state,client=env
    candidate=await lead(db,users)
    await db.leads.update_one({'id':candidate['id']},{'$set':{'status':'lineup','status_history':[{'status':'lineup','at':now_utc()-timedelta(days=2)}]}})
    report=await ms.reports(db,users['admin'],await perms(db,users))
    assert next(r for r in report['leaderboard'] if r['recruiter_id']=='own')['lineups']==0
    await db.leads.update_one({'id':candidate['id']},{'$set':{'status':'selected'},'$push':{'status_history':{'status':'lineup','at':now_utc()}}})
    report=await ms.reports(db,users['admin'],await perms(db,users))
    assert next(r for r in report['leaderboard'] if r['recruiter_id']=='own')['lineups']==1

async def test_password_reset_single_use_hash_and_revocation(env):
    from services import auth_service
    from core.security import verify_password
    db,users,state,client=env
    await db.sessions.insert_one({'id':'old','user_id':'own','revoked':False})
    reset=await auth_service.create_password_reset(db,users['own']['email'])
    token=await db.password_reset_tokens.find_one({})
    assert reset['raw'] not in str(token)
    response=await client.post('/api/auth/reset-password',json={'token':reset['raw'],'password':'UpdatedPass123!'})
    assert response.status_code==200,response.text
    assert verify_password('UpdatedPass123!',(await db.users.find_one({'id':'own'}))['password_hash'])
    assert (await db.sessions.find_one({'id':'old'}))['revoked']
    assert (await client.post('/api/auth/reset-password',json={'token':reset['raw'],'password':'AnotherPass123!'})).status_code==400
    unknown=await client.post('/api/auth/forgot-password',json={'email':'missing@example.com'})
    known=await client.post('/api/auth/forgot-password',json={'email':'own@example.com'})
    assert unknown.status_code==known.status_code==200 and unknown.json()==known.json()

async def test_change_password_retains_only_calling_session(env):
    from services import auth_service
    db,users,state,client=env
    await db.users.update_one({'id':'own'},{'$set':{'password_hash':hash_password('OriginalPass123!')}})
    await db.sessions.insert_many([{'id':i,'user_id':'own','revoked':False} for i in ['current','other']])
    await auth_service.change_password(db,{**users['own'],'session_id':'current'},'OriginalPass123!','UpdatedPass123!')
    assert not (await db.sessions.find_one({'id':'current'}))['revoked']
    assert (await db.sessions.find_one({'id':'other'}))['revoked']

async def test_code_collision_retries_whole_workflow(env,monkeypatch):
    from pymongo.errors import DuplicateKeyError
    db,users,state,client=env
    original=type(db.leads).insert_one;attempts=[]
    async def insert(collection,doc,**kwargs):
        if collection.name!='leads': return await original(collection,doc,**kwargs)
        attempts.append(doc['lead_code'])
        if len(attempts)==1: raise DuplicateKeyError('collision',11000,{'keyPattern':{'lead_code':1}})
        return await original(collection,doc,**kwargs)
    monkeypatch.setattr(type(db.leads),'insert_one',insert)
    result=await lead(db,users)
    assert len(attempts)==2 and attempts[0]!=attempts[1]
    assert await db.leads.count_documents({})==1 and result['lead_code']==attempts[-1]

async def test_dashboard_recruiter_filter_limits_call_totals(env):
    db,users,state,client=env
    own=await lead(db,users,'own','9876543210');peer=await lead(db,users,'peer','9876543211')
    await db.calls.insert_many([{'id':c['id'],'lead_id':c['id'],'recruiter_id':c['owner_id'],'connected':True,'created_at':now_utc()} for c in [own,peer]])
    result=await client.get('/api/dashboard/overview',params={'recruiter_id':'own'})
    assert result.status_code==200 and result.json()['kpis']['calls_today']==1,result.text
    assert result.json()['kpis']['connected']==1

async def test_csrf_rejection_has_cors_headers(env):
    db,users,state,client=env
    origin=settings.cors_origins[0]
    result=await client.post('/api/auth/login',json={'email':'own@example.com','password':'WrongPass123!'},headers={'origin':origin})
    assert result.status_code==403 and result.headers['access-control-allow-origin']==origin
    assert result.json()['error']['code']=='csrf'

async def test_tag_migration_preserves_catalog_references_and_is_idempotent(env,monkeypatch):
    from core import database
    db,_,_,_=env
    monkeypatch.setattr(database,'db',db)
    await db.lead_tags.insert_many([{'id':'canonical','name':'Sales','created_at':now_utc()}, {'id':'duplicate','name':' sales ','created_at':now_utc()}])
    await db.leads.insert_one({'id':'tagged','lead_code':'LD-MIGRATION','tags':['sales','Sales','Legacy']})
    await database.ensure_indexes()
    await database.ensure_indexes()
    assert (await db.leads.find_one({'id':'tagged'}))['tags']==['Sales','Legacy']
    assert (await db.lead_tags.find_one({'id':'duplicate'}))['archived'] is True

@pytest.mark.parametrize('patch,expected',[
    ({},200),({'aud':'another-client'},401),({'iss':'https://attacker.example'},401),
    ({'exp':0},401),({'email_verified':'false'},401),({'email':'absent@example.com'},403)])
async def test_google_oidc_validation_and_cookie_contract(env,monkeypatch,patch,expected):
    import httpx
    import time
    db,users,_,client=env
    monkeypatch.setattr(settings,'google_enabled',True)
    monkeypatch.setattr(settings,'google_client_id','public-client-id')
    info={'aud':'public-client-id','iss':'https://accounts.google.com','exp':str(time.time()+300),'email_verified':'true','email':users['admin']['email'],**patch}
    class Provider:
        def __init__(self,**kwargs): pass
        async def __aenter__(self): return self
        async def __aexit__(self,*args): pass
        async def get(self,url,params):
            assert url=='https://oauth2.googleapis.com/tokeninfo'
            return httpx.Response(200,json=info)
    monkeypatch.setattr(auth_routes.httpx,'AsyncClient',Provider)
    response=await client.post('/api/auth/google',json={'id_token':'provider-token'})
    assert response.status_code==expected,response.text
    if expected==200:
        assert 'access_token' not in response.json()
        assert 'HttpOnly' in response.headers.get_list('set-cookie')[0]
        assert await db.sessions.count_documents({'user_id':'admin'})==1
    else: assert await db.sessions.count_documents({})==0

@pytest.mark.parametrize('variable,value',[
    ('JWT_SECRET','replace-with-a-unique-random-secret'),('ADMIN_PASSWORD','short'),
    ('FRONTEND_URL','https://untrusted.example.com'),('CORS_ORIGINS','https://crm.example.com/path'),
    ('TRUSTED_PROXY_CIDRS','not-a-network')])
def test_production_config_rejects_unsafe_values(monkeypatch,variable,value):
    from core.config import Settings
    for key,entry in {'APP_ENV':'production','JWT_SECRET':'a-unique-test-secret-of-more-than-32-characters','ADMIN_PASSWORD':'ValidBootstrap123!','CORS_ORIGINS':'https://crm.example.com','FRONTEND_URL':'https://crm.example.com','SEED_DEMO':'false','TRUSTED_PROXY_CIDRS':'172.30.70.2/32'}.items():
        monkeypatch.setenv(key,entry)
    monkeypatch.setenv(variable,value)
    with pytest.raises(ValueError): Settings()

async def test_readiness_database_failure_is_sanitized_503(env,monkeypatch):
    from pymongo.errors import ServerSelectionTimeoutError
    _,_,_,client=env
    async def unavailable(): raise ServerSelectionTimeoutError("internal-host-with-secret")
    monkeypatch.setattr(server,'supports_transactions',unavailable)
    response=await client.get('/api/ready')
    assert response.status_code==503
    assert response.json()['error']['code']=='database_unavailable'
    assert 'internal-host-with-secret' not in response.text
