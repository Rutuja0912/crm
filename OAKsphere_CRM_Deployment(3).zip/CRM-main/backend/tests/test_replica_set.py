"""Release-gate tests. These require an explicitly authorized real replica set.
No mongomock or transaction substitution is used in this module.
"""
import asyncio
import os
from uuid import uuid4
from datetime import timedelta
import pytest
from httpx import ASGITransport, AsyncClient
from motor.motor_asyncio import AsyncIOMotorClient
from core import transactions as tx
from models.entities import now_utc
from models.recruitment import LeadCreate, InterviewCreate, InterviewUpdate
from services import recruitment_service as rs, permission_service as ps, audit_service, notify_service, user_service
from api import deps, recruitment_routes
import server

pytestmark = [pytest.mark.anyio, pytest.mark.skipif(
    os.environ.get('CRM_REAL_MONGO_REGRESSION') != '1', reason='Requires an isolated real MongoDB replica set')]

@pytest.fixture
def anyio_backend(): return 'asyncio'

@pytest.fixture
async def real_db(monkeypatch):
    if os.environ.get('CRM_TEST_DATABASE_CONFIRMED') != '1':
        pytest.fail('Set CRM_TEST_DATABASE_CONFIRMED=1 for an isolated deployment')
    # Each AnyIO test owns its event loop. Never reuse a Motor client already
    # bound to a loop that the previous test has closed.
    client = AsyncIOMotorClient(os.environ['MONGO_URL'], serverSelectionTimeoutMS=5000)
    monkeypatch.setattr(tx, 'client', client)
    assert await tx.supports_transactions(), 'A real replica set is required'
    name = 'crm_hardening_run_' + uuid4().hex
    db = tx.client[name]
    await db.leads.create_index('lead_code', unique=True)
    # Existing collections also exercise multi-collection writes on older supported deployments.
    for collection in ['activities','followups','interviews','joinings','notifications','audit_logs','security_guards']:
        await db[collection].insert_one({'_test_setup':True})
        await db[collection].delete_many({'_test_setup':True})
    actor={'id':'admin','role':'admin','name':'Release test','email':'admin@example.invalid','is_active':True}
    await db.users.insert_one(actor.copy())
    await db.users.insert_one({'id':'recruiter','name':'Recruiter','role':'recruiter','is_active':True})
    try: yield db, actor, set(ps.ALL_PERMISSIONS)
    finally:
        await client.drop_database(name)
        client.close()

async def create(db,actor,perms):
    return await rs.create_lead(db,actor,perms,LeadCreate(name='Rollback candidate',phone='9876543210'))

async def test_lead_activity_failure_rolls_back_all_writes(real_db,monkeypatch):
    db,actor,perms=real_db
    async def fail(*args,**kwargs): raise RuntimeError('injected activity failure')
    monkeypatch.setattr(rs,'write_activity',fail)
    with pytest.raises(RuntimeError): await create(db,actor,perms)
    assert await db.leads.count_documents({})==0 and await db.activities.count_documents({})==0

async def test_selected_interview_joining_failure_rolls_back(real_db,monkeypatch):
    db,actor,perms=real_db;lead=await create(db,actor,perms)
    iv=await rs.create_interview(db,actor,perms,lead['id'],InterviewCreate(scheduled_at=now_utc()+timedelta(days=1)))
    before=await db.leads.find_one({'id':lead['id']})
    async def fail(*args,**kwargs): raise RuntimeError('injected joining failure')
    monkeypatch.setattr(rs,'create_joining',fail)
    with pytest.raises(RuntimeError):
        await rs.update_interview(db,actor,perms,iv['id'],InterviewUpdate(status='selected',expected_joining_date=now_utc()+timedelta(days=3)))
    assert (await db.interviews.find_one({'id':iv['id']}))['status']=='scheduled'
    assert (await db.leads.find_one({'id':lead['id']}))['status_history']==before['status_history']
    assert await db.joinings.count_documents({})==0

async def test_assignment_notification_failure_rolls_back(real_db,monkeypatch):
    db,actor,perms=real_db;lead=await create(db,actor,perms)
    async def fail(*args,**kwargs): raise RuntimeError('injected notification failure')
    monkeypatch.setattr(notify_service,'notify',fail)
    with pytest.raises(RuntimeError): await rs.assign_leads(db,actor,perms,[lead['id']],'recruiter')
    assert (await db.leads.find_one({'id':lead['id']}))['owner_id']=='admin'
    assert await db.activities.count_documents({'type':'assignment'})==0

async def test_api_audit_failure_rolls_back_business_write(real_db,monkeypatch):
    db,actor,perms=real_db
    monkeypatch.setattr(recruitment_routes,'db',db)
    server.app.dependency_overrides[deps.get_current_user]=lambda:actor
    async def fail(*args,**kwargs): raise RuntimeError('injected audit failure')
    monkeypatch.setattr(audit_service,'record',fail)
    try:
        async with AsyncClient(transport=ASGITransport(app=server.app,raise_app_exceptions=False),base_url='http://test') as client:
            response=await client.post('/api/leads',json={'name':'Audit rollback','phone':'9876543210'})
        assert response.status_code==500
        assert await db.leads.count_documents({})==0
        assert await db.activities.count_documents({})==0
    finally: server.app.dependency_overrides.clear()

async def test_concurrent_admin_removal_keeps_an_admin(real_db):
    db,actor,perms=real_db
    second={**actor,'id':'admin2','email':'admin2@example.invalid'}
    await db.users.insert_one(second.copy())
    await db.security_guards.insert_one({'_id':'active_admins','revision':0})
    results=await asyncio.gather(user_service.set_active(db,actor,'admin2',False),user_service.set_active(db,second,'admin',False),return_exceptions=True)
    assert await db.users.count_documents({'role':'admin','is_active':True})>=1
    assert any(isinstance(result,Exception) for result in results)
