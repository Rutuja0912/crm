const { test, expect } = require("@playwright/test");
const { randomUUID, randomInt } = require("node:crypto");
const suffix = randomUUID().slice(0, 8);
const password = "IsolatedE2eTest123!";
const accounts = { admin: { email: process.env.ADMIN_EMAIL, password: process.env.ADMIN_PASSWORD } };
let adminCsrf;
let privateLead;
async function checked(response) {
  expect(response.ok(), await response.text()).toBeTruthy();
  return response.json();
}
async function login(page, account) {
  await page.goto("/login");
  await page.getByTestId("login-email-input").fill(account.email);
  await page.getByTestId("login-password-input").fill(account.password);
  await page.getByTestId("login-submit-button").click();
  await expect(page).toHaveURL(/\/admin\//);
}
test.beforeAll(async ({ request }) => {
  if (!accounts.admin.email || !accounts.admin.password) throw new Error("Set ADMIN_EMAIL and ADMIN_PASSWORD for the isolated deployment");
  adminCsrf = (await checked(await request.get("/api/auth/csrf"))).csrf_token;
  await checked(await request.post("/api/auth/login", { data: accounts.admin, headers: { "X-CSRF-Token": adminCsrf } }));
  const headers = { "X-CSRF-Token": adminCsrf };
  const custom = "e2e_" + suffix;
  await checked(await request.post("/api/roles", { headers, data: { key: custom, name: "E2E restricted", permissions: ["leads.view_own"] } }));
  for (const role of ["team_leader", "recruiter", "restricted"]) {
    const data = { name: "E2E " + role, email: `${role}.${suffix}@example.com`, password, role: role === "restricted" ? custom : role };
    if (role === "recruiter") data.manager_id = accounts.team_leader.id;
    const user = await checked(await request.post("/api/users", { data, headers }));
    accounts[role] = { email: data.email, password, id: user.id };
  }
  privateLead = await checked(await request.post("/api/leads", { headers, data: { name: "Private admin " + suffix, phone: String(randomInt(8000000000, 9999999999)) } }));
});
for (const role of ["admin", "team_leader", "recruiter", "restricted"]) {
  test(`${role}: cookie session survives reload and direct routes enforce permission`, async ({ page }) => {
    await login(page, accounts[role]);
    await page.goto("/admin/my-leads");
    await expect(page.getByTestId("leads-page")).toBeVisible();
    await page.reload();
    await expect(page.getByTestId("leads-page")).toBeVisible();
    expect(await page.evaluate(() => localStorage.getItem("crm_token"))).toBeNull();
    const me = await checked(await page.request.get("/api/auth/me"));
    expect(me.user.email).toBe(accounts[role].email);
    await expect(page.getByTestId("add-lead-button")).toHaveCount(role === "restricted" ? 0 : 1);
    await page.goto("/admin/settings");
    if (role === "admin") await expect(page.getByTestId("settings-page")).toBeVisible();
    else await expect(page.getByTestId("unauthorized")).toBeVisible();
    if (role !== "admin") {
      const response = await page.request.get(`/api/leads/${privateLead.id}`);
      expect([403, 404]).toContain(response.status());
    }
  });
}
test("admin: create and edit a candidate through the UI, then verify API and reload", async ({ page }) => {
  await login(page, accounts.admin);
  await page.goto("/admin/leads");
  await page.getByTestId("add-lead-button").click();
  const name = "Persisted candidate " + suffix;
  await page.getByTestId("lead-name-input").fill(name);
  await page.getByTestId("lead-phone-input").fill(String(randomInt(8000000000, 9999999999)));
  await page.getByTestId("lead-save-button").click();
  await expect(page.getByTestId("add-lead-dialog")).toHaveCount(0);
  const result = await checked(await page.request.get("/api/leads", { params: { search: name } }));
  const lead = result.items.find(item => item.name === name);
  expect(lead).toBeTruthy();
  await page.reload();
  await page.getByTestId(`row-edit-${lead.id}`).click();
  await page.getByTestId("lead-name-input").fill(name + " edited");
  await page.getByTestId("lead-save-button").click();
  await expect(page.getByTestId("add-lead-dialog")).toHaveCount(0);
  await page.reload();
  await expect(page.getByTestId(`lead-name-${lead.id}`)).toHaveText(name + " edited");
  const saved = await checked(await page.request.get(`/api/leads/${lead.id}`));
  expect(saved.name).toBe(name + " edited");
});
test("admin: tag create and rename persist after reload", async ({ page }) => {
  await login(page, accounts.admin);
  await page.goto("/admin/tags");
  await page.getByTestId("tag-add").click();
  await page.getByTestId("tag-name").fill("E2E " + suffix);
  await page.getByTestId("tag-save").click();
  await expect(page.getByTestId("tag-dialog")).toHaveCount(0);
  const tags = await checked(await page.request.get("/api/tags"));
  const tag = tags.find(item => item.name === "E2E " + suffix);
  expect(tag).toBeTruthy();
  await page.reload();
  await page.getByTestId(`tag-edit-${tag.id}`).click();
  await page.getByTestId("tag-name").fill("Renamed " + suffix);
  await page.getByTestId("tag-save").click();
  await expect(page.getByTestId("tag-dialog")).toHaveCount(0);
  await page.reload();
  await expect(page.getByTestId(`tag-${tag.id}`)).toContainText("Renamed " + suffix);
});
test("admin: joining dates, salary and remarks persist in MongoDB and after reload", async ({ page }) => {
  await login(page, accounts.admin);
  const csrf = (await checked(await page.request.get("/api/auth/csrf"))).csrf_token;
  const headers = { "X-CSRF-Token": csrf };
  const lead = await checked(await page.request.post("/api/leads", { headers, data: { name: "Joining " + suffix, phone: String(randomInt(8000000000, 9999999999)) } }));
  const scheduled = new Date(Date.now() + 86400000).toISOString();
  const expected = new Date(Date.now() + 7 * 86400000).toISOString();
  const interview = await checked(await page.request.post(`/api/leads/${lead.id}/interviews`, { headers, data: { scheduled_at: scheduled } }));
  await checked(await page.request.put(`/api/interviews/${interview.id}`, { headers, data: { status: "selected", expected_joining_date: expected } }));
  const joining = (await checked(await page.request.get("/api/joinings"))).find(item => item.lead_id === lead.id);
  expect(joining).toBeTruthy();
  const localDate = expected.slice(0, 10);
  await page.goto("/admin/joining");
  await page.getByTestId(`jn-edit-${joining.id}`).click();
  await page.getByTestId("jn-exp").fill(localDate + "T10:30");
  await page.getByTestId("jn-act").fill(localDate + "T11:30");
  await page.getByTestId("jn-salary").fill("42000");
  await page.getByTestId("jn-remarks").fill("Persisted joining details");
  await page.getByTestId("jn-save").click();
  await expect(page.getByTestId("jn-edit-dialog")).toHaveCount(0);
  const saved = (await checked(await page.request.get("/api/joinings"))).find(item => item.id === joining.id);
  expect(saved.salary).toBe("42000");
  expect(saved.remarks).toBe("Persisted joining details");
  expect(saved.joining_date).not.toBe(saved.actual_joining_date);
  await page.reload();
  await page.getByTestId(`jn-edit-${joining.id}`).click();
  await expect(page.getByTestId("jn-exp")).toHaveValue(localDate + "T10:30");
  await expect(page.getByTestId("jn-act")).toHaveValue(localDate + "T11:30");
  await expect(page.getByTestId("jn-salary")).toHaveValue("42000");
  await expect(page.getByTestId("jn-remarks")).toHaveValue("Persisted joining details");
});
test("recruiter: assigned-lead notification read state persists after reload", async ({ page }) => {
  await login(page, accounts.admin);
  const csrf = (await checked(await page.request.get("/api/auth/csrf"))).csrf_token;
  const lead = await checked(await page.request.post("/api/leads", { headers: { "X-CSRF-Token": csrf }, data: {
    name: "Notification " + suffix, phone: String(randomInt(8000000000, 9999999999)), owner_id: accounts.recruiter.id,
  } }));
  await page.context().clearCookies();
  await login(page, accounts.recruiter);
  const notification = (await checked(await page.request.get("/api/notifications"))).find(item => item.action_url?.includes(lead.id));
  expect(notification).toBeTruthy();
  await page.goto("/admin/notifications");
  const row = page.getByTestId(`notification-${notification.id}`);
  await row.getByRole("button", { name: "Mark read", exact: true }).click();
  await expect(row.getByRole("button", { name: "Mark read", exact: true })).toHaveCount(0);
  await page.reload();
  await expect(row).toBeVisible();
  await expect(row.getByRole("button", { name: "Mark read", exact: true })).toHaveCount(0);
  const saved = (await checked(await page.request.get("/api/notifications"))).find(item => item.id === notification.id);
  expect(saved.read_at).toBeTruthy();
});
