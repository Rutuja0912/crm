import { TextEncoder, TextDecoder } from "util";
global.TextEncoder = TextEncoder; global.TextDecoder = TextDecoder;
global.IS_REACT_ACT_ENVIRONMENT = true;
window.matchMedia ||= () => ({ matches: false, addListener() {}, removeListener() {}, addEventListener() {}, removeEventListener() {}, dispatchEvent() {} });
Element.prototype.scrollIntoView ||= () => {};
Element.prototype.hasPointerCapture ||= () => false;
Element.prototype.setPointerCapture ||= () => {};
Element.prototype.releasePointerCapture ||= () => {};
global.ResizeObserver ||= class { observe() {} unobserve() {} disconnect() {} };
