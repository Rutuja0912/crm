import { useCallback, useEffect, useState } from "react";
import { api, formatApiError } from "@/lib/api";
export default function useNotifications(unread = false) {
  const [items, setItems] = useState([]);
  const [count, setCount] = useState(0);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const load = useCallback(async () => {
    try {
      const [list, total] = await Promise.all([api.get("/notifications", { params: { unread } }), api.get("/notifications/unread-count")]);
      setItems(list.data); setCount(total.data.count); setError("");
    } catch (e) { setError(formatApiError(e)); }
    finally { setLoading(false); }
  }, [unread]);
  useEffect(() => {
    load(); const timer = setInterval(load, 60000);
    window.addEventListener("crm:notifications", load);
    return () => { clearInterval(timer); window.removeEventListener("crm:notifications", load); };
  }, [load]);
  const markRead = async (id) => {
    await api.post(`/notifications/${id}/read`);
    window.dispatchEvent(new Event("crm:notifications"));
  };
  const markAll = async () => { await api.post("/notifications/read-all"); window.dispatchEvent(new Event("crm:notifications")); };
  return { items, count, loading, error, load, markRead, markAll };
}
