import { act } from "react";
import { createRoot } from "react-dom/client";
export async function render(element) {
  const container = document.createElement("div"); document.body.append(container);
  const root = createRoot(container);
  await act(async () => root.render(element));
  return { container, async unmount() { await act(async () => root.unmount()); container.remove(); } };
}
export async function click(node) { if (!node) throw new Error("Control not found"); await act(async () => node.click()); }
export async function flush() { await act(async () => { await Promise.resolve(); }); }
