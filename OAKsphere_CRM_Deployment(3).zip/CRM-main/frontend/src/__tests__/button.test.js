import React, { act } from "react";
import { Button } from "../components/ui/button";
import { toast } from "sonner";
import { render, click } from "../testUtils";
jest.mock("../lib/api",()=>({formatApiError:e=>e.message}));
jest.mock("sonner",()=>({toast:{error:jest.fn()}}));
test("asChild preserves a single interactive link",async()=>{const view=await render(<Button asChild><a href="/admin/tasks">Tasks</a></Button>);expect(view.container.querySelectorAll("a").length).toBe(1);expect(view.container.querySelector("button")).toBeNull();await view.unmount();});
test("a pending action is disabled and cannot double submit",async()=>{let done;const action=jest.fn(()=>new Promise(resolve=>{done=resolve;}));const view=await render(<Button onClick={action}>Save</Button>);const button=view.container.querySelector("button");await click(button);await click(button);expect(action).toHaveBeenCalledTimes(1);expect(button.disabled).toBe(true);expect(button.getAttribute("aria-busy")).toBe("true");await act(async()=>done());expect(button.disabled).toBe(false);await view.unmount();});
test("an unhandled action failure is visible",async()=>{const view=await render(<Button onClick={async()=>{throw new Error("Save failed");}}>Save</Button>);await click(view.container.querySelector("button"));expect(toast.error).toHaveBeenCalledWith("Save failed");await view.unmount();});
