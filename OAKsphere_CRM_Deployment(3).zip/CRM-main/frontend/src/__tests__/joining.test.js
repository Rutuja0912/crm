import React, { act } from "react";
import Joinings from "../pages/Joinings";
import { api } from "../lib/api";
import { render, click } from "../testUtils";
jest.mock("../lib/api",()=>({api:{get:jest.fn(),put:jest.fn()},formatApiError:e=>e.message}));
jest.mock("sonner",()=>({toast:{success:jest.fn(),error:jest.fn()}}));
jest.mock("../components/LeadDrawer",()=>()=>null);
jest.mock("../context/AuthContext",()=>({useAuth:()=>({hasPermission:()=>true})}));
const input=async(id,value)=>{const node=document.querySelector(`[data-testid="${id}"]`);await act(async()=>{Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,"value").set.call(node,value);node.dispatchEvent(new Event("input",{bubbles:true}));});};
test("joining edit submits all fields and values survive page remount",async()=>{
 let record={id:"j1",lead_id:"l1",lead_name:"Candidate",phone:"9876543210",status:"selected",confirmation:"pending",joining_date:"2026-10-05T04:30:00Z",actual_joining_date:null,salary:"",remarks:""};
 api.get.mockImplementation(async()=>({data:[{...record}]}));api.put.mockImplementation(async(url,body)=>{record={...record,...body};return {data:{...record}};});
 let view=await render(<Joinings/>);await click(document.querySelector('[data-testid="jn-edit-j1"]'));
 await input("jn-exp","2026-10-06T10:00");await input("jn-act","2026-10-06T11:00");await input("jn-salary","42000");await input("jn-remarks","Offer confirmed");
 await click(document.querySelector('[data-testid="jn-save"]'));
 expect(api.put).toHaveBeenCalledWith("/joinings/j1",expect.objectContaining({joining_date:"2026-10-06T04:30:00.000Z",actual_joining_date:"2026-10-06T05:30:00.000Z",salary:"42000",remarks:"Offer confirmed"}));await view.unmount();
 view=await render(<Joinings/>);await click(document.querySelector('[data-testid="jn-edit-j1"]'));expect(document.querySelector('[data-testid="jn-salary"]').value).toBe("42000");expect(document.querySelector('[data-testid="jn-remarks"]').value).toBe("Offer confirmed");await view.unmount();
});
