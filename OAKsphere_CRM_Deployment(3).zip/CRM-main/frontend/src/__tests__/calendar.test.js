import { configureCalendar, nextWorkingLocal, toUtcISOString, localInput } from "../lib/calendar";
beforeEach(() => configureCalendar({ timezone:"Asia/Kolkata", working_days:[0,1,2,3,4], work_start:"10:00", holidays:[] }));
test("Friday suggests Monday in the organization timezone", () => expect(nextWorkingLocal(new Date("2026-09-18T15:00:00Z"))).toBe("2026-09-21T10:00"));
test("Holidays are skipped", () => { configureCalendar({holidays:["2026-09-21"]}); expect(nextWorkingLocal(new Date("2026-09-18T15:00:00Z"))).toBe("2026-09-22T10:00"); });
test("datetime inputs round trip independently of browser timezone", () => { expect(toUtcISOString("2026-09-21T10:00")).toBe("2026-09-21T04:30:00.000Z"); expect(localInput("2026-09-21T04:30:00Z")).toBe("2026-09-21T10:00"); });
test("Nonexistent DST time is rejected", () => { configureCalendar({timezone:"America/New_York"}); expect(()=>toUtcISOString("2026-03-08T02:30")).toThrow("does not exist"); });
