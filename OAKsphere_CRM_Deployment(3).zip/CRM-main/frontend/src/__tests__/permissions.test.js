import React from "react";
import { MemoryRouter } from "react-router-dom";
import ProtectedRoute from "../components/ProtectedRoute";
import { useAuth } from "../context/AuthContext";
import { render } from "../testUtils";
jest.mock("../context/AuthContext",()=>({useAuth:jest.fn()}));
test.each([
 ["admin",[],true],["team_leader",["leads.view_all","leads.edit"],true],
 ["recruiter",["leads.view_own","leads.edit"],true],["restricted",["recruiters.view","users.manage"],false]
])("%s direct route enforces any and all permission checks",async(role,perms,allowed)=>{
 useAuth.mockReturnValue({user:{role},hasPermission:p=>role==="admin"||perms.includes(p)});
 const view=await render(<MemoryRouter><ProtectedRoute anyPermissions={["leads.view_all","leads.view_own"]} allPermissions={["leads.edit"]}><p data-testid="content">Candidate</p></ProtectedRoute></MemoryRouter>);
 expect(!!view.container.querySelector('[data-testid="content"]')).toBe(allowed);expect(!!view.container.querySelector('[data-testid="unauthorized"]')).toBe(!allowed);await view.unmount();
});
test("candidate view alone does not grant edit route",async()=>{
 useAuth.mockReturnValue({user:{role:"restricted"},hasPermission:p=>p==="leads.view_own"});
 const view=await render(<MemoryRouter><ProtectedRoute permission="leads.edit" anyPermissions={["leads.view_own"]}>Private</ProtectedRoute></MemoryRouter>);expect(view.container.textContent).toContain("Access denied");await view.unmount();
});
