import React from "react";
import { MemoryRouter } from "react-router-dom";
import Notifications from "../pages/Notifications";
import { api } from "../lib/api";
import { render, click, flush } from "../testUtils";
jest.mock("../lib/api",()=>({api:{get:jest.fn(),post:jest.fn()},formatApiError:e=>e.message}));
jest.mock("sonner",()=>({toast:{error:jest.fn(),success:jest.fn()}}));
let records;
beforeEach(()=>{
 records=[{id:"n1",title:"Candidate assigned",message:"Follow up",created_at:"2026-09-18T12:00:00Z",read_at:null,action_url:"/admin/my-leads?open=l1"}];
 api.get.mockImplementation(async(url,config)=>({data:url.endsWith("unread-count")?{count:records.filter(r=>!r.read_at).length}:records.filter(r=>!config?.params?.unread||!r.read_at).map(r=>({...r}))}));
 api.post.mockImplementation(async(url)=>{if(url==="/notifications/read-all")records.forEach(r=>{r.read_at="2026-09-18T12:01:00Z";});else if(url==="/notifications/n1/read")records[0].read_at="2026-09-18T12:01:00Z";else throw new Error("Unexpected write");return {};});
});
const page=()=>render(<MemoryRouter><Notifications/></MemoryRouter>);
test("reads real notification endpoints and read state survives remount",async()=>{
 let view=await page();expect(view.container.textContent).toContain("Unread (1)");
 await click([...view.container.querySelectorAll("button")].find(b=>b.textContent==="Mark read"));await flush();expect(records[0].read_at).toBeTruthy();await view.unmount();
 view=await page();expect(view.container.textContent).toContain("Unread (0)");expect(api.get.mock.calls.every(([url])=>!url.includes("my-day"))).toBe(true);expect(view.container.textContent).not.toContain("Mark read");await view.unmount();
});
test("mark all persists and unread filter becomes empty",async()=>{
 const view=await page();await click(view.container.querySelector('[data-testid="notifications-read-all"]'));await flush();await click([...view.container.querySelectorAll("button")].find(b=>b.textContent.startsWith("Unread")));expect(view.container.textContent).toContain("No unread notifications.");expect(api.post).toHaveBeenCalledWith("/notifications/read-all");await view.unmount();
});
test("load errors show retry instead of an empty inbox",async()=>{api.get.mockRejectedValue(new Error("Network unavailable"));const view=await page();expect(view.container.querySelector('[role="alert"]').textContent).toContain("Network unavailable");expect(view.container.textContent).not.toContain("No notifications");await view.unmount();});
