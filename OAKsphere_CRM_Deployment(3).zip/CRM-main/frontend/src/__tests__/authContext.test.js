import React from "react";
import { AuthProvider, useAuth } from "../context/AuthContext";
import { api } from "../lib/api";
import { render, click } from "../testUtils";
jest.mock("../lib/api",()=>({api:{get:jest.fn(),post:jest.fn()},formatApiError:e=>e.message}));
jest.mock("sonner",()=>({toast:{error:jest.fn()}}));
function Probe() { const ctx=useAuth(); return <><p>{ctx.user?.name || (ctx.user === null ? "Signed out" : "Loading")}</p><p role="alert">{ctx.loadError}</p><button onClick={ctx.logout}>Logout</button></>; }
beforeEach(()=>{localStorage.clear();jest.clearAllMocks();api.get.mockImplementation(async(url)=>({data:url==="/auth/me"?{user:{id:"r",name:"Cookie user",role:"recruiter"},permissions:["leads.view_own"]}:{timezone:"Asia/Kolkata",working_days:[0,1,2,3,4],holidays:[],work_start:"10:00"}}));});
test("reload authenticates an HTTP-only cookie session without a localStorage token",async()=>{const view=await render(<AuthProvider><Probe/></AuthProvider>);expect(api.get).toHaveBeenCalledWith("/auth/me");expect(view.container.textContent).toContain("Cookie user");expect(localStorage.getItem("crm_token")).toBeNull();await view.unmount();});
test("failed logout retains user state",async()=>{api.post.mockRejectedValue(new Error("Network unavailable"));const view=await render(<AuthProvider><Probe/></AuthProvider>);await click(view.container.querySelector("button"));expect(view.container.textContent).toContain("Cookie user");await view.unmount();});
test("successful logout clears session state",async()=>{api.post.mockResolvedValue({});const view=await render(<AuthProvider><Probe/></AuthProvider>);await click(view.container.querySelector("button"));expect(view.container.textContent).toContain("Signed out");await view.unmount();});
test("transient session load failure is visible",async()=>{api.get.mockRejectedValue(new Error("Database unavailable"));const view=await render(<AuthProvider><Probe/></AuthProvider>);expect(view.container.querySelector('[role="alert"]').textContent).toBe("Database unavailable");await view.unmount();});
