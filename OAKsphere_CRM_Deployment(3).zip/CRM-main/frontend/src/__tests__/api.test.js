jest.mock("axios", () => ({ create: jest.fn() }));
let api, auth, request, reject, transport;
beforeEach(() => {
  jest.resetModules();
  const axios = require("axios");
  api = jest.fn().mockResolvedValue({data:"retried"});
  api.interceptors = {request:{use:fn=>{request=fn;}},response:{use:(ok,fn)=>{reject=fn;}}};
  auth = {get:jest.fn().mockResolvedValue({data:{csrf_token:"csrf-value"}}),post:jest.fn().mockResolvedValue({data:{ok:true}})};
  axios.create.mockReturnValueOnce(api).mockReturnValueOnce(auth);
  transport=require("../lib/api");
});
test("concurrent 401s share one refresh and retry each request once",async()=>{
  let release;auth.post.mockImplementation(()=>new Promise(resolve=>{release=resolve;}));
  const configs=[{url:"/leads"},{url:"/tasks"}];
  const pending=configs.map(config=>reject({config,response:{status:401}}));
  await new Promise(resolve => setTimeout(resolve, 0));
  expect(auth.post).toHaveBeenCalledTimes(1);release({});await Promise.all(pending);
  expect(api).toHaveBeenCalledTimes(2);expect(configs.every(c=>c._retried)).toBe(true);
});
test("failed refresh invalidates the session without a request loop",async()=>{
  const listener=jest.fn();window.addEventListener("crm:unauthenticated",listener);
  auth.post.mockRejectedValue(new Error("expired"));
  await expect(reject({config:{url:"/leads"},response:{status:401}})).rejects.toThrow("expired");
  expect(listener).toHaveBeenCalledTimes(1);expect(api).not.toHaveBeenCalled();window.removeEventListener("crm:unauthenticated",listener);
});
test("a retried 401 and a failed login never trigger refresh",async()=>{
  for(const config of [{url:"/leads",_retried:true},{url:"/auth/login"}]) await expect(reject({config,response:{status:401}})).rejects.toBeDefined();
  expect(auth.post).not.toHaveBeenCalled();
});
test("concurrent mutations share CSRF acquisition",async()=>{
 const configs=await Promise.all([request({method:"post",headers:{}}),request({method:"patch",headers:{}})]);
 expect(auth.get).toHaveBeenCalledTimes(1);expect(configs.map(c=>c.headers["X-CSRF-Token"])).toEqual(["csrf-value","csrf-value"]);
});
test("expired CSRF cookie is renewed once",async()=>{
 await transport.ensureCsrf();const config={url:"/leads",headers:{}};
 await reject({config,response:{status:403,data:{error:{code:"csrf"}}}});
 expect(auth.get).toHaveBeenCalledTimes(2);expect(api).toHaveBeenCalledWith(config);
 await expect(reject({config,response:{status:403,data:{error:{code:"csrf"}}}})).rejects.toBeDefined();expect(auth.get).toHaveBeenCalledTimes(2);
});
