import { createContext, useContext, useEffect, useState, useCallback } from "react";
import { api, formatApiError } from "@/lib/api";
import { configureCalendar } from "@/lib/calendar";
import { toast } from "sonner";

const AuthContext = createContext(null);
export function AuthProvider({ children }) {
  const [user, setUser] = useState(undefined);
  const [permissions, setPermissions] = useState([]);
  const [loadError, setLoadError] = useState("");
  const setSession = useCallback(async (data) => {
    const calendar = await api.get("/scheduling/next-working-day");
    configureCalendar(calendar.data);
    setUser(data.user); setPermissions(data.permissions || []); setLoadError("");
  }, []);
  const loadMe = useCallback(async () => {
    try { await setSession((await api.get("/auth/me")).data); }
    catch (error) {
      if ([401, 403].includes(error.response?.status)) { setUser(null); setPermissions([]); }
      else setLoadError(formatApiError(error));
    }
  }, [setSession]);
  useEffect(() => {
    localStorage.removeItem("crm_token"); // migrate legacy browser tokens once
    const expired = () => { setUser(null); setPermissions([]); };
    window.addEventListener("crm:unauthenticated", expired);
    loadMe();
    return () => window.removeEventListener("crm:unauthenticated", expired);
  }, [loadMe]);
  const login = async (email, password) => {
    const { data } = await api.post("/auth/login", { email, password });
    await setSession(data);
    return data.user;
  };
  const loginGoogle = async (idToken) => {
    const { data } = await api.post("/auth/google", { id_token: idToken });
    await setSession(data);
    return data.user;
  };
  const logout = async () => {
    try { await api.post("/auth/logout"); setUser(null); setPermissions([]); return true; }
    catch (error) { toast.error("Logout failed: " + formatApiError(error)); return false; }
  };
  const hasPermission = useCallback((perm) => user?.role === "admin" || permissions.includes(perm), [user, permissions]);
  return <AuthContext.Provider value={{ user, permissions, loadError, login, loginGoogle, logout, hasPermission, refresh: loadMe, formatApiError }}>{children}</AuthContext.Provider>;
}
export const useAuth = () => useContext(AuthContext);
