import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { formatApiError } from "@/lib/api";
import { fmtDateTime } from "@/lib/leadConstants";
import { safeActionUrl } from "@/lib/candidateActions";
import useNotifications from "@/hooks/useNotifications";
export default function Notifications() {
  const [unread, setUnread] = useState(false);
  const navigate = useNavigate();
  const { items, count, loading, error, load, markRead, markAll } = useNotifications(unread);
  const open = async (item) => { try { await markRead(item.id); navigate(safeActionUrl(item.action_url)); } catch (e) { toast.error(formatApiError(e)); } };
  return <div className="space-y-5" data-testid="notifications-page"><h1 className="font-heading text-2xl font-bold">Notifications</h1>
    <div className="flex gap-2"><Button variant={!unread ? "default" : "outline"} onClick={() => setUnread(false)}>All</Button><Button variant={unread ? "default" : "outline"} onClick={() => setUnread(true)}>Unread ({count})</Button>
    <Button variant="outline" disabled={!count} onClick={async () => { try { await markAll(); } catch (e) { toast.error(formatApiError(e)); } }} data-testid="notifications-read-all">Mark all read</Button></div>
    {error ? <div role="alert">{error}<Button onClick={load}>Retry</Button></div> : loading ? <p>Loading…</p> : <Card className="divide-y">{items.length === 0 ? <p className="p-8 text-center text-slate-500">No {unread ? "unread " : ""}notifications.</p> : items.map((item) => <div key={item.id} className="flex items-start justify-between gap-4 p-4" data-testid={`notification-${item.id}`}>
      <div><Button variant="link" className="h-auto p-0" onClick={() => open(item)}>{item.title}</Button><p className="text-sm">{item.message}</p><time className="text-xs text-slate-500">{fmtDateTime(item.created_at)}</time></div>
      {!item.read_at && <Button size="sm" variant="outline" onClick={async () => { try { await markRead(item.id); } catch (e) { toast.error(formatApiError(e)); } }}>Mark read</Button>}
    </div>)}</Card>}
  </div>;
}
