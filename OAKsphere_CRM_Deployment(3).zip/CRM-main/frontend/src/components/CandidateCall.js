import { useEffect, useState } from "react";
import { toast } from "sonner";
import { api, formatApiError } from "@/lib/api";
import CallActionModal from "@/components/CallActionModal";
import CallDispositionModal from "@/components/CallDispositionModal";
export default function CandidateCall({ leadId, onClose, onDone }) {
  const [lead, setLead] = useState(null);
  const [disposition, setDisposition] = useState(false);
  const [duration, setDuration] = useState(0);
  useEffect(() => {
    let active = true;
    setLead(null); setDisposition(false);
    if (leadId) api.get(`/leads/${leadId}`).then(({ data }) => { if (active) setLead(data); })
      .catch((error) => { if (active) toast.error(formatApiError(error)); });
    return () => { active = false; };
  }, [leadId]);
  if (!leadId || !lead) return null;
  return <><CallActionModal open={!disposition} onClose={onClose} lead={lead} onLogDisposition={(seconds) => { setDuration(seconds); setDisposition(true); }} />
    <CallDispositionModal open={disposition} onClose={onClose} lead={lead} initialDuration={duration} onDone={() => { onDone?.(); onClose(); }} /></>;
}
