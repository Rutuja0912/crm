import { useEffect, useRef, useState } from "react";
import { useAuth } from "@/context/AuthContext";
import { loadGoogleIdentity } from "@/lib/googleIdentity";
import { formatApiError } from "@/lib/api";
import { Button } from "@/components/ui/button";

export default function GoogleSignIn({ clientId, onSuccess }) {
  const host = useRef(null);
  const { loginGoogle } = useAuth();
  const callback = useRef({ loginGoogle, onSuccess });
  callback.current = { loginGoogle, onSuccess };
  const busy = useRef(false);
  const [error, setError] = useState("");
  const [attempt, setAttempt] = useState(0);
  useEffect(() => {
    let active = true;
    loadGoogleIdentity().then((identity) => {
      if (!active) return;
      identity.initialize({ client_id: clientId, auto_select: false, callback: async ({ credential }) => {
        if (!active || busy.current) return;
        if (!credential) { setError("Google did not return a sign-in credential. Please retry."); return; }
        busy.current = true; setError("");
        try {
          await callback.current.loginGoogle(credential);
          if (active) callback.current.onSuccess();
        } catch (e) { if (active) setError(formatApiError(e)); }
        finally { busy.current = false; }
      } });
      identity.renderButton(host.current, { theme: "outline", size: "large", width: 360 });
    }).catch(e => { if (active) setError(e.message); });
    return () => { active = false; };
  }, [clientId, attempt]);
  return <div>
    <div ref={host} data-testid="google-login-button" />
    {error && <div role="alert" className="mt-2 text-sm text-red-600">{error}
      <Button variant="outline" onClick={() => { setError(""); setAttempt(n => n + 1); }}>Retry Google sign-in</Button>
    </div>}
  </div>;
}
