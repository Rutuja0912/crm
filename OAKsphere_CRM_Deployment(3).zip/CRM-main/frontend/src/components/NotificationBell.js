import { useNavigate } from "react-router-dom";
import { Bell } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuTrigger, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuItem } from "@/components/ui/dropdown-menu";
import { formatApiError } from "@/lib/api";
import { safeActionUrl } from "@/lib/candidateActions";
import useNotifications from "@/hooks/useNotifications";
export default function NotificationBell() {
  const navigate = useNavigate();
  const { items, count, error, loading, markRead, load } = useNotifications();
  const open = async (item) => { try { await markRead(item.id); navigate(safeActionUrl(item.action_url)); } catch (e) { toast.error(formatApiError(e)); } };
  return <DropdownMenu><DropdownMenuTrigger asChild><Button variant="ghost" size="icon" className="relative" aria-label="Notifications" data-testid="notification-bell"><Bell className="h-4 w-4" />
    {count > 0 && <span className="absolute -right-0.5 -top-0.5 rounded-full bg-red-500 px-1 text-[10px] text-white" data-testid="notification-count">{count > 99 ? "99+" : count}</span>}
  </Button></DropdownMenuTrigger><DropdownMenuContent align="end" className="w-80 bg-white dark:bg-slate-900"><DropdownMenuLabel>Notifications</DropdownMenuLabel><DropdownMenuSeparator />
    {error ? <div role="alert" className="p-3 text-sm">{error}<Button variant="link" onClick={load}>Retry</Button></div> : loading ? <p className="p-3">Loading…</p> : items.length === 0 ? <p className="p-4 text-sm text-slate-500">No notifications.</p> : items.slice(0,6).map((item) => <DropdownMenuItem key={item.id} onClick={() => open(item)} data-testid={`notif-${item.id}`} className={!item.read_at ? "font-semibold" : ""}>{item.title}</DropdownMenuItem>)}
    <DropdownMenuSeparator /><DropdownMenuItem onClick={() => navigate("/admin/notifications")}>View all notifications</DropdownMenuItem>
  </DropdownMenuContent></DropdownMenu>;
}
