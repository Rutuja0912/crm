import { useEffect, useRef, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
let enqueue;
const request = (item) => new Promise((resolve) => {
  if (enqueue) enqueue({ ...item, resolve });
  else resolve(item.text ? null : false);
});
export const confirmAction = (description) => request({ description, title: "Confirm action" });
export const requestText = (title, initial = "", type = "text") => request({ title, initial, type, text: true });
export default function ActionDialogs() {
  const [queue, setQueue] = useState([]);
  const pending = useRef([]);
  const item = queue[0];
  const [value, setValue] = useState("");
  useEffect(() => {
    enqueue = (next) => { pending.current.push(next); setQueue([...pending.current]); };
    return () => { enqueue = null; pending.current.forEach((entry) => entry.resolve(entry.text ? null : false)); pending.current = []; };
  }, []);
  useEffect(() => { setValue(item?.initial || ""); }, [item]);
  const finish = (ok) => {
    if (!item || item.done) return;
    item.done = true;
    item.resolve(item.text ? (ok ? value : null) : ok);
    pending.current = pending.current.filter((entry) => entry !== item);
    setQueue([...pending.current]);
  };
  return <Dialog open={!!item} onOpenChange={(open) => !open && finish(false)}><DialogContent data-testid="action-confirm-dialog"><DialogHeader>
    <DialogTitle>{item?.title}</DialogTitle><DialogDescription>{item?.description || "Enter the value to continue. Cancel leaves the record unchanged."}</DialogDescription>
  </DialogHeader>{item?.text && <Input aria-label={item.title} type={item.type} value={value} onChange={(e) => setValue(e.target.value)} />}
  <DialogFooter><Button variant="outline" onClick={() => finish(false)}>Cancel</Button><Button disabled={item?.text && !value.trim()} onClick={() => finish(true)} data-testid="action-confirm">Confirm</Button></DialogFooter>
  </DialogContent></Dialog>;
}
