import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useRef, useState } from "react";
import { toast } from "sonner";
import { formatApiError } from "@/lib/api";

export default function ConfirmDialog({
  open, onOpenChange, title, description, confirmLabel = "Confirm",
  onConfirm, destructive = true, testId = "confirm-dialog",
}) {
  const [pending, setPending] = useState(false);
  const busy = useRef(false);
  const confirm = async (event) => {
    event.preventDefault();
    if (busy.current) return;
    busy.current = true; setPending(true);
    try { await onConfirm(); onOpenChange(false); }
    catch (error) { toast.error(formatApiError(error)); }
    finally { busy.current = false; setPending(false); }
  };
  return (
    <AlertDialog open={open} onOpenChange={(value) => !pending && onOpenChange(value)}>
      <AlertDialogContent data-testid={testId}>
        <AlertDialogHeader>
          <AlertDialogTitle>{title}</AlertDialogTitle>
          <AlertDialogDescription>{description}</AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel disabled={pending} data-testid={`${testId}-cancel`}>Cancel</AlertDialogCancel>
          <AlertDialogAction
            data-testid={`${testId}-confirm`}
            onClick={confirm} disabled={pending} aria-busy={pending}
            className={destructive ? "bg-red-600 hover:bg-red-700 text-white" : ""}
          >
            {pending ? "Saving…" : confirmLabel}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
