const { defineConfig } = require("@playwright/test");
if (process.env.CRM_TEST_DATABASE_CONFIRMED !== "1") {
  throw new Error("Browser tests create records. Set CRM_TEST_DATABASE_CONFIRMED=1 only for an isolated test deployment.");
}
module.exports = defineConfig({
  testDir: "./e2e", fullyParallel: false, workers: 1, retries: 0,
  timeout: 45000, expect: { timeout: 10000 },
  use: { baseURL: process.env.E2E_BASE_URL || "http://127.0.0.1:3000", trace: "retain-on-failure", screenshot: "only-on-failure" },
  reporter: [["list"], ["html", { open: "never" }], ["junit", { outputFile: "test-results/browser-results.xml" }]],
});
