# OAKsphere CRM deployment package

Start with `deploy/README.md` for the exact production commands. This ZIP includes the repaired source, compiled frontend, committed Yarn lockfile, Docker/Compose/HTTPS configuration, tests and CI release gates.

Verified locally: **235 backend tests and 37 frontend tests pass; production build, frozen Yarn install and strict ESLint pass.** All 121 formerly skipped API contracts now execute. Five real-Mongo checks remain blocked here. Eight browser scenarios and the production-container HTTPS smoke require a capable runner; the CI gate rejects skips or missing cases.

**Launch approval is still pending the real-Mongo, browser, container and enabled-provider checks.** The cloud browser blocked this local app (`ERR_BLOCKED_BY_CLIENT`); no UI pass is inferred from the component tests.

Supply the real hostname, authenticated MongoDB replica-set URI and credentials in `.env`, using `deploy/production.env.example`. Run the included release CI/staging checks before live rollout. Docker/browser/MongoDB runtime and live provider credentials could not be validated here.

The full 45-issue report, test evidence, remaining checks and every-button acceptance matrix are in `docs/hardening/`.
