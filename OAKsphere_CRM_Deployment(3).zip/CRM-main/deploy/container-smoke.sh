#!/usr/bin/env bash
# Linux CI, disposable DB only. Production images; locally trusted test TLS.
set -euo pipefail
if [[ "${CRM_TEST_DATABASE_CONFIRMED:-}" != 1 ]]; then
  echo 'This test requires CRM_TEST_DATABASE_CONFIRMED=1 and isolated MongoDB.' >&2
  exit 1
fi
task_dir=$(mktemp -d)
cleanup() {
  docker logs crm-container-api > /tmp/crm-container-api.log 2>&1 || true
  docker logs crm-container-web > /tmp/crm-container-web.log 2>&1 || true
  docker rm -f crm-container-api crm-container-web >/dev/null 2>&1 || true
  rm -rf "$task_dir"
}
trap cleanup EXIT
openssl req -x509 -newkey rsa:2048 -sha256 -nodes -days 1 \
  -subj '/CN=localhost' -addext 'subjectAltName=DNS:localhost' \
  -keyout "$task_dir/key.pem" -out "$task_dir/cert.pem" >/dev/null 2>&1
# Insert only the test certificate. All production routes/headers stay intact.
python - "$task_dir/Caddyfile" <<'PY'
from pathlib import Path
import sys
source = Path('frontend/Caddyfile').read_text()
Path(sys.argv[1]).write_text(source.replace('{$DOMAIN} {',
    '{$DOMAIN} {\n    tls /test-tls/cert.pem /test-tls/key.pem', 1))
PY
docker run --detach --name crm-container-api --network host \
  --read-only --tmpfs /tmp:rw,noexec,nosuid,size=64m \
  --cap-drop ALL --security-opt no-new-privileges:true \
  --env APP_ENV=production --env MONGO_URL --env JWT_SECRET \
  --env DB_NAME="crm_container_${GITHUB_RUN_ID:-local}_$RANDOM" \
  --env ADMIN_EMAIL --env ADMIN_PASSWORD --env SEED_DEMO=false \
  --env COOKIE_SECURE=true --env ENABLE_BEARER_AUTH=false \
  --env FRONTEND_URL=https://localhost:8443 --env CORS_ORIGINS=https://localhost:8443 \
  --env TRUSTED_PROXY_CIDRS=127.0.0.1/32 oaksphere-crm-api:ci >/dev/null
python deploy/wait_ready.py http://127.0.0.1:8000/api/ready
docker run --detach --name crm-container-web --network host \
  --add-host backend:127.0.0.1 --env DOMAIN=https://localhost:8443 \
  --security-opt no-new-privileges:true \
  --volume "$task_dir:/test-tls:ro" \
  --volume "$task_dir/Caddyfile:/etc/caddy/Caddyfile:ro" oaksphere-crm-web:ci >/dev/null
python deploy/https_smoke.py https://localhost:8443 "$task_dir/cert.pem"
