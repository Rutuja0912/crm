"""Verify the production image pair, trusted TLS, cookie auth and persistence."""
import os
import re
import sys
import time
from urllib.parse import urljoin
from uuid import uuid4
import httpx


def verify(base, ca):
    assert os.environ.get('CRM_TEST_DATABASE_CONFIRMED') == '1'
    import ssl
    with httpx.Client(base_url=base, verify=ssl.create_default_context(cafile=ca),
                      timeout=10, trust_env=False) as client:
        deadline = time.monotonic() + 60
        while True:
            try:
                response = client.get('/api/ready')
                response.raise_for_status()
                break
            except httpx.HTTPError:
                if time.monotonic() >= deadline:
                    raise
                time.sleep(1)
        assert response.json()['status'] == 'ready'
        assert response.headers['x-content-type-options'] == 'nosniff'
        assert response.headers['x-frame-options'] == 'DENY'
        assert 'max-age=' in response.headers['strict-transport-security']
        deep = client.get('/admin/my-leads')
        assert deep.status_code == 200 and '<div id="root">' in deep.text
        assets = re.findall(r'<script[^>]+src="([^\"]+)"', deep.text)
        assert assets, 'Production HTML must load built JavaScript'
        for asset in assets:
            assert urljoin(base, asset).startswith(base + '/'), 'Unexpected external script'
            script = client.get(asset)
            assert script.status_code == 200 and 'javascript' in script.headers['content-type']
        csrf = client.get('/api/auth/csrf').json()['csrf_token']
        headers = {'Origin': base, 'X-CSRF-Token': csrf}
        login = client.post('/api/auth/login', headers=headers, json={
            'email': os.environ['ADMIN_EMAIL'], 'password': os.environ['ADMIN_PASSWORD']})
        assert login.status_code == 200, login.text
        assert 'access_token' not in login.json()
        cookies = login.headers.get_list('set-cookie')
        assert len(cookies) == 2 and all('Secure' in c and 'HttpOnly' in c and 'SameSite=lax' in c for c in cookies)
        assert client.get('/api/auth/me').status_code == 200
        payload = {'name': 'Container smoke ' + uuid4().hex[:8], 'phone': '9988776655', 'duplicate_ack': True}
        assert client.post('/api/leads', json=payload).status_code == 403
        created = client.post('/api/leads', headers=headers, json=payload)
        assert created.status_code == 200, created.text
        lid = created.json()['id']
        assert client.get('/api/leads/' + lid).json()['name'] == payload['name']
        assert client.delete('/api/leads/' + lid, headers=headers).status_code == 200
        assert client.get('/api/leads/' + lid).status_code == 404
        assert client.post('/api/auth/logout', headers=headers).status_code == 200
        assert client.get('/api/auth/me').status_code == 401
    print('HTTPS container smoke passed: TLS, SPA/assets, headers, secure cookies, CSRF, write/read/archive, logout.')


if __name__ == '__main__':
    verify(sys.argv[1].rstrip('/'), sys.argv[2])
