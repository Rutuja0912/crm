"""Bounded readiness wait for release checks; exits nonzero on failure."""
import sys
import time
import urllib.error
import urllib.request

for attempt in range(30):
    try:
        with urllib.request.urlopen(sys.argv[1], timeout=2) as response:
            if response.status == 200:
                print("API is ready")
                break
    except (urllib.error.URLError, TimeoutError):
        pass
    time.sleep(1)
else:
    raise SystemExit("API readiness failed; inspect API and database logs")
