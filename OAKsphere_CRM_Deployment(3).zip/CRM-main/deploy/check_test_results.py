"""Fail release checks for missing, failed, errored, or skipped JUnit cases."""
import argparse
from pathlib import Path
import xml.etree.ElementTree as ET


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('report', type=Path)
    parser.add_argument('--minimum', type=int, required=True)
    args = parser.parse_args()
    cases = ET.parse(args.report).getroot().findall('.//testcase')
    problems = [case for case in cases if any(case.find(tag) is not None
                for tag in ('skipped', 'failure', 'error'))]
    if len(cases) < args.minimum or problems:
        raise SystemExit(f'Release blocked: {len(cases)} cases, {len(problems)} failed/errored/skipped; '
                         f'at least {args.minimum} passing cases required.')
    print(f'Release gate: {len(cases)} passed; no failures, errors, or skips.')


if __name__ == '__main__':
    main()
