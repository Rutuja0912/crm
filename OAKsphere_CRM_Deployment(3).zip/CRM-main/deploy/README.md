# Production deployment

The deployment keeps the existing React, FastAPI and MongoDB application. The frontend is compiled into static files. Caddy serves those files, forwards `/api/*` to FastAPI, and manages HTTPS certificates. The API runs as a non-root user with a read-only filesystem. MongoDB is external: supply an authenticated replica-set or supported sharded-cluster connection URI. No database port or API port is published by this Compose file.

## Prepare the host

Use a host with Docker Engine and the Compose plugin. Point the CRM hostname's DNS records to it and allow inbound TCP 80 and 443. Allow outbound access needed for your MongoDB cluster, certificate issuance, and enabled providers. Keep your database credentials and JWT secret out of source control. The JWT secret also protects stored integration credentials and must remain stable across releases.

Copy `deploy/production.env.example` to `.env` in the project root. Fill in the real domain, database URI, bootstrap administrator email, password, and a unique random JWT secret. Generate the secret with:

```sh
python3 -c 'import secrets; print(secrets.token_urlsafe(48))'
```

The application rejects placeholder credentials, short production administrator passwords, wildcard origins, malformed proxy networks and invalid HTTPS origins. Provider fields can remain blank until those features are configured. `SEED_DEMO=false` and cookie-only authentication are enforced by the production Compose configuration.

The dedicated ingress subnet defaults to `172.30.70.0/28`. If it conflicts with the host, change both `INGRESS_SUBNET` and `INGRESS_IP`. Only the Caddy address is trusted for forwarded client IPs. Uvicorn proxy-header rewriting is disabled so the application can verify the original peer. API access logging is disabled in the container to avoid recording verification tokens in query strings.

## Verify the release

The included `.github/workflows/release.yml` installs the frozen Yarn graph, runs strict lint, frontend tests and the production build, starts an isolated real MongoDB replica set, runs all 240 backend cases including rollback/concurrency checks, runs Playwright against the built frontend and real API, and builds both containers. It then exercises the production images over HTTPS using a locally trusted test certificate: SPA routes/assets, headers, secure cookie login, CSRF rejection, candidate write/read/archive, and logout. Backend and browser JUnit gates fail on any skipped, failed or missing cases. Commit this project to your repository and require the `Release checks / validate` job before release. No production secrets are needed for that job.

Local commands, with Python 3.12, Node 24 and Yarn 1.22.22:

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r backend/requirements-test.txt
.venv/bin/python -m pip check
yarn --cwd frontend install --frozen-lockfile --non-interactive --ignore-optional
yarn --cwd frontend lint --max-warnings=0
CI=true yarn --cwd frontend test --watchAll=false --runInBand
CI=true GENERATE_SOURCEMAP=false yarn --cwd frontend build
```

Run backend pytest from `backend`, using the activated virtual environment. The 121 former live suites now run automatically through the actual ASGI application, cookie authentication and signed CSRF. Every test owns a fresh randomly named database and its fixtures. The default local run uses mongomock and does not prove transaction behavior. With `CRM_REAL_MONGO_REGRESSION=1`, `CRM_TEST_DATABASE_CONFIRMED=1`, and an isolated test-cluster `MONGO_URL`, those same 121 cases use real MongoDB transactions and the five dedicated rollback/concurrency cases also run. The Mongo test user must be able to create/drop the temporary `crm_contract_run_*` and `crm_hardening_run_*` databases. Never use production MongoDB for these tests.

Browser tests require an isolated running API, its test administrator credentials and `CRM_TEST_DATABASE_CONFIRMED=1`. They create records. Use `frontend/scripts/serve-test.cjs` only for CI/local checks; production uses Caddy. The container smoke script requires Linux Docker and the CI environment variables; its database is disposable and uses the isolated replica set.

## Start the release

Take and verify a database backup. Rehearse startup/migration against a restored copy of your existing data. Pause application writes and start one API instance during the migration. The startup migration preserves replaced lead codes, archives duplicate tag catalog entries, and canonicalizes tag references without deleting candidates.

From the project root:

```sh
docker compose config --quiet
export RELEASE_TAG=20260919-r3
docker compose build --pull
docker compose up -d --wait --wait-timeout 180
docker compose ps
python3 deploy/wait_ready.py https://YOUR-CRM-DOMAIN/api/ready
```

The API health check waits for MongoDB transaction support. Caddy starts after the API is healthy. Certificate issuance additionally requires working DNS and reachable ports. `/api/health` is process liveness; `/api/ready` checks database transaction capability.

Open the HTTPS site, sign in as the configured administrator and create the real team accounts. Check session persistence after refresh, create/edit/archive a disposable candidate, and confirm scope using a recruiter account. Finish the role/action matrix on staging. The bootstrap password creates a missing administrator only; it never resets an existing account on restart.

## Updates, rollback and providers

Retain the previous image tag and a verified database backup. A code rollback uses the previous `RELEASE_TAG` with `docker compose up -d --no-build`; do not delete volumes. Database migrations are not automatically reversed. Restore a backup only through your controlled database recovery procedure after pausing writes and checking compatibility.

For Google sign-in, set `GOOGLE_CLIENT_ID` and register this exact HTTPS origin in the provider console. The UI loads Google's sign-in button and submits the signed credential to the existing cookie-auth endpoint; the server verifies audience, issuer, expiry, verified email and active CRM membership. See [Google's button setup](https://developers.google.com/identity/gsi/web/guides/display-button). Existing users must be provisioned in the CRM first. Test a real account before enabling the feature for staff.

Configure Meta, form-relay secrets and email in the application/server settings. Actual subscription, delivery and credential validation require those accounts. WhatsApp buttons open a phone-number deep link; they do not prove message delivery. Provider + phone + role deduplication also reuses archived intake applications; that policy is intentional in this release and does not silently create duplicate candidates.

Local verification results and the remaining environment-dependent gates are recorded in `docs/hardening/HARDENING_REPORT.md`. The CI job and container runtime have not been claimed as executed merely because their configuration is included.
