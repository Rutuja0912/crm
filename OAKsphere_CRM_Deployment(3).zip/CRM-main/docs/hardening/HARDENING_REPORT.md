# OAKsphere CRM — deployment handoff

Updated 19 September 2026. Source: `CRM-main (1)(1).zip` and its supplied 45-item hardening instructions. This continues the original repaired project.

The frontend now installs from a committed Yarn lockfile, builds successfully, passes strict ESLint and runs its component tests. Production Docker/Compose configuration, HTTPS ingress, readiness checks, a deployment runbook, eight browser release scenarios and a CI workflow are included. The existing React/FastAPI/MongoDB stack and CRM layout are retained. The application has not been deployed to a live host.

## Verified results

| Check | Actual result |
|---|---|
| Backend pytest | **235 passed, 0 failed, 5 explicitly skipped**, 756 dependency/framework deprecation warnings |
| Original live API suites | **121 passed**; modernized as isolated ASGI contracts with cookie auth, CSRF and per-test databases |
| Real replica-set gates | 5 skipped in the mock run; explicit real-Mongo run fails at database setup (connection refused); startup previously denied (`Operation not permitted`) |
| Python syntax and critical static errors | PASS |
| Python installed dependency compatibility | `pip check`: PASS |
| Frontend component tests | **37 passed, 0 failed**, 9 suites |
| Frontend production build | **PASS** from the Yarn-installed dependency graph |
| ESLint | **PASS**, `--max-warnings=0` |
| Yarn lock / frozen install | **PASS**, Yarn 1.22.22; repeat frozen install leaves the lockfile unchanged |
| Browser release tests | Eight scenarios collect; cloud browser cannot reach the local build (`ERR_BLOCKED_BY_CLIENT`); local browser/real Mongo remain unavailable |
| Deployment YAML | Compose and workflow parse successfully; source/configuration reviewed |
| Docker builds / Caddy runtime / CI execution | Builds, Caddy/Compose validation and HTTPS image smoke prepared; not executed here because Docker is unavailable |
| Live provider subscriptions, email and Google sign-in | Require actual provider credentials; mocked success is not live verification |

The backend suite exercises real FastAPI routes and services with fresh mongomock databases. Persisted values are read back, but transaction sessions are substituted. The five real-Mongo tests do not substitute transactions. In CI, the 121 repaired API contracts also use a real replica set; only the 114 targeted hardening cases retain controlled mocked dependencies. The release gate requires at least 240 cases and rejects all skipped/error/failed cases. Component remount tests verify API/UI contracts using stateful fixtures, not physical database durability. Browser tests use the real API and MongoDB when run in CI/staging.

Remaining warnings are recorded in the raw logs: existing CRA/transitive dependency deprecations, out-of-range inherited security resolutions, optional TypeScript/preview-tool peers, React Day Picker's older React peer range, Node's `fs.F_OK` deprecation, FastAPI event-handler deprecations and mongomock's UTC helper. The tested install, build and component suites pass despite those warnings. No clean vulnerability-audit claim is made.

## Deployment follow-up repairs

- Corrected the AJV/webpack dependency mismatch, aligned ESLint with CRA, resolved Jest's React Router export handling, fixed the refresh-concurrency test's asynchronous wait and generated the real Yarn lock. Optional editor overlays are excluded from production installs and load only for the development server.
- Removed unused imports, corrected hook dependencies, added joining-dialog descriptive text and made the toast reducer return its existing state for unknown actions. Strict lint now passes without source warnings.
- Replaced the enabled-but-inert Google login button with the provider's rendered button and cookie-session flow. Added credential callback/error tests and server checks for audience, issuer, expiry, verified email and existing active membership. Provider failures return controlled errors. Real Google-account validation remains external.
- Added Python 3.12/Node 24 container builds, non-root API execution, a read-only API filesystem, same-origin HTTPS, narrowly trusted ingress forwarding, persistent TLS data, health checks, release image tags and deployment/rollback instructions.
- Production startup rejects placeholder secrets, short bootstrap passwords, invalid proxy networks and invalid frontend/CORS origins. Mongo connection attempts are bounded; database outages return a sanitized 503.
- Completed historical tag-reference canonicalization and tested migration idempotence. Archived duplicate catalog entries retain their documents while candidates point to the canonical spelling.
- Removed preview analytics/session-recording scripts from production HTML and replaced the generic page title. Suppressed HTTP-client URL logs that could contain provider tokens; the production API disables query-bearing access logs. Old administrator credentials in legacy test/document artifacts now use environment references or redacted placeholders.
- Added a CI release job with real replica-set rollback/concurrency tests, eight browser scenarios against the compiled frontend and real API, container builds and Caddy/Compose validation. Browser scenarios cover four-role route/session checks, candidate create/edit persistence, tag rename, joining fields and notification read state.

## Final test-suite repairs

- Removed the blanket skip of 121 API cases, the obsolete external preview URL, bearer-token assumptions and the dependency on existing shared demo data.
- Added a fresh per-test database and explicit login cookies/CSRF. Password resets, session revocations and lead edits no longer race across the two configured workers. Expected permission, validation and pipeline contracts now match the repaired application.
- Removed cross-test `pytest.created_lead_*` state and missing-application/lead skips. Conversion, duplicate, detail and scope checks own their fixtures and verify stored state.
- CI now rejects skipped or missing backend/browser cases. The default local run deliberately fails this release gate because five real-Mongo cases have not passed.
- Added a production-image HTTPS smoke covering a trusted test certificate, asset/deep-link serving, security headers, secure HttpOnly cookies, CSRF rejection, candidate write/read/archive and logout. This script is prepared, not falsely reported as executed.

## Root causes and repairs

Paths without a frontend prefix are under `backend/`. Browser-dependent fixes are implemented but still require execution in the button matrix.

| # | Area | Affected files | Root cause | Repair |
|---|---|---|---|---|
| 1 | Applications scope | api/modules_routes.py; services/modules_service.py | Authenticated access and detached construction bypassed scope. | Candidate view + owner/team checks on list/status/archive/convert; canonical conversion preserves provenance and team. |
| 2 | User escalation | services/user_service.py; api/user_routes.py | Delegated user management lacked target scope and grant ceilings. | Admin-only elevation, role/override ceilings, target/session scope, manager checks, self/last-admin protection and transaction guard. |
| 3 | Role escalation | api/role_routes.py | users.manage could mutate powerful roles. | Role creation, clone, rename, reset, permissions and delete require admin. |
| 4 | Resource scope | services/scope_service.py | Directory/user permissions widened candidate access. | Separate candidate, user, assignment, task and vendor scope policies. |
| 5 | Lead archive | core/query.py; recruitment/modules/dashboard/myday services | Operational queries included archived leads and children. | Central active filter; child scope follows current active parent; archive metadata retained. |
| 6 | Distribution | services/recruitment_service.py; frontend/src/pages/Leads.js | Empty payload could redistribute assigned/final records. | Preview eligible active unassigned records; explicit selected redistribution confirmation; scoped active targets and notifications. |
| 7 | Joining contract | models/recruitment.py; services/recruitment_service.py; frontend/src/pages/Joinings.js | UI stages/fields differed from backend and were dropped. | Strict supported stages and fields, transition validation, actual-date requirement, canonical lead transition. |
| 8 | Interview confirmation | models/recruitment.py; services/recruitment_service.py | Confirmation was unsupported and silently ignored. | Canonical independent confirmation field persisted and returned. |
| 9 | Interview actions | frontend/src/pages/Interviews.js; components/CandidateCall.js | WhatsApp lacked number; Call opened a drawer. | Scoped parent phone, shared WhatsApp activity, shared call workflow. |
| 10 | Joining WhatsApp | frontend/src/pages/Joinings.js | WhatsApp opened the drawer. | Shared normalized candidate deep link and activity logging. |
| 11 | Drawer permissions | frontend/src/components/LeadDrawer.js | Actions/own notes were shown despite backend denial. | Gate follow-up, disposition, edit, tags, assign and archive; notes use leads.edit policy. |
| 12 | Follow-up Call | frontend/src/pages/Followups.js | Call opened a drawer. | Shared calling workflow. |
| 13 | Working day | core/timeutil.py; frontend/src/lib/calendar.js | Next working day meant tomorrow regardless of weekends. | Organization weekdays, holidays and work-start time used by lead/follow-up/conversion suggestions. |
| 14 | Webhook routes | api/webhook_routes.py; server.py | Copied URLs had no registered route. | Registered Meta challenge/signature/account validation, bounded parsing, event identity and provider field retrieval. |
| 15 | Intake | services/intake_service.py; api/webhook_routes.py | Applications had no genuine secure ingestion path. | Secret-authenticated forms/careers intake and authenticated internal intake; strict fields, limits, owner isolation and dedupe. |
| 16 | Connection test | services/modules_service.py; frontend/src/pages/Integrations.js | Credential presence was reported as connected. | Remote Meta verification; connected only on success; Google configuration check explicitly says no remote test. |
| 17 | Partial credentials | services/modules_service.py | Blank fields erased saved secrets. | Merge encrypted values, retain blank fields, explicit clear, required initial fields. |
| 18 | Disconnect | services/modules_service.py | Missing integration could report success. | Missing record returns 404; valid disconnect clears encrypted credentials and status. |
| 19 | Notifications | frontend/src/hooks/useNotifications.js; NotificationBell.js; pages/Notifications.js | UI substituted My Day counts. | Real list/count/read/read-all endpoints, polling, cap, action links, timestamps and error/retry states. |
| 20 | Import owner | services/modules_service.py | Batch lookup ignored actor identity. | Commit requires batch ID + creator ID even for admins. |
| 21 | Import TTL | core/database.py; services/modules_service.py | Expired batches lacked consistent deletion/rejection. | TTL expiry index plus application-level expiry check before reuse. |
| 22 | Import validation | services/modules_service.py; models/recruitment.py | Raw row values bypassed canonical contracts. | Strict mappings/rules/enums/source validation and canonical lead creation; explicit row error counts. |
| 23 | Specific recruiter | frontend/src/pages/ImportLeads.js; services/modules_service.py | Backend workflow had no UI and weak owner checks. | Active in-scope picker, canonical resolver, team propagation and assignment notifications. |
| 24 | Auth architecture | core/config.py; core/csrf.py; api/auth_routes.py; frontend/src/lib/api.js | LocalStorage JWT plus cookies and permissive CORS. | Cookie-only default, HttpOnly/Secure policy, explicit origins, signed CSRF; bearer compatibility opt-in. |
| 25 | Refresh | frontend/src/lib/api.js; context/AuthContext.js | Client did not refresh or load cookie sessions. | Single-flight refresh, once-only retry, failed-refresh session invalidation and cookie-based reload. |
| 26 | Proxy IP | api/deps.py | Blind trust of arbitrary X-Forwarded-For. | Only known proxy CIDRs enable trusted-chain parsing. |
| 27 | Route RBAC | frontend/src/components/ProtectedRoute.js; App.js; layout/Sidebar.js | Direct URLs differed from hidden sidebar decisions. | any/all permission predicates and matching route/sidebar policies. |
| 28 | Assignment picker | api/recruitment_routes.py; services/user_service.py; frontend dialogs | Assignment depended on unrelated directory permission. | Dedicated assignment picker endpoint with action-specific authority. |
| 29 | Inactive users | services/user_service.py | Inactive accounts appeared as assignment targets. | Active valid candidate users only; scope enforced. |
| 30 | Timezone | core/timeutil.py; recruitment/modules/dashboard services; frontend/src/lib/calendar.js | UTC/browser day boundaries differed from organization day. | Organization-local day/week/month boundaries and input conversion, inclusive date ranges, DST checks and timezone validation. |
| 31 | Enum validation | models/recruitment.py | Services accepted inconsistent states and phone default. | Explicit Literals/strict models; interview default telephonic. |
| 32 | Lead updates | models/recruitment.py; services/recruitment_service.py | Empty/invalid identity values accepted; optional values could be discarded. | Validated supplied fields, explicit null rules, safe normalization and persisted optional clears. |
| 33 | Priorities | services/modules_service.py; models/recruitment.py | Settings exposed incompatible priorities. | Canonical low/medium/high across settings, API and UI. |
| 34 | Regex safety | core/query.py; recruitment/modules/user services; api/audit_routes.py | Raw user regex altered search meaning/cost. | Escaped bounded literal substring search. |
| 35 | Vendor removal | services/modules_service.py | Hard delete lost CRM history. | Soft archive with actor/time metadata and active-only lists. |
| 36 | Missing records | services/modules_service.py; services/notify_service.py | Several missing-target writes returned false success. | 404 checks on required archive/disconnect/read operations. |
| 37 | Tag uniqueness | services/modules_service.py; core/database.py | Rename admitted case variants; cascade not protected. | Normalized unique key, case-insensitive conflict checks, transactional rename/delete cascade. |
| 38 | Atomic workflow | core/transactions.py; recruitment/modules/user services; API mutation routes | Standalone fallback and writes before validation could partially commit. | Fail closed without transactions, session-bound nested writes, prevalidation, route audit in same commit; real rollback gates added. |
| 39 | Action Required | services/modules_service.py; frontend/src/pages/ActionRequired.js | View All was text and links/counts were poorly scoped. | Real scoped links, own-lead navigation, permission-filtered cards, confirmation-aware counts and error state. |
| 40 | Simulator | frontend/src/pages/LeadSources.js | Timeout closure could use stale source state. | Explicit source parameter; development flag; label disclaims real webhook testing. |
| 41 | Quick actions | frontend/src/components/QuickActions.js; ResourceScreen.js | Labels promised creation but only navigated. | Honest Open labels or deep links that open the create dialog. |
| 42 | Confirmations | frontend/src/components/ActionDialogs.js; ConfirmDialog.js; ui/button.jsx | Native prompts and unguarded async controls. | Accessible queued dialogs, cancel/confirm, pending feedback and double-submit prevention for async buttons. |
| 43 | Silent errors | frontend/src/lib/api.js; affected pages/dialogs | Empty catches/empty lists masked failed requests. | Visible error messages; retry states on key pages; no false clipboard success; failed logout retains session. |
| 44 | Settings | services/modules_service.py; api/settings_routes.py | Duplicate company/agency keys could drift. | Canonical org record and aliases; calendar/list/target validation. |
| 45 | Identifiers | core/database.py; core/transactions.py; services/recruitment_service.py | Short UUID code lacked unique index/collision recovery. | Full UUID codes, history-preserving backfill, unique index and whole-workflow retry for code conflicts. |

## Additional findings repaired

- Startup no longer resets an existing administrator password or writes a credentials file.
- Audit actor filters cannot replace a restricted user's self-scope. Audit dates use inclusive organization-local calendar days and reject malformed values.
- The legacy quick-call path now uses the status engine, including closure reasons, status history and cancellation of final-stage follow-ups.
- Lead partial-update validation no longer rejects omitted name/phone/priority fields. Explicit optional-field clearing persists.
- Dashboard recruiter filtering now also limits call totals. Daily lineup reporting uses dated status history instead of total current lineup inventory.
- Malformed signed WhatsApp metadata/contacts and malformed provider field data receive controlled errors.
- Concurrent administrator removal is serialized by a shared transaction guard; the actual concurrent Mongo test is supplied but unexecuted.
- API mutations for recruitment, modules, users, roles and settings share a transaction with their audit write. Meta remote verification is kept outside a long-running transaction.
- Shared Button correctly supports a single `asChild` element; async failures surface, and controls disable while pending. Search URL changes update the existing Leads screen.

## Security assessment

| Topic | Evidence and limit |
|---|---|
| IDOR / record scope | Negative tests cover applications, user permissions/sessions, candidate archive exclusion, bulk operations, imports and audit filters. Known gaps repaired. This does **not** prove the absence of every possible IDOR. |
| Privilege escalation | Tested non-admin admin creation, grant ceilings, role mutation restrictions, manager scope, self/last-admin protections. Real concurrent protection remains a release gate. |
| Secrets | Responses expose only set/unset credential state; encrypted storage retained; blank-edit and redaction tests pass. Provider responses/errors are sanitized. No real credentials included in this delivery. |
| Cookies / CSRF | Login, refresh, logout, signed CSRF and trusted proxy behavior tested. Cross-site browser cookie behavior remains untested. |
| Intake | Shared-secret checks, Meta challenge/signature checks, deduplication, bounds and owner-field rejection tested with fixtures/mocked provider reads. Actual provider subscriptions and tokens remain unverified. |
| Transactions | Silent standalone fallback removed; workflows and audit use session-bound writes. Mongo failed to start here (`Operation not permitted`), so rollback is **not verified**. |
| Dependencies | Backend runtime installs succeeded after removing unused/unavailable dependencies. Frozen Yarn installation, production build, ESLint and frontend tests pass. A full dependency vulnerability audit is not claimed. |

## Remaining staging and account checks

1. Run the included CI release job on a Docker/browser-capable runner. MongoDB is unavailable, Docker is absent, and the cloud browser blocks the local application. Do not treat collected browser cases or parsed YAML as executed tests.
2. Rehearse startup/index migration on a restored copy of the real database, then complete the browser role/action matrix. Start one API instance with writes paused during migration. All 121 repaired API contracts pass locally with mongomock; real-database execution remains required in CI.
3. Supply the deployment hostname, authenticated replica-set URI, stable JWT secret and bootstrap administrator credentials. Configure and validate each enabled provider using its real account. The code and mock tests cannot certify subscription delivery or real account consent.

Repeated public applications with the same provider, phone and role reuse the existing application, including archived applications. Public intake remains unassigned for administrator triage. WhatsApp opens a deep link; it does not prove delivery. These behavior contracts are preserved and documented rather than left as hidden pending implementation.

Start with `deploy/README.md`. `DEPLOYMENT.md` documents business/intake contracts; `TEST_EVIDENCE.md` enumerates actual cases; `BUTTON_REGRESSION_MATRIX.md` distinguishes executed component checks from pending browser acceptance. The compiled frontend is included in the ZIP under `frontend/build/`.
