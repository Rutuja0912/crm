# Remaining runtime checks — 19 September 2026

- Local full backend run: 235 passed, five explicitly skipped real-Mongo cases. The six former live suites contribute 121 passing ASGI API contracts, with actual cookie authentication, signed CSRF and isolated mongomock data.
- After the final fixture/negative-duplicate refinements, three affected contracts were rerun: three passed.
- Explicit real-Mongo run: all five cases attempted; all five failed during setup because `127.0.0.1:27018` refused the connection. No transaction scenario reached execution. The prior mongod startup log reported `open: Operation not permitted`. See real-mongo-tests.log and real-mongo-results.xml.
- A supported cloud Chrome session was acquired. Opening the running production build at `http://127.0.0.1:3000` returned `net::ERR_BLOCKED_BY_CLIENT`. No UI clicks or screenshots are reported as passes. The earlier standalone browser download was denied by the network allowlist.
- Docker/Podman and a Docker daemon/socket are unavailable. Both container builds and the new HTTPS production-image smoke remain unexecuted here. Shell/Python syntax, workflow/Compose YAML parsing and critical static checks pass.
- `python deploy/check_test_results.py docs/hardening/backend-results.xml --minimum 240` exits 1 with `Release blocked: 240 cases, 5 failed/errored/skipped; at least 240 passing cases required.` This is the intended result until a real runner passes every gate.
- GitHub was found as an available, unconnected integration and suggested for running CI. No repository was uploaded, workflow triggered or deployment performed.

The test workflow uses only disposable fixture accounts and an isolated replica set. Production hostname, database, host access and live provider credentials remain the user's deployment configuration; none is invented or bundled.
