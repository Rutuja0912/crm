# Test evidence

Backend: 235 passed, 5 skipped, 0 failed. All 121 former live API cases now run. Frontend: 37 passed, 0 failed.

All results below come from captured pytest/Jest outputs. Component API fixtures and in-memory backend tests do not prove real MongoDB transaction behavior.

## Frontend component results

| Suite | Scenario | Result |
|---|---|---|
| `__tests__/joining.test.js` | joining edit submits all fields and values survive page remount | PASSED |
| `__tests__/api.test.js` | concurrent 401s share one refresh and retry each request once | PASSED |
| `__tests__/api.test.js` | failed refresh invalidates the session without a request loop | PASSED |
| `__tests__/api.test.js` | a retried 401 and a failed login never trigger refresh | PASSED |
| `__tests__/api.test.js` | concurrent mutations share CSRF acquisition | PASSED |
| `__tests__/api.test.js` | expired CSRF cookie is renewed once | PASSED |
| `__tests__/notifications.test.js` | reads real notification endpoints and read state survives remount | PASSED |
| `__tests__/notifications.test.js` | mark all persists and unread filter becomes empty | PASSED |
| `__tests__/notifications.test.js` | load errors show retry instead of an empty inbox | PASSED |
| `__tests__/authContext.test.js` | reload authenticates an HTTP-only cookie session without a localStorage token | PASSED |
| `__tests__/authContext.test.js` | failed logout retains user state | PASSED |
| `__tests__/authContext.test.js` | successful logout clears session state | PASSED |
| `__tests__/authContext.test.js` | transient session load failure is visible | PASSED |
| `__tests__/googleSignIn.test.js` | Google credential creates the cookie session before navigating | PASSED |
| `__tests__/googleSignIn.test.js` | provider script failure is visible and retryable | PASSED |
| `__tests__/permissions.test.js` | admin direct route enforces any and all permission checks | PASSED |
| `__tests__/permissions.test.js` | team_leader direct route enforces any and all permission checks | PASSED |
| `__tests__/permissions.test.js` | recruiter direct route enforces any and all permission checks | PASSED |
| `__tests__/permissions.test.js` | restricted direct route enforces any and all permission checks | PASSED |
| `__tests__/permissions.test.js` | candidate view alone does not grant edit route | PASSED |
| `__tests__/button.test.js` | asChild preserves a single interactive link | PASSED |
| `__tests__/button.test.js` | a pending action is disabled and cannot double submit | PASSED |
| `__tests__/button.test.js` | an unhandled action failure is visible | PASSED |
| `__tests__/candidateActions.test.js` | normalizes 9876543210 safely | PASSED |
| `__tests__/candidateActions.test.js` | normalizes +44 7700 900123 safely | PASSED |
| `__tests__/candidateActions.test.js` | normalizes 0091 9876543210 safely | PASSED |
| `__tests__/candidateActions.test.js` | rejects invalid numbers | PASSED |
| `__tests__/candidateActions.test.js` | candidate WhatsApp opens the correct number and logs the parent lead | PASSED |
| `__tests__/candidateActions.test.js` | clipboard failure never reports success | PASSED |
| `__tests__/candidateActions.test.js` | rejects unsafe action URL https://outside.example/ | PASSED |
| `__tests__/candidateActions.test.js` | rejects unsafe action URL //outside.example/ | PASSED |
| `__tests__/candidateActions.test.js` | rejects unsafe action URL /admin/\outside | PASSED |
| `__tests__/candidateActions.test.js` | rejects unsafe action URL null | PASSED |
| `__tests__/calendar.test.js` | Friday suggests Monday in the organization timezone | PASSED |
| `__tests__/calendar.test.js` | Holidays are skipped | PASSED |
| `__tests__/calendar.test.js` | datetime inputs round trip independently of browser timezone | PASSED |
| `__tests__/calendar.test.js` | Nonexistent DST time is rejected | PASSED |

## Backend results

| Case | Result |
|---|---|
| `tests.test_hardening.test_strict_models[LeadCreate-payload0]` | PASS |
| `tests.test_hardening.test_strict_models[LeadCreate-payload1]` | PASS |
| `tests.test_hardening.test_strict_models[LeadCreate-payload2]` | PASS |
| `tests.test_hardening.test_strict_models[LeadCreate-payload3]` | PASS |
| `tests.test_hardening.test_strict_models[LeadUpdate-payload4]` | PASS |
| `tests.test_hardening.test_strict_models[LeadUpdate-payload5]` | PASS |
| `tests.test_hardening.test_strict_models[LeadUpdate-payload6]` | PASS |
| `tests.test_hardening.test_strict_models[LeadUpdate-payload7]` | PASS |
| `tests.test_hardening.test_strict_models[TaskUpdate-payload8]` | PASS |
| `tests.test_hardening.test_strict_models[TaskCreate-payload9]` | PASS |
| `tests.test_hardening.test_strict_models[InterviewUpdate-payload10]` | PASS |
| `tests.test_hardening.test_strict_models[InterviewUpdate-payload11]` | PASS |
| `tests.test_hardening.test_strict_models[InterviewUpdate-payload12]` | PASS |
| `tests.test_hardening.test_strict_models[JoiningUpdate-payload13]` | PASS |
| `tests.test_hardening.test_strict_models[JoiningUpdate-payload14]` | PASS |
| `tests.test_hardening.test_strict_models[UserUpdate-payload15]` | PASS |
| `tests.test_hardening.test_strict_models[VendorInput-payload16]` | PASS |
| `tests.test_hardening.test_strict_models[TemplateInput-payload17]` | PASS |
| `tests.test_hardening.test_default_interview_type` | PASS |
| `tests.test_hardening.test_directory_not_candidate_scope[own]` | PASS |
| `tests.test_hardening.test_directory_not_candidate_scope[restricted]` | PASS |
| `tests.test_hardening.test_user_target_scope[get_effective-own]` | PASS |
| `tests.test_hardening.test_user_target_scope[get_effective-leader]` | PASS |
| `tests.test_hardening.test_user_target_scope[get_effective-restricted]` | PASS |
| `tests.test_hardening.test_user_target_scope[list_sessions-own]` | PASS |
| `tests.test_hardening.test_user_target_scope[list_sessions-leader]` | PASS |
| `tests.test_hardening.test_user_target_scope[list_sessions-restricted]` | PASS |
| `tests.test_hardening.test_user_target_scope[revoke_all_sessions-own]` | PASS |
| `tests.test_hardening.test_user_target_scope[revoke_all_sessions-leader]` | PASS |
| `tests.test_hardening.test_user_target_scope[revoke_all_sessions-restricted]` | PASS |
| `tests.test_hardening.test_user_target_scope[set_permission_overrides-own]` | PASS |
| `tests.test_hardening.test_user_target_scope[set_permission_overrides-leader]` | PASS |
| `tests.test_hardening.test_user_target_scope[set_permission_overrides-restricted]` | PASS |
| `tests.test_hardening.test_nonadmin_cannot_create_admin[leader]` | PASS |
| `tests.test_hardening.test_nonadmin_cannot_create_admin[restricted]` | PASS |
| `tests.test_hardening.test_permission_ceiling_and_last_admin` | PASS |
| `tests.test_hardening.test_role_mutation_admin_only[POST-/roles-payload0]` | PASS |
| `tests.test_hardening.test_role_mutation_admin_only[POST-/roles/admin/clone-payload1]` | PASS |
| `tests.test_hardening.test_role_mutation_admin_only[PUT-/roles/team_leader-payload2]` | PASS |
| `tests.test_hardening.test_role_mutation_admin_only[PUT-/roles/recruiter/rename-payload3]` | PASS |
| `tests.test_hardening.test_role_mutation_admin_only[POST-/roles/recruiter/reset-payload4]` | PASS |
| `tests.test_hardening.test_role_mutation_admin_only[DELETE-/roles/recruiter-None]` | PASS |
| `tests.test_hardening.test_application_list_scope[admin-3]` | PASS |
| `tests.test_hardening.test_application_list_scope[leader-2]` | PASS |
| `tests.test_hardening.test_application_list_scope[own-1]` | PASS |
| `tests.test_hardening.test_application_list_scope[restricted-0]` | PASS |
| `tests.test_hardening.test_application_idor[shortlist]` | PASS |
| `tests.test_hardening.test_application_idor[archive]` | PASS |
| `tests.test_hardening.test_application_idor[convert]` | PASS |
| `tests.test_hardening.test_conversion_canonical_team_private_duplicate` | PASS |
| `tests.test_hardening.test_conversion_bad_assignment_no_write` | PASS |
| `tests.test_hardening.test_archive_operational_exclusion` | PASS |
| `tests.test_hardening.test_auto_distribution_preview_safe_default` | PASS |
| `tests.test_hardening.test_assignable_without_directory_permission` | PASS |
| `tests.test_hardening.test_bulk_authorizes_every_record_before_write` | PASS |
| `tests.test_hardening.test_interview_persistence_prevalidation` | PASS |
| `tests.test_hardening.test_joining_contract_persisted` | PASS |
| `tests.test_hardening.test_followup_prevalidation` | PASS |
| `tests.test_hardening.test_standalone_fails_before_writes` | PASS |
| `tests.test_hardening.test_import_ownership_even_for_admin[peer]` | PASS |
| `tests.test_hardening.test_import_ownership_even_for_admin[leader]` | PASS |
| `tests.test_hardening.test_import_ownership_even_for_admin[admin]` | PASS |
| `tests.test_hardening.test_import_validation_expiry_and_idempotency` | PASS |
| `tests.test_hardening.test_tag_duplicate_rename_cascade` | PASS |
| `tests.test_hardening.test_nonexistent_archive_404[/jobs/missing]` | PASS |
| `tests.test_hardening.test_nonexistent_archive_404[/clients/missing]` | PASS |
| `tests.test_hardening.test_nonexistent_archive_404[/templates/missing]` | PASS |
| `tests.test_hardening.test_nonexistent_archive_404[/applications/missing]` | PASS |
| `tests.test_hardening.test_nonexistent_archive_404[/vendors/missing]` | PASS |
| `tests.test_hardening.test_vendor_soft_archive` | PASS |
| `tests.test_hardening.test_literal_regex_search[/leads]` | PASS |
| `tests.test_hardening.test_literal_regex_search[/jobs]` | PASS |
| `tests.test_hardening.test_literal_regex_search[/clients]` | PASS |
| `tests.test_hardening.test_literal_regex_search[/vendors]` | PASS |
| `tests.test_hardening.test_literal_regex_search[/templates]` | PASS |
| `tests.test_hardening.test_literal_regex_search[/applications]` | PASS |
| `tests.test_hardening.test_literal_regex_search[/users]` | PASS |
| `tests.test_hardening.test_literal_regex_search[/search]` | PASS |
| `tests.test_hardening.test_timezone_calendar_settings` | PASS |
| `tests.test_hardening.test_notification_privacy_and_read_state` | PASS |
| `tests.test_hardening.test_integration_partial_edits_and_validation` | PASS |
| `tests.test_hardening.test_forms_secret_idempotency_and_bounds` | PASS |
| `tests.test_hardening.test_meta_signature_challenge_and_deduplication` | PASS |
| `tests.test_hardening.test_cookie_auth_csrf_refresh_logout` | PASS |
| `tests.test_hardening.test_trusted_proxy_headers` | PASS |
| `tests.test_hardening.test_create_assignment_does_not_inherit_other_actions[leads.transfer]` | PASS |
| `tests.test_hardening.test_create_assignment_does_not_inherit_other_actions[leads.auto_distribute]` | PASS |
| `tests.test_hardening.test_lead_clear_optional_fields_persists` | PASS |
| `tests.test_public_api.test_health` | PASS |
| `tests.test_hardening.test_legacy_call_uses_status_engine` | PASS |
| `tests.test_public_api.test_admin_login_and_me` | PASS |
| `tests.test_hardening.test_malformed_whatsapp_is_validation_error[None-contacts0]` | PASS |
| `tests.test_hardening.test_malformed_whatsapp_is_validation_error[metadata1-None]` | PASS |
| `tests.test_hardening.test_malformed_whatsapp_is_validation_error[metadata2-contacts2]` | PASS |
| `tests.test_hardening.test_action_cards_follow_candidate_and_module_permissions` | PASS |
| `tests.test_hardening.test_audit_actor_filter_cannot_expand_self_scope` | PASS |
| `tests.test_hardening.test_audit_dates_use_inclusive_org_day_and_reject_invalid` | PASS |
| `tests.test_hardening.test_report_lineups_count_day_history_not_current_inventory` | PASS |
| `tests.test_hardening.test_password_reset_single_use_hash_and_revocation` | PASS |
| `tests.test_public_api.test_admin_list_users` | PASS |
| `tests.test_public_api.test_recruiter_denied_list_users` | PASS |
| `tests.test_hardening.test_change_password_retains_only_calling_session` | PASS |
| `tests.test_public_api.test_recruiter_denied_create_user` | PASS |
| `tests.test_public_api.test_recruiter_denied_other_user` | PASS |
| `tests.test_hardening.test_code_collision_retries_whole_workflow` | PASS |
| `tests.test_hardening.test_dashboard_recruiter_filter_limits_call_totals` | PASS |
| `tests.test_hardening.test_csrf_rejection_has_cors_headers` | PASS |
| `tests.test_hardening.test_tag_migration_preserves_catalog_references_and_is_idempotent` | PASS |
| `tests.test_hardening.test_google_oidc_validation_and_cookie_contract[patch0-200]` | PASS |
| `tests.test_hardening.test_google_oidc_validation_and_cookie_contract[patch1-401]` | PASS |
| `tests.test_hardening.test_google_oidc_validation_and_cookie_contract[patch2-401]` | PASS |
| `tests.test_hardening.test_google_oidc_validation_and_cookie_contract[patch3-401]` | PASS |
| `tests.test_hardening.test_google_oidc_validation_and_cookie_contract[patch4-401]` | PASS |
| `tests.test_public_api.test_team_leader_scope` | PASS |
| `tests.test_hardening.test_google_oidc_validation_and_cookie_contract[patch5-403]` | PASS |
| `tests.test_hardening.test_production_config_rejects_unsafe_values[JWT_SECRET-replace-with-a-unique-random-secret]` | PASS |
| `tests.test_hardening.test_production_config_rejects_unsafe_values[ADMIN_PASSWORD-short]` | PASS |
| `tests.test_hardening.test_production_config_rejects_unsafe_values[FRONTEND_URL-https://untrusted.example.com]` | PASS |
| `tests.test_hardening.test_production_config_rejects_unsafe_values[CORS_ORIGINS-https://crm.example.com/path]` | PASS |
| `tests.test_hardening.test_production_config_rejects_unsafe_values[TRUSTED_PROXY_CIDRS-not-a-network]` | PASS |
| `tests.test_hardening.test_readiness_database_failure_is_sanitized_503` | PASS |
| `tests.test_public_api.test_team_leader_cannot_access_admin_record` | PASS |
| `tests.test_public_api.test_logout_revokes_session` | PASS |
| `tests.test_auth_prompt2.test_auth_config_endpoint` | PASS |
| `tests.test_auth_prompt2.test_google_login_not_configured` | PASS |
| `tests.test_auth_prompt2.test_admin_login_success` | PASS |
| `tests.test_public_api.test_forgot_password_generic_success` | PASS |
| `tests.test_public_api.test_reset_password_invalid_token` | PASS |
| `tests.test_public_api.test_admin_can_view_audit_logs` | PASS |
| `tests.test_auth_prompt2.test_wrong_password_returns_401` | PASS |
| `tests.test_public_api.test_admin_dashboard` | PASS |
| `tests.test_auth_prompt2.test_logout_revokes_session` | PASS |
| `tests.test_public_api.test_admin_settings_get` | PASS |
| `tests.test_auth_prompt2.test_forgot_password_neutral_message` | PASS |
| `tests.test_auth_prompt2.test_rate_limit_after_10_failures` | PASS |
| `tests.test_public_api.test_admin_roles_get` | PASS |
| `tests.test_auth_prompt2.test_inactive_user_blocked` | PASS |
| `tests.test_foundation.test_effective_permissions_admin_all` | PASS |
| `tests.test_auth_prompt2.test_change_password_full_flow` | PASS |
| `tests.test_foundation.test_recruiter_defaults` | PASS |
| `tests.test_foundation.test_login_and_me` | PASS |
| `tests.test_foundation.test_login_bad_password` | PASS |
| `tests.test_foundation.test_me_requires_auth` | PASS |
| `tests.test_foundation.test_recruiter_cannot_create_user` | PASS |
| `tests.test_foundation.test_recruiter_cannot_list_users` | PASS |
| `tests.test_foundation.test_team_leader_cannot_access_admin_record` | PASS |
| `tests.test_foundation.test_team_leader_scope` | PASS |
| `tests.test_foundation.test_logout_revokes_session` | PASS |
| `tests.test_recruitment_prompts6to10.TestLeadsGrid.test_admin_list_default` | PASS |
| `tests.test_recruitment_prompts6to10.TestLeadsGrid.test_view_chip[fresh-new]` | PASS |
| `tests.test_recruitment_prompts6to10.TestLeadsGrid.test_view_chip[interested-interested]` | PASS |
| `tests.test_auth_prompt2.test_reset_password_weak_policy_rejected` | PASS |
| `tests.test_recruitment_prompts6to10.TestLeadsGrid.test_view_chip[joined-joined]` | PASS |
| `tests.test_auth_prompt2.test_reset_password_expired_token_rejected` | PASS |
| `tests.test_auth_prompt2.test_reset_password_single_use` | PASS |
| `tests.test_recruitment_prompts6to10.TestLeadsGrid.test_view_hot` | PASS |
| `tests.test_recruitment_prompts6to10.TestLeadsGrid.test_search_filter` | PASS |
| `tests.test_recruitment_prompts6to10.TestLeadsGrid.test_pagination` | PASS |
| `tests.test_recruitment_prompts6to10.TestLeadsGrid.test_sort_by_name_asc` | PASS |
| `tests.test_auth_prompt2.test_recruiter_cannot_access_admin_endpoints` | PASS |
| `tests.test_recruitment_prompts6to10.TestLeadsGrid.test_priority_filter` | PASS |
| `tests.test_modules_prompts11to34.TestReports.test_leaderboard` | PASS |
| `tests.test_modules_prompts11to34.test_health` | PASS |
| `tests.test_modules_prompts11to34.TestReports.test_targets` | PASS |
| `tests.test_modules_prompts11to34.test_lead_inbox` | PASS |
| `tests.test_modules_prompts11to34.TestReports.test_funnel` | PASS |
| `tests.test_modules_prompts11to34.TestReports.test_aging` | PASS |
| `tests.test_modules_prompts11to34.test_action_required_9_cards` | PASS |
| `tests.test_modules_prompts11to34.TestReports.test_missed` | PASS |
| `tests.test_modules_prompts11to34.test_action_required_recruiter_scoped` | PASS |
| `tests.test_modules_prompts11to34.TestReports.test_recruiter_forbidden` | PASS |
| `tests.test_modules_prompts11to34.test_global_search` | PASS |
| `tests.test_recruitment_prompts3to6.TestSecurity.test_recruiter_forbidden_admin_endpoints` | PASS |
| `tests.test_modules_prompts11to34.test_org_settings` | PASS |
| `tests.test_recruitment_prompts6to10.TestDisposition.test_connected_interested_moves_status` | PASS |
| `tests.test_recruitment_prompts6to10.TestDisposition.test_callback_requires_followup` | PASS |
| `tests.test_recruitment_prompts6to10.TestDisposition.test_callback_with_followup_ok` | PASS |
| `tests.test_recruitment_prompts3to6.TestSecurity.test_recruiter_cannot_read_or_edit_other_recruiters_lead` | PASS |
| `tests.test_recruitment_prompts6to10.TestDisposition.test_interview_scheduled_requires_details_and_moves_to_lineup` | PASS |
| `tests.test_recruitment_prompts6to10.TestDisposition.test_not_interested_requires_reason_then_finalizes` | PASS |
| `tests.test_recruitment_prompts3to6.TestSecurity.test_recruiter_filter_bypass_returns_zero` | PASS |
| `tests.test_recruitment_prompts6to10.TestDisposition.test_invalid_number_finalizes_invalid` | PASS |
| `tests.test_recruitment_prompts3to6.TestSecurity.test_recruiter_cannot_change_own_role` | PASS |
| `tests.test_recruitment_prompts3to6.TestSecurity.test_admin_cannot_change_own_role` | PASS |
| `tests.test_recruitment_prompts3to6.TestDashboard.test_admin_kpis_seeded` | PASS |
| `tests.test_recruitment_prompts3to6.TestSecurity.test_admin_cannot_deactivate_last_admin` | PASS |
| `tests.test_recruitment_prompts3to6.TestDashboard.test_recruiter_scope_only_own` | PASS |
| `tests.test_recruitment_prompts3to6.TestAccessControl.test_users_list_and_permissions_catalog` | PASS |
| `tests.test_recruitment_prompts3to6.TestDashboard.test_team_leader_scope_team` | PASS |
| `tests.test_recruitment_prompts3to6.TestDashboard.test_admin_recruiter_filter` | PASS |
| `tests.test_recruitment_prompts3to6.TestAccessControl.test_effective_permissions_endpoint` | PASS |
| `tests.test_recruitment_prompts3to6.TestDashboard.test_fresh_leads_link_filter` | PASS |
| `tests.test_recruitment_prompts3to6.TestAccessControl.test_role_lifecycle_clone_rename_reset_update_delete` | PASS |
| `tests.test_recruitment_prompts6to10.TestBulkAndExport.test_admin_export_csv` | PASS |
| `tests.test_recruitment_prompts3to6.TestAccessControl.test_admin_role_cannot_be_modified` | PASS |
| `tests.test_recruitment_prompts6to10.TestBulkAndExport.test_recruiter_cannot_export` | PASS |
| `tests.test_recruitment_prompts6to10.TestBulkAndExport.test_bulk_assign_admin` | PASS |
| `tests.test_recruitment_prompts3to6.TestAccessControl.test_sessions_and_revoke` | PASS |
| `tests.test_replica_set.test_lead_activity_failure_rolls_back_all_writes` | SKIPPED — real Mongo required |
| `tests.test_replica_set.test_selected_interview_joining_failure_rolls_back` | SKIPPED — real Mongo required |
| `tests.test_replica_set.test_assignment_notification_failure_rolls_back` | SKIPPED — real Mongo required |
| `tests.test_replica_set.test_api_audit_failure_rolls_back_business_write` | SKIPPED — real Mongo required |
| `tests.test_replica_set.test_concurrent_admin_removal_keeps_an_admin` | SKIPPED — real Mongo required |
| `tests.test_modules_prompts11to34.TestImport.test_template_download` | PASS |
| `tests.test_recruitment_prompts6to10.TestBulkAndExport.test_recruiter_cannot_assign` | PASS |
| `tests.test_modules_prompts11to34.TestImport.test_preview_and_commit_idempotent` | PASS |
| `tests.test_recruitment_prompts6to10.TestBulkAndExport.test_auto_distribute_admin` | PASS |
| `tests.test_modules_prompts11to34.TestImport.test_commit_requires_phone_mapping` | PASS |
| `tests.test_modules_prompts11to34.TestIntegrations.test_list_masked_by_default` | PASS |
| `tests.test_modules_prompts11to34.TestImport.test_recruiter_forbidden` | PASS |
| `tests.test_modules_prompts11to34.TestIntegrations.test_save_test_disconnect_round_trip` | PASS |
| `tests.test_recruitment_prompts6to10.TestCreateAndDuplicate.test_check_duplicate_negative` | PASS |
| `tests.test_modules_prompts11to34.TestIntegrations.test_recruiter_forbidden` | PASS |
| `tests.test_recruitment_prompts6to10.TestCreateAndDuplicate.test_create_unique_and_first_followup` | PASS |
| `tests.test_recruitment_prompts6to10.TestDetailNotesActivity.test_get_detail` | PASS |
| `tests.test_recruitment_prompts6to10.TestCreateAndDuplicate.test_duplicate_flagged_creation` | PASS |
| `tests.test_recruitment_prompts6to10.TestDetailNotesActivity.test_notes_crud` | PASS |
| `tests.test_recruitment_prompts6to10.TestDetailNotesActivity.test_activities_recorded` | PASS |
| `tests.test_recruitment_prompts6to10.TestRBAC.test_recruiter_only_sees_own` | PASS |
| `tests.test_modules_prompts11to34.TestJobs.test_crud` | PASS |
| `tests.test_modules_prompts11to34.TestJobs.test_missing_title` | PASS |
| `tests.test_modules_prompts11to34.TestVendors.test_summary_and_crud` | PASS |
| `tests.test_recruitment_prompts6to10.TestRBAC.test_recruiter_cannot_read_other_lead` | PASS |
| `tests.test_modules_prompts11to34.TestVendors.test_recruiter_forbidden` | PASS |
| `tests.test_recruitment_prompts6to10.TestRBAC.test_recruiter_cannot_auto_distribute` | PASS |
| `tests.test_modules_prompts11to34.TestNotifications.test_flow` | PASS |
| `tests.test_modules_prompts11to34.TestApplications.test_list_all` | PASS |
| `tests.test_modules_prompts11to34.TestApplications.test_convert_idempotent` | PASS |
| `tests.test_modules_prompts11to34.TestNotifications.test_isolation` | PASS |
| `tests.test_recruitment_prompts3to6.TestQuickActions.test_create_lead_persists` | PASS |
| `tests.test_recruitment_prompts3to6.TestMyDay.test_recruiter_myday_counts` | PASS |
| `tests.test_recruitment_prompts3to6.TestQuickActions.test_create_task_persists` | PASS |
| `tests.test_recruitment_prompts3to6.TestMyDay.test_myday_live_update_on_followup_done` | PASS |
| `tests.test_modules_prompts11to34.TestClients.test_crud` | PASS |
| `tests.test_modules_prompts11to34.TestTemplates.test_crud_and_channel_validation` | PASS |
| `tests.test_modules_prompts11to34.TestTags.test_crud` | PASS |
| `tests.test_modules_prompts11to34.TestFollowupsBoard.test_board_counts_and_tabs` | PASS |
| `tests.test_modules_prompts11to34.TestTasks.test_summary_and_crud` | PASS |
| `tests.test_modules_prompts11to34.TestInterviewsJoinings.test_lists` | PASS |
| `tests.test_recruitment_prompts3to6.TestStatusEngineAudit.test_status_transition_and_call_audit` | PASS |

The separate `real-mongo-tests.log` / `real-mongo-results.xml` record the explicit real-Mongo attempt. Setup cannot connect to a local replica set. `check_test_results.py` correctly rejects the default five skipped cases, so this package has no false green release approval.

Final targeted verification: three affected contracts passed after the final fixture refinements; see `final-targeted-tests.log`. Runtime-access attempts and the release-gate rejection are recorded in `RUNTIME_CHECKS.md`.
