# Button regression matrix

**Browser acceptance remains BLOCKED for every row below.** The cloud-browser attempt returned `net::ERR_BLOCKED_BY_CLIENT` for the local production build. All 121 former API contracts now execute within the 235 passing backend cases; this is additional API evidence, not browser click evidence. Admin, Team Leader, Recruiter and a restricted custom role must each be exercised. Backend API/service passes and executed frontend component checks in TEST_EVIDENCE.md are separate evidence; they are not substituted for a click/refresh test. Endpoint families below are relative to `/api`; the API inventory below gives exact registered methods and paths.

For every permitted mutation: show loading, prevent double submission, verify the database change, refresh the page and verify the retained value. For denied actions: hide/disable appropriately, reject direct URL/API-ID tampering, and prevent cross-team access. For navigation/filter actions: verify destination and matching scoped records. Errors must be visible and retryable.

| Page | Button/action | Roles actually browser-tested | API family | Expected | Actual | PASS/FAIL/BLOCKED |
|---|---|---|---|---|---|---|
| AUTH | Login | None; A/TL/R/custom required | `/auth/*` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| AUTH | Logout | None; A/TL/R/custom required | `/auth/*` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| AUTH | Forgot Password | None; A/TL/R/custom required | `/auth/*` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| AUTH | Reset Password | None; A/TL/R/custom required | `/auth/*` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| AUTH | session refresh | None; A/TL/R/custom required | `/auth/*` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| AUTH | Change Password | None; A/TL/R/custom required | `/auth/*` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| LEADS | All Leads | None; A/TL/R/custom required | `/leads; /leads/{id}/*; /leads/assign; /leads/transfer; /leads/auto-distribute` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| LEADS | My Leads | None; A/TL/R/custom required | `/leads; /leads/{id}/*; /leads/assign; /leads/transfer; /leads/auto-distribute` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| LEADS | Calling List | None; A/TL/R/custom required | `/leads; /leads/{id}/*; /leads/assign; /leads/transfer; /leads/auto-distribute` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| LEADS | every saved view | None; A/TL/R/custom required | `/leads; /leads/{id}/*; /leads/assign; /leads/transfer; /leads/auto-distribute` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| LEADS | every filter | None; A/TL/R/custom required | `/leads; /leads/{id}/*; /leads/assign; /leads/transfer; /leads/auto-distribute` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| LEADS | clear filters | None; A/TL/R/custom required | `/leads; /leads/{id}/*; /leads/assign; /leads/transfer; /leads/auto-distribute` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| LEADS | sorting | None; A/TL/R/custom required | `/leads; /leads/{id}/*; /leads/assign; /leads/transfer; /leads/auto-distribute` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| LEADS | pagination | None; A/TL/R/custom required | `/leads; /leads/{id}/*; /leads/assign; /leads/transfer; /leads/auto-distribute` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| LEADS | Add Lead | None; A/TL/R/custom required | `/leads; /leads/{id}/*; /leads/assign; /leads/transfer; /leads/auto-distribute` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| LEADS | duplicate detection | None; A/TL/R/custom required | `/leads; /leads/{id}/*; /leads/assign; /leads/transfer; /leads/auto-distribute` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| LEADS | Open Existing | None; A/TL/R/custom required | `/leads; /leads/{id}/*; /leads/assign; /leads/transfer; /leads/auto-distribute` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| LEADS | create flagged duplicate | None; A/TL/R/custom required | `/leads; /leads/{id}/*; /leads/assign; /leads/transfer; /leads/auto-distribute` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| LEADS | Edit | None; A/TL/R/custom required | `/leads; /leads/{id}/*; /leads/assign; /leads/transfer; /leads/auto-distribute` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| LEADS | Assign | None; A/TL/R/custom required | `/leads; /leads/{id}/*; /leads/assign; /leads/transfer; /leads/auto-distribute` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| LEADS | Transfer | None; A/TL/R/custom required | `/leads; /leads/{id}/*; /leads/assign; /leads/transfer; /leads/auto-distribute` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| LEADS | Auto-distribute | None; A/TL/R/custom required | `/leads; /leads/{id}/*; /leads/assign; /leads/transfer; /leads/auto-distribute` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| LEADS | bulk actions | None; A/TL/R/custom required | `/leads; /leads/{id}/*; /leads/assign; /leads/transfer; /leads/auto-distribute` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| LEADS | Export | None; A/TL/R/custom required | `/leads; /leads/{id}/*; /leads/assign; /leads/transfer; /leads/auto-distribute` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| LEADS | Call | None; A/TL/R/custom required | `/leads; /leads/{id}/*; /leads/assign; /leads/transfer; /leads/auto-distribute` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| LEADS | Disposition | None; A/TL/R/custom required | `/leads; /leads/{id}/*; /leads/assign; /leads/transfer; /leads/auto-distribute` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| LEADS | WhatsApp | None; A/TL/R/custom required | `/leads; /leads/{id}/*; /leads/assign; /leads/transfer; /leads/auto-distribute` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| LEADS | Tags | None; A/TL/R/custom required | `/leads; /leads/{id}/*; /leads/assign; /leads/transfer; /leads/auto-distribute` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| LEADS | status change | None; A/TL/R/custom required | `/leads; /leads/{id}/*; /leads/assign; /leads/transfer; /leads/auto-distribute` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| LEADS | Archive | None; A/TL/R/custom required | `/leads; /leads/{id}/*; /leads/assign; /leads/transfer; /leads/auto-distribute` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| LEAD DRAWER | Call | None; A/TL/R/custom required | `/leads/{id}; /leads/{id}/notes; /notes/{id}; /leads/{id}/followups; /leads/{id}/activities` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| LEAD DRAWER | Disposition | None; A/TL/R/custom required | `/leads/{id}; /leads/{id}/notes; /notes/{id}; /leads/{id}/followups; /leads/{id}/activities` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| LEAD DRAWER | WhatsApp | None; A/TL/R/custom required | `/leads/{id}; /leads/{id}/notes; /notes/{id}; /leads/{id}/followups; /leads/{id}/activities` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| LEAD DRAWER | Edit | None; A/TL/R/custom required | `/leads/{id}; /leads/{id}/notes; /notes/{id}; /leads/{id}/followups; /leads/{id}/activities` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| LEAD DRAWER | Assign | None; A/TL/R/custom required | `/leads/{id}; /leads/{id}/notes; /notes/{id}; /leads/{id}/followups; /leads/{id}/activities` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| LEAD DRAWER | Archive | None; A/TL/R/custom required | `/leads/{id}; /leads/{id}/notes; /notes/{id}; /leads/{id}/followups; /leads/{id}/activities` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| LEAD DRAWER | Follow-up | None; A/TL/R/custom required | `/leads/{id}; /leads/{id}/notes; /notes/{id}; /leads/{id}/followups; /leads/{id}/activities` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| LEAD DRAWER | Notes CRUD | None; A/TL/R/custom required | `/leads/{id}; /leads/{id}/notes; /notes/{id}; /leads/{id}/followups; /leads/{id}/activities` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| LEAD DRAWER | Tags | None; A/TL/R/custom required | `/leads/{id}; /leads/{id}/notes; /notes/{id}; /leads/{id}/followups; /leads/{id}/activities` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| LEAD DRAWER | activity | None; A/TL/R/custom required | `/leads/{id}; /leads/{id}/notes; /notes/{id}; /leads/{id}/followups; /leads/{id}/activities` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| LEAD DRAWER | follow-up history | None; A/TL/R/custom required | `/leads/{id}; /leads/{id}/notes; /notes/{id}; /leads/{id}/followups; /leads/{id}/activities` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| FOLLOW-UPS | every tab | None; A/TL/R/custom required | `/followups/board; /followups/{id}; /followups/{id}/complete; /leads/{id}/whatsapp` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| FOLLOW-UPS | search | None; A/TL/R/custom required | `/followups/board; /followups/{id}; /followups/{id}/complete; /leads/{id}/whatsapp` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| FOLLOW-UPS | recruiter filter | None; A/TL/R/custom required | `/followups/board; /followups/{id}; /followups/{id}/complete; /leads/{id}/whatsapp` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| FOLLOW-UPS | Call | None; A/TL/R/custom required | `/followups/board; /followups/{id}; /followups/{id}/complete; /leads/{id}/whatsapp` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| FOLLOW-UPS | WhatsApp | None; A/TL/R/custom required | `/followups/board; /followups/{id}; /followups/{id}/complete; /leads/{id}/whatsapp` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| FOLLOW-UPS | Reschedule | None; A/TL/R/custom required | `/followups/board; /followups/{id}; /followups/{id}/complete; /leads/{id}/whatsapp` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| FOLLOW-UPS | Complete / schedule next | None; A/TL/R/custom required | `/followups/board; /followups/{id}; /followups/{id}/complete; /leads/{id}/whatsapp` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| FOLLOW-UPS | Complete / final status | None; A/TL/R/custom required | `/followups/board; /followups/{id}; /followups/{id}/complete; /leads/{id}/whatsapp` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| FOLLOW-UPS | delete/archive | None; A/TL/R/custom required | `/followups/board; /followups/{id}; /followups/{id}/complete; /leads/{id}/whatsapp` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| TASKS | Add | None; A/TL/R/custom required | `/tasks; /tasks/{id}; /tasks/summary` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| TASKS | Edit | None; A/TL/R/custom required | `/tasks; /tasks/{id}; /tasks/summary` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| TASKS | Start | None; A/TL/R/custom required | `/tasks; /tasks/{id}; /tasks/summary` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| TASKS | Done | None; A/TL/R/custom required | `/tasks; /tasks/{id}; /tasks/summary` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| TASKS | Reopen | None; A/TL/R/custom required | `/tasks; /tasks/{id}; /tasks/summary` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| TASKS | filters | None; A/TL/R/custom required | `/tasks; /tasks/{id}; /tasks/summary` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| TASKS | Delete | None; A/TL/R/custom required | `/tasks; /tasks/{id}; /tasks/summary` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| APPLICATIONS | Search | None; A/TL/R/custom required | `/applications; /applications/{id}/status; /applications/{id}/convert; /webhooks/{provider}` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| APPLICATIONS | filter | None; A/TL/R/custom required | `/applications; /applications/{id}/status; /applications/{id}/convert; /webhooks/{provider}` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| APPLICATIONS | Shortlist | None; A/TL/R/custom required | `/applications; /applications/{id}/status; /applications/{id}/convert; /webhooks/{provider}` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| APPLICATIONS | Convert | None; A/TL/R/custom required | `/applications; /applications/{id}/status; /applications/{id}/convert; /webhooks/{provider}` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| APPLICATIONS | duplicate conversion | None; A/TL/R/custom required | `/applications; /applications/{id}/status; /applications/{id}/convert; /webhooks/{provider}` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| APPLICATIONS | Archive | None; A/TL/R/custom required | `/applications; /applications/{id}/status; /applications/{id}/convert; /webhooks/{provider}` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| APPLICATIONS | inbound creation/webhook | None; A/TL/R/custom required | `/applications; /applications/{id}/status; /applications/{id}/convert; /webhooks/{provider}` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| INTERVIEWS | All | None; A/TL/R/custom required | `/interviews; /interviews/{id}; /leads/{id}/whatsapp` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| INTERVIEWS | Tomorrow | None; A/TL/R/custom required | `/interviews; /interviews/{id}; /leads/{id}/whatsapp` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| INTERVIEWS | stage | None; A/TL/R/custom required | `/interviews; /interviews/{id}; /leads/{id}/whatsapp` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| INTERVIEWS | confirmation | None; A/TL/R/custom required | `/interviews; /interviews/{id}; /leads/{id}/whatsapp` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| INTERVIEWS | Call | None; A/TL/R/custom required | `/interviews; /interviews/{id}; /leads/{id}/whatsapp` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| INTERVIEWS | WhatsApp | None; A/TL/R/custom required | `/interviews; /interviews/{id}; /leads/{id}/whatsapp` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| INTERVIEWS | edit/reschedule | None; A/TL/R/custom required | `/interviews; /interviews/{id}; /leads/{id}/whatsapp` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| JOININGS | status | None; A/TL/R/custom required | `/joinings; /joinings/{id}; /leads/{id}/whatsapp` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| JOININGS | confirmation | None; A/TL/R/custom required | `/joinings; /joinings/{id}; /leads/{id}/whatsapp` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| JOININGS | expected date | None; A/TL/R/custom required | `/joinings; /joinings/{id}; /leads/{id}/whatsapp` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| JOININGS | actual date | None; A/TL/R/custom required | `/joinings; /joinings/{id}; /leads/{id}/whatsapp` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| JOININGS | salary | None; A/TL/R/custom required | `/joinings; /joinings/{id}; /leads/{id}/whatsapp` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| JOININGS | remarks | None; A/TL/R/custom required | `/joinings; /joinings/{id}; /leads/{id}/whatsapp` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| JOININGS | WhatsApp | None; A/TL/R/custom required | `/joinings; /joinings/{id}; /leads/{id}/whatsapp` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| JOININGS | Edit | None; A/TL/R/custom required | `/joinings; /joinings/{id}; /leads/{id}/whatsapp` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| JOBS | Add | None; A/TL/R/custom required | `/jobs; /jobs/{id}` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| JOBS | Edit | None; A/TL/R/custom required | `/jobs; /jobs/{id}` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| JOBS | Archive | None; A/TL/R/custom required | `/jobs; /jobs/{id}` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| JOBS | Search | None; A/TL/R/custom required | `/jobs; /jobs/{id}` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| CLIENTS | Add | None; A/TL/R/custom required | `/clients; /clients/{id}` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| CLIENTS | Edit | None; A/TL/R/custom required | `/clients; /clients/{id}` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| CLIENTS | Archive | None; A/TL/R/custom required | `/clients; /clients/{id}` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| CLIENTS | Search | None; A/TL/R/custom required | `/clients; /clients/{id}` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| CLIENTS | stats | None; A/TL/R/custom required | `/clients; /clients/{id}` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| VENDORS | Add | None; A/TL/R/custom required | `/vendors; /vendors/{id}; /vendors/summary` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| VENDORS | Edit | None; A/TL/R/custom required | `/vendors; /vendors/{id}; /vendors/summary` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| VENDORS | stage | None; A/TL/R/custom required | `/vendors; /vendors/{id}; /vendors/summary` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| VENDORS | Search | None; A/TL/R/custom required | `/vendors; /vendors/{id}; /vendors/summary` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| VENDORS | Archive | None; A/TL/R/custom required | `/vendors; /vendors/{id}; /vendors/summary` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| TEMPLATES | WhatsApp/Email | None; A/TL/R/custom required | `/templates; /templates/{id}` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| TEMPLATES | Add | None; A/TL/R/custom required | `/templates; /templates/{id}` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| TEMPLATES | Edit | None; A/TL/R/custom required | `/templates; /templates/{id}` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| TEMPLATES | preview | None; A/TL/R/custom required | `/templates; /templates/{id}` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| TEMPLATES | variables | None; A/TL/R/custom required | `/templates; /templates/{id}` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| TEMPLATES | Copy Formatted | None; A/TL/R/custom required | `/templates; /templates/{id}` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| TEMPLATES | Duplicate | None; A/TL/R/custom required | `/templates; /templates/{id}` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| TEMPLATES | Archive/Delete | None; A/TL/R/custom required | `/templates; /templates/{id}` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| REPORTS | every tab | None; A/TL/R/custom required | `/reports?tab=…` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| REPORTS | recruiter/team scoping | None; A/TL/R/custom required | `/reports?tab=…` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| REPORTS | time boundaries | None; A/TL/R/custom required | `/reports?tab=…` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| ACTION REQUIRED | every card | None; A/TL/R/custom required | `/action-required; client navigation` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| ACTION REQUIRED | every View All navigation | None; A/TL/R/custom required | `/action-required; client navigation` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| LEAD INBOX / SOURCES | source chips | None; A/TL/R/custom required | `/lead-inbox; /webhooks/{provider}; development-only /leads` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| LEAD INBOX / SOURCES | search | None; A/TL/R/custom required | `/lead-inbox; /webhooks/{provider}; development-only /leads` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| LEAD INBOX / SOURCES | source counts | None; A/TL/R/custom required | `/lead-inbox; /webhooks/{provider}; development-only /leads` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| LEAD INBOX / SOURCES | webhook ingestion | None; A/TL/R/custom required | `/lead-inbox; /webhooks/{provider}; development-only /leads` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| LEAD INBOX / SOURCES | simulator | None; A/TL/R/custom required | `/lead-inbox; /webhooks/{provider}; development-only /leads` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| INTEGRATIONS | Configure | None; A/TL/R/custom required | `/integrations; /integrations/{key}; /integrations/{key}/test; /integrations/{key}/disconnect` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| INTEGRATIONS | partial credential edit | None; A/TL/R/custom required | `/integrations; /integrations/{key}; /integrations/{key}/test; /integrations/{key}/disconnect` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| INTEGRATIONS | Test | None; A/TL/R/custom required | `/integrations; /integrations/{key}; /integrations/{key}/test; /integrations/{key}/disconnect` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| INTEGRATIONS | Disconnect | None; A/TL/R/custom required | `/integrations; /integrations/{key}; /integrations/{key}/test; /integrations/{key}/disconnect` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| INTEGRATIONS | Webhook URL | None; A/TL/R/custom required | `/integrations; /integrations/{key}; /integrations/{key}/test; /integrations/{key}/disconnect` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| INTEGRATIONS | invalid token | None; A/TL/R/custom required | `/integrations; /integrations/{key}; /integrations/{key}/test; /integrations/{key}/disconnect` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| INTEGRATIONS | expired token | None; A/TL/R/custom required | `/integrations; /integrations/{key}; /integrations/{key}/test; /integrations/{key}/disconnect` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| INTEGRATIONS | missing credential | None; A/TL/R/custom required | `/integrations; /integrations/{key}; /integrations/{key}/test; /integrations/{key}/disconnect` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| INTEGRATIONS | correct provider connection | None; A/TL/R/custom required | `/integrations; /integrations/{key}; /integrations/{key}/test; /integrations/{key}/disconnect` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| IMPORT | Template download | None; A/TL/R/custom required | `/imports/template; /imports/preview; /imports/commit` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| IMPORT | CSV | None; A/TL/R/custom required | `/imports/template; /imports/preview; /imports/commit` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| IMPORT | XLSX | None; A/TL/R/custom required | `/imports/template; /imports/preview; /imports/commit` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| IMPORT | mapping | None; A/TL/R/custom required | `/imports/template; /imports/preview; /imports/commit` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| IMPORT | duplicates | None; A/TL/R/custom required | `/imports/template; /imports/preview; /imports/commit` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| IMPORT | invalid phone | None; A/TL/R/custom required | `/imports/template; /imports/preview; /imports/commit` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| IMPORT | unassigned | None; A/TL/R/custom required | `/imports/template; /imports/preview; /imports/commit` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| IMPORT | auto-distribute | None; A/TL/R/custom required | `/imports/template; /imports/preview; /imports/commit` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| IMPORT | specific recruiter if supported | None; A/TL/R/custom required | `/imports/template; /imports/preview; /imports/commit` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| IMPORT | repeat commit | None; A/TL/R/custom required | `/imports/template; /imports/preview; /imports/commit` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| IMPORT | expired batch | None; A/TL/R/custom required | `/imports/template; /imports/preview; /imports/commit` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| IMPORT | another user's batch | None; A/TL/R/custom required | `/imports/template; /imports/preview; /imports/commit` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| NOTIFICATIONS | bell unread count | None; A/TL/R/custom required | `/notifications; /notifications/unread-count; /notifications/{id}/read; /notifications/read-all` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| NOTIFICATIONS | dropdown | None; A/TL/R/custom required | `/notifications; /notifications/unread-count; /notifications/{id}/read; /notifications/read-all` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| NOTIFICATIONS | mark read | None; A/TL/R/custom required | `/notifications; /notifications/unread-count; /notifications/{id}/read; /notifications/read-all` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| NOTIFICATIONS | mark all | None; A/TL/R/custom required | `/notifications; /notifications/unread-count; /notifications/{id}/read; /notifications/read-all` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| NOTIFICATIONS | action_url | None; A/TL/R/custom required | `/notifications; /notifications/unread-count; /notifications/{id}/read; /notifications/read-all` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| NOTIFICATIONS | Notifications page | None; A/TL/R/custom required | `/notifications; /notifications/unread-count; /notifications/{id}/read; /notifications/read-all` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| ACCESS CONTROL | create user | None; A/TL/R/custom required | `/users/*; /roles/*; /recruiters/assignable` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| ACCESS CONTROL | edit user | None; A/TL/R/custom required | `/users/*; /roles/*; /recruiters/assignable` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| ACCESS CONTROL | activate/deactivate | None; A/TL/R/custom required | `/users/*; /roles/*; /recruiters/assignable` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| ACCESS CONTROL | permissions | None; A/TL/R/custom required | `/users/*; /roles/*; /recruiters/assignable` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| ACCESS CONTROL | create role | None; A/TL/R/custom required | `/users/*; /roles/*; /recruiters/assignable` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| ACCESS CONTROL | clone role | None; A/TL/R/custom required | `/users/*; /roles/*; /recruiters/assignable` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| ACCESS CONTROL | rename role | None; A/TL/R/custom required | `/users/*; /roles/*; /recruiters/assignable` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| ACCESS CONTROL | role permissions | None; A/TL/R/custom required | `/users/*; /roles/*; /recruiters/assignable` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| ACCESS CONTROL | manager assignment | None; A/TL/R/custom required | `/users/*; /roles/*; /recruiters/assignable` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| ACCESS CONTROL | effective permissions | None; A/TL/R/custom required | `/users/*; /roles/*; /recruiters/assignable` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| ACCESS CONTROL | sessions | None; A/TL/R/custom required | `/users/*; /roles/*; /recruiters/assignable` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| ACCESS CONTROL | revoke sessions | None; A/TL/R/custom required | `/users/*; /roles/*; /recruiters/assignable` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| ACCESS CONTROL | privilege-escalation tests | None; A/TL/R/custom required | `/users/*; /roles/*; /recruiters/assignable` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |
| SETTINGS / TAGS / AUDIT | all save/update/remove/filter actions. | None; A/TL/R/custom required | `/settings; /org-settings; /tags/*; /audit-logs/*` | Authorized, correctly scoped behavior; persistence for writes | Source reviewed/repaired; browser execution unavailable | BLOCKED |

## Exact API inventory

| Method | Registered path | Source |
|---|---|---|
| GET | `/api/audit-logs` | `backend/api/audit_routes.py` |
| GET | `/api/audit-logs/actions` | `backend/api/audit_routes.py` |
| GET | `/api/audit-logs/export` | `backend/api/audit_routes.py` |
| POST | `/api/auth/login` | `backend/api/auth_routes.py` |
| POST | `/api/auth/logout` | `backend/api/auth_routes.py` |
| GET | `/api/auth/me` | `backend/api/auth_routes.py` |
| POST | `/api/auth/refresh` | `backend/api/auth_routes.py` |
| POST | `/api/auth/forgot-password` | `backend/api/auth_routes.py` |
| POST | `/api/auth/reset-password` | `backend/api/auth_routes.py` |
| POST | `/api/auth/change-password` | `backend/api/auth_routes.py` |
| GET | `/api/auth/config` | `backend/api/auth_routes.py` |
| POST | `/api/auth/google` | `backend/api/auth_routes.py` |
| GET | `/api/auth/csrf` | `backend/api/auth_routes.py` |
| GET | `/api/dashboard/overview` | `backend/api/dashboard_routes.py` |
| GET | `/api/my-day` | `backend/api/dashboard_routes.py` |
| GET | `/api/jobs` | `backend/api/modules_routes.py` |
| POST | `/api/jobs` | `backend/api/modules_routes.py` |
| PUT | `/api/jobs/{job_id}` | `backend/api/modules_routes.py` |
| DELETE | `/api/jobs/{job_id}` | `backend/api/modules_routes.py` |
| GET | `/api/clients` | `backend/api/modules_routes.py` |
| POST | `/api/clients` | `backend/api/modules_routes.py` |
| PUT | `/api/clients/{cid}` | `backend/api/modules_routes.py` |
| DELETE | `/api/clients/{cid}` | `backend/api/modules_routes.py` |
| GET | `/api/vendors` | `backend/api/modules_routes.py` |
| GET | `/api/vendors/summary` | `backend/api/modules_routes.py` |
| POST | `/api/vendors` | `backend/api/modules_routes.py` |
| PUT | `/api/vendors/{vid}` | `backend/api/modules_routes.py` |
| DELETE | `/api/vendors/{vid}` | `backend/api/modules_routes.py` |
| GET | `/api/templates` | `backend/api/modules_routes.py` |
| POST | `/api/templates` | `backend/api/modules_routes.py` |
| PUT | `/api/templates/{tid}` | `backend/api/modules_routes.py` |
| DELETE | `/api/templates/{tid}` | `backend/api/modules_routes.py` |
| GET | `/api/applications` | `backend/api/modules_routes.py` |
| PUT | `/api/applications/{aid}/status` | `backend/api/modules_routes.py` |
| POST | `/api/applications/{aid}/convert` | `backend/api/modules_routes.py` |
| DELETE | `/api/applications/{aid}` | `backend/api/modules_routes.py` |
| GET | `/api/lead-inbox` | `backend/api/modules_routes.py` |
| GET | `/api/reports` | `backend/api/modules_routes.py` |
| GET | `/api/action-required` | `backend/api/modules_routes.py` |
| GET | `/api/integrations` | `backend/api/modules_routes.py` |
| PUT | `/api/integrations/{key}` | `backend/api/modules_routes.py` |
| POST | `/api/integrations/{key}/test` | `backend/api/modules_routes.py` |
| POST | `/api/integrations/{key}/disconnect` | `backend/api/modules_routes.py` |
| GET | `/api/org-settings` | `backend/api/modules_routes.py` |
| PUT | `/api/org-settings` | `backend/api/modules_routes.py` |
| GET | `/api/tags` | `backend/api/modules_routes.py` |
| POST | `/api/tags` | `backend/api/modules_routes.py` |
| PUT | `/api/tags/{tid}` | `backend/api/modules_routes.py` |
| DELETE | `/api/tags/{tid}` | `backend/api/modules_routes.py` |
| GET | `/api/search` | `backend/api/modules_routes.py` |
| GET | `/api/notifications` | `backend/api/modules_routes.py` |
| GET | `/api/notifications/unread-count` | `backend/api/modules_routes.py` |
| POST | `/api/notifications/{nid}/read` | `backend/api/modules_routes.py` |
| POST | `/api/notifications/read-all` | `backend/api/modules_routes.py` |
| GET | `/api/import/template` | `backend/api/modules_routes.py` |
| POST | `/api/import/preview` | `backend/api/modules_routes.py` |
| POST | `/api/import/commit` | `backend/api/modules_routes.py` |
| GET | `/api/recruiters` | `backend/api/recruitment_routes.py` |
| GET | `/api/recruiters/assignable` | `backend/api/recruitment_routes.py` |
| GET | `/api/scheduling/next-working-day` | `backend/api/recruitment_routes.py` |
| GET | `/api/leads` | `backend/api/recruitment_routes.py` |
| GET | `/api/leads/export` | `backend/api/recruitment_routes.py` |
| POST | `/api/leads/check-duplicate` | `backend/api/recruitment_routes.py` |
| POST | `/api/leads/assign` | `backend/api/recruitment_routes.py` |
| POST | `/api/leads/transfer` | `backend/api/recruitment_routes.py` |
| POST | `/api/leads/auto-distribute` | `backend/api/recruitment_routes.py` |
| POST | `/api/leads` | `backend/api/recruitment_routes.py` |
| GET | `/api/leads/{lead_id}` | `backend/api/recruitment_routes.py` |
| PATCH | `/api/leads/{lead_id}` | `backend/api/recruitment_routes.py` |
| DELETE | `/api/leads/{lead_id}` | `backend/api/recruitment_routes.py` |
| POST | `/api/leads/{lead_id}/status` | `backend/api/recruitment_routes.py` |
| POST | `/api/leads/{lead_id}/calls` | `backend/api/recruitment_routes.py` |
| POST | `/api/leads/{lead_id}/disposition` | `backend/api/recruitment_routes.py` |
| POST | `/api/leads/{lead_id}/whatsapp` | `backend/api/recruitment_routes.py` |
| PUT | `/api/leads/{lead_id}/tags` | `backend/api/recruitment_routes.py` |
| GET | `/api/leads/{lead_id}/notes` | `backend/api/recruitment_routes.py` |
| POST | `/api/leads/{lead_id}/notes` | `backend/api/recruitment_routes.py` |
| PUT | `/api/notes/{note_id}` | `backend/api/recruitment_routes.py` |
| DELETE | `/api/notes/{note_id}` | `backend/api/recruitment_routes.py` |
| GET | `/api/leads/{lead_id}/activities` | `backend/api/recruitment_routes.py` |
| GET | `/api/leads/{lead_id}/followups` | `backend/api/recruitment_routes.py` |
| GET | `/api/followups` | `backend/api/recruitment_routes.py` |
| GET | `/api/followups/board` | `backend/api/recruitment_routes.py` |
| POST | `/api/followups/{followup_id}/complete` | `backend/api/recruitment_routes.py` |
| DELETE | `/api/followups/{followup_id}` | `backend/api/recruitment_routes.py` |
| POST | `/api/leads/{lead_id}/followups` | `backend/api/recruitment_routes.py` |
| PUT | `/api/followups/{followup_id}` | `backend/api/recruitment_routes.py` |
| GET | `/api/tasks` | `backend/api/recruitment_routes.py` |
| GET | `/api/tasks/summary` | `backend/api/recruitment_routes.py` |
| POST | `/api/tasks` | `backend/api/recruitment_routes.py` |
| PUT | `/api/tasks/{task_id}` | `backend/api/recruitment_routes.py` |
| DELETE | `/api/tasks/{task_id}` | `backend/api/recruitment_routes.py` |
| GET | `/api/interviews` | `backend/api/recruitment_routes.py` |
| POST | `/api/leads/{lead_id}/interviews` | `backend/api/recruitment_routes.py` |
| PUT | `/api/interviews/{interview_id}` | `backend/api/recruitment_routes.py` |
| GET | `/api/joinings` | `backend/api/recruitment_routes.py` |
| POST | `/api/leads/{lead_id}/joinings` | `backend/api/recruitment_routes.py` |
| PUT | `/api/joinings/{joining_id}` | `backend/api/recruitment_routes.py` |
| GET | `/api/roles/permissions/catalog` | `backend/api/role_routes.py` |
| GET | `/api/roles` | `backend/api/role_routes.py` |
| POST | `/api/roles` | `backend/api/role_routes.py` |
| PUT | `/api/roles/{role_key}` | `backend/api/role_routes.py` |
| PUT | `/api/roles/{role_key}/rename` | `backend/api/role_routes.py` |
| POST | `/api/roles/{role_key}/clone` | `backend/api/role_routes.py` |
| POST | `/api/roles/{role_key}/reset` | `backend/api/role_routes.py` |
| DELETE | `/api/roles/{role_key}` | `backend/api/role_routes.py` |
| GET | `/api/settings` | `backend/api/settings_routes.py` |
| PUT | `/api/settings` | `backend/api/settings_routes.py` |
| GET | `/api/users` | `backend/api/user_routes.py` |
| GET | `/api/users/assignable-managers` | `backend/api/user_routes.py` |
| GET | `/api/users/{user_id}` | `backend/api/user_routes.py` |
| GET | `/api/users/{user_id}/effective-permissions` | `backend/api/user_routes.py` |
| GET | `/api/users/{user_id}/sessions` | `backend/api/user_routes.py` |
| POST | `/api/users/{user_id}/revoke-sessions` | `backend/api/user_routes.py` |
| POST | `/api/users` | `backend/api/user_routes.py` |
| PATCH | `/api/users/{user_id}` | `backend/api/user_routes.py` |
| POST | `/api/users/{user_id}/status` | `backend/api/user_routes.py` |
| PUT | `/api/users/{user_id}/permissions` | `backend/api/user_routes.py` |
| GET | `/api/webhooks/{provider}` | `backend/api/webhook_routes.py` |
| POST | `/api/intake/applications` | `backend/api/webhook_routes.py` |
| POST | `/api/applications` | `backend/api/webhook_routes.py` |
| POST | `/api/webhooks/{provider}` | `backend/api/webhook_routes.py` |

## Source control inventory

Controls include repeated row buttons and conditional components; this is a static inventory, not proof of rendering or successful clicks.

| File | Test/control identifier | Browser status |
|---|---|---|
| `frontend/src/components/ActionDialogs.js` | `action-confirm-dialog` | BLOCKED |
| `frontend/src/components/ActionDialogs.js` | `action-confirm` | BLOCKED |
| `frontend/src/components/AddLeadDialog.js` | `lead-${k}-input` | BLOCKED |
| `frontend/src/components/AddLeadDialog.js` | `add-lead-dialog` | BLOCKED |
| `frontend/src/components/AddLeadDialog.js` | `lead-name-input` | BLOCKED |
| `frontend/src/components/AddLeadDialog.js` | `lead-phone-input` | BLOCKED |
| `frontend/src/components/AddLeadDialog.js` | `lead-gender-select` | BLOCKED |
| `frontend/src/components/AddLeadDialog.js` | `lead-priority-select` | BLOCKED |
| `frontend/src/components/AddLeadDialog.js` | `lead-owner-select` | BLOCKED |
| `frontend/src/components/AddLeadDialog.js` | `lead-notes-input` | BLOCKED |
| `frontend/src/components/AddLeadDialog.js` | `lead-first-followup-input` | BLOCKED |
| `frontend/src/components/AddLeadDialog.js` | `lead-first-reason-input` | BLOCKED |
| `frontend/src/components/AddLeadDialog.js` | `duplicate-banner` | BLOCKED |
| `frontend/src/components/AddLeadDialog.js` | `dup-cancel` | BLOCKED |
| `frontend/src/components/AddLeadDialog.js` | `dup-open-existing` | BLOCKED |
| `frontend/src/components/AddLeadDialog.js` | `dup-flag` | BLOCKED |
| `frontend/src/components/AddLeadDialog.js` | `lead-save-button` | BLOCKED |
| `frontend/src/components/AddTaskDialog.js` | `add-task-dialog` | BLOCKED |
| `frontend/src/components/AddTaskDialog.js` | `task-title-input` | BLOCKED |
| `frontend/src/components/AddTaskDialog.js` | `task-category-select` | BLOCKED |
| `frontend/src/components/AddTaskDialog.js` | `task-priority-select` | BLOCKED |
| `frontend/src/components/AddTaskDialog.js` | `task-due-input` | BLOCKED |
| `frontend/src/components/AddTaskDialog.js` | `task-related-input` | BLOCKED |
| `frontend/src/components/AddTaskDialog.js` | `task-notes-input` | BLOCKED |
| `frontend/src/components/AddTaskDialog.js` | `task-save-button` | BLOCKED |
| `frontend/src/components/AssignDialog.js` | `assign-dialog` | BLOCKED |
| `frontend/src/components/AssignDialog.js` | `assign-target-select` | BLOCKED |
| `frontend/src/components/AssignDialog.js` | `assign-confirm` | BLOCKED |
| `frontend/src/components/CallActionModal.js` | `call-action-modal` | BLOCKED |
| `frontend/src/components/CallActionModal.js` | `call-primary-phone` | BLOCKED |
| `frontend/src/components/CallActionModal.js` | `call-copy-number` | BLOCKED |
| `frontend/src/components/CallActionModal.js` | `call-dial-primary` | BLOCKED |
| `frontend/src/components/CallActionModal.js` | `call-dial-alternate` | BLOCKED |
| `frontend/src/components/CallActionModal.js` | `call-timer` | BLOCKED |
| `frontend/src/components/CallActionModal.js` | `call-timer-toggle` | BLOCKED |
| `frontend/src/components/CallActionModal.js` | `call-timer-reset` | BLOCKED |
| `frontend/src/components/CallActionModal.js` | `call-whatsapp` | BLOCKED |
| `frontend/src/components/CallActionModal.js` | `call-log-disposition` | BLOCKED |
| `frontend/src/components/CallDispositionModal.js` | `disposition-modal` | BLOCKED |
| `frontend/src/components/CallDispositionModal.js` | `dispo-dial` | BLOCKED |
| `frontend/src/components/CallDispositionModal.js` | `dispo-copy` | BLOCKED |
| `frontend/src/components/CallDispositionModal.js` | `dispo-whatsapp` | BLOCKED |
| `frontend/src/components/CallDispositionModal.js` | `dispo-outcome-select` | BLOCKED |
| `frontend/src/components/CallDispositionModal.js` | `dispo-duration` | BLOCKED |
| `frontend/src/components/CallDispositionModal.js` | `dispo-status-override` | BLOCKED |
| `frontend/src/components/CallDispositionModal.js` | `dispo-quick-${k}` | BLOCKED |
| `frontend/src/components/CallDispositionModal.js` | `dispo-followup-date` | BLOCKED |
| `frontend/src/components/CallDispositionModal.js` | `dispo-followup-reason` | BLOCKED |
| `frontend/src/components/CallDispositionModal.js` | `dispo-interview-block` | BLOCKED |
| `frontend/src/components/CallDispositionModal.js` | `dispo-iv-date` | BLOCKED |
| `frontend/src/components/CallDispositionModal.js` | `dispo-iv-client` | BLOCKED |
| `frontend/src/components/CallDispositionModal.js` | `dispo-iv-job` | BLOCKED |
| `frontend/src/components/CallDispositionModal.js` | `dispo-iv-type` | BLOCKED |
| `frontend/src/components/CallDispositionModal.js` | `dispo-iv-location` | BLOCKED |
| `frontend/src/components/CallDispositionModal.js` | `dispo-iv-contact` | BLOCKED |
| `frontend/src/components/CallDispositionModal.js` | `dispo-joining-date` | BLOCKED |
| `frontend/src/components/CallDispositionModal.js` | `dispo-closure-reason` | BLOCKED |
| `frontend/src/components/CallDispositionModal.js` | `dispo-notes` | BLOCKED |
| `frontend/src/components/CallDispositionModal.js` | `dispo-save` | BLOCKED |
| `frontend/src/components/ChangePasswordDialog.js` | `change-password-dialog` | BLOCKED |
| `frontend/src/components/ChangePasswordDialog.js` | `current-password-input` | BLOCKED |
| `frontend/src/components/ChangePasswordDialog.js` | `change-password-toggle` | BLOCKED |
| `frontend/src/components/ChangePasswordDialog.js` | `new-password-input` | BLOCKED |
| `frontend/src/components/ChangePasswordDialog.js` | `confirm-password-input` | BLOCKED |
| `frontend/src/components/ChangePasswordDialog.js` | `change-password-submit` | BLOCKED |
| `frontend/src/components/ConfirmDialog.js` | `${testId}-cancel` | BLOCKED |
| `frontend/src/components/ConfirmDialog.js` | `${testId}-confirm` | BLOCKED |
| `frontend/src/components/LeadDrawer.js` | `lead-drawer` | BLOCKED |
| `frontend/src/components/LeadDrawer.js` | `lead-drawer-name` | BLOCKED |
| `frontend/src/components/LeadDrawer.js` | `drawer-status-badge` | BLOCKED |
| `frontend/src/components/LeadDrawer.js` | `followup-banner` | BLOCKED |
| `frontend/src/components/LeadDrawer.js` | `drawer-add-followup` | BLOCKED |
| `frontend/src/components/LeadDrawer.js` | `drawer-followup-date` | BLOCKED |
| `frontend/src/components/LeadDrawer.js` | `drawer-followup-save` | BLOCKED |
| `frontend/src/components/LeadDrawer.js` | `drawer-call` | BLOCKED |
| `frontend/src/components/LeadDrawer.js` | `drawer-disposition` | BLOCKED |
| `frontend/src/components/LeadDrawer.js` | `drawer-whatsapp` | BLOCKED |
| `frontend/src/components/LeadDrawer.js` | `drawer-edit` | BLOCKED |
| `frontend/src/components/LeadDrawer.js` | `drawer-assign` | BLOCKED |
| `frontend/src/components/LeadDrawer.js` | `drawer-delete` | BLOCKED |
| `frontend/src/components/LeadDrawer.js` | `drawer-status-select` | BLOCKED |
| `frontend/src/components/LeadDrawer.js` | `drawer-status-joining` | BLOCKED |
| `frontend/src/components/LeadDrawer.js` | `drawer-status-reason` | BLOCKED |
| `frontend/src/components/LeadDrawer.js` | `drawer-status-apply` | BLOCKED |
| `frontend/src/components/LeadDrawer.js` | `tab-details` | BLOCKED |
| `frontend/src/components/LeadDrawer.js` | `tab-notes` | BLOCKED |
| `frontend/src/components/LeadDrawer.js` | `tab-followups` | BLOCKED |
| `frontend/src/components/LeadDrawer.js` | `tab-activity` | BLOCKED |
| `frontend/src/components/LeadDrawer.js` | `remove-tag-${t}` | BLOCKED |
| `frontend/src/components/LeadDrawer.js` | `tag-input` | BLOCKED |
| `frontend/src/components/LeadDrawer.js` | `add-tag-button` | BLOCKED |
| `frontend/src/components/LeadDrawer.js` | `note-input` | BLOCKED |
| `frontend/src/components/LeadDrawer.js` | `note-save` | BLOCKED |
| `frontend/src/components/LeadDrawer.js` | `note-${n.id}` | BLOCKED |
| `frontend/src/components/LeadDrawer.js` | `note-edit-${n.id}` | BLOCKED |
| `frontend/src/components/LeadDrawer.js` | `note-delete-${n.id}` | BLOCKED |
| `frontend/src/components/LeadDrawer.js` | `fu-${f.id}` | BLOCKED |
| `frontend/src/components/LeadDrawer.js` | `activity-${a.id}` | BLOCKED |
| `frontend/src/components/NotificationBell.js` | `notification-bell` | BLOCKED |
| `frontend/src/components/NotificationBell.js` | `notification-count` | BLOCKED |
| `frontend/src/components/NotificationBell.js` | `notif-${item.id}` | BLOCKED |
| `frontend/src/components/ProtectedRoute.js` | `auth-loading` | BLOCKED |
| `frontend/src/components/ProtectedRoute.js` | `unauthorized` | BLOCKED |
| `frontend/src/components/QuickActions.js` | `quick-action-trigger` | BLOCKED |
| `frontend/src/components/ResourceScreen.js` | `${testid}-page` | BLOCKED |
| `frontend/src/components/ResourceScreen.js` | `${testid}-add` | BLOCKED |
| `frontend/src/components/ResourceScreen.js` | `${testid}-search` | BLOCKED |
| `frontend/src/components/ResourceScreen.js` | `${testid}-row-${r.id}` | BLOCKED |
| `frontend/src/components/ResourceScreen.js` | `${testid}-edit-${r.id}` | BLOCKED |
| `frontend/src/components/ResourceScreen.js` | `${testid}-del-${r.id}` | BLOCKED |
| `frontend/src/components/ResourceScreen.js` | `${testid}-dialog` | BLOCKED |
| `frontend/src/components/ResourceScreen.js` | `${testid}-field-${f.key}` | BLOCKED |
| `frontend/src/components/ResourceScreen.js` | `${testid}-save` | BLOCKED |
| `frontend/src/components/RoleBadge.js` | `role-badge-${role}` | BLOCKED |
| `frontend/src/components/layout/Sidebar.js` | `sidebar-nav` | BLOCKED |
| `frontend/src/components/layout/Sidebar.js` | `sidebar-nav-${testId}` | BLOCKED |
| `frontend/src/components/layout/Sidebar.js` | `sidebar` | BLOCKED |
| `frontend/src/components/layout/Sidebar.js` | `mobile-sidebar` | BLOCKED |
| `frontend/src/components/layout/Sidebar.js` | `mobile-sidebar-close` | BLOCKED |
| `frontend/src/components/layout/Topbar.js` | `mobile-menu-button` | BLOCKED |
| `frontend/src/components/layout/Topbar.js` | `product-label` | BLOCKED |
| `frontend/src/components/layout/Topbar.js` | `global-search-input` | BLOCKED |
| `frontend/src/components/layout/Topbar.js` | `theme-toggle` | BLOCKED |
| `frontend/src/components/layout/Topbar.js` | `profile-menu-trigger` | BLOCKED |
| `frontend/src/components/layout/Topbar.js` | `change-password-menu-item` | BLOCKED |
| `frontend/src/components/layout/Topbar.js` | `logout-button` | BLOCKED |
| `frontend/src/pages/AccessControl.js` | `access-control-page` | BLOCKED |
| `frontend/src/pages/AccessControl.js` | `tab-users` | BLOCKED |
| `frontend/src/pages/AccessControl.js` | `tab-roles` | BLOCKED |
| `frontend/src/pages/AccessControl.js` | `tab-permissions` | BLOCKED |
| `frontend/src/pages/AccessControl.js` | `tab-team` | BLOCKED |
| `frontend/src/pages/AccessControl.js` | `tab-sessions` | BLOCKED |
| `frontend/src/pages/AccessControl.js` | `add-user-button` | BLOCKED |
| `frontend/src/pages/AccessControl.js` | `user-row-${u.id}` | BLOCKED |
| `frontend/src/pages/AccessControl.js` | `user-status-toggle-${u.id}` | BLOCKED |
| `frontend/src/pages/AccessControl.js` | `user-actions-${u.id}` | BLOCKED |
| `frontend/src/pages/AccessControl.js` | `edit-user-${u.id}` | BLOCKED |
| `frontend/src/pages/AccessControl.js` | `revoke-user-${u.id}` | BLOCKED |
| `frontend/src/pages/AccessControl.js` | `user-dialog` | BLOCKED |
| `frontend/src/pages/AccessControl.js` | `user-name-input` | BLOCKED |
| `frontend/src/pages/AccessControl.js` | `user-email-input` | BLOCKED |
| `frontend/src/pages/AccessControl.js` | `user-password-input` | BLOCKED |
| `frontend/src/pages/AccessControl.js` | `user-role-select` | BLOCKED |
| `frontend/src/pages/AccessControl.js` | `user-manager-select` | BLOCKED |
| `frontend/src/pages/AccessControl.js` | `user-save-button` | BLOCKED |
| `frontend/src/pages/AccessControl.js` | `create-role-button` | BLOCKED |
| `frontend/src/pages/AccessControl.js` | `role-item-${r.key}` | BLOCKED |
| `frontend/src/pages/AccessControl.js` | `rename-role-button` | BLOCKED |
| `frontend/src/pages/AccessControl.js` | `clone-role-button` | BLOCKED |
| `frontend/src/pages/AccessControl.js` | `reset-role-button` | BLOCKED |
| `frontend/src/pages/AccessControl.js` | `delete-role-button` | BLOCKED |
| `frontend/src/pages/AccessControl.js` | `save-role-button` | BLOCKED |
| `frontend/src/pages/AccessControl.js` | `perm-${key}` | BLOCKED |
| `frontend/src/pages/AccessControl.js` | `create-role-dialog` | BLOCKED |
| `frontend/src/pages/AccessControl.js` | `new-role-name` | BLOCKED |
| `frontend/src/pages/AccessControl.js` | `new-role-save` | BLOCKED |
| `frontend/src/pages/AccessControl.js` | `permissions-tab` | BLOCKED |
| `frontend/src/pages/AccessControl.js` | `effective-user-select` | BLOCKED |
| `frontend/src/pages/AccessControl.js` | `effective-permissions` | BLOCKED |
| `frontend/src/pages/AccessControl.js` | `team-tab` | BLOCKED |
| `frontend/src/pages/AccessControl.js` | `team-recruiter-${u.id}` | BLOCKED |
| `frontend/src/pages/AccessControl.js` | `assign-manager-${u.id}` | BLOCKED |
| `frontend/src/pages/AccessControl.js` | `sessions-tab` | BLOCKED |
| `frontend/src/pages/AccessControl.js` | `sessions-user-select` | BLOCKED |
| `frontend/src/pages/AccessControl.js` | `revoke-all-sessions-button` | BLOCKED |
| `frontend/src/pages/ActionRequired.js` | `action-required-page` | BLOCKED |
| `frontend/src/pages/ActionRequired.js` | `ar-card-${c.key}` | BLOCKED |
| `frontend/src/pages/ActionRequired.js` | `ar-count-${c.key}` | BLOCKED |
| `frontend/src/pages/Applications.js` | `applications-page` | BLOCKED |
| `frontend/src/pages/Applications.js` | `app-search` | BLOCKED |
| `frontend/src/pages/Applications.js` | `app-status-filter` | BLOCKED |
| `frontend/src/pages/Applications.js` | `app-row-${a.id}` | BLOCKED |
| `frontend/src/pages/Applications.js` | `app-resume-${a.id}` | BLOCKED |
| `frontend/src/pages/Applications.js` | `app-shortlist-${a.id}` | BLOCKED |
| `frontend/src/pages/Applications.js` | `app-convert-${a.id}` | BLOCKED |
| `frontend/src/pages/Applications.js` | `app-openlead-${a.id}` | BLOCKED |
| `frontend/src/pages/Applications.js` | `app-archive-${a.id}` | BLOCKED |
| `frontend/src/pages/AuditLog.js` | `audit-log-page` | BLOCKED |
| `frontend/src/pages/AuditLog.js` | `audit-export-button` | BLOCKED |
| `frontend/src/pages/AuditLog.js` | `audit-search-input` | BLOCKED |
| `frontend/src/pages/AuditLog.js` | `audit-action-filter` | BLOCKED |
| `frontend/src/pages/AuditLog.js` | `audit-severity-filter` | BLOCKED |
| `frontend/src/pages/AuditLog.js` | `audit-date-from` | BLOCKED |
| `frontend/src/pages/AuditLog.js` | `audit-date-to` | BLOCKED |
| `frontend/src/pages/AuditLog.js` | `audit-row-${log.id}` | BLOCKED |
| `frontend/src/pages/AuditLog.js` | `audit-detail-${log.id}` | BLOCKED |
| `frontend/src/pages/AuditLog.js` | `audit-prev-page` | BLOCKED |
| `frontend/src/pages/AuditLog.js` | `audit-next-page` | BLOCKED |
| `frontend/src/pages/Dashboard.js` | `dashboard-page` | BLOCKED |
| `frontend/src/pages/Dashboard.js` | `dash-date-from` | BLOCKED |
| `frontend/src/pages/Dashboard.js` | `dash-date-to` | BLOCKED |
| `frontend/src/pages/Dashboard.js` | `dash-recruiter-filter` | BLOCKED |
| `frontend/src/pages/Dashboard.js` | `kpi-${kpi.key}` | BLOCKED |
| `frontend/src/pages/Dashboard.js` | `funnel-chart` | BLOCKED |
| `frontend/src/pages/Dashboard.js` | `leaderboard-view-all` | BLOCKED |
| `frontend/src/pages/Dashboard.js` | `leaderboard` | BLOCKED |
| `frontend/src/pages/Dashboard.js` | `comparison-table` | BLOCKED |
| `frontend/src/pages/Dashboard.js` | `comparison-row-${r.recruiter_id}` | BLOCKED |
| `frontend/src/pages/Followups.js` | `complete-followup-dialog` | BLOCKED |
| `frontend/src/pages/Followups.js` | `complete-outcome` | BLOCKED |
| `frontend/src/pages/Followups.js` | `complete-mode-next` | BLOCKED |
| `frontend/src/pages/Followups.js` | `complete-mode-final` | BLOCKED |
| `frontend/src/pages/Followups.js` | `complete-next-date` | BLOCKED |
| `frontend/src/pages/Followups.js` | `complete-next-reason` | BLOCKED |
| `frontend/src/pages/Followups.js` | `complete-final-status` | BLOCKED |
| `frontend/src/pages/Followups.js` | `complete-joining` | BLOCKED |
| `frontend/src/pages/Followups.js` | `complete-closure` | BLOCKED |
| `frontend/src/pages/Followups.js` | `complete-save` | BLOCKED |
| `frontend/src/pages/Followups.js` | `reschedule-dialog` | BLOCKED |
| `frontend/src/pages/Followups.js` | `reschedule-date` | BLOCKED |
| `frontend/src/pages/Followups.js` | `reschedule-reason` | BLOCKED |
| `frontend/src/pages/Followups.js` | `reschedule-save` | BLOCKED |
| `frontend/src/pages/Followups.js` | `followups-page` | BLOCKED |
| `frontend/src/pages/Followups.js` | `followup-tabs` | BLOCKED |
| `frontend/src/pages/Followups.js` | `fu-tab-${t.key}` | BLOCKED |
| `frontend/src/pages/Followups.js` | `fu-count-${t.key}` | BLOCKED |
| `frontend/src/pages/Followups.js` | `fu-search-input` | BLOCKED |
| `frontend/src/pages/Followups.js` | `fu-recruiter-filter` | BLOCKED |
| `frontend/src/pages/Followups.js` | `fu-clear-recruiter` | BLOCKED |
| `frontend/src/pages/Followups.js` | `followup-${f.id}` | BLOCKED |
| `frontend/src/pages/Followups.js` | `fu-name-${f.id}` | BLOCKED |
| `frontend/src/pages/Followups.js` | `fu-overdue-${f.id}` | BLOCKED |
| `frontend/src/pages/Followups.js` | `fu-call-${f.id}` | BLOCKED |
| `frontend/src/pages/Followups.js` | `fu-wa-${f.id}` | BLOCKED |
| `frontend/src/pages/Followups.js` | `fu-reschedule-${f.id}` | BLOCKED |
| `frontend/src/pages/Followups.js` | `fu-complete-${f.id}` | BLOCKED |
| `frontend/src/pages/Followups.js` | `fu-delete-${f.id}` | BLOCKED |
| `frontend/src/pages/ForgotPassword.js` | `forgot-password-sent` | BLOCKED |
| `frontend/src/pages/ForgotPassword.js` | `forgot-email-input` | BLOCKED |
| `frontend/src/pages/ForgotPassword.js` | `forgot-submit-button` | BLOCKED |
| `frontend/src/pages/ImportLeads.js` | `import-page` | BLOCKED |
| `frontend/src/pages/ImportLeads.js` | `import-template` | BLOCKED |
| `frontend/src/pages/ImportLeads.js` | `import-file` | BLOCKED |
| `frontend/src/pages/ImportLeads.js` | `import-summary` | BLOCKED |
| `frontend/src/pages/ImportLeads.js` | `map-${c}` | BLOCKED |
| `frontend/src/pages/ImportLeads.js` | `rule-assign` | BLOCKED |
| `frontend/src/pages/ImportLeads.js` | `import-recruiter` | BLOCKED |
| `frontend/src/pages/ImportLeads.js` | `rule-dupes` | BLOCKED |
| `frontend/src/pages/ImportLeads.js` | `rule-invalid` | BLOCKED |
| `frontend/src/pages/ImportLeads.js` | `import-commit` | BLOCKED |
| `frontend/src/pages/ImportLeads.js` | `import-result` | BLOCKED |
| `frontend/src/pages/Integrations.js` | `integrations-page` | BLOCKED |
| `frontend/src/pages/Integrations.js` | `intg-${it.key}` | BLOCKED |
| `frontend/src/pages/Integrations.js` | `intg-copy-${it.key}` | BLOCKED |
| `frontend/src/pages/Integrations.js` | `intg-config-${it.key}` | BLOCKED |
| `frontend/src/pages/Integrations.js` | `intg-test-${it.key}` | BLOCKED |
| `frontend/src/pages/Integrations.js` | `intg-disconnect-${it.key}` | BLOCKED |
| `frontend/src/pages/Integrations.js` | `intg-dialog` | BLOCKED |
| `frontend/src/pages/Integrations.js` | `intg-field-${f}` | BLOCKED |
| `frontend/src/pages/Integrations.js` | `intg-save` | BLOCKED |
| `frontend/src/pages/Interviews.js` | `interviews-page` | BLOCKED |
| `frontend/src/pages/Interviews.js` | `iv-tab-${k}` | BLOCKED |
| `frontend/src/pages/Interviews.js` | `iv-search` | BLOCKED |
| `frontend/src/pages/Interviews.js` | `iv-row-${r.id}` | BLOCKED |
| `frontend/src/pages/Interviews.js` | `iv-stage-${r.id}` | BLOCKED |
| `frontend/src/pages/Interviews.js` | `iv-confirm-${r.id}` | BLOCKED |
| `frontend/src/pages/Interviews.js` | `iv-call-${r.id}` | BLOCKED |
| `frontend/src/pages/Interviews.js` | `iv-wa-${r.id}` | BLOCKED |
| `frontend/src/pages/Interviews.js` | `iv-edit-${r.id}` | BLOCKED |
| `frontend/src/pages/Interviews.js` | `iv-edit-dialog` | BLOCKED |
| `frontend/src/pages/Interviews.js` | `iv-edit-date` | BLOCKED |
| `frontend/src/pages/Interviews.js` | `iv-edit-notes` | BLOCKED |
| `frontend/src/pages/Interviews.js` | `iv-edit-save` | BLOCKED |
| `frontend/src/pages/Joinings.js` | `joinings-page` | BLOCKED |
| `frontend/src/pages/Joinings.js` | `jn-search` | BLOCKED |
| `frontend/src/pages/Joinings.js` | `jn-status-filter` | BLOCKED |
| `frontend/src/pages/Joinings.js` | `jn-row-${r.id}` | BLOCKED |
| `frontend/src/pages/Joinings.js` | `jn-stage-${r.id}` | BLOCKED |
| `frontend/src/pages/Joinings.js` | `jn-confirm-${r.id}` | BLOCKED |
| `frontend/src/pages/Joinings.js` | `jn-wa-${r.id}` | BLOCKED |
| `frontend/src/pages/Joinings.js` | `jn-edit-${r.id}` | BLOCKED |
| `frontend/src/pages/Joinings.js` | `jn-edit-dialog` | BLOCKED |
| `frontend/src/pages/Joinings.js` | `jn-exp` | BLOCKED |
| `frontend/src/pages/Joinings.js` | `jn-act` | BLOCKED |
| `frontend/src/pages/Joinings.js` | `jn-salary` | BLOCKED |
| `frontend/src/pages/Joinings.js` | `jn-remarks` | BLOCKED |
| `frontend/src/pages/Joinings.js` | `jn-save` | BLOCKED |
| `frontend/src/pages/LeadInbox.js` | `lead-inbox-page` | BLOCKED |
| `frontend/src/pages/LeadInbox.js` | `inbox-source-${s.source}` | BLOCKED |
| `frontend/src/pages/LeadInbox.js` | `inbox-chip-${c}` | BLOCKED |
| `frontend/src/pages/LeadInbox.js` | `inbox-search` | BLOCKED |
| `frontend/src/pages/LeadInbox.js` | `inbox-row-${l.id}` | BLOCKED |
| `frontend/src/pages/LeadSources.js` | `lead-sources-page` | BLOCKED |
| `frontend/src/pages/LeadSources.js` | `ls-kpi` | BLOCKED |
| `frontend/src/pages/LeadSources.js` | `ls-webhook-sim` | BLOCKED |
| `frontend/src/pages/LeadSources.js` | `sim-name` | BLOCKED |
| `frontend/src/pages/LeadSources.js` | `sim-phone` | BLOCKED |
| `frontend/src/pages/LeadSources.js` | `sim-role` | BLOCKED |
| `frontend/src/pages/LeadSources.js` | `sim-meta` | BLOCKED |
| `frontend/src/pages/LeadSources.js` | `sim-google` | BLOCKED |
| `frontend/src/pages/Leads.js` | `leads-page` | BLOCKED |
| `frontend/src/pages/Leads.js` | `export-csv-button` | BLOCKED |
| `frontend/src/pages/Leads.js` | `auto-distribute-button` | BLOCKED |
| `frontend/src/pages/Leads.js` | `add-lead-button` | BLOCKED |
| `frontend/src/pages/Leads.js` | `saved-views` | BLOCKED |
| `frontend/src/pages/Leads.js` | `view-chip-${v.key}` | BLOCKED |
| `frontend/src/pages/Leads.js` | `leads-search-input` | BLOCKED |
| `frontend/src/pages/Leads.js` | `leads-priority-filter` | BLOCKED |
| `frontend/src/pages/Leads.js` | `leads-status-filter` | BLOCKED |
| `frontend/src/pages/Leads.js` | `leads-source-filter` | BLOCKED |
| `frontend/src/pages/Leads.js` | `leads-tag-filter` | BLOCKED |
| `frontend/src/pages/Leads.js` | `leads-recruiter-filter` | BLOCKED |
| `frontend/src/pages/Leads.js` | `leads-sort-by` | BLOCKED |
| `frontend/src/pages/Leads.js` | `leads-sort-dir` | BLOCKED |
| `frontend/src/pages/Leads.js` | `clear-filters-button` | BLOCKED |
| `frontend/src/pages/Leads.js` | `bulk-bar` | BLOCKED |
| `frontend/src/pages/Leads.js` | `bulk-count` | BLOCKED |
| `frontend/src/pages/Leads.js` | `bulk-assign` | BLOCKED |
| `frontend/src/pages/Leads.js` | `bulk-transfer` | BLOCKED |
| `frontend/src/pages/Leads.js` | `bulk-distribute` | BLOCKED |
| `frontend/src/pages/Leads.js` | `bulk-clear` | BLOCKED |
| `frontend/src/pages/Leads.js` | `select-page-checkbox` | BLOCKED |
| `frontend/src/pages/Leads.js` | `lead-row-${l.id}` | BLOCKED |
| `frontend/src/pages/Leads.js` | `select-lead-${l.id}` | BLOCKED |
| `frontend/src/pages/Leads.js` | `lead-name-${l.id}` | BLOCKED |
| `frontend/src/pages/Leads.js` | `flag-invalid-${l.id}` | BLOCKED |
| `frontend/src/pages/Leads.js` | `flag-dup-${l.id}` | BLOCKED |
| `frontend/src/pages/Leads.js` | `flag-overdue-${l.id}` | BLOCKED |
| `frontend/src/pages/Leads.js` | `flag-nofu-${l.id}` | BLOCKED |
| `frontend/src/pages/Leads.js` | `lead-phone-${l.id}` | BLOCKED |
| `frontend/src/pages/Leads.js` | `row-call-${l.id}` | BLOCKED |
| `frontend/src/pages/Leads.js` | `row-dispo-${l.id}` | BLOCKED |
| `frontend/src/pages/Leads.js` | `row-wa-${l.id}` | BLOCKED |
| `frontend/src/pages/Leads.js` | `row-tags-${l.id}` | BLOCKED |
| `frontend/src/pages/Leads.js` | `row-edit-${l.id}` | BLOCKED |
| `frontend/src/pages/Leads.js` | `row-delete-${l.id}` | BLOCKED |
| `frontend/src/pages/Leads.js` | `pagination-info` | BLOCKED |
| `frontend/src/pages/Leads.js` | `prev-page` | BLOCKED |
| `frontend/src/pages/Leads.js` | `next-page` | BLOCKED |
| `frontend/src/pages/Login.js` | `login-email-input` | BLOCKED |
| `frontend/src/pages/Login.js` | `forgot-password-link` | BLOCKED |
| `frontend/src/pages/Login.js` | `login-password-input` | BLOCKED |
| `frontend/src/pages/Login.js` | `login-password-toggle` | BLOCKED |
| `frontend/src/pages/Login.js` | `login-submit-button` | BLOCKED |
| `frontend/src/pages/Login.js` | `google-signin-button` | BLOCKED |
| `frontend/src/pages/MyDay.js` | `my-day-page` | BLOCKED |
| `frontend/src/pages/MyDay.js` | `myday-progress-text` | BLOCKED |
| `frontend/src/pages/MyDay.js` | `myday-progress-bar` | BLOCKED |
| `frontend/src/pages/MyDay.js` | `myday-progress-percent` | BLOCKED |
| `frontend/src/pages/MyDay.js` | `myday-step-${step.key}` | BLOCKED |
| `frontend/src/pages/MyDay.js` | `myday-count-${step.key}` | BLOCKED |
| `frontend/src/pages/MyDay.js` | `myday-open-${it.id}` | BLOCKED |
| `frontend/src/pages/Notifications.js` | `notifications-page` | BLOCKED |
| `frontend/src/pages/Notifications.js` | `notifications-read-all` | BLOCKED |
| `frontend/src/pages/Notifications.js` | `notification-${item.id}` | BLOCKED |
| `frontend/src/pages/PermissionsDialog.js` | `user-permissions-dialog` | BLOCKED |
| `frontend/src/pages/PermissionsDialog.js` | `override-${perm}` | BLOCKED |
| `frontend/src/pages/PermissionsDialog.js` | `save-permissions-button` | BLOCKED |
| `frontend/src/pages/Placeholder.js` | `placeholder-page` | BLOCKED |
| `frontend/src/pages/Reports.js` | `reports-page` | BLOCKED |
| `frontend/src/pages/Reports.js` | `rep-tab-${k}` | BLOCKED |
| `frontend/src/pages/Reports.js` | `rep-target-card` | BLOCKED |
| `frontend/src/pages/Reports.js` | `rep-board-row` | BLOCKED |
| `frontend/src/pages/Reports.js` | `rep-funnel-row` | BLOCKED |
| `frontend/src/pages/Reports.js` | `rep-aging-bucket` | BLOCKED |
| `frontend/src/pages/Reports.js` | `rep-missed-row` | BLOCKED |
| `frontend/src/pages/ResetPassword.js` | `reset-no-token` | BLOCKED |
| `frontend/src/pages/ResetPassword.js` | `reset-password-toggle` | BLOCKED |
| `frontend/src/pages/ResetPassword.js` | `reset-password-input` | BLOCKED |
| `frontend/src/pages/ResetPassword.js` | `reset-confirm-input` | BLOCKED |
| `frontend/src/pages/ResetPassword.js` | `reset-submit-button` | BLOCKED |
| `frontend/src/pages/Roles.js` | `roles-page` | BLOCKED |
| `frontend/src/pages/Roles.js` | `role-tab-${r.key}` | BLOCKED |
| `frontend/src/pages/Roles.js` | `save-role-button` | BLOCKED |
| `frontend/src/pages/Roles.js` | `role-permission-checkbox-${g.module}-${a}` | BLOCKED |
| `frontend/src/pages/Settings.js` | `settings-page` | BLOCKED |
| `frontend/src/pages/Settings.js` | `settings-company-input` | BLOCKED |
| `frontend/src/pages/Settings.js` | `settings-timezone-input` | BLOCKED |
| `frontend/src/pages/Settings.js` | `settings-dateformat-input` | BLOCKED |
| `frontend/src/pages/Settings.js` | `settings-save-button` | BLOCKED |
| `frontend/src/pages/Tags.js` | `tags-page` | BLOCKED |
| `frontend/src/pages/Tags.js` | `tag-add` | BLOCKED |
| `frontend/src/pages/Tags.js` | `tag-${t.id}` | BLOCKED |
| `frontend/src/pages/Tags.js` | `tag-edit-${t.id}` | BLOCKED |
| `frontend/src/pages/Tags.js` | `tag-del-${t.id}` | BLOCKED |
| `frontend/src/pages/Tags.js` | `tag-dialog` | BLOCKED |
| `frontend/src/pages/Tags.js` | `tag-name` | BLOCKED |
| `frontend/src/pages/Tags.js` | `tag-color-${c}` | BLOCKED |
| `frontend/src/pages/Tags.js` | `tag-save` | BLOCKED |
| `frontend/src/pages/Tasks.js` | `tasks-page` | BLOCKED |
| `frontend/src/pages/Tasks.js` | `add-task-button` | BLOCKED |
| `frontend/src/pages/Tasks.js` | `task-summary-${c.label.split(" ")[0].toLowerCase()}` | BLOCKED |
| `frontend/src/pages/Tasks.js` | `task-search-input` | BLOCKED |
| `frontend/src/pages/Tasks.js` | `task-status-filter` | BLOCKED |
| `frontend/src/pages/Tasks.js` | `task-priority-filter` | BLOCKED |
| `frontend/src/pages/Tasks.js` | `task-${t.id}` | BLOCKED |
| `frontend/src/pages/Tasks.js` | `task-toggle-${t.id}` | BLOCKED |
| `frontend/src/pages/Tasks.js` | `task-overdue-${t.id}` | BLOCKED |
| `frontend/src/pages/Tasks.js` | `task-progress-${t.id}` | BLOCKED |
| `frontend/src/pages/Tasks.js` | `task-reopen-${t.id}` | BLOCKED |
| `frontend/src/pages/Tasks.js` | `task-done-${t.id}` | BLOCKED |
| `frontend/src/pages/Tasks.js` | `task-edit-${t.id}` | BLOCKED |
| `frontend/src/pages/Tasks.js` | `task-delete-${t.id}` | BLOCKED |
| `frontend/src/pages/Templates.js` | `templates-page` | BLOCKED |
| `frontend/src/pages/Templates.js` | `tpl-add` | BLOCKED |
| `frontend/src/pages/Templates.js` | `tpl-tab-${k}` | BLOCKED |
| `frontend/src/pages/Templates.js` | `tpl-search` | BLOCKED |
| `frontend/src/pages/Templates.js` | `tpl-card-${r.id}` | BLOCKED |
| `frontend/src/pages/Templates.js` | `tpl-copy-${r.id}` | BLOCKED |
| `frontend/src/pages/Templates.js` | `tpl-edit-${r.id}` | BLOCKED |
| `frontend/src/pages/Templates.js` | `tpl-dup-${r.id}` | BLOCKED |
| `frontend/src/pages/Templates.js` | `tpl-del-${r.id}` | BLOCKED |
| `frontend/src/pages/Templates.js` | `tpl-dialog` | BLOCKED |
| `frontend/src/pages/Templates.js` | `tpl-name` | BLOCKED |
| `frontend/src/pages/Templates.js` | `tpl-channel` | BLOCKED |
| `frontend/src/pages/Templates.js` | `tpl-category` | BLOCKED |
| `frontend/src/pages/Templates.js` | `tpl-subject` | BLOCKED |
| `frontend/src/pages/Templates.js` | `tpl-body` | BLOCKED |
| `frontend/src/pages/Templates.js` | `tpl-var-${v}` | BLOCKED |
| `frontend/src/pages/Templates.js` | `tpl-preview` | BLOCKED |
| `frontend/src/pages/Templates.js` | `tpl-save` | BLOCKED |
| `frontend/src/pages/Users.js` | `users-page` | BLOCKED |
| `frontend/src/pages/Users.js` | `add-user-button` | BLOCKED |
| `frontend/src/pages/Users.js` | `user-search-input` | BLOCKED |
| `frontend/src/pages/Users.js` | `user-role-filter` | BLOCKED |
| `frontend/src/pages/Users.js` | `user-status-filter` | BLOCKED |
| `frontend/src/pages/Users.js` | `user-row-${u.id}` | BLOCKED |
| `frontend/src/pages/Users.js` | `user-status-toggle-${u.id}` | BLOCKED |
| `frontend/src/pages/Users.js` | `user-actions-${u.id}` | BLOCKED |
| `frontend/src/pages/Users.js` | `edit-user-${u.id}` | BLOCKED |
| `frontend/src/pages/Users.js` | `perms-user-${u.id}` | BLOCKED |
| `frontend/src/pages/Users.js` | `user-dialog` | BLOCKED |
| `frontend/src/pages/Users.js` | `user-name-input` | BLOCKED |
| `frontend/src/pages/Users.js` | `user-email-input` | BLOCKED |
| `frontend/src/pages/Users.js` | `user-password-input` | BLOCKED |
| `frontend/src/pages/Users.js` | `user-role-select` | BLOCKED |
| `frontend/src/pages/Users.js` | `user-phone-input` | BLOCKED |
| `frontend/src/pages/Users.js` | `user-manager-select` | BLOCKED |
| `frontend/src/pages/Users.js` | `user-save-button` | BLOCKED |

## Executed component action checks

37 frontend tests passed. These controlled-fixture checks are not browser execution or real MongoDB proof. Eight browser scenarios are supplied in `frontend/e2e/release.spec.js` and collect successfully; run them through the CI release job.

| Suite | Action / contract checked | Actual result |
|---|---|---|
| `__tests__/joining.test.js` | joining edit submits all fields and values survive page remount | PASSED (component) |
| `__tests__/api.test.js` | concurrent 401s share one refresh and retry each request once | PASSED (component) |
| `__tests__/api.test.js` | failed refresh invalidates the session without a request loop | PASSED (component) |
| `__tests__/api.test.js` | a retried 401 and a failed login never trigger refresh | PASSED (component) |
| `__tests__/api.test.js` | concurrent mutations share CSRF acquisition | PASSED (component) |
| `__tests__/api.test.js` | expired CSRF cookie is renewed once | PASSED (component) |
| `__tests__/notifications.test.js` | reads real notification endpoints and read state survives remount | PASSED (component) |
| `__tests__/notifications.test.js` | mark all persists and unread filter becomes empty | PASSED (component) |
| `__tests__/notifications.test.js` | load errors show retry instead of an empty inbox | PASSED (component) |
| `__tests__/authContext.test.js` | reload authenticates an HTTP-only cookie session without a localStorage token | PASSED (component) |
| `__tests__/authContext.test.js` | failed logout retains user state | PASSED (component) |
| `__tests__/authContext.test.js` | successful logout clears session state | PASSED (component) |
| `__tests__/authContext.test.js` | transient session load failure is visible | PASSED (component) |
| `__tests__/googleSignIn.test.js` | Google credential creates the cookie session before navigating | PASSED (component) |
| `__tests__/googleSignIn.test.js` | provider script failure is visible and retryable | PASSED (component) |
| `__tests__/permissions.test.js` | admin direct route enforces any and all permission checks | PASSED (component) |
| `__tests__/permissions.test.js` | team_leader direct route enforces any and all permission checks | PASSED (component) |
| `__tests__/permissions.test.js` | recruiter direct route enforces any and all permission checks | PASSED (component) |
| `__tests__/permissions.test.js` | restricted direct route enforces any and all permission checks | PASSED (component) |
| `__tests__/permissions.test.js` | candidate view alone does not grant edit route | PASSED (component) |
| `__tests__/button.test.js` | asChild preserves a single interactive link | PASSED (component) |
| `__tests__/button.test.js` | a pending action is disabled and cannot double submit | PASSED (component) |
| `__tests__/button.test.js` | an unhandled action failure is visible | PASSED (component) |
| `__tests__/candidateActions.test.js` | normalizes 9876543210 safely | PASSED (component) |
| `__tests__/candidateActions.test.js` | normalizes +44 7700 900123 safely | PASSED (component) |
| `__tests__/candidateActions.test.js` | normalizes 0091 9876543210 safely | PASSED (component) |
| `__tests__/candidateActions.test.js` | rejects invalid numbers | PASSED (component) |
| `__tests__/candidateActions.test.js` | candidate WhatsApp opens the correct number and logs the parent lead | PASSED (component) |
| `__tests__/candidateActions.test.js` | clipboard failure never reports success | PASSED (component) |
| `__tests__/candidateActions.test.js` | rejects unsafe action URL https://outside.example/ | PASSED (component) |
| `__tests__/candidateActions.test.js` | rejects unsafe action URL //outside.example/ | PASSED (component) |
| `__tests__/candidateActions.test.js` | rejects unsafe action URL /admin/\outside | PASSED (component) |
| `__tests__/candidateActions.test.js` | rejects unsafe action URL null | PASSED (component) |
| `__tests__/calendar.test.js` | Friday suggests Monday in the organization timezone | PASSED (component) |
| `__tests__/calendar.test.js` | Holidays are skipped | PASSED (component) |
| `__tests__/calendar.test.js` | datetime inputs round trip independently of browser timezone | PASSED (component) |
| `__tests__/calendar.test.js` | Nonexistent DST time is rejected | PASSED (component) |
