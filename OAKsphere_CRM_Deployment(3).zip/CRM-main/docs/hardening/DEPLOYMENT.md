# Deployment and verification

The production container/HTTPS runbook is `deploy/README.md`; its example configuration is `deploy/production.env.example`.

This is a repair of the supplied OAKsphere CRM, not a replacement application. The existing React/FastAPI/MongoDB stack and UI are retained. Do not treat the earlier `test_result.md` or `memory/PRD.md` claims as validation of this revision; use the hardening reports and captured logs.

## Before deployment

1. Back up the database and verify the backup can be restored. Rehearse this revision on an isolated copy first.
2. Run MongoDB as a replica set or supported sharded cluster. A standalone server is deliberately unsupported for transactional mutations. Production startup rejects a standalone deployment. `/api/health` is process liveness; `/api/ready` checks transaction support.
3. Fill in `backend/.env.example` as `backend/.env` with unique credentials. Set `APP_ENV=production`, explicit HTTPS `CORS_ORIGINS` and `FRONTEND_URL`, `SEED_DEMO=false`, and secure cookies. Do not use the example secrets. The admin password is used only to create a missing account; restarting no longer resets an existing password.
4. Prefer serving frontend and `/api` through one HTTPS origin. For genuinely cross-site cookie deployments use `COOKIE_SAMESITE=none` with Secure cookies and explicit allowed origins. The client acquires a signed CSRF token from `/api/auth/csrf`; all browser mutations send it. Access and refresh JWTs stay in HttpOnly cookies. `ENABLE_BEARER_AUTH` is an opt-in compatibility mode, off by default.
5. Configure `TRUSTED_PROXY_CIDRS` only for the actual trusted ingress peers. Forwarded client IPs are ignored from other peers. Do not globally trust every IP.
6. Keep the JWT secret stable: existing integration encryption derives its key from it. A key change requires credential migration or reconfiguration as well as session invalidation.
7. Install the backend with `python -m pip install -r backend/requirements.txt`. The original broad dependency snapshot is preserved in `requirements-original.txt`. The unused, unavailable `emergentintegrations` dependency was removed from the runtime list; the email service already uses HTTP.
8. Install the committed graph with Yarn 1.22.22 using `yarn install --frozen-lockfile --ignore-optional`, then run `yarn build`. The frozen install, strict lint, component tests and build now pass locally. Use Node 24. Never deploy the development server publicly.

## Data and ownership rules

- Candidate view permissions determine candidate scope. Admin is global, Team Leader with team view sees their team, Recruiter/custom roles see their own records. User-management and directory permissions do not widen candidate scope. Vendors and tasks have separate resource scopes.
- Public intake creates unassigned applications. Admin reviews/converts them and can select an authorized recruiter. Internal authenticated intake is owned by its creator. No public owner/team field is accepted.
- Notes follow policy B: note writes require `leads.edit` and record/author checks; viewers can read scoped notes.
- Assign, transfer and auto-distribute each require their own permission. Import assignment uses `imports.run` plus the same active target and team-scope resolver. A non-admin non-leader cannot create globally unassigned records.
- Canonical settings are the `organization_settings` document with `key=org`. `/settings` and `/org-settings` use that document. `company_name` and `agency_name` are aliases of the same value. Working days are integers 0=Monday through 6=Sunday; holidays are organization-local `YYYY-MM-DD` dates. Priorities are `low`, `medium`, `high`.
- Joining stages are selected → documents_pending → offer_pending → offer_released → joining_confirmed → joined, with delayed/no_show and terminal dropped/client_rejected alternatives. Legacy pending/confirmed are supported aliases. Confirmation remains separate. Joined requires an actual date; Selected requires an expected date.
- Archive preserves historical leads and vendors while excluding them and related operational records from active views. Jobs, clients, applications and templates return 404 for missing archive targets.

## First startup and migration

Run one application instance during the index/migration step with writes paused. Startup backfills missing or repeated lead codes and preserves replaced codes in `previous_lead_code`, then installs a unique index. It normalizes active tag keys, archives duplicate catalog entries and canonicalizes historical lead tag spellings, preserving the documents. Import expiry, webhook event identity, application intake identity and notification query indexes are created as well. Rehearse this against a realistic restored database; index creation/migration has not been exercised on the user's historical data here.

Do not enable demo data in production. Tests create their own isolated demo fixtures; never point them at a production database.

## Automated tests

From `backend`:

```sh
python -m pip install -r requirements-test.txt
python -m pytest tests -q --junitxml=backend-results.xml
python -m compileall -q api core models services server.py
python -m flake8 api core models services server.py --select=E9,F63,F7,F82
```

The normal suite runs fresh in-memory Mongo substitutes through real FastAPI routes and services. It re-reads saved values and tests authorization, but substitutes transaction handling. It does not establish real Mongo rollback, concurrent correctness, index behavior or query performance.

For the complete real-Mongo release gate, configure `MONGO_URL` for an isolated replica set and run:

```sh
CRM_TEST_DATABASE_CONFIRMED=1 CRM_REAL_MONGO_REGRESSION=1 python -m pytest tests -q --junitxml=backend-results.xml
python ../deploy/check_test_results.py backend-results.xml --minimum 240
```

The 121 former live contracts now run by default, with cookie-only authentication and signed CSRF. Every test has a fresh database and deterministic fixtures; there are no missing-data skips or dependencies on an old preview URL. Enabling real Mongo runs those same contracts with real transactions. The 114 targeted hardening cases retain their mocked dependency/failure fixtures, and the five dedicated real-Mongo cases test rollback and concurrency without transaction substitution. Temporary databases use `crm_contract_run_*` or `crm_hardening_run_*` names and are dropped after their tests. The repository's `pytest.ini` two-worker options are unchanged.

The release gate rejects any skip/error/failure or fewer than 240 cases. The local result of 235 passed / five skipped therefore cannot approve a release. CI also requires all eight browser cases, successful image builds and the HTTPS production-container smoke. None of those environment-dependent checks is reported as passed without execution.

From `frontend`, run `CI=true yarn test --watchAll=false --runInBand`, the production build, and lint. Component tests use controlled API fixtures: remount persistence proves the UI contract, not database durability. Use the button matrix to finish browser testing on an isolated deployed environment for Admin, Team Leader, Recruiter and a restricted custom role.

## Webhooks and genuine intake

Configure integrations through the administrator UI. Credentials are encrypted and API responses only disclose whether each is set. Blank edits retain an existing value; an explicit removal clears it. Configure is not Connect. Meta integrations become connected only after a successful remote account check; Google Forms' action is explicitly a saved-configuration check.

Meta routes:

- `GET /api/webhooks/facebook`, `/instagram`, `/whatsapp`: Meta subscribe verification using `hub.mode`, `hub.verify_token` and numeric `hub.challenge`.
- `POST` to the same routes: validate `X-Hub-Signature-256` as `sha256=<HMAC-SHA256(raw-body, app-secret)>`, require the configured page/WABA/phone identity, and deduplicate provider events. Facebook/Instagram leadgen notifications retrieve candidate fields from the fixed Graph API host; WhatsApp inbound messages create an enquiry application.
- Required Facebook/Instagram fields: page_id, access_token, webhook_verify_token, app_secret. WhatsApp additionally uses phone_number_id and waba_id instead of page_id.
- Set `META_API_VERSION` to the API version approved for your provider application. Real subscription, access permissions, valid/expired token behavior and production payload fixtures still need provider-account validation.

Forms/Careers server-side submission:

```http
POST /api/webhooks/google_forms
Content-Type: application/json
X-Intake-Secret: <configured-shared-secret>

{"name":"Example Candidate","phone":"+919876543210","email":"candidate@example.com","role":"Support Associate","source":"google_form","campaign":"September hiring","utm_source":"careers","utm_medium":"form","utm_campaign":"september","provider_lead_id":"submission-unique-id"}
```

`POST /api/intake/applications` uses the same secret contract and can retain a supplied source. Put the secret in a trusted form relay or Apps Script properties, never in a public website or `REACT_APP_*` variable. Unknown fields (including owner/team), invalid candidates, oversized bodies and invalid secrets are rejected. Limits: 256KB body, 120 authenticated deliveries/minute per provider/client IP, at most 100 entries/changes/messages per corresponding batch. The public response does not reveal application or candidate IDs.

Provider + event ID is idempotent. Provider + normalized phone + role also reuses an existing application, including an archived one. This release preserves that deduplication policy, including archived applications. Inbound delivery does not automatically create an assigned lead: conversion is the existing authorized inbox action.

Outbound WhatsApp actions open a candidate deep link and record that it was opened. They do not send a WhatsApp Business API message or prove delivery. Email delivery and Google sign-in also need their actual external credentials to validate end to end.
