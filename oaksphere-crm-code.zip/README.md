# OAKsphere Connect — CRM / Admin / HRMS / Payroll (code split)

This package contains only the CRM/admin side, pulled out of the merged
`final-crm-oaksphere-7-aug.zip` bundle. The public marketing website has
been moved to a separate package.

## What's included
- `src/pages/*` — all CRM & admin screens (Leads, Jobs, Clients, Interviews,
  HRMS, Attendance, Employees, Payroll, Reports, Settings, Website CMS editor, etc.)
- `src/components/*` — CRM UI (Layout, lead modals, call modals, shared `ui/`
  component library, and the `cms/` editor tabs used by the Website CMS page)
- `src/context`, `src/hooks`, `src/lib`, `src/constants` — shared app logic
- `src/App.js` — trimmed to CRM-only routes (auth, `/dashboard`, `/leads`,
  `/hrms`, `/payroll`, etc. — no public site routes)
- `server.ts`, `src/server/mockDb.ts`, `src/server/cmsStore.ts` — the backend
  (kept as-is; see note below)
- Build config: `package.json`, `vite.config.ts`, `tailwind.config.cjs`, etc.

## Important note on the backend
`server.ts` is the **original, unsplit** Express server — it still serves
API routes for both the CRM and the public website (they share the same
Node process and mock database in the source project). Splitting that file
route-by-route was **not** done automatically because it's a large (3,200+
line), tightly-coupled file and a mechanical split risks breaking working
endpoints. It's included here so this package still runs standalone.
If you want the backend physically separated too, say so and I'll go
through `server.ts` and split the CRM vs website route handlers.

## Run
```bash
npm install
npm run dev
```
