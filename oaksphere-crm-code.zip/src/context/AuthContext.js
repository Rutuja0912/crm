import { createContext, useContext, useEffect, useState } from "react";
import api from "@/lib/api";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null); // null = loading, false = unauth
  const [ready, setReady] = useState(false);

  useEffect(() => {
    // Google OAuth callback: exchange the one-time session_id for our session cookie.
    if (window.location.hash && window.location.hash.includes("session_id=")) {
      const sid = new URLSearchParams(window.location.hash.slice(1)).get("session_id");
      if (sid) {
        api
          .post("/auth/google/session", { session_id: sid })
          .then((r) => {
            setUser(r.data.user);
            window.history.replaceState({}, "", window.location.pathname);
          })
          .catch(() => {
            setUser(false);
            window.history.replaceState({}, "", "/login");
            window.location.href = "/login?google=denied";
          })
          .finally(() => setReady(true));
        return;
      }
    }
    api
      .get("/auth/me")
      .then((r) => setUser(r.data))
      .catch(() => setUser(false))
      .finally(() => setReady(true));
  }, []);

  const login = async (email, password) => {
    const { data } = await api.post("/auth/login", { email, password });
    setUser(data.user);
    return data.user;
  };

  const logout = async () => {
    try { await api.post("/auth/logout"); } catch (_) {}
    setUser(false);
    window.location.href = "/login";
  };

  return (
    <AuthContext.Provider value={{ user, ready, login, logout, setUser }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
