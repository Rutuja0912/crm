import { BrowserRouter, Routes, Route, Navigate, useLocation } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import Layout from "@/components/Layout";
import Login from "@/pages/Login";
import ForgotPassword from "@/pages/ForgotPassword";
import ResetPassword from "@/pages/ResetPassword";
import PortalGateway from "@/pages/PortalGateway";
import Dashboard from "@/pages/Dashboard";
import MyDay from "@/pages/MyDay";
import Leads from "@/pages/Leads";
import CallingList from "@/pages/CallingList";
import Followups from "@/pages/Followups";
import Interviews from "@/pages/Interviews";
import Joining from "@/pages/Joining";
import Jobs from "@/pages/Jobs";
import Clients from "@/pages/Clients";
import Recruiters from "@/pages/Recruiters";
import Reports from "@/pages/Reports";
import ImportLeads from "@/pages/ImportLeads";
import NotificationsPage from "@/pages/NotificationsPage";
import Settings from "@/pages/Settings";
import ActionRequired from "@/pages/ActionRequired";
import LeadInbox from "@/pages/LeadInbox";
import WebsiteCMS from "@/pages/WebsiteCMS";
import Integrations from "@/pages/Integrations";
import HRMS from "@/pages/HRMS";
import Attendance from "@/pages/Attendance";
import Employees from "@/pages/Employees";
import Payroll from "@/pages/Payroll";
import Tasks from "@/pages/Tasks";
import Vendors from "@/pages/Vendors";
import Applications from "@/pages/Applications";
import Templates from "@/pages/Templates";
import Leave from "@/pages/Leave";
import MarketingDashboard from "@/pages/MarketingDashboard";
import AuditLogs from "@/pages/AuditLogs";
import "@/App.css";

function Protected({ children, roles }) {
  const { user, ready } = useAuth();
  const location = useLocation();
  if (!ready) return <div className="min-h-screen flex items-center justify-center text-slate-400">Loading…</div>;
  if (!user) return <Navigate to="/login" state={{ from: location }} replace />;
  if (roles && !roles.includes(user.role)) return <Layout><div className="py-20 text-center text-slate-400">You don't have access to this page.</div></Layout>;
  return <Layout>{children}</Layout>;
}

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/portal" element={<PortalGateway />} />
        <Route path="/workspace" element={<PortalGateway />} />
        <Route path="/login" element={<Login />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/reset-password" element={<ResetPassword />} />

        <Route path="/" element={<Protected><Dashboard /></Protected>} />
        <Route path="/dashboard" element={<Protected><Dashboard /></Protected>} />
        <Route path="/my-day" element={<Protected roles={["recruiter", "team_leader"]}><MyDay /></Protected>} />
        <Route path="/leads" element={<Protected><Leads key="all" /></Protected>} />
        <Route path="/my-leads" element={<Protected roles={["recruiter", "team_leader"]}><Leads key="mine" mine /></Protected>} />
        <Route path="/calling" element={<Protected><CallingList /></Protected>} />
        <Route path="/followups" element={<Protected><Followups /></Protected>} />
        <Route path="/interviews" element={<Protected><Interviews /></Protected>} />
        <Route path="/joining" element={<Protected><Joining /></Protected>} />
        <Route path="/jobs" element={<Protected><Jobs /></Protected>} />
        <Route path="/clients" element={<Protected><Clients /></Protected>} />
        <Route path="/recruiters" element={<Protected roles={["admin", "team_leader"]}><Recruiters /></Protected>} />
        <Route path="/reports" element={<Protected><Reports /></Protected>} />
        <Route path="/action-required" element={<Protected roles={["admin", "team_leader"]}><ActionRequired /></Protected>} />
        <Route path="/lead-inbox" element={<Protected roles={["admin", "team_leader"]}><LeadInbox /></Protected>} />
        <Route path="/website-cms" element={<Protected roles={["admin", "team_leader"]}><WebsiteCMS /></Protected>} />
        <Route path="/control-center" element={<Protected roles={["admin", "team_leader"]}><WebsiteCMS /></Protected>} />
        <Route path="/integrations" element={<Protected roles={["admin"]}><Integrations /></Protected>} />
        <Route path="/import" element={<Protected roles={["admin"]}><ImportLeads /></Protected>} />
        <Route path="/notifications" element={<Protected><NotificationsPage /></Protected>} />
        <Route path="/hrms" element={<Protected><HRMS /></Protected>} />
        <Route path="/attendance" element={<Protected><Attendance /></Protected>} />
        <Route path="/employees" element={<Protected roles={["admin", "team_leader"]}><Employees /></Protected>} />
        <Route path="/payroll" element={<Protected><Payroll /></Protected>} />
        <Route path="/tasks" element={<Protected><Tasks /></Protected>} />
        <Route path="/vendors" element={<Protected><Vendors /></Protected>} />
        <Route path="/applications" element={<Protected><Applications /></Protected>} />
        <Route path="/templates" element={<Protected><Templates /></Protected>} />
        <Route path="/leave" element={<Protected><Leave /></Protected>} />
        <Route path="/marketing" element={<Protected><MarketingDashboard /></Protected>} />
        <Route path="/audit-logs" element={<Protected roles={["admin"]}><AuditLogs /></Protected>} />
        <Route path="/settings" element={<Protected roles={["admin"]}><Settings /></Protected>} />

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
