export interface Lead {
  id: string;
  name: string;
  phone: string;
  email?: string;
  source: string;
  status: string;
  city: string;
  assigned_recruiter_id?: string;
  assigned_recruiter_name?: string;
  job_title?: string;
  next_followup_date?: string;
  next_followup_reason?: string;
  created_at: string;
  updated_at: string;
  notes?: any[];
  calls?: any[];
  tags?: string[];
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: string;
  active: boolean;
  phone?: string;
  target?: number;
}

export interface Client {
  id: string;
  name: string;
  industry: string;
  contact_person: string;
  contact_email: string;
  contact_phone: string;
  city: string;
  status: string;
  active_jobs: number;
}

export interface Job {
  id: string;
  title: string;
  slug: string;
  client_id?: string;
  client_name?: string;
  location: string;
  experience: string;
  salary_range: string;
  positions: number;
  status: string;
  category: string;
  industry: string;
  description: string;
  requirements: string[];
  created_at: string;
}

const now = new Date();
const iso = (d: Date) => d.toISOString();

export const mockUsers: User[] = [
  { id: "u-admin", name: "Admin User", email: "admin@oaksphere.com", role: "admin", active: true, phone: "+91 98765 43210" },
  { id: "u-harshika", name: "Harshika Sharma", email: "harshika@oaksphere.com", role: "recruiter", active: true, phone: "+91 98605 00768", target: 15 },
  { id: "u-karan", name: "Karan Mehta", email: "karan@oaksphere.com", role: "recruiter", active: true, phone: "+91 98234 56789", target: 12 },
  { id: "u-priya", name: "Priya Singh", email: "priya@oaksphere.com", role: "team_leader", active: true, phone: "+91 99123 45678", target: 20 },
];

export const mockClients: Client[] = [
  { id: "c1", name: "Tech Mahindra", industry: "IT Services", contact_person: "Ananya Roy", contact_email: "ananya.roy@techm.com", contact_phone: "9823112233", city: "Pune", status: "Active", active_jobs: 4 },
  { id: "c2", name: "HDFC Life", industry: "BFSI", contact_person: "Rohit Jain", contact_email: "rohit.j@hdfclife.com", contact_phone: "9823114455", city: "Mumbai", status: "Active", active_jobs: 6 },
  { id: "c3", name: "Cognizant", industry: "IT Services", contact_person: "Meera Nair", contact_email: "meera.n@cognizant.com", contact_phone: "9823116677", city: "Bangalore", status: "Active", active_jobs: 3 },
  { id: "c4", name: "Apollo Hospitals", industry: "Healthcare", contact_person: "Dr. Sandeep K", contact_email: "sandeep@apollo.org", contact_phone: "9823118899", city: "Hyderabad", status: "Active", active_jobs: 2 },
];

export const mockJobs: Job[] = [
  {
    id: "j1",
    title: "Senior Full Stack Engineer (React/Node)",
    slug: "senior-full-stack-engineer-react-node",
    client_id: "c1",
    client_name: "Tech Mahindra",
    location: "Pune, India (Hybrid)",
    experience: "4-7 years",
    salary_range: "₹14,00,000 - ₹22,00,000 PA",
    positions: 3,
    status: "Active",
    category: "IT / Software",
    industry: "Information Technology",
    description: "Seeking a seasoned Full Stack Engineer with strong proficiency in React, Node.js, Express, and PostgreSQL/MongoDB to lead the candidate assessment portal.",
    requirements: ["4+ years in modern React & Node.js", "Solid TypeScript & REST API design", "Experience leading agile teams"],
    created_at: iso(new Date(now.getTime() - 4 * 86400000)),
  },
  {
    id: "j2",
    title: "Relationship Manager — Wealth Banking",
    slug: "relationship-manager-wealth-banking",
    client_id: "c2",
    client_name: "HDFC Life",
    location: "Mumbai, India (Onsite)",
    experience: "3-5 years",
    salary_range: "₹8,00,000 - ₹12,00,000 PA + Incentives",
    positions: 5,
    status: "Active",
    category: "Banking / Finance",
    industry: "BFSI",
    description: "Drive high-net-worth client acquisitions, portfolio reviews, and personalized investment solutions across western India.",
    requirements: ["Bachelor or MBA in Finance / Marketing", "Strong verbal negotiation & communication skills", "NISM certifications preferred"],
    created_at: iso(new Date(now.getTime() - 2 * 86400000)),
  },
  {
    id: "j3",
    title: "Cloud DevOps & Platform Engineer",
    slug: "cloud-devops-platform-engineer",
    client_id: "c3",
    client_name: "Cognizant",
    location: "Bangalore, India (Remote)",
    experience: "5-8 years",
    salary_range: "₹18,00,000 - ₹28,00,000 PA",
    positions: 2,
    status: "Active",
    category: "IT / Cloud",
    industry: "Information Technology",
    description: "Build robust CI/CD pipelines, container orchestration on EKS, infrastructure-as-code with Terraform and monitor production reliability.",
    requirements: ["Strong hands-on AWS or GCP experience", "Kubernetes, Docker, Helm, ArgoCD", "Terraform & GitHub Actions automation"],
    created_at: iso(new Date(now.getTime() - 7 * 86400000)),
  },
];

export const mockLeads: Lead[] = [
  {
    id: "l1",
    name: "Rahul Verma",
    phone: "9876543211",
    email: "rahul.verma@example.com",
    source: "Website",
    status: "Contacted",
    city: "Pune",
    assigned_recruiter_id: "u-harshika",
    assigned_recruiter_name: "Harshika Sharma",
    job_title: "Senior Full Stack Engineer",
    next_followup_date: iso(new Date(now.getTime() + 2 * 3600000)),
    next_followup_reason: "Schedule technical screening round",
    created_at: iso(new Date(now.getTime() - 86400000)),
    updated_at: iso(now),
    tags: ["Hot", "React", "NodeJS"],
    notes: [{ id: "n1", text: "Candidate has 5 yrs exp with excellent communication. Ready to relocate.", date: iso(now), author: "Harshika Sharma" }],
    calls: [{ id: "c1", disposition: "Interested", duration: 180, notes: "Discussed CTC expectation ₹18LPA", date: iso(now) }],
  },
  {
    id: "l2",
    name: "Pooja Deshmukh",
    phone: "9876543212",
    email: "pooja.d@example.com",
    source: "Referral",
    status: "Interview Scheduled",
    city: "Mumbai",
    assigned_recruiter_id: "u-harshika",
    assigned_recruiter_name: "Harshika Sharma",
    job_title: "Relationship Manager",
    next_followup_date: iso(new Date(now.getTime() - 4 * 3600000)),
    next_followup_reason: "Post-interview feedback collection",
    created_at: iso(new Date(now.getTime() - 3 * 86400000)),
    updated_at: iso(now),
    tags: ["BFSI", "NISM"],
    notes: [{ id: "n2", text: "Client interview scheduled for 3 PM today.", date: iso(now), author: "Harshika Sharma" }],
  },
  {
    id: "l3",
    name: "Amit Kulkarni",
    phone: "9876543213",
    email: "amit.k@example.com",
    source: "LinkedIn",
    status: "New",
    city: "Bangalore",
    assigned_recruiter_id: "u-karan",
    assigned_recruiter_name: "Karan Mehta",
    job_title: "Cloud DevOps Engineer",
    next_followup_date: iso(new Date(now.getTime() + 24 * 3600000)),
    next_followup_reason: "Initial profile assessment call",
    created_at: iso(now),
    updated_at: iso(now),
    tags: ["AWS", "DevOps"],
  },
  {
    id: "l4",
    name: "Neha Patel",
    phone: "9876543214",
    email: "neha.patel@example.com",
    source: "Job Board",
    status: "Offer Released",
    city: "Pune",
    assigned_recruiter_id: "u-priya",
    assigned_recruiter_name: "Priya Singh",
    job_title: "Senior Full Stack Engineer",
    next_followup_date: iso(new Date(now.getTime() + 48 * 3600000)),
    next_followup_reason: "Offer letter acceptance verification",
    created_at: iso(new Date(now.getTime() - 10 * 86400000)),
    updated_at: iso(now),
    tags: ["High Priority"],
  },
];

export const mockInterviews = [
  {
    id: "i1",
    lead_id: "l2",
    candidate_name: "Pooja Deshmukh",
    job_id: "j2",
    job_title: "Relationship Manager — Wealth Banking",
    client_id: "c2",
    client_name: "HDFC Life",
    scheduled_at: iso(new Date(now.getTime() + 4 * 3600000)),
    round: "Technical Round 1",
    interviewer: "Suresh Gupta (VP Wealth)",
    status: "Scheduled",
    meeting_link: "https://meet.google.com/abc-defg-hij",
  },
];

export const mockJoinings = [
  {
    id: "jn1",
    lead_id: "l4",
    candidate_name: "Neha Patel",
    job_title: "Senior Full Stack Engineer",
    client_name: "Tech Mahindra",
    joining_date: iso(new Date(now.getTime() + 14 * 86400000)),
    offered_ctc: "₹19,50,000 PA",
    status: "Documentation In Progress",
  },
];

export const mockSiteData = {
  settings: {
    home: {
      hero_badge: "India’s 360° Recruitment Ecosystem",
      hero_title: "India’s Trusted Recruitment Partner for Fast-Growing Companies",
      hero_subtitle: "Connecting ambition with opportunity. Verified talent in IT, BFSI, Healthcare & Manufacturing delivered with lightning speed across 25+ cities.",
      hero_chips: ["Fast 48h Turnaround", "100% Background Verified", "PAN-India Presence", "Zero Sourcing Cost for Candidates"],
      pipeline: [
        { role: "Senior React Engineer", city: "Pune", match: "96%" },
        { role: "Wealth Relationship Manager", city: "Mumbai", match: "92%" },
        { role: "Cloud DevOps Architect", city: "Bangalore", match: "95%" },
      ],
      pipeline_stats: { sourced: "2,500+", shortlisted: "480+", offers: "125+", placements: "2,500+", satisfaction: "98.4%", retention: "94%" },
      partners: ["Tech Mahindra", "HDFC Life", "Cognizant", "Apollo Hospitals", "Tata Consultancy Services", "ICICI Bank"],
      employer_services: [
        { title: "IT & Software Staffing", desc: "Full-stack engineers, cloud architects, DevOps & AI specialists vetted for culture and technical excellence." },
        { title: "BFSI & Wealth Management", desc: "Relationship managers, credit underwriters, compliance officers and branch leadership across India." },
        { title: "Executive Search", desc: "Confidential C-level, VP and Director level leadership talent acquisitions." },
        { title: "Bulk & Turnkey Hiring", desc: "Rapid ramp-ups for BPO, customer operations, sales and branch expansions." },
        { title: "Contract & Temp Staffing", desc: "Flexible staffing models to scale project teams with rapid onboarding." },
        { title: "Background & Credential Checks", desc: "Comprehensive education, employment, reference and criminal verification." },
      ],
      candidate_features: [
        { title: "Zero Placement Fee", desc: "Candidates never pay for applications, interview scheduling or job placements." },
        { title: "Curated Matching", desc: "We align your skills, salary expectations and work preferences with ideal companies." },
        { title: "Interview Prep Coaching", desc: "Direct guidance on employer expectations, technical rounds and salary negotiation." },
        { title: "Fast-Track Responses", desc: "Real-time updates at every stage of your selection pipeline." },
      ],
      process: [
        { step: "01", title: "Discovery", desc: "Deep dive into your hiring mandate, culture and technical requirements." },
        { step: "02", title: "Talent Sourcing", desc: "AI-powered candidate retrieval combined with our extensive proprietary talent pool." },
        { step: "03", title: "Evaluation", desc: "Multi-round technical and behavioural screening before presentation." },
        { step: "04", title: "Client Interviews", desc: "Seamless scheduling, briefing and post-interview feedback loops." },
        { step: "05", title: "Offer & Joining", desc: "Smooth offer negotiation, documentation and day-one onboarding support." },
      ],
      why: [
        { title: "Strict Quality Benchmarks", desc: "Only top 5% matched candidates are forwarded to client interview rounds." },
        { title: "Industry Specialization", desc: "Dedicated recruiting pods with domain knowledge in IT, Banking and Healthcare." },
        { title: "Replacement Guarantee", desc: "3-month replacement guarantee for full peace of mind on all direct hires." },
      ],
      testimonials: [
        { quote: "OAKsphere reduced our IT engineering time-to-hire by 40% while delivering exceptionally skilled talent.", author: "Rajesh Kulkarni", org: "Head of Engineering, Tech Mahindra" },
        { quote: "Their deep network in BFSI helped us staff 30+ relationship managers across Maharashtra in record time.", author: "Sneha Kapoor", org: "AVP Talent Acquisition, HDFC Life" },
        { quote: "Professional, transparent and candidate-friendly. The best recruitment partner we've collaborated with.", author: "Venkatesh Rao", org: "Director HR, Cognizant" },
      ],
      case_study: {
        title: "Scaling 50+ Specialized Engineers in 30 Days",
        desc: "How OakSphere helped a multinational enterprise scale its cloud migration team across Pune & Bangalore on tight deadlines.",
        stats: [
          { label: "Turnaround Time", value: "24h" },
          { label: "Acceptance Rate", value: "96%" },
          { label: "Retention at 1 Year", value: "94%" },
          { label: "Candidates Placed", value: "54" },
        ],
      },
      platform: [
        { title: "AI Candidate Scoring", desc: "Automated resume parsing, skill matching and qualification scoring." },
        { title: "WhatsApp Recruiter Bot", desc: "Instant candidate screening, interview reminders and status broadcasts." },
        { title: "Unified CRM & HRMS", desc: "End-to-end recruitment tracking from first outreach to monthly payroll." },
      ],
    },
  },
  contact: {
    phone: "+91 98605 00768",
    email: "contact@oaksphere.com",
    address: "World Trade Center, Kharadi, Pune, Maharashtra 411014",
    whatsapp: "919860500768",
  },
  categories: [
    { id: "cat1", name: "IT / Software", slug: "it-software", count: 42 },
    { id: "cat2", name: "Banking & Financial Services", slug: "banking-finance", count: 28 },
    { id: "cat3", name: "Healthcare & Life Sciences", slug: "healthcare", count: 19 },
    { id: "cat4", name: "BPO & Customer Operations", slug: "bpo-customer-ops", count: 35 },
  ],
  locations: [
    { id: "loc1", name: "Pune", slug: "pune", count: 38 },
    { id: "loc2", name: "Mumbai", slug: "mumbai", count: 45 },
    { id: "loc3", name: "Bangalore", slug: "bangalore", count: 52 },
    { id: "loc4", name: "Hyderabad", slug: "hyderabad", count: 27 },
    { id: "loc5", name: "Delhi NCR", slug: "delhi-ncr", count: 31 },
  ],
  industries: [
    { id: "ind1", name: "Information Technology", slug: "information-technology", job_count: 42, icon: "Laptop" },
    { id: "ind2", name: "Banking, Financial Services & Insurance", slug: "bfsi", job_count: 28, icon: "Landmark" },
    { id: "ind3", name: "Healthcare & Pharmaceuticals", slug: "healthcare", job_count: 19, icon: "HeartPulse" },
    { id: "ind4", name: "Manufacturing & Engineering", slug: "manufacturing", job_count: 15, icon: "Cog" },
  ],
};

export const mockFaqs = [
  { id: "faq1", question: "How does OakSphere Connect screen candidates?", answer: "We perform a thorough 3-tier validation: technical screening, background verification, and culture fitment interviews before presenting candidates to clients." },
  { id: "faq2", question: "What industries does OakSphere specialize in?", answer: "We specialize in IT & Software Development, BFSI, Healthcare & Pharma, BPO/KPO operations, and Executive Leadership search." },
  { id: "faq3", question: "How fast can you fulfill open positions?", answer: "Our standard turnaround time for pre-screened candidate shortlists is 24 to 48 hours for standard roles and 3 to 5 business days for niche executive positions." },
  { id: "faq4", question: "Do candidates have to pay any fees for job placement?", answer: "No. OakSphere Connect never charges job seekers any registration or placement fees. Our services are 100% free for candidates." },
];

export const mockBlogs = [
  {
    id: "b1",
    title: "Navigating Tech Hiring in 2026: Trends in AI, Cloud, and Full-Stack Engineering",
    slug: "navigating-tech-hiring-in-2026",
    summary: "Key strategies for talent acquisition leaders to attract top-tier tech talent amid rapid shifts in AI and cloud architecture.",
    author: "OakSphere Research Team",
    date: "2026-08-15",
    content: "Talent acquisition in technology requires agile, candidate-first engagement...",
  },
  {
    id: "b2",
    title: "The Rise of Specialized BFSI Talent: Meeting Compliance and Growth Goals",
    slug: "rise-of-specialized-bfsi-talent",
    summary: "Why financial institutions are prioritizing relationship managers with digital competencies and regulatory expertise.",
    author: "Harshika Sharma",
    date: "2026-08-02",
    content: "Modern banking demands professionals who can navigate complex wealth solutions...",
  },
];

export const mockEmployees = [
  { id: "emp1", name: "Harshika Sharma", email: "harshika@oaksphere.com", role: "Senior Recruiter", department: "Recruitment", status: "Active", joinDate: "2024-03-15", salary: 55000 },
  { id: "emp2", name: "Karan Mehta", email: "karan@oaksphere.com", role: "Talent Scout", department: "Recruitment", status: "Active", joinDate: "2024-06-01", salary: 42000 },
  { id: "emp3", name: "Priya Singh", email: "priya@oaksphere.com", role: "Team Leader", department: "Recruitment", status: "Active", joinDate: "2023-11-10", salary: 75000 },
];

export const mockAttendance = [
  { id: "att1", employeeId: "emp1", name: "Harshika Sharma", date: "2026-09-07", checkIn: "09:15 AM", checkOut: "06:30 PM", status: "Present" },
  { id: "att2", employeeId: "emp2", name: "Karan Mehta", date: "2026-09-07", checkIn: "09:28 AM", checkOut: "06:45 PM", status: "Present" },
  { id: "att3", employeeId: "emp3", name: "Priya Singh", date: "2026-09-07", checkIn: "09:05 AM", checkOut: "06:15 PM", status: "Present" },
];

export const mockPayroll = [
  { id: "pay1", employeeId: "emp1", name: "Harshika Sharma", month: "August 2026", basic: 45000, allowances: 10000, deductions: 2500, net: 52500, status: "Paid" },
  { id: "pay2", employeeId: "emp2", name: "Karan Mehta", month: "August 2026", basic: 35000, allowances: 7000, deductions: 2000, net: 40000, status: "Paid" },
  { id: "pay3", employeeId: "emp3", name: "Priya Singh", month: "August 2026", basic: 60000, allowances: 15000, deductions: 3500, net: 71500, status: "Paid" },
];

export const mockTasks = [
  {
    id: "tsk-1",
    title: "Call Pooja Deshmukh for Interview Lineup Confirmation",
    owner_id: "u-harshika",
    owner_name: "Harshika Sharma",
    priority: "High",
    due_date: new Date().toISOString(),
    status: "Pending",
    category: "Candidate follow-up",
    related_type: "candidate",
    related_name: "Pooja Deshmukh",
    notes: "Confirm she has Google Meet installed and stable WiFi for Round 1.",
    created_at: new Date().toISOString(),
  },
  {
    id: "tsk-2",
    title: "Send Tech Mahindra Commercial Contract for Sign-off",
    owner_id: "u-admin",
    owner_name: "Admin User",
    priority: "High",
    due_date: new Date(Date.now() + 86400000).toISOString(),
    status: "In Progress",
    category: "Client follow-up",
    related_type: "client",
    related_name: "Tech Mahindra",
    notes: "Review 8.33% commercial term with 90-day replacement clause.",
    created_at: new Date().toISOString(),
  },
  {
    id: "tsk-3",
    title: "Follow up with Wipro on Vendor Empanelment Proposal",
    owner_id: "u-priya",
    owner_name: "Priya Singh",
    priority: "Medium",
    due_date: new Date(Date.now() + 172800000).toISOString(),
    status: "Pending",
    category: "Vendor follow-up",
    related_type: "vendor",
    related_name: "Wipro Technologies",
    notes: "Requested staffing rate card for Bangalore and Pune locations.",
    created_at: new Date().toISOString(),
  },
  {
    id: "tsk-4",
    title: "Post new React Lead openings on LinkedIn & Meta Ads",
    owner_id: "u-karan",
    owner_name: "Karan Mehta",
    priority: "Low",
    due_date: new Date(Date.now() + 259200000).toISOString(),
    status: "Completed",
    category: "Marketing task",
    related_type: "job",
    related_name: "Senior Full Stack Engineer",
    notes: "Meta lead form active with 34 submissions so far.",
    created_at: new Date().toISOString(),
  },
];

export const mockVendors = [
  {
    id: "v-1",
    company: "Wipro Technologies",
    contact_person: "Vikramaditya Sengupta",
    designation: "Head of Talent Procurement",
    email: "vikram.s@wipro.com",
    phone: "+91 98450 11223",
    linkedin: "https://linkedin.com/in/vikram-talent-wipro",
    industry: "IT Services",
    date_contacted: "2026-08-20",
    status: "Proposal Sent",
    proposal_sent: true,
    commercial_proposed: "8.33% of CTC with 90-day replacement guarantee",
    next_action: "Follow-up meeting with Procurement VP next Tuesday",
    owner_id: "u-priya",
    owner_name: "Priya Singh",
    notes: "Empanelment open for Q3 lateral tech hiring.",
    created_at: new Date().toISOString(),
  },
  {
    id: "v-2",
    company: "Infosys BPM",
    contact_person: "Shruti Kulkarni",
    designation: "Vendor Manager",
    email: "shruti.k@infosysbpm.com",
    phone: "+91 98220 99887",
    linkedin: "https://linkedin.com/in/shruti-infosys-bpm",
    industry: "BPO / ITES",
    date_contacted: "2026-08-25",
    status: "Negotiation",
    proposal_sent: true,
    commercial_proposed: "₹18,000 per joined candidate (BPO bulk)",
    next_action: "Send GST and MSME registration certificates",
    owner_id: "u-admin",
    owner_name: "Admin User",
    notes: "Bulk voice and customer support staffing for Pune center.",
    created_at: new Date().toISOString(),
  },
  {
    id: "v-3",
    company: "Bajaj Finserv",
    contact_person: "Deepak Chawla",
    designation: "Zonal HR Manager",
    email: "deepak.c@bajajfinserv.in",
    phone: "+91 98900 44556",
    linkedin: "https://linkedin.com/in/deepak-bajaj-hr",
    industry: "Banking & NBFC",
    date_contacted: "2026-07-15",
    status: "Empanelled",
    proposal_sent: true,
    commercial_proposed: "7.5% of CTC with 60-day replacement",
    next_action: "Active vendor agreement executed; receiving requisitions.",
    owner_id: "u-harshika",
    owner_name: "Harshika Sharma",
    notes: "Empanelled vendor status approved for Maharashtra region.",
    created_at: new Date().toISOString(),
  },
];

export const mockLeaves = [
  {
    id: "lv-1",
    employee_id: "emp1",
    employee_name: "Harshika Sharma",
    leave_type: "Casual Leave",
    start_date: "2026-09-12",
    end_date: "2026-09-13",
    days: 2,
    reason: "Attending family function out of town",
    status: "Approved",
    applied_at: "2026-09-05T10:00:00Z",
    approved_by: "Admin User",
    comments: "Approved. Please ensure all lineups are briefed.",
  },
  {
    id: "lv-2",
    employee_id: "emp2",
    employee_name: "Karan Mehta",
    leave_type: "Sick Leave",
    start_date: "2026-09-08",
    end_date: "2026-09-08",
    days: 1,
    reason: "Severe viral fever and physician appointment",
    status: "Pending",
    applied_at: "2026-09-07T08:30:00Z",
    approved_by: null,
    comments: "",
  },
];

export const mockTemplates = [
  {
    id: "tpl-1",
    type: "whatsapp",
    category: "Interview Confirmation",
    name: "Interview Schedule & Link",
    body: "Hello {{candidate_name}},\n\nYour interview for {{job_title}} at {{company}} is scheduled on *{{interview_date}}*.\n\n📍 Location / Link: {{location}}\n💼 Position: {{job_title}}\n💰 Package: {{salary}}\n\nPlease reply *CONFIRM* to lock in your slot.\n\nBest regards,\n{{recruiter_name}}\nOAKsphere Connect Recruitment",
  },
  {
    id: "tpl-2",
    type: "whatsapp",
    category: "Job Details",
    name: "Job Opportunity Pitch",
    body: "Hi {{candidate_name}},\n\nWe have an urgent opening for *{{job_title}}* at *{{company}}* in {{location}}.\n\n💰 Expected CTC: {{salary}}\n📌 Immediate joiners preferred.\n\nAre you interested in exploring this position? Reply YES for full JD!\n\n{{recruiter_name}} | OAKsphere Connect",
  },
  {
    id: "tpl-3",
    type: "whatsapp",
    category: "Follow-up",
    name: "Quick Callback Follow-up",
    body: "Hello {{candidate_name}}, tried calling you regarding your application for {{job_title}}. When would be a good time to connect today for 5 minutes?\n\nThanks, {{recruiter_name}} (OAKsphere Connect)",
  },
  {
    id: "tpl-4",
    type: "email",
    category: "Interview",
    name: "Formal Interview Invitation",
    subject: "Interview Invitation: {{job_title}} at {{company}} — OAKsphere Connect",
    body: "Dear {{candidate_name}},\n\nCongratulations! We are pleased to invite you for the interview round for {{job_title}} with {{company}}.\n\nDate & Time: {{interview_date}}\nFormat: {{location}}\n\nPlease bring updated copies of your resume, ID proof, and last 3 months payslips.\n\nWarm regards,\n{{recruiter_name}}\nOAKsphere Connect Recruitment Team",
  },
  {
    id: "tpl-5",
    type: "email",
    category: "Vendor Empanelment",
    name: "Recruitment Partnership Proposal",
    subject: "Talent Partnership Proposal for {{company}} — OAKsphere Connect",
    body: "Dear {{contact_person}},\n\nOAKsphere Connect specializes in pan-India staffing across IT, BFSI, Healthcare, and Corporate domains with a 48-hour shortlist turnaround.\n\nWe would love to submit our vendor empanelment credentials and standard commercial proposal.\n\nLooking forward to speaking with your team.\n\nSincerely,\nOAKsphere Connect Leadership",
  },
];

export const mockApplications = [
  {
    id: "app-1",
    candidate_name: "Aditya Kadam",
    phone: "+91 97654 32110",
    email: "aditya.k@gmail.com",
    job_id: "j1",
    job_title: "Senior Full Stack Engineer (React/Node)",
    city: "Pune",
    experience: "5 years",
    resume_url: "https://oaksphere.com/resumes/aditya-kadam.pdf",
    source: "Website Job Portal",
    utm_source: "google",
    utm_medium: "cpc",
    utm_campaign: "pune_tech_hiring",
    status: "New",
    applied_at: new Date(Date.now() - 3600000 * 3).toISOString(),
  },
  {
    id: "app-2",
    candidate_name: "Snehal More",
    phone: "+91 98221 44556",
    email: "snehal.more@yahoo.com",
    job_id: "j2",
    job_title: "Relationship Manager — Wealth Banking",
    city: "Mumbai",
    experience: "3.5 years",
    resume_url: "https://oaksphere.com/resumes/snehal-more.pdf",
    source: "Meta Ads",
    utm_source: "instagram",
    utm_medium: "lead_gen",
    utm_campaign: "bfsi_mumbai_leads",
    status: "Shortlisted",
    applied_at: new Date(Date.now() - 3600000 * 12).toISOString(),
  },
  {
    id: "app-3",
    candidate_name: "Farhan Sheikh",
    phone: "+91 99300 77889",
    email: "farhan.s@gmail.com",
    job_id: "j1",
    job_title: "Senior Full Stack Engineer (React/Node)",
    city: "Bangalore",
    experience: "6 years",
    resume_url: "https://oaksphere.com/resumes/farhan-sheikh.pdf",
    source: "Google Form",
    utm_source: "google_forms",
    utm_medium: "referral",
    utm_campaign: "candidate_walkin_sheet",
    status: "New",
    applied_at: new Date(Date.now() - 3600000 * 24).toISOString(),
  },
];

