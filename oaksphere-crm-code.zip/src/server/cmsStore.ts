// OAKSphere Website Control Center - Centralized CMS & Search Visibility Store
import { Job } from "./mockDb";

export interface PageSection {
  id: string;
  type: "hero" | "features" | "stats" | "cta" | "content" | "comparison" | "faqs" | "testimonials" | "contact_form" | "jobs_grid";
  title: string;
  subtitle?: string;
  content?: string;
  badge?: string;
  primary_button_text?: string;
  primary_button_link?: string;
  secondary_button_text?: string;
  secondary_button_link?: string;
  image_url?: string;
  items?: any[];
  active: boolean;
  order: number;
}

export interface CmsPage {
  id: string;
  slug: string;
  title: string;
  category: "core" | "landing" | "service" | "location" | "custom";
  status: "published" | "draft" | "scheduled";
  last_reviewed: string;
  h1: string;
  meta_title: string;
  meta_description: string;
  canonical_url: string;
  robots_index: boolean;
  robots_follow: boolean;
  og_title: string;
  og_description: string;
  og_image: string;
  schema_type: "WebPage" | "AboutPage" | "ContactPage" | "ItemPage" | "CollectionPage" | "LocalBusiness";
  sections: PageSection[];
  aeo_qa: { question: string; answer: string; concise_answer: string }[];
  target_keywords: string[];
}

export interface MenuItem {
  id: string;
  label: string;
  url: string;
  target: "_self" | "_blank";
  badge?: string;
  order: number;
  active: boolean;
  children?: { id: string; label: string; url: string; badge?: string; order: number }[];
}

export interface LocationItem {
  id: string;
  name: string;
  slug: string;
  state: string;
  address: string;
  pincodes: string;
  landmark: string;
  phone: string;
  email: string;
  lat: number;
  lng: number;
  hiring_focus: string[];
  active_jobs_count: number;
  meta_title: string;
  meta_description: string;
  h1: string;
  intro_content: string;
  geo_radius_km: number;
}

export interface ServiceItem {
  id: string;
  name: string;
  slug: string;
  category: string;
  icon: string;
  short_desc: string;
  full_desc: string;
  deliverables: string[];
  turnaround: string;
  commercial_model: string;
  roles_covered: string[];
  meta_title: string;
  meta_description: string;
  h1: string;
  active: boolean;
}

export interface MediaItem {
  id: string;
  name: string;
  url: string;
  file_type: "image" | "document" | "logo" | "video";
  size_kb: number;
  alt_text: string;
  caption: string;
  folder: string;
  uploaded_at: string;
}

export interface FormField {
  id: string;
  name: string;
  label: string;
  type: "text" | "email" | "tel" | "textarea" | "select" | "file" | "checkbox";
  required: boolean;
  placeholder?: string;
  options?: string[];
}

export interface FormDefinition {
  id: string;
  title: string;
  description: string;
  slug: string;
  email_notifications: string[];
  webhook_url?: string;
  crm_auto_lead: boolean;
  success_message: string;
  fields: FormField[];
  submissions_count: number;
}

export interface RedirectRule {
  id: string;
  from_path: string;
  to_path: string;
  status_code: 301 | 302 | 410;
  hits: number;
  last_hit?: string;
  active: boolean;
  note?: string;
}

export interface CrawlerRule {
  user_agent: string;
  name: string;
  type: "search" | "ai_search" | "ai_training" | "social";
  allow: boolean;
  note: string;
  recommended: "allow" | "disallow" | "optional";
}

// Initialized CMS Data Store
export const cmsStore = {
  settings: {
    site_name: "OAKSphere Connect",
    tagline: "India’s 360° Recruitment Ecosystem & Search Visibility Hub",
    site_url: "https://oaksphereconnect.com",
    logo_url: "https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=200&h=60&q=80",
    favicon_url: "https://images.unsplash.com/photo-1572021335469-31706a17aaef?auto=format&fit=crop&w=64&h=64&q=80",
    brand_colors: {
      primary: "#5F259F",
      secondary: "#0A66C2",
      accent: "#2164F3",
      background: "#FFFFFF",
      dark: "#0F172A",
    },
    typography: {
      font_display: "Plus Jakarta Sans",
      font_body: "Inter",
    },
    header: {
      sticky: true,
      show_announcement: true,
      show_login_btn: true,
      cta_label: "Hire Talent",
      cta_link: "/employers",
    },
    announcement_bar: {
      enabled: true,
      text: "⚡ 100+ High-Growth Tech & BFSI Vacancies Live across Pune, Mumbai, Navi Mumbai & Bangalore",
      link: "/jobs",
      bg_color: "bg-gradient-to-r from-purple-900 via-indigo-900 to-blue-900",
      text_color: "text-white",
    },
    footer: {
      copyright_text: "© 2026 OAKSphere Connect Private Limited. All rights reserved.",
      disclaimer: "OAKSphere Connect is a certified recruitment firm. We do not charge candidates any registration or interview fee.",
      cin: "U74999PN2023PTC219800",
    },
    contact: {
      company_name: "OAKSphere Connect Pvt. Ltd.",
      phone: "+91 98605 00768",
      alt_phone: "+91 20 4911 2200",
      email: "contact@oaksphereconnect.com",
      careers_email: "careers@oaksphereconnect.com",
      whatsapp: "919860500768",
      hq_address: "Level 8, World Trade Center, Kharadi, Pune, Maharashtra 411014",
      cin: "U74999PN2023PTC219800",
      gstin: "27AABCO4995Q1Z4",
      opening_hours: "Mo-Sa 09:30-18:30 IST",
    },
    social_links: {
      linkedin: "https://www.linkedin.com/company/oaksphere-connect",
      twitter: "https://x.com/oaksphereconnect",
      instagram: "https://instagram.com/oaksphereconnect",
      facebook: "https://facebook.com/oaksphereconnect",
      youtube: "https://youtube.com/@oaksphereconnect",
    },
    global_scripts: {
      head_script: `<!-- Google tag (gtag.js) -->\n<script async src="https://www.googletagmanager.com/gtag/js?id=G-OAKSPHERE01"></script>`,
      body_script: `<!-- Global Custom Scripts -->`,
    },
    seo_defaults: {
      gsc_verification: "google-site-verification=OAKSphereConnect2026VerificationTokenKey",
      bing_verification: "BING-VERIFY-OAKSPHERE-2026-X99",
      analytics_id: "G-OAKSPHERE01",
      meta_pixel_id: "98605007680199",
      indexnow_key: "oaksphere2026indexnowkey",
      default_og_image: "https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=1200&h=630&q=80",
    },
  },

  menus: {
    header: [
      { id: "m-1", label: "For Employers", url: "/employers", target: "_self", order: 1, active: true },
      { id: "m-2", label: "For Candidates", url: "/candidates", target: "_self", order: 2, active: true },
      { id: "m-3", label: "Jobs", url: "/jobs", target: "_self", badge: "Live", order: 3, active: true },
      { id: "m-4", label: "Industries", url: "/industries", target: "_self", order: 4, active: true },
      { id: "m-5", label: "About", url: "/about", target: "_self", order: 5, active: true },
      { id: "m-6", label: "Insights", url: "/insights", target: "_self", order: 6, active: true },
      { id: "m-7", label: "Contact", url: "/contact", target: "_self", order: 7, active: true },
    ] as MenuItem[],

    footer: [
      {
        title: "Recruitment Services",
        links: [
          { label: "BPO & Customer Ops", url: "/category/bpo-customer-ops" },
          { label: "IT & Software Staffing", url: "/category/it-software" },
          { label: "BFSI & Banking", url: "/category/banking-finance" },
          { label: "Executive Search", url: "/employers" },
          { label: "Bulk Hiring Solutions", url: "/employers" },
        ],
      },
      {
        title: "Key Job Locations",
        links: [
          { label: "Jobs in Pune", url: "/location/pune" },
          { label: "Jobs in Mumbai", url: "/location/mumbai" },
          { label: "Jobs in Navi Mumbai", url: "/location/navi-mumbai" },
          { label: "Jobs in Thane", url: "/location/thane" },
          { label: "Jobs in Bangalore", url: "/location/bangalore" },
          { label: "Jobs in Nagpur", url: "/location/nagpur" },
        ],
      },
      {
        title: "Company & Resources",
        links: [
          { label: "About OAKSphere", url: "/about" },
          { label: "Candidate Help & FAQs", url: "/faqs" },
          { label: "Hiring Insights & Blog", url: "/insights" },
          { label: "Contact Office", url: "/contact" },
          { label: "Sitemap XML", url: "/sitemap.xml" },
        ],
      },
    ],
  },

  pages: [
    {
      id: "p-home",
      slug: "/",
      title: "Homepage",
      category: "core",
      status: "published",
      last_reviewed: "2026-09-13",
      h1: "India’s Trusted Recruitment Partner for Fast-Growing Companies",
      meta_title: "OAKSphere Connect | India's Leading Recruitment Agency & Staffing Firm",
      meta_description: "Hire pre-screened talent in IT, BFSI, Healthcare & BPO within 48 hours. Zero placement fees for candidates across Pune, Mumbai, Bangalore & 25+ cities.",
      canonical_url: "https://oaksphereconnect.com/",
      robots_index: true,
      robots_follow: true,
      og_title: "OAKSphere Connect | 360° Recruitment Ecosystem across India",
      og_description: "Connecting verified talent with India's top employers. Fast 48h turnaround, strict background verification, and seamless hiring pipelines.",
      og_image: "https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=1200&h=630&q=80",
      schema_type: "WebPage",
      target_keywords: ["recruitment agency india", "staffing firm pune", "it recruitment consultant", "bfsi hiring partner"],
      sections: [
        {
          id: "s-hero",
          type: "hero",
          title: "India’s Trusted Recruitment Partner for Fast-Growing Companies",
          subtitle: "Connecting ambition with opportunity. Verified talent in IT, BFSI, Healthcare & Manufacturing delivered with lightning speed across 25+ cities.",
          badge: "India’s 360° Recruitment Ecosystem",
          primary_button_text: "Hire Talent Now",
          primary_button_link: "/employers",
          secondary_button_text: "Explore Open Jobs",
          secondary_button_link: "/jobs",
          image_url: "https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=1200&q=80",
          active: true,
          order: 1,
        },
        {
          id: "s-stats",
          type: "stats",
          title: "Recruitment Impact in Numbers",
          subtitle: "Proven speed, retention, and scale across India's premier enterprises.",
          active: true,
          order: 2,
        },
        {
          id: "s-features",
          type: "features",
          title: "Comprehensive Hiring Solutions",
          subtitle: "From single high-impact leadership hires to 500+ bulk campus ramp-ups.",
          active: true,
          order: 3,
        },
      ],
      aeo_qa: [
        {
          question: "What is OAKSphere Connect?",
          answer: "OAKSphere Connect is a premier PAN-India recruitment agency and workforce consulting firm headquartered in Pune, specializing in IT, BFSI, BPO/KPO, and Healthcare talent acquisition with a guaranteed 48-hour shortlist turnaround.",
          concise_answer: "OAKSphere Connect is a top Indian recruitment and staffing firm delivering vetted IT, BFSI, and BPO professionals in 48 hours across 25+ cities.",
        },
        {
          question: "Do job seekers pay any fee to OAKSphere Connect?",
          answer: "No. OAKSphere Connect operates strictly under a zero-fee candidate policy. Job applications, screening, interview coordination, and placement services are 100% free of charge for candidates.",
          concise_answer: "OAKSphere Connect charges zero fees to candidates. All job placement services are free.",
        },
      ],
    },
    {
      id: "p-employers",
      slug: "/employers",
      title: "For Employers",
      category: "core",
      status: "published",
      last_reviewed: "2026-09-13",
      h1: "Scale Your Workforce with Pre-Screened Talent in 48 Hours",
      meta_title: "Hire Top Talent Fast | OAKSphere Connect Employer Solutions",
      meta_description: "Access pre-screened talent across IT, BFSI, BPO and Healthcare with 48h turnaround, 94% 1-year retention, and 90-day replacement guarantee.",
      canonical_url: "https://oaksphereconnect.com/employers",
      robots_index: true,
      robots_follow: true,
      og_title: "Hire Top Talent Fast | OAKSphere Connect Employer Solutions",
      og_description: "Access pre-screened talent across IT, BFSI, BPO and Healthcare with 48h turnaround, 94% 1-year retention, and 90-day replacement guarantee.",
      og_image: "https://images.unsplash.com/photo-1551836022-d5d88e9218df?auto=format&fit=crop&w=1200&h=630&q=80",
      schema_type: "ItemPage",
      target_keywords: ["hire tech engineers", "bfsi staffing", "bulk recruitment india", "rpo services pune"],
      sections: [],
      aeo_qa: [
        {
          question: "What is the turnaround time for candidate shortlists?",
          answer: "OAKSphere Connect delivers qualified, screened candidate shortlists within 24 to 48 hours of intake for standard roles, and 3 to 5 business days for niche executive positions.",
          concise_answer: "Candidate shortlists are delivered within 24 to 48 hours for standard roles.",
        },
      ],
    },
    {
      id: "p-candidates",
      slug: "/candidates",
      title: "For Candidates",
      category: "core",
      status: "published",
      last_reviewed: "2026-09-13",
      h1: "Accelerate Your Career with Verified Employers Across India",
      meta_title: "Find Your Next Job | 100% Free Candidate Placement | OAKSphere Connect",
      meta_description: "Explore verified job openings in IT, BFSI, Customer Support and Sales. Transparent hiring, interview coaching, and zero fees for candidates.",
      canonical_url: "https://oaksphereconnect.com/candidates",
      robots_index: true,
      robots_follow: true,
      og_title: "Find Your Next Job | 100% Free Candidate Placement | OAKSphere Connect",
      og_description: "Explore verified job openings in IT, BFSI, Customer Support and Sales. Transparent hiring, interview coaching, and zero fees for candidates.",
      og_image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=1200&h=630&q=80",
      schema_type: "ItemPage",
      target_keywords: ["jobs in pune for freshers", "it jobs pune", "bpo vacancies mumbai", "free job placement"],
      sections: [],
      aeo_qa: [],
    },
    {
      id: "p-jobs",
      slug: "/jobs",
      title: "Jobs Directory",
      category: "core",
      status: "published",
      last_reviewed: "2026-09-13",
      h1: "Explore Verified Job Vacancies Across Top Indian Cities",
      meta_title: "Current Job Openings | OAKSphere Connect Career Portal",
      meta_description: "Browse live job vacancies across IT Software, BFSI, BPO, and Executive Leadership in Pune, Mumbai, Navi Mumbai, Thane, and Bangalore.",
      canonical_url: "https://oaksphereconnect.com/jobs",
      robots_index: true,
      robots_follow: true,
      og_title: "Current Job Openings | OAKSphere Connect Career Portal",
      og_description: "Browse live job vacancies across IT Software, BFSI, BPO, and Executive Leadership.",
      og_image: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1200&h=630&q=80",
      schema_type: "CollectionPage",
      target_keywords: ["jobs in india", "hiring now", "software engineer vacancies", "bank relationship manager jobs"],
      sections: [],
      aeo_qa: [],
    },
    {
      id: "p-about",
      slug: "/about",
      title: "About OAKSphere",
      category: "core",
      status: "published",
      last_reviewed: "2026-09-13",
      h1: "About OAKSphere Connect — Empowering Careers, Powering Industry",
      meta_title: "About Us | OAKSphere Connect Recruitment & Talent Ecosystem",
      meta_description: "Learn about OAKSphere Connect's mission, leadership team, ISO-compliant background screening, and nationwide recruitment footprint.",
      canonical_url: "https://oaksphereconnect.com/about",
      robots_index: true,
      robots_follow: true,
      og_title: "About Us | OAKSphere Connect Recruitment & Talent Ecosystem",
      og_description: "Learn about OAKSphere Connect's mission, leadership team, and nationwide recruitment footprint.",
      og_image: "https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=1200&h=630&q=80",
      schema_type: "AboutPage",
      target_keywords: ["about oaksphere connect", "recruitment firm leadership", "recruitment agency history"],
      sections: [],
      aeo_qa: [],
    },
    {
      id: "p-contact",
      slug: "/contact",
      title: "Contact Us",
      category: "core",
      status: "published",
      last_reviewed: "2026-09-13",
      h1: "Connect With Our Recruitment Specialists Today",
      meta_title: "Contact OAKSphere Connect | Pune Head Office & Branch Locations",
      meta_description: "Reach our talent specialists in Pune, Mumbai, Navi Mumbai, and Bangalore. Call +91 98605 00768 or visit World Trade Center Kharadi.",
      canonical_url: "https://oaksphereconnect.com/contact",
      robots_index: true,
      robots_follow: true,
      og_title: "Contact OAKSphere Connect | Pune Head Office & Branch Locations",
      og_description: "Reach our talent specialists in Pune, Mumbai, Navi Mumbai, and Bangalore.",
      og_image: "https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=1200&h=630&q=80",
      schema_type: "ContactPage",
      target_keywords: ["oaksphere contact number", "recruitment office kharadi", "oaksphere pune address"],
      sections: [],
      aeo_qa: [],
    },
    // High-Impact SEO Landing Pages (Campaign Pages)
    {
      id: "p-landing-mumbai",
      slug: "/jobs-in-mumbai",
      title: "Jobs in Mumbai",
      category: "landing",
      status: "published",
      last_reviewed: "2026-09-13",
      h1: "Top Jobs in Mumbai — BFSI, IT, Media & Corporate Hiring 2026",
      meta_title: "Jobs in Mumbai 2026 | High-Paying Careers in BKC, Andheri & Lower Parel",
      meta_description: "Find verified job openings in Mumbai across Banking, IT, FinTech, and BPO. Immediate openings with top MNCs. 100% free candidate placement.",
      canonical_url: "https://oaksphereconnect.com/jobs-in-mumbai",
      robots_index: true,
      robots_follow: true,
      og_title: "Jobs in Mumbai 2026 | Top MNC Vacancies in Mumbai",
      og_description: "Discover verified career opportunities across Mumbai's top business hubs.",
      og_image: "https://images.unsplash.com/photo-1570168007204-dfb528c6958f?auto=format&fit=crop&w=1200&h=630&q=80",
      schema_type: "CollectionPage",
      target_keywords: ["jobs in mumbai", "bkc jobs", "andheri recruitment agency", "mumbai finance careers"],
      sections: [],
      aeo_qa: [
        {
          question: "What are the top hiring sectors in Mumbai for 2026?",
          answer: "The top hiring sectors in Mumbai include Banking & Financial Services (BFSI), FinTech, IT Services, Media, Supply Chain, and International BPO operations centered around BKC, Lower Parel, and Andheri East.",
          concise_answer: "Top hiring sectors in Mumbai are BFSI, FinTech, IT Services, and BPO operations.",
        },
      ],
    },
    {
      id: "p-landing-navi-mumbai",
      slug: "/bpo-jobs-navi-mumbai",
      title: "BPO Jobs in Navi Mumbai",
      category: "landing",
      status: "published",
      last_reviewed: "2026-09-13",
      h1: "BPO & Customer Operations Jobs in Navi Mumbai (Airoli, Mahape, Vashi)",
      meta_title: "BPO Jobs in Navi Mumbai | Customer Support & Voice Vacancies",
      meta_description: "Immediate openings for Voice, Semi-Voice, and Chat Support in Navi Mumbai IT parks. High incentives, night shift allowances & company transport.",
      canonical_url: "https://oaksphereconnect.com/bpo-jobs-navi-mumbai",
      robots_index: true,
      robots_follow: true,
      og_title: "BPO Jobs in Navi Mumbai | Customer Support & Voice Vacancies",
      og_description: "Immediate openings for Voice and Non-Voice support in Airoli, Mahape and Vashi.",
      og_image: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=1200&h=630&q=80",
      schema_type: "CollectionPage",
      target_keywords: ["bpo jobs navi mumbai", "airoli call center openings", "vashi customer support jobs", "mahape bpo"],
      sections: [],
      aeo_qa: [],
    },
    {
      id: "p-landing-bulk",
      slug: "/bulk-hiring-india",
      title: "Bulk Hiring India",
      category: "landing",
      status: "published",
      last_reviewed: "2026-09-13",
      h1: "Turnkey Bulk Hiring Solutions for Fast-Scaling Enterprises in India",
      meta_title: "Bulk Hiring & High-Volume Staffing Solutions India | OAKSphere",
      meta_description: "Scale 100 to 1,000+ hires per month for customer ops, branch networks, logistics, and tech teams. AI-accelerated sourcing with verified compliance.",
      canonical_url: "https://oaksphereconnect.com/bulk-hiring-india",
      robots_index: true,
      robots_follow: true,
      og_title: "Bulk Hiring & High-Volume Staffing Solutions India | OAKSphere",
      og_description: "Turnkey mass-recruitment solutions with rapid turnaround and verified compliance.",
      og_image: "https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=1200&h=630&q=80",
      schema_type: "ItemPage",
      target_keywords: ["bulk hiring india", "mass recruitment agency", "volume staffing pune", "turnkey hiring partner"],
      sections: [],
      aeo_qa: [],
    },
  ] as CmsPage[],

  locations: [
    {
      id: "loc-pune",
      name: "Pune",
      slug: "pune",
      state: "Maharashtra",
      address: "Level 8, World Trade Center, Kharadi, Pune 411014",
      pincodes: "411014, 411057, 411006, 411028",
      landmark: "Opposite EON Free Zone, Kharadi",
      phone: "+91 98605 00768",
      email: "pune@oaksphereconnect.com",
      lat: 18.5516,
      lng: 73.9348,
      hiring_focus: ["IT & Cloud Engineering", "BFSI Operations", "Automotive & Manufacturing", "Healthcare BPO"],
      active_jobs_count: 38,
      meta_title: "Jobs in Pune 2026 | IT, Software & Banking Openings in Hinjewadi & Kharadi",
      meta_description: "Explore 35+ verified job openings in Pune. Top engineering, BFSI, and operations careers with top MNCs. Free candidate registration with OAKSphere.",
      h1: "Recruitment Agency in Pune — IT, BFSI & Engineering Talent Hub",
      intro_content: "Pune is the silicon capital of Western India. OAKSphere Connect's headquarters at World Trade Center Kharadi connects top talent with tech giants in Hinjewadi, Kharadi, Magarpatta, and Viman Nagar.",
      geo_radius_km: 35,
    },
    {
      id: "loc-mumbai",
      name: "Mumbai",
      slug: "mumbai",
      state: "Maharashtra",
      address: "Bandra Kurla Complex (BKC), Bandra East, Mumbai 400051",
      pincodes: "400051, 400013, 400069, 400093",
      landmark: "Near Diamond Bourse, BKC",
      phone: "+91 98605 00768",
      email: "mumbai@oaksphereconnect.com",
      lat: 19.0688,
      lng: 72.8697,
      hiring_focus: ["Investment Banking", "FinTech", "Corporate Sales", "Digital Marketing"],
      active_jobs_count: 45,
      meta_title: "Recruitment Consultants in Mumbai | Top Financial & Tech Staffing Agency",
      meta_description: "Leading recruitment agency in Mumbai for BFSI, IT, FinTech, and Executive Search across BKC, Lower Parel, Andheri, and Nariman Point.",
      h1: "Premier Recruitment Agency in Mumbai — Financial Capital Talent Specialists",
      intro_content: "From the high-stakes trading floors of BKC to media conglomerates in Lower Parel and IT hubs in Andheri, OAKSphere Connect powers leadership and operational hiring across Greater Mumbai.",
      geo_radius_km: 40,
    },
    {
      id: "loc-navi-mumbai",
      name: "Navi Mumbai",
      slug: "navi-mumbai",
      state: "Maharashtra",
      address: "Sector 30A, Vashi InfoTech Park, Navi Mumbai 400705",
      pincodes: "400705, 400708, 400710",
      landmark: "Near Vashi Railway Station",
      phone: "+91 98605 00768",
      email: "navimumbai@oaksphereconnect.com",
      lat: 19.076,
      lng: 72.9982,
      hiring_focus: ["International BPO", "Data Analytics", "Cloud Services", "Logistics Operations"],
      active_jobs_count: 29,
      meta_title: "Jobs in Navi Mumbai 2026 | BPO, Tech & Customer Support Careers",
      meta_description: "Find verified job vacancies in Navi Mumbai across Airoli Mindspace, Mahape Millennium Business Park, and Vashi. Direct employer shortlisting.",
      h1: "Recruitment Consultants in Navi Mumbai — BPO & IT Staffing Agency",
      intro_content: "Navi Mumbai is the operational nerve-center for India's largest BPO, customer success, and cloud operations. We staff Airoli Mindspace, Mahape, and Belapur tech parks.",
      geo_radius_km: 25,
    },
    {
      id: "loc-thane",
      name: "Thane",
      slug: "thane",
      state: "Maharashtra",
      address: "Wagle Industrial Estate, Thane West 400604",
      pincodes: "400604, 400607, 400615",
      landmark: "Near Road No. 16, Wagle Estate",
      phone: "+91 98605 00768",
      email: "thane@oaksphereconnect.com",
      lat: 19.2183,
      lng: 72.9781,
      hiring_focus: ["Engineering & Automation", "Back-Office BFSI", "Pharmaceutical Manufacturing", "Enterprise Support"],
      active_jobs_count: 22,
      meta_title: "Jobs in Thane 2026 | IT Parks & Wagle Estate Vacancies",
      meta_description: "Discover top employment opportunities in Thane West, Ghodbunder Road, and Wagle Estate. Immediate hiring with top Indian and international firms.",
      h1: "Recruitment Agency in Thane — Industrial & Corporate Staffing",
      intro_content: "Thane has rapidly evolved into a bustling corporate suburb with extensive IT SEZs and manufacturing hubs. OAKSphere provides end-to-end recruitment for Thane-based employers.",
      geo_radius_km: 20,
    },
    {
      id: "loc-nagpur",
      name: "Nagpur",
      slug: "nagpur",
      state: "Maharashtra",
      address: "MIHAN SEZ, Nagpur, Maharashtra 441108",
      pincodes: "441108, 440010, 440022",
      landmark: "Near Infosys & TCS Campuses, MIHAN",
      phone: "+91 98605 00768",
      email: "nagpur@oaksphereconnect.com",
      lat: 21.0543,
      lng: 79.0528,
      hiring_focus: ["IT Services & Coding", "Aviation Maintenance", "Logistics & Warehousing", "Customer Operations"],
      active_jobs_count: 18,
      meta_title: "Jobs in Nagpur 2026 | MIHAN SEZ & Tech Campus Openings",
      meta_description: "Browse verified vacancies in Nagpur across MIHAN SEZ, IT services, logistics, and banking. Accelerate your career in Central India's growth capital.",
      h1: "Recruitment Consultants in Nagpur — MIHAN & Vidarbha Talent Partner",
      intro_content: "Nagpur and MIHAN SEZ represent the next giant growth frontier for IT, aviation, and smart logistics in Central India. OAKSphere recruits top talent locally.",
      geo_radius_km: 30,
    },
    {
      id: "loc-bangalore",
      name: "Bangalore",
      slug: "bangalore",
      state: "Karnataka",
      address: "Outer Ring Road, Bellandur, Bengaluru 560103",
      pincodes: "560103, 560066, 560100",
      landmark: "Near Ecospace Tech Park",
      phone: "+91 98605 00768",
      email: "bangalore@oaksphereconnect.com",
      lat: 12.926,
      lng: 77.6834,
      hiring_focus: ["Full-Stack Software", "AI & Machine Learning", "Product Management", "Cloud Infrastructure"],
      active_jobs_count: 52,
      meta_title: "Tech Recruitment Agency in Bangalore | Software & AI Hiring",
      meta_description: "Leading technology recruitment firm in Bengaluru connecting top unicorns, product firms, and global capability centers with elite engineers.",
      h1: "Tech Staffing Agency in Bangalore — Silicon Valley of India",
      intro_content: "Connecting ambitious product builders, AI innovators, and cloud engineers with India's most innovative startups and Global Capability Centers (GCCs).",
      geo_radius_km: 45,
    },
  ] as LocationItem[],

  services: [
    {
      id: "srv-bpo",
      name: "BPO & Customer Operations Hiring",
      slug: "bpo-hiring",
      category: "Volume Hiring",
      icon: "Headphones",
      short_desc: "High-volume recruitment for voice, chat, back-office, and technical support teams with fast 48h deployment.",
      full_desc: "We understand that BPO operations demand relentless speed, high linguistic proficiency, and strict background checks. Our proprietary candidate database and automated screening allow us to fulfill mandates of 50 to 500+ agents smoothly.",
      deliverables: ["Language & Accent Assessment", "Typing Speed & Accuracy Verification", "Day/Night Shift Orientation", "Address & Criminal Verification", "Zero-Dropout Replacement SLA"],
      turnaround: "24-48 Hours",
      commercial_model: "Contingency & Volume Retention Tier",
      roles_covered: ["Customer Support Executive", "Technical Support Associate", "Team Leader - Operations", "Quality Analyst", "Workforce Management Planner"],
      meta_title: "BPO Recruitment Agency India | Customer Support Staffing Solutions",
      meta_description: "Scale your contact center with verified voice and chat agents. Rapid 48h turnaround, zero placement fees for candidates, and verified credentials.",
      h1: "BPO & Customer Operations Hiring Agency — Pan-India Solutions",
      active: true,
    },
    {
      id: "srv-it",
      name: "IT & Software Staffing",
      slug: "it-hiring",
      category: "Tech Hiring",
      icon: "Laptop",
      short_desc: "Vetted full-stack developers, cloud architects, DevOps leads, and AI/data scientists ready to contribute on day one.",
      full_desc: "Our tech recruitment pod consists of technical talent scouts who evaluate candidate code repositories, architectural fluency, and problem-solving depth before client submission.",
      deliverables: ["Live Coding & Architecture Pre-screen", "Notice Period Buyout Facilitation", "Culture & Remote-Work Readiness Check", "90-Day Unconditional Replacement Guarantee"],
      turnaround: "48-72 Hours",
      commercial_model: "Success-Fee Contingent",
      roles_covered: ["Senior React/Node Full Stack", "Cloud DevOps & Kubernetes", "Python AI/ML Engineers", "Mobile iOS/Android Leads", "Cybersecurity Analysts"],
      meta_title: "IT Staffing & Tech Recruitment Agency India | OAKSphere Connect",
      meta_description: "Hire pre-vetted software engineers, architects, and DevOps leads. Fast 48h shortlists, technical pre-screening, and guaranteed retention.",
      h1: "IT & Technology Recruitment Agency — Vetted Tech Talent Across India",
      active: true,
    },
    {
      id: "srv-bfsi",
      name: "BFSI & Wealth Management",
      slug: "bfsi-hiring",
      category: "Financial Services",
      icon: "Landmark",
      short_desc: "Branch managers, relationship managers, credit underwriters, and compliance officers for banks and NBFCs.",
      full_desc: "Financial institutions require professionals with pristine ethical backgrounds, deep regulatory understanding, and proven sales or underwriting capabilities.",
      deliverables: ["Regulatory & NISM Certification Check", "CIBIL / Credit History Verification", "Branch Sales Target Track Record Audit", "Pan-India Multi-Branch Staffing"],
      turnaround: "48 Hours",
      commercial_model: "Tiered Percentage of CTC",
      roles_covered: ["Branch Relationship Manager", "Credit Underwriter", "Wealth Advisor", "Compliance Officer", "Area Sales Manager"],
      meta_title: "BFSI Recruitment Agency India | Banking & Financial Staffing",
      meta_description: "Trusted recruitment agency for Banks, NBFCs, and FinTechs in Mumbai, Pune & India. Verified relationship managers and credit underwriters.",
      h1: "BFSI Recruitment Specialists — Banking, FinTech & Wealth Management",
      active: true,
    },
    {
      id: "srv-bulk",
      name: "Bulk & Campus Turnkey Hiring",
      slug: "bulk-hiring",
      category: "High Volume",
      icon: "Users2",
      short_desc: "Rapid hiring ramp-ups for retail expansions, branch rollouts, logistics hubs, and annual campus recruitment drives.",
      full_desc: "End-to-end turnkey recruitment management for organizations scaling by hundreds of headcount in compressed timelines.",
      deliverables: ["Dedicated Recruiter Deployment", "Assessment Infrastructure & Hackathons", "Offer Rollout & Pre-Joining Engagement", "Comprehensive BGV Reports"],
      turnaround: "7 Business Days",
      commercial_model: "Hybrid Retainer + Per-Hire SLA",
      roles_covered: ["Graduate Trainees", "Retail Sales Associates", "Warehouse Supervisors", "Field Collection Executives"],
      meta_title: "Bulk Hiring Solutions India | Mass Staffing & Campus Drives",
      meta_description: "Scale 100 to 1,000+ hires per month for retail, logistics, and tech operations. Proven turnkey recruitment across 25+ Indian cities.",
      h1: "Bulk & High-Volume Recruitment Agency India",
      active: true,
    },
  ] as ServiceItem[],

  media: [
    {
      id: "med-1",
      name: "oaksphere-primary-logo.png",
      url: "https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=400&q=80",
      file_type: "logo",
      size_kb: 48,
      alt_text: "OAKSphere Connect Official Brand Logo",
      caption: "Primary header and vector brand mark",
      folder: "branding",
      uploaded_at: "2026-08-01",
    },
    {
      id: "med-2",
      name: "hero-collaboration-banner.jpg",
      url: "https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=1200&h=630&q=80",
      file_type: "image",
      size_kb: 142,
      alt_text: "Corporate recruitment team collaborating on talent acquisition in Pune",
      caption: "Homepage open graph and hero banner",
      folder: "banners",
      uploaded_at: "2026-08-10",
    },
    {
      id: "med-3",
      name: "pune-wtc-headquarters.jpg",
      url: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=800&q=80",
      file_type: "image",
      size_kb: 96,
      alt_text: "World Trade Center Kharadi Pune office exterior",
      caption: "Pune branch office image",
      folder: "locations",
      uploaded_at: "2026-08-15",
    },
    {
      id: "med-4",
      name: "mumbai-bkc-skyline.jpg",
      url: "https://images.unsplash.com/photo-1570168007204-dfb528c6958f?auto=format&fit=crop&w=800&q=80",
      file_type: "image",
      size_kb: 112,
      alt_text: "Bandra Kurla Complex business district skyline Mumbai",
      caption: "Mumbai branch office image",
      folder: "locations",
      uploaded_at: "2026-08-18",
    },
  ] as MediaItem[],

  forms: [
    {
      id: "frm-candidate",
      title: "Candidate Job Application Form",
      description: "Primary candidate intake form linked to individual job posts and general candidate pool.",
      slug: "candidate-application",
      email_notifications: ["talent@oaksphereconnect.com"],
      crm_auto_lead: true,
      success_message: "Thank you! Your profile has been received. Our recruiter will reach out within 24 hours.",
      fields: [
        { id: "f1", name: "name", label: "Full Name", type: "text", required: true, placeholder: "e.g. Rahul Sharma" },
        { id: "f2", name: "phone", label: "WhatsApp / Phone Number", type: "tel", required: true, placeholder: "10-digit mobile number" },
        { id: "f3", name: "email", label: "Email Address", type: "email", required: true, placeholder: "rahul.sharma@example.com" },
        { id: "f4", name: "city", label: "Current City", type: "select", required: true, options: ["Pune", "Mumbai", "Navi Mumbai", "Thane", "Nagpur", "Bangalore", "Hyderabad", "Delhi NCR", "Other"] },
        { id: "f5", name: "experience", label: "Total Experience", type: "select", required: true, options: ["Fresher (0-1 year)", "1-3 years", "3-5 years", "5-8 years", "8+ years"] },
        { id: "f6", name: "expected_salary", label: "Expected Annual CTC", type: "text", required: false, placeholder: "e.g. ₹8,00,000 PA" },
        { id: "f7", name: "resume_url", label: "Resume / LinkedIn Profile URL", type: "text", required: false, placeholder: "Link to PDF or LinkedIn" },
      ],
      submissions_count: 86,
    },
    {
      id: "frm-employer",
      title: "Employer Hiring Requirement Mandate",
      description: "High-intent client intake form for hiring managers seeking talent.",
      slug: "employer-mandate",
      email_notifications: ["business@oaksphereconnect.com"],
      crm_auto_lead: true,
      success_message: "Mandate received. Our Client Solutions Director will contact you within 2 business hours.",
      fields: [
        { id: "ef1", name: "company_name", label: "Company / Organization Name", type: "text", required: true, placeholder: "e.g. Tech Enterprise Pvt Ltd" },
        { id: "ef2", name: "contact_person", label: "Contact Person & Title", type: "text", required: true, placeholder: "e.g. Anjali Verma, Head of HR" },
        { id: "ef3", name: "work_email", label: "Official Work Email", type: "email", required: true, placeholder: "anjali.v@company.com" },
        { id: "ef4", name: "phone", label: "Phone Number", type: "tel", required: true, placeholder: "10-digit mobile number" },
        { id: "ef5", name: "hiring_domain", label: "Hiring Domain", type: "select", required: true, options: ["IT & Software Engineering", "BFSI & Banking", "BPO & Customer Operations", "Executive Search", "Bulk Hiring (50+ positions)"] },
        { id: "ef6", name: "positions_count", label: "Number of Openings", type: "text", required: true, placeholder: "e.g. 5 openings" },
        { id: "ef7", name: "job_details", label: "Job Description / Key Requirements", type: "textarea", required: false, placeholder: "Paste key skills, location, target CTC range..." },
      ],
      submissions_count: 34,
    },
    {
      id: "frm-contact",
      title: "Quick Contact & Callback Request",
      description: "General inquiry form for candidate or corporate inquiries.",
      slug: "contact-inquiry",
      email_notifications: ["contact@oaksphereconnect.com"],
      crm_auto_lead: true,
      success_message: "Message sent successfully! We will connect with you shortly.",
      fields: [
        { id: "cf1", name: "name", label: "Your Name", type: "text", required: true },
        { id: "cf2", name: "phone", label: "Phone", type: "tel", required: true },
        { id: "cf3", name: "email", label: "Email", type: "email", required: true },
        { id: "cf4", name: "message", label: "How can we help?", type: "textarea", required: true },
      ],
      submissions_count: 42,
    },
  ] as FormDefinition[],

  content_blocks: {
    testimonials: [
      {
        id: "t1",
        quote: "OAKSphere Connect reduced our IT engineering time-to-hire by 40% while delivering exceptionally skilled talent.",
        author: "Rajesh Kulkarni",
        role: "Head of Engineering",
        company: "Tech Mahindra",
        rating: 5,
        avatar_url: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=120&q=80",
        active: true,
      },
      {
        id: "t2",
        quote: "Their deep network in BFSI helped us staff 30+ relationship managers across Maharashtra in record time.",
        author: "Sneha Kapoor",
        role: "AVP Talent Acquisition",
        company: "HDFC Life",
        rating: 5,
        avatar_url: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=120&q=80",
        active: true,
      },
      {
        id: "t3",
        quote: "Professional, transparent and candidate-friendly. The best recruitment partner we've collaborated with in Pune.",
        author: "Venkatesh Rao",
        role: "Director HR",
        company: "Cognizant",
        rating: 5,
        avatar_url: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=120&q=80",
        active: true,
      },
      {
        id: "t4",
        quote: "Got placed as Senior React Lead with 40% salary hike within 5 days. Zero fees and amazing interview guidance!",
        author: "Pooja Deshmukh",
        role: "Candidate (Placed at Tech Unicorn)",
        company: "Candidate Testimonial",
        rating: 5,
        avatar_url: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=120&q=80",
        active: true,
      },
    ],
    clients: [
      { id: "cl1", name: "Tech Mahindra", logo_url: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=160&q=80", industry: "IT Services", featured: true },
      { id: "cl2", name: "HDFC Life", logo_url: "https://images.unsplash.com/photo-1559526324-4b87b5e36e44?auto=format&fit=crop&w=160&q=80", industry: "BFSI", featured: true },
      { id: "cl3", name: "Cognizant", logo_url: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=160&q=80", industry: "IT Services", featured: true },
      { id: "cl4", name: "Apollo Hospitals", logo_url: "https://images.unsplash.com/photo-1505751172876-fa1923c5c528?auto=format&fit=crop&w=160&q=80", industry: "Healthcare", featured: true },
      { id: "cl5", name: "Tata Consultancy Services", logo_url: "https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=160&q=80", industry: "IT & Consulting", featured: true },
      { id: "cl6", name: "ICICI Bank", logo_url: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&w=160&q=80", industry: "Banking", featured: true },
    ],
    team: [
      { id: "tm1", name: "Onkar Khillare", role: "Managing Director & Chief Strategist", bio: "15+ years scaling corporate talent acquisition ecosystems across APAC.", photo_url: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=240&q=80", linkedin: "https://linkedin.com" },
      { id: "tm2", name: "Harshika Sharma", role: "Head of Talent Acquisition (IT & Cloud)", bio: "Expert technical recruiter managing high-growth software mandates in Pune & Bangalore.", photo_url: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=240&q=80", linkedin: "https://linkedin.com" },
      { id: "tm3", name: "Karan Mehta", role: "Practice Lead - BFSI & Financial Markets", bio: "Specialized in wealth management and executive banking leadership searches.", photo_url: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=240&q=80", linkedin: "https://linkedin.com" },
      { id: "tm4", name: "Priya Singh", role: "Team Leader - Operations & Screening", bio: "Leading multi-tier verification and 48-hour candidate response pipelines.", photo_url: "https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=240&q=80", linkedin: "https://linkedin.com" },
    ],
    stats: [
      { id: "st1", value: "2,500+", label: "Verified Placements", sub: "Placed in Top 100 Indian Corporates", icon: "Users2", active: true },
      { id: "st2", value: "48h", label: "Average Shortlist Time", sub: "Fastest SLA in Recruitment Industry", icon: "Clock", active: true },
      { id: "st3", value: "98.4%", label: "Client Satisfaction", sub: "Based on 300+ Verified Audits", icon: "HeartHandshake", active: true },
      { id: "st4", value: "94%", label: "1-Year Candidate Retention", sub: "Long-term Cultural Fit Guarantee", icon: "ShieldCheck", active: true },
    ],
  },

  redirects: [
    { id: "red-1", from_path: "/careers", to_path: "/jobs", status_code: 301, hits: 142, last_hit: "2026-09-12 14:20", active: true, note: "Legacy careers page redirect" },
    { id: "red-2", from_path: "/jobs/senior-react-dev-old", to_path: "/jobs", status_code: 302, hits: 28, last_hit: "2026-09-11 09:15", active: true, note: "Closed job redirect to job catalog" },
    { id: "red-3", from_path: "/openings-mumbai", to_path: "/location/mumbai", status_code: 301, hits: 87, last_hit: "2026-09-13 08:30", active: true, note: "Short url for campaign" },
  ] as RedirectRule[],

  crawlers: [
    { user_agent: "Googlebot", name: "Googlebot", type: "search", allow: true, note: "Google Search indexing & Google Jobs crawler", recommended: "allow" },
    { user_agent: "Bingbot", name: "Bingbot", type: "search", allow: true, note: "Microsoft Bing Search & Copilot Search crawler", recommended: "allow" },
    { user_agent: "OAI-SearchBot", name: "OAI-SearchBot", type: "ai_search", allow: true, note: "OpenAI ChatGPT Search discoverability (Crucial for ChatGPT citations)", recommended: "allow" },
    { user_agent: "GPTBot", name: "GPTBot", type: "ai_training", allow: false, note: "OpenAI LLM general training scraper", recommended: "optional" },
    { user_agent: "ClaudeBot", name: "ClaudeBot", type: "ai_search", allow: false, note: "Anthropic Claude web indexing scraper", recommended: "optional" },
    { user_agent: "PerplexityBot", name: "PerplexityBot", type: "ai_search", allow: true, note: "Perplexity AI search engine live citation crawler", recommended: "allow" },
    { user_agent: "Applebot", name: "Applebot", type: "search", allow: true, note: "Apple Intelligence & Siri web crawler", recommended: "allow" },
    { user_agent: "Twitterbot", name: "Twitterbot / X", type: "social", allow: true, note: "Social card previews when URLs shared on X", recommended: "allow" },
    { user_agent: "facebookexternalhit", name: "Facebook / WhatsApp", type: "social", allow: true, note: "WhatsApp link preview generator & Meta shares", recommended: "allow" },
  ] as CrawlerRule[],

  rules_engine: {
    title_template: "{title} | OAKSphere Connect",
    default_meta_description: "Connect with OAKSphere Connect, India's leading 360° recruitment partner for IT, BFSI, Healthcare & BPO talent.",
    auto_close_expired_jobs: true,
    expired_job_action: "show_expired_banner", // 'show_expired_banner' | 'redirect_to_jobs' | '410_gone'
    enable_breadcrumbs_schema: true,
    enable_organization_schema: true,
    enable_jobposting_schema: true,
    enable_aeo_qa_schema: true,
    max_meta_description_length: 160,
    min_meta_description_length: 110,
    enforce_canonical_lowercase: true,
    auto_ping_indexnow_on_publish: true,
    custom_robots_directives: [
      "Disallow: /admin",
      "Disallow: /api/",
      "Disallow: /login",
      "Disallow: /forgot-password",
    ],
  },

  activity_log: [
    { id: "act-1", timestamp: "2026-09-13 07:45", user: "Admin User", action: "SEO Audit Executed", target: "All 18 Pages & Jobs", details: "Health score computed at 96/100" },
    { id: "act-2", timestamp: "2026-09-12 16:30", user: "Admin User", action: "Updated Job Expiry Policy", target: "Job CMS", details: "Set auto-close to 'show_expired_banner' with past validThrough" },
    { id: "act-3", timestamp: "2026-09-11 11:10", user: "Admin User", action: "Published Landing Page", target: "/jobs-in-mumbai", details: "Enabled LocalBusiness & CollectionPage schema" },
    { id: "act-4", timestamp: "2026-09-10 14:05", user: "Admin User", action: "Updated Robots.txt Rules", target: "AI Crawlers", details: "Enabled OAI-SearchBot for ChatGPT Search discoverability" },
  ],
};

// ---------------- ALGORITHMIC AUDIT & READINESS ENGINES ----------------

export function calculateSearchAiReadiness(allJobs: Job[], allBlogs: any[]) {
  const pages = cmsStore.pages;
  const baseUrl = cmsStore.settings.site_url || "https://oaksphereconnect.com";

  // Score each page against the 11 Search & AI readiness dimensions
  return pages.map((p) => {
    const isJobRelated = p.slug === "/jobs" || p.category === "landing";
    const hasStructuredData = !!p.schema_type;
    const hasCanonical = !!p.canonical_url;
    const hasAeo = (p.aeo_qa && p.aeo_qa.length > 0) || p.slug === "/" || p.slug === "/employers";
    const isLocal = p.category === "location" || p.slug.includes("mumbai") || p.slug.includes("pune");
    const robotsValid = p.robots_index && p.robots_follow;

    // Checks
    const checks = {
      google_seo: p.meta_title && p.meta_description && p.meta_description.length >= 70,
      google_job_search: isJobRelated ? true : "n/a",
      local_seo: isLocal ? true : "n/a",
      structured_data: hasStructuredData,
      bing_indexnow: true,
      chatgpt_search_crawl: cmsStore.crawlers.find((c) => c.user_agent === "OAI-SearchBot")?.allow ?? true,
      canonical: hasCanonical,
      sitemap: true,
      mobile: true,
      performance: true,
      ai_readable_content: hasAeo || (p.sections && p.sections.length > 0) || p.meta_description.length > 80,
    };

    const applicableChecks = Object.entries(checks).filter(([_, v]) => v !== "n/a");
    const passedChecks = applicableChecks.filter(([_, v]) => v === true).length;
    const readiness_score = Math.round((passedChecks / applicableChecks.length) * 100);

    return {
      id: p.id,
      slug: p.slug,
      title: p.title,
      url: `${baseUrl}${p.slug === "/" ? "" : p.slug}`,
      category: p.category,
      status: p.status,
      last_reviewed: p.last_reviewed || "2026-09-13",
      readiness_score,
      checks,
    };
  });
}

export function runFullSeoAudit(allJobs: Job[], allBlogs: any[]) {
  const pages = cmsStore.pages;
  const issues: { id: string; severity: "critical" | "warning" | "good"; category: string; page: string; title: string; recommendation: string }[] = [];

  let criticalCount = 0;
  let warningCount = 0;
  let goodCount = 0;

  pages.forEach((p) => {
    // 1. Title Length
    if (!p.meta_title) {
      issues.push({
        id: `crit-title-${p.id}`,
        severity: "critical",
        category: "Meta Tags",
        page: p.slug,
        title: `Missing SEO Meta Title on "${p.title}"`,
        recommendation: `Add a high-impact meta title between 50-60 characters featuring primary keywords.`,
      });
      criticalCount++;
    } else if (p.meta_title.length < 35) {
      issues.push({
        id: `warn-title-${p.id}`,
        severity: "warning",
        category: "Meta Tags",
        page: p.slug,
        title: `Short Title (${p.meta_title.length} chars) on "${p.title}"`,
        recommendation: `Expand title to 50-60 characters to optimize click-through rate on Google and Bing.`,
      });
      warningCount++;
    } else {
      issues.push({
        id: `good-title-${p.id}`,
        severity: "good",
        category: "Meta Tags",
        page: p.slug,
        title: `Optimal Title Length (${p.meta_title.length} chars) on "${p.title}"`,
        recommendation: `Passed Google & Bing optimal display guidelines.`,
      });
      goodCount++;
    }

    // 2. Meta Description Length
    if (!p.meta_description) {
      issues.push({
        id: `crit-desc-${p.id}`,
        severity: "critical",
        category: "Meta Tags",
        page: p.slug,
        title: `Missing Meta Description on "${p.title}"`,
        recommendation: `Write a compelling 120-160 character description with clear CTA.`,
      });
      criticalCount++;
    } else if (p.meta_description.length < 100 || p.meta_description.length > 170) {
      issues.push({
        id: `warn-desc-${p.id}`,
        severity: "warning",
        category: "Meta Tags",
        page: p.slug,
        title: `Meta Description Length (${p.meta_description.length} chars) on "${p.title}"`,
        recommendation: `Aim for 120-160 characters to prevent snippet truncation on mobile & desktop.`,
      });
      warningCount++;
    } else {
      goodCount++;
    }

    // 3. Canonical Tag
    if (!p.canonical_url) {
      issues.push({
        id: `warn-canon-${p.id}`,
        severity: "warning",
        category: "Indexing",
        page: p.slug,
        title: `Missing Explicit Canonical URL on "${p.title}"`,
        recommendation: `Specify an absolute canonical URL to prevent duplicate content consolidation issues.`,
      });
      warningCount++;
    } else {
      goodCount++;
    }

    // 4. Schema Markup
    if (!p.schema_type) {
      issues.push({
        id: `warn-schema-${p.id}`,
        severity: "warning",
        category: "Structured Data",
        page: p.slug,
        title: `No Schema Type Assigned to "${p.title}"`,
        recommendation: `Assign JSON-LD schema (e.g. WebPage, AboutPage, LocalBusiness) to help AI & search engines parse entity details.`,
      });
      warningCount++;
    } else {
      goodCount++;
    }

    // 5. AEO & Concise Answers
    if (!p.aeo_qa || p.aeo_qa.length === 0) {
      if (p.category === "core") {
        issues.push({
          id: `warn-aeo-${p.id}`,
          severity: "warning",
          category: "AEO / AI Search",
          page: p.slug,
          title: `No Concise AEO Answer Blocks on "${p.title}"`,
          recommendation: `Add structured question-and-answer pairs with 40-60 word definitions for ChatGPT Search & Google AI Overviews.`,
        });
        warningCount++;
      }
    } else {
      issues.push({
        id: `good-aeo-${p.id}`,
        severity: "good",
        category: "AEO / AI Search",
        page: p.slug,
        title: `AEO Concise Answer Blocks Present on "${p.title}"`,
        recommendation: `Entities formatted for direct extraction by generative AI search agents.`,
      });
      goodCount++;
    }
  });

  // Check Job SEO & Expiry Handling
  const activeJobs = allJobs.filter((j) => j.status === "Active");
  const expiredJobs = allJobs.filter((j) => j.status === "Expired" || j.status === "Closed");

  if (activeJobs.length > 0) {
    goodCount += 3;
    issues.push({
      id: "good-jobs-schema",
      severity: "good",
      category: "Job SEO",
      page: "/jobs",
      title: `${activeJobs.length} Active Jobs With Automated JobPosting Schema`,
      recommendation: `Google Job Search rich snippets actively provisioned with hiringOrganization, validThrough & salary.`,
    });
  }

  if (expiredJobs.length > 0) {
    issues.push({
      id: "good-expired-handling",
      severity: "good",
      category: "Job SEO",
      page: "/jobs",
      title: `${expiredJobs.length} Expired/Closed Jobs Automatically Guarded`,
      recommendation: `Expired jobs display explicit closing banners and exclude active JobPosting markup per Google May 2026 guidelines.`,
    });
    goodCount += 1;
  }

  // Check AI Crawler Access
  const oaiAllowed = cmsStore.crawlers.find((c) => c.user_agent === "OAI-SearchBot")?.allow;
  if (oaiAllowed) {
    issues.push({
      id: "good-oai",
      severity: "good",
      category: "AI Crawlers",
      page: "/robots.txt",
      title: "OAI-SearchBot Allowed in robots.txt",
      recommendation: "OpenAI ChatGPT Search can index and cite your public jobs and company data.",
    });
    goodCount += 1;
  } else {
    issues.push({
      id: "warn-oai",
      severity: "warning",
      category: "AI Crawlers",
      page: "/robots.txt",
      title: "OAI-SearchBot is Blocked or Restricted",
      recommendation: "Enable OAI-SearchBot in AI Crawler Manager if you want ChatGPT Search users to find your website.",
    });
    warningCount++;
  }

  const total = criticalCount + warningCount + goodCount;
  const overall_score = total > 0 ? Math.round(((goodCount * 1 + warningCount * 0.5) / total) * 100) : 95;

  return {
    overall_score,
    critical_count: criticalCount,
    warning_count: warningCount,
    good_count: goodCount,
    total_pages_audited: pages.length + allJobs.length,
    audited_at: new Date().toISOString(),
    issues,
  };
}

// ---------------- REAL DYNAMIC ROBOTS.TXT GENERATOR ----------------
export function generateRobotsTxtContent(): string {
  const baseUrl = cmsStore.settings.site_url || "https://oaksphereconnect.com";
  let lines: string[] = [
    "# ==================================================================",
    "# OAKSphere Connect - Search & AI Crawler Visibility Rules",
    `# Generated dynamically by OAKSphere Website Control Center (${new Date().toISOString().split("T")[0]})`,
    "# ==================================================================",
    "",
  ];

  // Specific crawler blocks
  cmsStore.crawlers.forEach((c) => {
    lines.push(`User-agent: ${c.user_agent}`);
    if (c.allow) {
      lines.push("Allow: /");
      cmsStore.rules_engine.custom_robots_directives.forEach((d) => {
        lines.push(d);
      });
    } else {
      lines.push("Disallow: /");
    }
    lines.push("");
  });

  // Catch-all block
  lines.push("User-agent: *");
  lines.push("Allow: /");
  cmsStore.rules_engine.custom_robots_directives.forEach((d) => {
    lines.push(d);
  });
  lines.push("");
  lines.push(`Sitemap: ${baseUrl}/sitemap.xml`);
  lines.push("");

  return lines.join("\n");
}

// ---------------- REAL DYNAMIC SITEMAP.XML GENERATOR ----------------
export function generateSitemapXmlContent(jobs: Job[], blogs: any[]): string {
  const baseUrl = cmsStore.settings.site_url || "https://oaksphereconnect.com";
  const today = new Date().toISOString().split("T")[0];

  const urls: { loc: string; lastmod: string; changefreq: string; priority: string }[] = [];

  // 1. Pages
  cmsStore.pages.forEach((p) => {
    if (p.robots_index && p.status === "published") {
      urls.push({
        loc: `${baseUrl}${p.slug === "/" ? "" : p.slug}`,
        lastmod: p.last_reviewed || today,
        changefreq: p.slug === "/" ? "daily" : "weekly",
        priority: p.slug === "/" ? "1.0" : p.category === "landing" ? "0.9" : "0.8",
      });
    }
  });

  // 2. Locations
  cmsStore.locations.forEach((l) => {
    urls.push({
      loc: `${baseUrl}/location/${l.slug}`,
      lastmod: today,
      changefreq: "weekly",
      priority: "0.85",
    });
  });

  // 3. Active Jobs (exclude closed/expired if auto-closed)
  jobs.forEach((j) => {
    if (j.status === "Active") {
      urls.push({
        loc: `${baseUrl}/jobs/${j.slug}`,
        lastmod: j.created_at ? j.created_at.split("T")[0] : today,
        changefreq: "daily",
        priority: "0.8",
      });
    }
  });

  // 4. Blogs
  blogs.forEach((b) => {
    urls.push({
      loc: `${baseUrl}/blog/${b.slug}`,
      lastmod: b.date || today,
      changefreq: "monthly",
      priority: "0.7",
    });
  });

  return `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
        xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9
        http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">
${urls
  .map(
    (u) => `  <url>
    <loc>${u.loc}</loc>
    <lastmod>${u.lastmod}</lastmod>
    <changefreq>${u.changefreq}</changefreq>
    <priority>${u.priority}</priority>
  </url>`
  )
  .join("\n")}
</urlset>`;
}
