import React from "react";
import { useNavigate } from "react-router-dom";
import api from "@/lib/api";
import { StatusBadge } from "@/lib/ui";
import { Inbox, Search, Loader2, RefreshCw } from "lucide-react";

const SOURCE_COLORS = {
  Website: "bg-cyan-100 text-cyan-700", WhatsApp: "bg-green-100 text-green-700",
  Instagram: "bg-pink-100 text-pink-700", Facebook: "bg-blue-100 text-blue-700",
  "Meta Lead Ad": "bg-indigo-100 text-indigo-700", "Google Form": "bg-amber-100 text-amber-700",
  Referral: "bg-purple-100 text-purple-700", Manual: "bg-slate-100 text-slate-600",
};
function srcColor(s = "") {
  const key = Object.keys(SOURCE_COLORS).find((k) => s.toLowerCase().includes(k.toLowerCase()));
  return SOURCE_COLORS[key] || "bg-slate-100 text-slate-600";
}

export default function LeadInbox() {
  const nav = useNavigate();
  const [report, setReport] = React.useState({ sources: [], total_leads: 0 });
  const [leads, setLeads] = React.useState([]);
  const [loading, setLoading] = React.useState(true);
  const [source, setSource] = React.useState("");
  const [q, setQ] = React.useState("");

  const load = React.useCallback(() => {
    setLoading(true);
    const qs = new URLSearchParams();
    if (source) qs.set("source", source);
    if (q) qs.set("q", q);
    Promise.all([
      api.get("/reports/leads-by-source"),
      api.get(`/inbox/leads?${qs.toString()}`),
    ]).then(([r1, r2]) => {
      setReport(r1.data && Array.isArray(r1.data.sources) ? r1.data : { sources: [], total_leads: 0 });
      const rawLeads = Array.isArray(r2.data) ? r2.data : (r2.data?.leads || []);
      setLeads(rawLeads);
    }).catch(() => {
      setReport({ sources: [], total_leads: 0 });
      setLeads([]);
    }).finally(() => setLoading(false));
  }, [source, q]);

  React.useEffect(() => { load(); }, [source]);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2"><Inbox className="w-6 h-6 text-cyan-600" /> Unified Lead Inbox</h1>
          <p className="text-slate-500 text-sm mt-1">Every lead from Website, WhatsApp, Instagram, Facebook, Google Forms & Meta — in one place.</p>
        </div>
        <button onClick={load} className="flex items-center gap-2 text-sm font-medium text-slate-600 hover:text-cyan-700"><RefreshCw className="w-4 h-4" /> Refresh</button>
      </div>

      {/* Source funnel report */}
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-4">
        <p className="text-sm font-semibold text-slate-700 dark:text-slate-200 mb-3">Leads by source · {report.total_leads} total</p>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead><tr className="text-left text-xs uppercase text-slate-400">
              <th className="py-2 pr-4">Source</th><th className="px-3">Total</th><th className="px-3">Connected</th><th className="px-3">Interview</th><th className="px-3">Selected</th><th className="px-3">Joined</th>
            </tr></thead>
            <tbody>
              {report.sources.map((s) => (
                <tr key={s.source} className="border-t border-slate-100 dark:border-slate-800">
                  <td className="py-2 pr-4"><span className={`px-2 py-0.5 rounded-full text-xs font-medium ${srcColor(s.source)}`}>{s.source}</span></td>
                  <td className="px-3 font-semibold">{s.total}</td><td className="px-3">{s.connected}</td><td className="px-3">{s.interview}</td><td className="px-3">{s.selected}</td><td className="px-3">{s.joined}</td>
                </tr>
              ))}
              {report.sources.length === 0 && <tr><td colSpan={6} className="py-4 text-slate-400">No leads yet.</td></tr>}
            </tbody>
          </table>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-2">
        <button onClick={() => setSource("")} className={`px-3 py-1.5 rounded-full text-sm font-medium ${!source ? "bg-cyan-600 text-white" : "bg-white border border-slate-200 text-slate-600"}`}>All</button>
        {report.sources.map((s) => (
          <button key={s.source} onClick={() => setSource(s.source)} className={`px-3 py-1.5 rounded-full text-sm font-medium ${source === s.source ? "bg-cyan-600 text-white" : "bg-white border border-slate-200 text-slate-600"}`}>{s.source} ({s.total})</button>
        ))}
        <form onSubmit={(e) => { e.preventDefault(); load(); }} className="ml-auto flex items-center gap-2 px-3 border border-slate-200 rounded-lg bg-white">
          <Search className="w-4 h-4 text-slate-400" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search name / phone / email" className="h-9 outline-none text-sm w-56" />
        </form>
      </div>

      {/* Leads table */}
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 overflow-hidden">
        {loading ? (
          <div className="py-16 flex justify-center"><Loader2 className="w-6 h-6 animate-spin text-cyan-600" /></div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 dark:bg-slate-800/50 text-xs uppercase text-slate-400">
                <tr className="text-left"><th className="px-4 py-3">Name</th><th className="px-4">Phone</th><th className="px-4">Source</th><th className="px-4">Interested in</th><th className="px-4">Status</th><th className="px-4">Recruiter</th><th className="px-4">Added</th></tr>
              </thead>
              <tbody>
                {leads.map((l) => (
                  <tr key={l.id} onClick={() => nav(`/leads?focus=${l.id}`)} className="border-t border-slate-100 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/40 cursor-pointer">
                    <td className="px-4 py-3 font-medium text-slate-800 dark:text-slate-100">{l.name || "—"}{l.duplicate_flag && <span className="ml-2 text-[10px] text-rose-600 font-semibold">DUP</span>}</td>
                    <td className="px-4 font-mono text-slate-600">{l.phone}</td>
                    <td className="px-4"><span className={`px-2 py-0.5 rounded-full text-xs font-medium ${srcColor(l.source)}`}>{l.source || "Manual"}</span></td>
                    <td className="px-4 text-slate-600">{l.interested_job || "—"}</td>
                    <td className="px-4"><StatusBadge status={l.lead_status} /></td>
                    <td className="px-4 text-slate-600">{l.recruiter_name || "Unassigned"}</td>
                    <td className="px-4 text-slate-400 text-xs">{(l.created_at || "").slice(0, 10)}</td>
                  </tr>
                ))}
                {leads.length === 0 && <tr><td colSpan={7} className="py-10 text-center text-slate-400">No leads found.</td></tr>}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
