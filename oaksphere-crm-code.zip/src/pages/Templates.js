import { useState, useEffect, useCallback } from "react";
import api, { formatError } from "@/lib/api";
import { toast } from "sonner";
import { useAuth } from "@/context/AuthContext";
import { PageHeader, Loading, EmptyState } from "@/components/common";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  MessageSquare,
  Mail,
  Copy,
  Plus,
  Check,
  Search,
  Sparkles,
  Trash2,
  Edit2,
  Code,
} from "lucide-react";

const SAMPLE_VARS = {
  candidate_name: "Rahul Verma",
  job_title: "Relationship Manager — Banking",
  company: "HDFC Life",
  location: "Pune (Shivajinagar)",
  salary: "₹4,50,000 - ₹5,50,000 PA",
  interview_date: "Tomorrow at 3:00 PM",
  recruiter_name: "Harshika Sharma",
  contact_person: "Pooja Deshmukh",
};

export default function Templates() {
  const { user } = useAuth();
  const [templates, setTemplates] = useState(null);
  const [activeTab, setActiveTab] = useState("whatsapp"); // whatsapp | email
  const [search, setSearch] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [copiedId, setCopiedId] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  // Form state
  const [name, setName] = useState("");
  const [category, setCategory] = useState("Interview");
  const [type, setType] = useState("whatsapp");
  const [subject, setSubject] = useState("");
  const [body, setBody] = useState("");

  const loadTemplates = useCallback(() => {
    setTemplates(null);
    api
      .get("/templates")
      .then((r) => setTemplates(r.data))
      .catch(() => {
        toast.error("Failed to load templates");
        setTemplates([]);
      });
  }, []);

  useEffect(() => {
    loadTemplates();
  }, [loadTemplates]);

  const handleCreate = async (e) => {
    e.preventDefault();
    if (!name.trim() || !body.trim()) {
      toast.error("Template name and body are required");
      return;
    }
    setSubmitting(true);
    try {
      await api.post("/templates", {
        name,
        category,
        type,
        subject,
        body,
      });
      toast.success("Template saved successfully");
      setDialogOpen(false);
      setName("");
      setSubject("");
      setBody("");
      loadTemplates();
    } catch (err) {
      toast.error(formatError(err.response?.data?.detail));
    } finally {
      setSubmitting(false);
    }
  };

  const copyTemplate = (tpl) => {
    let text = tpl.body;
    Object.entries(SAMPLE_VARS).forEach(([k, v]) => {
      text = text.replaceAll(`{{${k}}}`, v);
    });
    navigator.clipboard.writeText(text);
    setCopiedId(tpl.id);
    toast.success("Template text copied to clipboard!");
    setTimeout(() => setCopiedId(null), 2500);
  };

  const deleteTemplate = async (id) => {
    try {
      await api.delete(`/templates/${id}`);
      toast.success("Template deleted");
      loadTemplates();
    } catch (err) {
      toast.error("Could not delete template");
    }
  };

  const filtered = (templates || []).filter((t) => {
    if (t.type !== activeTab) return false;
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return t.name.toLowerCase().includes(q) || t.body.toLowerCase().includes(q) || t.category?.toLowerCase().includes(q);
  });

  return (
    <div className="space-y-6" id="templates-module-page">
      <PageHeader
        title="Message Templates"
        description="Standardized WhatsApp pitches, interview calls, lineup reminders, and email correspondence with automated personalization variables."
        action={
          <Button
            onClick={() => {
              setType(activeTab);
              setDialogOpen(true);
            }}
            className="bg-[#2B1055] hover:bg-[#3d1878] text-white shadow-sm flex items-center gap-2"
            id="btn-new-template"
          >
            <Plus className="w-4 h-4" /> New Template
          </Button>
        }
      />

      {/* Tabs */}
      <div className="flex border-b border-slate-200 dark:border-slate-800">
        <button
          onClick={() => setActiveTab("whatsapp")}
          className={`px-5 py-2.5 text-sm font-semibold flex items-center gap-2 border-b-2 transition-colors ${
            activeTab === "whatsapp"
              ? "border-emerald-600 text-emerald-600 dark:text-emerald-400"
              : "border-transparent text-slate-500 hover:text-slate-800"
          }`}
        >
          <MessageSquare className="w-4 h-4" /> WhatsApp Templates
        </button>
        <button
          onClick={() => setActiveTab("email")}
          className={`px-5 py-2.5 text-sm font-semibold flex items-center gap-2 border-b-2 transition-colors ${
            activeTab === "email"
              ? "border-blue-600 text-blue-600 dark:text-blue-400"
              : "border-transparent text-slate-500 hover:text-slate-800"
          }`}
        >
          <Mail className="w-4 h-4" /> Email Templates
        </button>
      </div>

      {/* Variables Cheat Sheet */}
      <div className="bg-purple-50/70 dark:bg-purple-950/20 p-3.5 rounded-lg border border-purple-200/60 dark:border-purple-900/40 text-xs">
        <p className="font-bold text-[#2B1055] dark:text-purple-300 flex items-center gap-1.5 mb-1.5">
          <Code className="w-4 h-4" /> Dynamic Variables Available:
        </p>
        <div className="flex flex-wrap gap-2 text-[11px] font-mono">
          {Object.keys(SAMPLE_VARS).map((v) => (
            <span key={v} className="bg-white dark:bg-slate-900 px-2 py-0.5 rounded border border-purple-200 dark:border-purple-800 text-purple-700 dark:text-purple-300">
              {`{{${v}}}`}
            </span>
          ))}
        </div>
      </div>

      {/* Search Bar */}
      <div className="flex items-center gap-2 bg-white dark:bg-slate-900 p-3 rounded-lg border border-slate-200 dark:border-slate-800 shadow-sm max-w-md">
        <Search className="w-4 h-4 text-slate-400" />
        <Input
          placeholder="Search templates..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="h-8 text-xs border-0 focus-visible:ring-0 p-0"
        />
      </div>

      {/* Templates Grid */}
      {templates === null ? (
        <Loading />
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={activeTab === "whatsapp" ? MessageSquare : Mail}
          title={`No ${activeTab} templates found`}
          description="Create your first template to speed up candidate communication across your team."
          action={
            <Button onClick={() => setDialogOpen(true)} variant="outline" size="sm">
              <Plus className="w-4 h-4 mr-1" /> Add Template
            </Button>
          }
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filtered.map((tpl) => {
            const isCopied = copiedId === tpl.id;

            return (
              <Card
                key={tpl.id}
                id={`template-card-${tpl.id}`}
                className="p-5 flex flex-col justify-between border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm hover:border-purple-300 transition-all"
              >
                <div>
                  <div className="flex items-center justify-between gap-2">
                    <h4 className="font-bold text-sm text-slate-900 dark:text-white">{tpl.name}</h4>
                    <span className="text-[10px] font-semibold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 px-2 py-0.5 rounded">
                      {tpl.category}
                    </span>
                  </div>

                  {tpl.subject && (
                    <p className="text-xs font-semibold text-slate-700 dark:text-slate-300 mt-2 bg-slate-50 dark:bg-slate-800 p-2 rounded">
                      Subject: {tpl.subject}
                    </p>
                  )}

                  <div className="mt-3 p-3 rounded-lg bg-slate-50/80 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 text-xs text-slate-700 dark:text-slate-300 whitespace-pre-wrap font-sans leading-relaxed">
                    {tpl.body}
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                  <Button
                    size="sm"
                    onClick={() => copyTemplate(tpl)}
                    className={`h-8 text-xs font-medium flex items-center gap-1.5 ${
                      isCopied
                        ? "bg-emerald-600 text-white"
                        : "bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-200"
                    }`}
                  >
                    {isCopied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    {isCopied ? "Copied Sample" : "Copy Formatted"}
                  </Button>

                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => deleteTemplate(tpl.id)}
                    className="h-8 w-8 p-0 text-slate-400 hover:text-rose-600"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      {/* Create Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg bg-white dark:bg-slate-900">
          <DialogHeader>
            <DialogTitle>Add Message Template</DialogTitle>
            <DialogDescription className="sr-only">Add candidate communication message template</DialogDescription>
          </DialogHeader>

          <form onSubmit={handleCreate} className="space-y-3 mt-2">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Template Name *
                </label>
                <Input
                  placeholder="e.g. Lineup Confirmation"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                  className="text-xs"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Type
                </label>
                <Select value={type} onValueChange={setType}>
                  <SelectTrigger className="text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="whatsapp">WhatsApp</SelectItem>
                    <SelectItem value="email">Email</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                Category
              </label>
              <Input
                placeholder="e.g. Interview Confirmation, Job Pitch, Follow-up"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="text-xs"
              />
            </div>

            {type === "email" && (
              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Subject Line
                </label>
                <Input
                  placeholder="e.g. Interview with {{company}} for {{job_title}}"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  className="text-xs"
                />
              </div>
            )}

            <div>
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                Template Body *
              </label>
              <textarea
                placeholder="Use dynamic tags like {{candidate_name}}, {{job_title}}, {{company}}, {{interview_date}}..."
                value={body}
                onChange={(e) => setBody(e.target.value)}
                rows={6}
                required
                className="w-full text-xs p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 focus:outline-none focus:ring-1 focus:ring-purple-600 font-sans leading-relaxed"
              />
            </div>

            <DialogFooter className="pt-2">
              <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={submitting} className="bg-[#2B1055] text-white hover:bg-[#3c1775]">
                {submitting ? "Saving..." : "Save Template"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
