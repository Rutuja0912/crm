import { useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import api, { formatError } from "@/lib/api";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Loader2, ArrowLeft } from "lucide-react";

export default function ResetPassword() {
  const [params] = useSearchParams();
  const token = params.get("token") || "";
  const navigate = useNavigate();
  const [pw, setPw] = useState("");
  const [pw2, setPw2] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const submit = async (e) => {
    e?.preventDefault();
    setError("");
    if (pw.length < 12) { setError("Password must be at least 12 characters"); return; }
    if (pw !== pw2) { setError("Passwords do not match"); return; }
    setLoading(true);
    try {
      await api.post("/auth/reset-password", { token, password: pw });
      toast.success("Password updated — please sign in");
      navigate("/login");
    } catch (err) {
      setError(formatError(err.response?.data?.detail) || "Reset failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-[#F4F7FB]">
      <Card className="w-full max-w-md p-8 rounded-2xl border border-slate-200 shadow-sm">
        <h2 className="text-2xl font-bold font-display text-slate-900">Set a new password</h2>
        <p className="text-sm text-slate-500 mt-1 mb-6">Choose a strong password (min 12 characters).</p>
        {!token ? (
          <p data-testid="reset-no-token" className="text-sm text-rose-600 bg-rose-50 border border-rose-200 rounded-md px-3 py-2">This reset link is missing its token. Request a new link.</p>
        ) : (
          <form onSubmit={submit} className="space-y-4">
            <div>
              <Label htmlFor="pw">New password</Label>
              <Input data-testid="reset-password-input" id="pw" type="password" value={pw} onChange={(e) => setPw(e.target.value)} placeholder="••••••••••••" className="mt-1" required />
            </div>
            <div>
              <Label htmlFor="pw2">Confirm password</Label>
              <Input data-testid="reset-password-confirm" id="pw2" type="password" value={pw2} onChange={(e) => setPw2(e.target.value)} placeholder="••••••••••••" className="mt-1" required />
            </div>
            {error && <p data-testid="reset-error" className="text-sm text-rose-600 bg-rose-50 border border-rose-200 rounded-md px-3 py-2">{error}</p>}
            <Button data-testid="reset-submit-btn" type="submit" disabled={loading} className="w-full h-11 bg-[#0A66C2] hover:bg-[#08549e] text-white font-semibold shadow-md shadow-blue-500/20 transition-colors">
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : "Update password"}
            </Button>
          </form>
        )}
        <Link to="/login" className="inline-flex items-center gap-1 text-sm text-[#0A66C2] hover:underline mt-5"><ArrowLeft className="w-4 h-4" /> Back to sign in</Link>
      </Card>
    </div>
  );
}
