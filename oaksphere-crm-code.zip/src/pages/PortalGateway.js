import React from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import {
  LayoutDashboard,
  Globe,
  Briefcase,
  Users2,
  PhoneCall,
  CalendarClock,
  ShieldCheck,
  Building2,
  ArrowRight,
  Sparkles,
  ExternalLink,
  Layers,
  HeartPulse,
  Settings,
} from "lucide-react";
import { Button } from "@/components/ui/button";

export default function PortalGateway() {
  const { user, login } = useAuth();
  const navigate = useNavigate();

  const handleQuickLogin = async (email) => {
    try {
      await login(email, "password");
      navigate("/crm");
    } catch (err) {
      console.error(err);
      navigate("/login");
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col justify-between selection:bg-[#0A66C2] selection:text-white">
      {/* Top Header */}
      <header className="border-b border-slate-800/80 bg-slate-950/60 backdrop-blur-md px-6 py-4">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#5F259F] via-[#2164F3] to-[#0A66C2] flex items-center justify-center font-bold text-white text-lg shadow-lg">
              O
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-xl tracking-tight text-white font-display">
                  OAK<span className="text-[#0A66C2]">sphere</span>
                </span>
                <span className="text-[10px] uppercase font-bold tracking-widest px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 border border-purple-500/30">
                  Platform Hub
                </span>
              </div>
              <p className="text-xs text-slate-400">Enterprise Recruitment Ecosystem</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {user ? (
              <div className="flex items-center gap-3">
                <div className="text-right hidden sm:block">
                  <p className="text-xs font-semibold text-white">{user.name}</p>
                  <p className="text-[10px] text-slate-400 capitalize">{user.role.replace("_", " ")}</p>
                </div>
                <Link
                  to="/crm"
                  className="px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-[#5F259F] hover:bg-[#501E87] text-white transition-colors"
                >
                  Enter CRM →
                </Link>
              </div>
            ) : (
              <Link
                to="/login"
                className="px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors"
              >
                Sign In
              </Link>
            )}
          </div>
        </div>
      </header>

      {/* Main Hero & Dual App Showcase */}
      <main className="max-w-6xl mx-auto px-6 py-12 flex-1 flex flex-col justify-center">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-800/80 border border-slate-700 text-xs font-medium text-purple-300 mb-4">
            <Layers className="w-3.5 h-3.5 text-[#0A66C2]" />
            <span>Select Your Operating Workspace</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight font-display">
            Two Independent Applications, One Connected Ecosystem
          </h1>
          <p className="mt-3 text-slate-400 text-sm sm:text-base leading-relaxed">
            Choose whether to launch the individual <strong>Recruitment CRM</strong> for your daily talent pipeline and team operations, or explore the <strong>Public Website</strong> for candidate job search and client hiring.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Card 1: Individual Recruitment CRM */}
          <div className="relative group rounded-2xl bg-gradient-to-b from-slate-800/90 to-slate-850/90 border border-purple-500/30 p-8 flex flex-col justify-between shadow-2xl hover:border-purple-500/60 transition-all duration-300 hover:shadow-purple-950/30">
            <div className="absolute top-0 right-0 transform translate-x-2 -translate-y-2">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#5F259F] text-white text-[11px] font-bold shadow-md">
                <Sparkles className="w-3 h-3" /> Individual CRM
              </span>
            </div>

            <div>
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#5F259F] to-[#0A66C2] flex items-center justify-center text-white mb-6 shadow-md shadow-purple-900/40">
                <LayoutDashboard className="w-6 h-6" />
              </div>

              <h2 className="text-2xl font-bold text-white font-display">
                OAKSphere Recruitment CRM
              </h2>
              <p className="text-xs text-purple-300 font-medium mt-0.5 mb-4">
                Internal Recruiter Operating System
              </p>
              <p className="text-sm text-slate-300 leading-relaxed mb-6">
                A dedicated, standalone CRM workspace designed for recruiters, team leads, and agency owners. Manage end-to-end candidate funnels, live calling queues, and client mandates without clutter.
              </p>

              <div className="space-y-2.5 mb-8 text-xs text-slate-300">
                <div className="flex items-center gap-2.5">
                  <div className="w-5 h-5 rounded-full bg-purple-500/20 flex items-center justify-center text-purple-300">
                    <PhoneCall className="w-3 h-3" />
                  </div>
                  <span>High-velocity calling lists, follow-ups & disposition logs</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <div className="w-5 h-5 rounded-full bg-blue-500/20 flex items-center justify-center text-blue-300">
                    <Users2 className="w-3 h-3" />
                  </div>
                  <span>Full-cycle candidate pipeline (Lead → Interview → Joining)</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <div className="w-5 h-5 rounded-full bg-emerald-500/20 flex items-center justify-center text-emerald-300">
                    <Building2 className="w-3 h-3" />
                  </div>
                  <span>Corporate client accounts, vendor empanelment & jobs</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <div className="w-5 h-5 rounded-full bg-rose-500/20 flex items-center justify-center text-rose-300">
                    <HeartPulse className="w-3 h-3" />
                  </div>
                  <span>Built-in HRMS, employee directory, attendance & payroll</span>
                </div>
              </div>
            </div>

            <div>
              <div className="pt-4 border-t border-slate-700/60 mb-6">
                <p className="text-[11px] uppercase tracking-wider text-slate-400 font-semibold mb-2">
                  Fast Demo Role Access:
                </p>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <button
                    type="button"
                    onClick={() => handleQuickLogin("admin@oaksphere.com")}
                    className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-left border border-slate-700 hover:border-purple-400 transition-colors"
                  >
                    <span className="font-semibold text-white block">Admin / Owner</span>
                    <span className="text-[10px] text-slate-400">Full control & HRMS</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleQuickLogin("harshika@oaksphere.com")}
                    className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-left border border-slate-700 hover:border-purple-400 transition-colors"
                  >
                    <span className="font-semibold text-white block">Recruiter Harshika</span>
                    <span className="text-[10px] text-slate-400">Calling & candidates</span>
                  </button>
                </div>
              </div>

              <Link
                to="/crm"
                id="launch-crm-gateway-btn"
                className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-[#5F259F] via-[#2164F3] to-[#0A66C2] hover:opacity-95 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-purple-900/30 transition-all group-hover:shadow-purple-700/50"
              >
                <span>Launch Individual CRM Workspace</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>

          {/* Card 2: Public Career Website */}
          <div className="relative group rounded-2xl bg-gradient-to-b from-slate-800/90 to-slate-850/90 border border-slate-700 p-8 flex flex-col justify-between shadow-2xl hover:border-blue-500/50 transition-all duration-300 hover:shadow-blue-950/30">
            <div className="absolute top-0 right-0 transform translate-x-2 -translate-y-2">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-800 border border-slate-600 text-slate-300 text-[11px] font-bold">
                <Globe className="w-3 h-3 text-[#0A66C2]" /> Public Portal
              </span>
            </div>

            <div>
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#0A66C2] to-cyan-600 flex items-center justify-center text-white mb-6 shadow-md shadow-blue-900/40">
                <Globe className="w-6 h-6" />
              </div>

              <h2 className="text-2xl font-bold text-white font-display">
                OAKSphere Public Website
              </h2>
              <p className="text-xs text-blue-300 font-medium mt-0.5 mb-4">
                Candidate & Employer External Portal
              </p>
              <p className="text-sm text-slate-300 leading-relaxed mb-6">
                The public-facing agency presence where candidates search job openings, apply online, and corporate employers submit staffing inquiries across India.
              </p>

              <div className="space-y-2.5 mb-8 text-xs text-slate-300">
                <div className="flex items-center gap-2.5">
                  <div className="w-5 h-5 rounded-full bg-blue-500/20 flex items-center justify-center text-blue-300">
                    <Briefcase className="w-3 h-3" />
                  </div>
                  <span>Searchable live job board with Schema.org JobPosting indexing</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <div className="w-5 h-5 rounded-full bg-cyan-500/20 flex items-center justify-center text-cyan-300">
                    <Building2 className="w-3 h-3" />
                  </div>
                  <span>Dedicated employer hiring mandates & staffing inquiry forms</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <div className="w-5 h-5 rounded-full bg-indigo-500/20 flex items-center justify-center text-indigo-300">
                    <ShieldCheck className="w-3 h-3" />
                  </div>
                  <span>City hubs for Pune, Mumbai, Navi Mumbai, Nagpur & Bangalore</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <div className="w-5 h-5 rounded-full bg-purple-500/20 flex items-center justify-center text-purple-300">
                    <Settings className="w-3 h-3" />
                  </div>
                  <span>SEO landing pages, knowledge base, FAQs & industry insights</span>
                </div>
              </div>
            </div>

            <div>
              <div className="pt-4 border-t border-slate-700/60 mb-6">
                <p className="text-[11px] uppercase tracking-wider text-slate-400 font-semibold mb-2">
                  Key Public Portals:
                </p>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <Link
                    to="/jobs"
                    className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-left border border-slate-700 hover:border-blue-400 transition-colors block"
                  >
                    <span className="font-semibold text-white block">Job Board</span>
                    <span className="text-[10px] text-slate-400">View active openings</span>
                  </Link>
                  <Link
                    to="/employers"
                    className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-left border border-slate-700 hover:border-blue-400 transition-colors block"
                  >
                    <span className="font-semibold text-white block">For Employers</span>
                    <span className="text-[10px] text-slate-400">Hire top talent</span>
                  </Link>
                </div>
              </div>

              <Link
                to="/"
                id="visit-website-gateway-btn"
                className="w-full py-3.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-600 hover:border-slate-500 text-white font-bold text-sm flex items-center justify-center gap-2 transition-all group-hover:bg-slate-750"
              >
                <span>Visit Public Website</span>
                <ExternalLink className="w-4 h-4 text-slate-400" />
              </Link>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800 py-4 px-6 text-center text-xs text-slate-500">
        <p>© 2026 OAKSphere Connect. Standalone Recruitment CRM & Public Career Platform.</p>
      </footer>
    </div>
  );
}
