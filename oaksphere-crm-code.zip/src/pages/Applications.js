import { useState, useEffect, useCallback } from "react";
import api, { formatError } from "@/lib/api";
import { toast } from "sonner";
import { useAuth } from "@/context/AuthContext";
import { PageHeader, Loading, EmptyState } from "@/components/common";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  FileText,
  UserCheck,
  Search,
  ExternalLink,
  Phone,
  Mail,
  Briefcase,
  MapPin,
  Calendar,
  Sparkles,
  Trash2,
} from "lucide-react";

export default function Applications() {
  const { user } = useAuth();
  const [applications, setApplications] = useState(null);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [convertingId, setConvertingId] = useState(null);

  const loadApplications = useCallback(() => {
    setApplications(null);
    const params = new URLSearchParams();
    if (statusFilter !== "all") params.set("status", statusFilter);
    if (search) params.set("search", search);
    api
      .get(`/applications?${params.toString()}`)
      .then((r) => setApplications(r.data))
      .catch(() => {
        toast.error("Failed to load applications");
        setApplications([]);
      });
  }, [statusFilter, search]);

  useEffect(() => {
    loadApplications();
  }, [loadApplications]);

  const convertToLead = async (appItem) => {
    setConvertingId(appItem.id);
    try {
      const res = await api.post(`/applications/${appItem.id}/convert-lead`);
      if (res.data?.message === "Lead already exists") {
        toast.info("Candidate already exists in CRM lead database.");
      } else {
        toast.success(`Converted ${appItem.candidate_name} to active CRM lead!`);
      }
      loadApplications();
    } catch (err) {
      toast.error(formatError(err.response?.data?.detail));
    } finally {
      setConvertingId(null);
    }
  };

  const deleteApp = async (id) => {
    try {
      await api.delete(`/applications/${id}`);
      toast.success("Application removed");
      loadApplications();
    } catch (err) {
      toast.error("Could not delete application");
    }
  };

  return (
    <div className="space-y-6" id="applications-module-page">
      <PageHeader
        title="Job Applications & Portal Submissions"
        description="Review inbound candidate resumes from the website careers portal, Google Forms, and social recruiting campaigns."
      />

      {/* Filters and Search */}
      <div className="flex flex-col sm:flex-row gap-3 items-center justify-between bg-white dark:bg-slate-900 p-3.5 rounded-lg border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex items-center gap-2 w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400" />
          <Input
            placeholder="Search candidate name, phone, role..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="h-9 text-sm"
          />
        </div>

        <div className="flex items-center gap-3 w-full sm:w-auto">
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-40 h-9 text-xs">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Applications</SelectItem>
              <SelectItem value="new">New</SelectItem>
              <SelectItem value="shortlisted">Shortlisted</SelectItem>
              <SelectItem value="converted">Converted to Lead</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Applications Table */}
      {applications === null ? (
        <Loading />
      ) : applications.length === 0 ? (
        <EmptyState
          icon={FileText}
          title="No applications found"
          description="Inbound candidate submissions from your public website jobs will appear here automatically."
        />
      ) : (
        <div className="border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden bg-white dark:bg-slate-900 shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 uppercase tracking-wider text-slate-500 font-semibold">
                <tr>
                  <th className="py-3 px-4">Candidate</th>
                  <th className="py-3 px-4">Role Applied For</th>
                  <th className="py-3 px-4">Location & Exp</th>
                  <th className="py-3 px-4">Source & Campaign</th>
                  <th className="py-3 px-4">Applied Date</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {applications.map((app) => {
                  const isConverted = app.status === "Converted";

                  return (
                    <tr key={app.id} id={`app-row-${app.id}`} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30">
                      <td className="py-3.5 px-4">
                        <p className="font-bold text-slate-900 dark:text-white text-sm">{app.candidate_name}</p>
                        <div className="flex items-center gap-3 mt-1 text-[11px] text-slate-500">
                          <span className="flex items-center gap-1 font-mono">
                            <Phone className="w-3 h-3 text-slate-400" /> {app.phone}
                          </span>
                          {app.email && (
                            <span className="flex items-center gap-1">
                              <Mail className="w-3 h-3 text-slate-400" /> {app.email}
                            </span>
                          )}
                        </div>
                      </td>

                      <td className="py-3.5 px-4 font-medium text-slate-800 dark:text-slate-200">
                        {app.job_title}
                        {app.resume_url && (
                          <a
                            href={app.resume_url}
                            target="_blank"
                            rel="noreferrer"
                            className="text-xs text-purple-700 dark:text-purple-400 hover:underline flex items-center gap-1 mt-1 font-semibold"
                          >
                            <ExternalLink className="w-3 h-3" /> View Resume PDF
                          </a>
                        )}
                      </td>

                      <td className="py-3.5 px-4 text-slate-600 dark:text-slate-400">
                        <p className="flex items-center gap-1">
                          <MapPin className="w-3 h-3 text-slate-400" /> {app.city}
                        </p>
                        <p className="text-[11px] text-slate-400 mt-0.5">{app.experience}</p>
                      </td>

                      <td className="py-3.5 px-4">
                        <span className="inline-block px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-semibold text-[10px]">
                          {app.source}
                        </span>
                        {app.utm_campaign && (
                          <p className="text-[10px] text-slate-400 font-mono mt-0.5">
                            {app.utm_source} / {app.utm_campaign}
                          </p>
                        )}
                      </td>

                      <td className="py-3.5 px-4 text-slate-500 text-[11px]">
                        {app.applied_at
                          ? new Date(app.applied_at).toLocaleDateString("en-IN", {
                              month: "short",
                              day: "numeric",
                              hour: "2-digit",
                              minute: "2-digit",
                            })
                          : "—"}
                      </td>

                      <td className="py-3.5 px-4">
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase ${
                            isConverted
                              ? "bg-emerald-100 text-emerald-800"
                              : app.status === "Shortlisted"
                              ? "bg-purple-100 text-purple-800"
                              : "bg-blue-100 text-blue-800"
                          }`}
                        >
                          {app.status}
                        </span>
                      </td>

                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          {!isConverted ? (
                            <Button
                              size="sm"
                              onClick={() => convertToLead(app)}
                              disabled={convertingId === app.id}
                              className="h-7 text-xs bg-emerald-600 hover:bg-emerald-700 text-white font-medium flex items-center gap-1"
                              id={`btn-convert-${app.id}`}
                            >
                              <Sparkles className="w-3 h-3" />
                              {convertingId === app.id ? "Converting..." : "Convert to Lead"}
                            </Button>
                          ) : (
                            <span className="text-[11px] text-emerald-600 font-semibold flex items-center gap-1">
                              <UserCheck className="w-3.5 h-3.5" /> In Lead CRM
                            </span>
                          )}

                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => deleteApp(app.id)}
                            className="h-7 w-7 p-0 text-slate-400 hover:text-rose-600"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
