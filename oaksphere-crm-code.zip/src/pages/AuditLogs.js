import { useState, useEffect, useCallback } from "react";
import api from "@/lib/api";
import { toast } from "sonner";
import { PageHeader, Loading, EmptyState } from "@/components/common";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { ShieldCheck, Search, Filter, Clock, User, Activity } from "lucide-react";

export default function AuditLogs() {
  const [logs, setLogs] = useState(null);
  const [search, setSearch] = useState("");

  const loadLogs = useCallback(() => {
    api
      .get("/audit-logs")
      .then((r) => setLogs(r.data))
      .catch(() => {
        toast.error("Failed to load audit logs");
        setLogs([]);
      });
  }, []);

  useEffect(() => {
    loadLogs();
  }, [loadLogs]);

  const filtered = (logs || []).filter((l) => {
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return (
      l.action?.toLowerCase().includes(q) ||
      l.user?.toLowerCase().includes(q) ||
      l.details?.toLowerCase().includes(q)
    );
  });

  return (
    <div className="space-y-6" id="audit-logs-page">
      <PageHeader
        title="Audit & Compliance Logs"
        description="Immutable system-wide ledger tracking lead updates, assignments, status changes, and administrator operations."
      />

      {/* Search Bar */}
      <div className="flex items-center gap-2 bg-white dark:bg-slate-900 p-3 rounded-lg border border-slate-200 dark:border-slate-800 shadow-sm max-w-md">
        <Search className="w-4 h-4 text-slate-400" />
        <Input
          placeholder="Filter by action, user, or details..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="h-8 text-xs border-0 focus-visible:ring-0 p-0"
        />
      </div>

      {logs === null ? (
        <Loading />
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={ShieldCheck}
          title="No audit logs matching search"
          description="System events and compliance logs will be recorded as actions occur."
        />
      ) : (
        <div className="border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden bg-white dark:bg-slate-900 shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 uppercase tracking-wider text-slate-500 font-semibold">
                <tr>
                  <th className="py-3 px-4">Timestamp</th>
                  <th className="py-3 px-4">User</th>
                  <th className="py-3 px-4">Action Event</th>
                  <th className="py-3 px-4">Details</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filtered.map((log) => (
                  <tr key={log.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30">
                    <td className="py-3 px-4 text-slate-500 text-[11px] font-mono whitespace-nowrap">
                      {new Date(log.timestamp).toLocaleString("en-IN", {
                        month: "short",
                        day: "numeric",
                        hour: "2-digit",
                        minute: "2-digit",
                        second: "2-digit",
                      })}
                    </td>

                    <td className="py-3 px-4 font-semibold text-slate-900 dark:text-white flex items-center gap-1.5 whitespace-nowrap">
                      <User className="w-3.5 h-3.5 text-slate-400" /> {log.user}
                    </td>

                    <td className="py-3 px-4">
                      <span className="font-mono text-[10px] font-bold px-2 py-0.5 rounded bg-purple-100 dark:bg-purple-900/50 text-[#5F259F] dark:text-purple-300">
                        {log.action}
                      </span>
                    </td>

                    <td className="py-3 px-4 text-slate-700 dark:text-slate-300 max-w-xl break-words">
                      {log.details}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
