import { useState, useEffect, useCallback } from "react";
import api, { formatError } from "@/lib/api";
import { toast } from "sonner";
import { useAuth } from "@/context/AuthContext";
import { PageHeader, Loading } from "@/components/common";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import {
  Megaphone,
  Share2,
  TrendingUp,
  Link2,
  Send,
  Sparkles,
  CheckCircle2,
  Layers,
  BarChart3,
  Flame,
  Globe,
} from "lucide-react";

export default function MarketingDashboard() {
  const { user } = useAuth();
  const [stats, setStats] = useState(null);
  const [simulatingMeta, setSimulatingMeta] = useState(false);
  const [simulatingGForm, setSimulatingGForm] = useState(false);

  // Simulation form inputs
  const [testName, setTestName] = useState("Vikas Kulkarni");
  const [testPhone, setTestPhone] = useState("+91 98223 99881");
  const [testRole, setTestRole] = useState("Senior Full Stack Developer");

  const loadStats = useCallback(() => {
    api
      .get("/marketing/stats")
      .then((r) => setStats(r.data))
      .catch(() => {
        toast.error("Failed to load marketing statistics");
      });
  }, []);

  useEffect(() => {
    loadStats();
  }, [loadStats]);

  const testMetaWebhook = async () => {
    setSimulatingMeta(true);
    try {
      const res = await api.post("/webhooks/meta-leads", {
        name: testName,
        phone: testPhone,
        job_title: testRole,
        campaign: "Meta Ads (Instagram / FB)",
        city: "Pune",
      });
      if (res.data?.status === "duplicate_skipped") {
        toast.info("Webhook acknowledged: Duplicate candidate phone detected and skipped.");
      } else {
        toast.success(`Meta Lead captured! Auto-assigned to: ${res.data?.lead?.assigned_recruiter_name}`);
      }
      loadStats();
    } catch (err) {
      toast.error("Meta Webhook test failed");
    } finally {
      setSimulatingMeta(false);
    }
  };

  const testGoogleFormWebhook = async () => {
    setSimulatingGForm(true);
    try {
      const res = await api.post("/webhooks/google-forms", {
        name: testName,
        phone: testPhone,
        job_title: testRole,
        city: "Mumbai",
      });
      if (res.data?.status === "duplicate_skipped") {
        toast.info("Google Form lead already exists in CRM.");
      } else {
        toast.success(`Google Form lead ingested! Auto-assigned to: ${res.data?.lead?.assigned_recruiter_name}`);
      }
      loadStats();
    } catch (err) {
      toast.error("Google Forms Webhook test failed");
    } finally {
      setSimulatingGForm(false);
    }
  };

  if (!stats) return <Loading />;

  return (
    <div className="space-y-6" id="marketing-dashboard-page">
      <PageHeader
        title="Lead Sources & Inbound Marketing"
        description="Monitor lead generation channels, Meta Ads performance, Google Sheets/Forms ingestion, and automated webhook capture."
      />

      {/* Summary KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <Card className="p-4 border-l-4 border-l-purple-600 bg-white dark:bg-slate-900 shadow-sm">
          <p className="text-xs font-semibold text-slate-500 uppercase">Total Leads Ingested</p>
          <p className="text-2xl font-bold text-slate-900 dark:text-white mt-1">{stats.totals.total_leads}</p>
        </Card>

        <Card className="p-4 border-l-4 border-l-blue-600 bg-white dark:bg-slate-900 shadow-sm">
          <p className="text-xs font-semibold text-slate-500 uppercase">Meta / Instagram Leads</p>
          <p className="text-2xl font-bold text-blue-600 mt-1">{stats.totals.meta_leads}</p>
        </Card>

        <Card className="p-4 border-l-4 border-l-emerald-600 bg-white dark:bg-slate-900 shadow-sm">
          <p className="text-xs font-semibold text-slate-500 uppercase">Google Form Submissions</p>
          <p className="text-2xl font-bold text-emerald-600 mt-1">{stats.totals.google_form_leads}</p>
        </Card>

        <Card className="p-4 border-l-4 border-l-amber-600 bg-white dark:bg-slate-900 shadow-sm">
          <p className="text-xs font-semibold text-slate-500 uppercase">Website Applicants</p>
          <p className="text-2xl font-bold text-amber-600 mt-1">{stats.totals.website_leads}</p>
        </Card>
      </div>

      {/* Two column: Source Share & Campaign Performance */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Source Breakdown */}
        <Card className="p-5 bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 shadow-sm">
          <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2 mb-4">
            <Layers className="w-4 h-4 text-[#2B1055] dark:text-purple-400" /> Channel Distribution
          </h3>
          <div className="space-y-3">
            {stats.sources.map((src) => (
              <div key={src.name} className="space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-medium text-slate-700 dark:text-slate-300">{src.name}</span>
                  <span className="font-bold text-slate-900 dark:text-white">
                    {src.count} leads ({src.share})
                  </span>
                </div>
                <div className="w-full h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-[#2B1055] dark:bg-purple-500 rounded-full transition-all"
                    style={{ width: src.share }}
                  />
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* Live Webhook Capture Console */}
        <Card className="p-5 bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 shadow-sm">
          <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2 mb-2">
            <Sparkles className="w-4 h-4 text-emerald-600" /> Webhook Testing & Simulation
          </h3>
          <p className="text-xs text-slate-500 mb-4">
            Verify round-robin assignment, duplicate suppression, and immediate recruiter SLA follow-up triggers.
          </p>

          <div className="space-y-3 bg-slate-50 dark:bg-slate-800/40 p-3 rounded-lg border border-slate-200 dark:border-slate-800">
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[11px] font-semibold text-slate-600 dark:text-slate-300 block mb-1">
                  Candidate Name
                </label>
                <Input
                  value={testName}
                  onChange={(e) => setTestName(e.target.value)}
                  className="h-8 text-xs bg-white dark:bg-slate-900"
                />
              </div>
              <div>
                <label className="text-[11px] font-semibold text-slate-600 dark:text-slate-300 block mb-1">
                  Phone (Must not mutate)
                </label>
                <Input
                  value={testPhone}
                  onChange={(e) => setTestPhone(e.target.value)}
                  className="h-8 text-xs bg-white dark:bg-slate-900 font-mono"
                />
              </div>
            </div>

            <div>
              <label className="text-[11px] font-semibold text-slate-600 dark:text-slate-300 block mb-1">
                Target Role
              </label>
              <Input
                value={testRole}
                onChange={(e) => setTestRole(e.target.value)}
                className="h-8 text-xs bg-white dark:bg-slate-900"
              />
            </div>

            <div className="flex gap-2 pt-2">
              <Button
                size="sm"
                onClick={testMetaWebhook}
                disabled={simulatingMeta}
                className="bg-blue-600 hover:bg-blue-700 text-white text-xs h-8 flex-1"
                id="btn-simulate-meta"
              >
                <Send className="w-3.5 h-3.5 mr-1" />
                {simulatingMeta ? "Simulating..." : "Simulate Meta Lead"}
              </Button>

              <Button
                size="sm"
                onClick={testGoogleFormWebhook}
                disabled={simulatingGForm}
                className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs h-8 flex-1"
                id="btn-simulate-gform"
              >
                <Send className="w-3.5 h-3.5 mr-1" />
                {simulatingGForm ? "Simulating..." : "Simulate Google Form"}
              </Button>
            </div>
          </div>
        </Card>
      </div>

      {/* Active Ad Campaigns Table */}
      <Card className="p-5 bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 shadow-sm">
        <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2 mb-3">
          <TrendingUp className="w-4 h-4 text-purple-600" /> Active Recruitment Campaigns
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 uppercase tracking-wider text-slate-500 font-semibold">
              <tr>
                <th className="py-2.5 px-3">Campaign Name</th>
                <th className="py-2.5 px-3">Platform</th>
                <th className="py-2.5 px-3">Leads Captured</th>
                <th className="py-2.5 px-3">CPL (Estimated)</th>
                <th className="py-2.5 px-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {stats.campaigns.map((c) => (
                <tr key={c.name} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30">
                  <td className="py-3 px-3 font-semibold text-slate-900 dark:text-white">{c.name}</td>
                  <td className="py-3 px-3 text-slate-600 dark:text-slate-300">{c.platform}</td>
                  <td className="py-3 px-3 font-bold text-slate-800 dark:text-slate-200">{c.leads}</td>
                  <td className="py-3 px-3 font-mono text-emerald-600">{c.cost_per_lead}</td>
                  <td className="py-3 px-3">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 uppercase">
                      {c.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
