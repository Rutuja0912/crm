import { useState } from "react";
import { Link } from "react-router-dom";
import api, { formatError } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Loader2, MailCheck, ArrowLeft } from "lucide-react";

export default function ForgotPassword() {
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  const submit = async (e) => {
    e?.preventDefault();
    setLoading(true);
    try {
      await api.post("/auth/forgot-password", { email: email.trim() });
      setSent(true);
    } catch (err) {
      setSent(true); // never reveal whether the email exists
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-[#F4F7FB]">
      <Card className="w-full max-w-md p-8 rounded-2xl border border-slate-200 shadow-sm bg-white">
        {sent ? (
          <div className="text-center space-y-3">
            <MailCheck className="w-10 h-10 text-[#0A66C2] mx-auto" />
            <h2 className="text-xl font-bold font-display text-slate-900">Check your inbox</h2>
            <p className="text-sm text-slate-500">If an account exists for <b>{email}</b>, we’ve sent a password reset link. It expires in 1 hour.</p>
            <Link to="/login" className="inline-flex items-center gap-1 text-sm text-[#0A66C2] hover:underline font-semibold mt-2"><ArrowLeft className="w-4 h-4" /> Back to sign in</Link>
          </div>
        ) : (
          <>
            <h2 className="text-2xl font-bold font-display text-slate-900">Forgot password</h2>
            <p className="text-sm text-slate-500 mt-1 mb-6">Enter your email and we’ll send you a reset link.</p>
            <form onSubmit={submit} className="space-y-4">
              <div>
                <Label htmlFor="email">Email</Label>
                <Input data-testid="forgot-email-input" id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@oaksphere.com" className="mt-1 focus-visible:ring-[#0A66C2]" required />
              </div>
              <Button data-testid="forgot-submit-btn" type="submit" disabled={loading} className="w-full h-11 bg-[#0A66C2] hover:bg-[#08549e] text-white font-semibold shadow-md shadow-blue-500/20 transition-colors">
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : "Send reset link"}
              </Button>
            </form>
            <Link to="/login" className="inline-flex items-center gap-1 text-sm text-[#0A66C2] hover:underline mt-5"><ArrowLeft className="w-4 h-4" /> Back to sign in</Link>
          </>
        )}
      </Card>
    </div>
  );
}
