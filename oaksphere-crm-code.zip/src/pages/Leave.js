import { useState, useEffect, useCallback } from "react";
import api, { formatError } from "@/lib/api";
import { toast } from "sonner";
import { useAuth } from "@/context/AuthContext";
import { PageHeader, Loading, EmptyState } from "@/components/common";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  CalendarDays,
  Plus,
  CheckCircle,
  XCircle,
  Clock,
  User,
  HeartPulse,
  Sun,
  Award,
} from "lucide-react";

export default function Leave() {
  const { user } = useAuth();
  const [leaves, setLeaves] = useState(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  // Form state
  const [leaveType, setLeaveType] = useState("Casual Leave");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [days, setDays] = useState(1);
  const [reason, setReason] = useState("");

  const isAdmin = user?.role === "admin" || user?.role === "team_leader";

  const loadLeaves = useCallback(() => {
    setLeaves(null);
    api
      .get("/hrms/leaves")
      .then((r) => setLeaves(r.data))
      .catch(() => {
        toast.error("Failed to load leave records");
        setLeaves([]);
      });
  }, []);

  useEffect(() => {
    loadLeaves();
  }, [loadLeaves]);

  const handleApply = async (e) => {
    e.preventDefault();
    if (!startDate || !endDate) {
      toast.error("Please select start and end dates");
      return;
    }
    setSubmitting(true);
    try {
      await api.post("/hrms/leaves", {
        leave_type: leaveType,
        start_date: startDate,
        end_date: endDate,
        days,
        reason,
      });
      toast.success("Leave application submitted");
      setDialogOpen(false);
      setReason("");
      loadLeaves();
    } catch (err) {
      toast.error(formatError(err.response?.data?.detail));
    } finally {
      setSubmitting(false);
    }
  };

  const handleApprove = async (id) => {
    try {
      await api.post(`/hrms/leaves/${id}/approve`, { comments: "Approved by manager" });
      toast.success("Leave approved");
      loadLeaves();
    } catch (err) {
      toast.error("Could not approve leave");
    }
  };

  const handleReject = async (id) => {
    try {
      await api.post(`/hrms/leaves/${id}/reject`, { comments: "Rejected due to operational exigency" });
      toast.info("Leave rejected");
      loadLeaves();
    } catch (err) {
      toast.error("Could not reject leave");
    }
  };

  return (
    <div className="space-y-6" id="leave-module-page">
      <PageHeader
        title="Leave Management"
        description="Apply for leave, track casual/sick leave balances, and manage team attendance requests."
        action={
          <Button
            onClick={() => setDialogOpen(true)}
            className="bg-[#0A66C2] hover:bg-[#08549e] text-white shadow-sm flex items-center gap-2"
            id="btn-apply-leave"
          >
            <Plus className="w-4 h-4" /> Apply for Leave
          </Button>
        }
      />

      {/* Leave Balances */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card className="p-4 border-l-4 border-l-blue-500 bg-white dark:bg-slate-900 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Casual Leave (CL)</p>
              <div className="flex items-baseline gap-2 mt-1">
                <p className="text-2xl font-bold text-slate-800 dark:text-white">8</p>
                <span className="text-xs text-slate-400">/ 12 days remaining</span>
              </div>
            </div>
            <Sun className="w-8 h-8 text-blue-500 opacity-80" />
          </div>
        </Card>

        <Card className="p-4 border-l-4 border-l-rose-500 bg-white dark:bg-slate-900 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Sick Leave (SL)</p>
              <div className="flex items-baseline gap-2 mt-1">
                <p className="text-2xl font-bold text-slate-800 dark:text-white">5</p>
                <span className="text-xs text-slate-400">/ 7 days remaining</span>
              </div>
            </div>
            <HeartPulse className="w-8 h-8 text-rose-500 opacity-80" />
          </div>
        </Card>

        <Card className="p-4 border-l-4 border-l-emerald-500 bg-white dark:bg-slate-900 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Earned Leave (EL)</p>
              <div className="flex items-baseline gap-2 mt-1">
                <p className="text-2xl font-bold text-slate-800 dark:text-white">14</p>
                <span className="text-xs text-slate-400">/ 18 days remaining</span>
              </div>
            </div>
            <Award className="w-8 h-8 text-emerald-500 opacity-80" />
          </div>
        </Card>
      </div>

      {/* Leave Requests Table */}
      {leaves === null ? (
        <Loading />
      ) : leaves.length === 0 ? (
        <EmptyState
          icon={CalendarDays}
          title="No leave requests"
          description="No leave applications submitted for this period."
          action={
            <Button onClick={() => setDialogOpen(true)} variant="outline" size="sm">
              <Plus className="w-4 h-4 mr-1" /> Submit Leave
            </Button>
          }
        />
      ) : (
        <div className="border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden bg-white dark:bg-slate-900 shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 uppercase tracking-wider text-slate-500 font-semibold">
                <tr>
                  <th className="py-3 px-4">Employee</th>
                  <th className="py-3 px-4">Leave Type</th>
                  <th className="py-3 px-4">Duration & Days</th>
                  <th className="py-3 px-4">Reason</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Approver</th>
                  {isAdmin && <th className="py-3 px-4 text-right">Actions</th>}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {leaves.map((lv) => {
                  const isPending = lv.status === "Pending";
                  const isApproved = lv.status === "Approved";

                  return (
                    <tr key={lv.id} id={`leave-row-${lv.id}`} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30">
                      <td className="py-3.5 px-4 font-semibold text-slate-900 dark:text-white flex items-center gap-2">
                        <User className="w-3.5 h-3.5 text-slate-400" />
                        {lv.employee_name}
                      </td>

                      <td className="py-3.5 px-4 font-medium text-slate-700 dark:text-slate-300">
                        {lv.leave_type}
                      </td>

                      <td className="py-3.5 px-4 text-slate-600 dark:text-slate-400">
                        <p className="font-semibold text-slate-800 dark:text-slate-200">
                          {lv.days} {lv.days === 1 ? "day" : "days"}
                        </p>
                        <p className="text-[11px] text-slate-400">
                          {lv.start_date} to {lv.end_date}
                        </p>
                      </td>

                      <td className="py-3.5 px-4 text-slate-600 dark:text-slate-400 max-w-xs">
                        {lv.reason || "—"}
                      </td>

                      <td className="py-3.5 px-4">
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase ${
                            isApproved
                              ? "bg-emerald-100 text-emerald-800"
                              : isPending
                              ? "bg-amber-100 text-amber-800"
                              : "bg-rose-100 text-rose-800"
                          }`}
                        >
                          {lv.status}
                        </span>
                      </td>

                      <td className="py-3.5 px-4 text-slate-500 text-[11px]">
                        {lv.approved_by ? lv.approved_by : "—"}
                        {lv.comments && <p className="text-[10px] text-slate-400 italic mt-0.5">{lv.comments}</p>}
                      </td>

                      {isAdmin && (
                        <td className="py-3.5 px-4 text-right">
                          {isPending && (
                            <div className="flex items-center justify-end gap-2">
                              <Button
                                size="sm"
                                onClick={() => handleApprove(lv.id)}
                                className="h-7 text-xs bg-emerald-600 hover:bg-emerald-700 text-white font-medium"
                              >
                                Approve
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleReject(lv.id)}
                                className="h-7 text-xs text-rose-600 hover:bg-rose-50 border-rose-200"
                              >
                                Reject
                              </Button>
                            </div>
                          )}
                        </td>
                      )}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Apply Leave Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-md bg-white dark:bg-slate-900">
          <DialogHeader>
            <DialogTitle>Apply for Leave</DialogTitle>
            <DialogDescription className="sr-only">Submit a leave request for review and approval</DialogDescription>
          </DialogHeader>

          <form onSubmit={handleApply} className="space-y-3 mt-2">
            <div>
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                Leave Type *
              </label>
              <Select value={leaveType} onValueChange={setLeaveType}>
                <SelectTrigger className="text-xs">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Casual Leave">Casual Leave (CL)</SelectItem>
                  <SelectItem value="Sick Leave">Sick Leave (SL)</SelectItem>
                  <SelectItem value="Earned Leave">Earned Leave (EL)</SelectItem>
                  <SelectItem value="Comp Off">Comp Off</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Start Date *
                </label>
                <Input
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  required
                  className="text-xs"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  End Date *
                </label>
                <Input
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  required
                  className="text-xs"
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                Number of Days *
              </label>
              <Input
                type="number"
                min="0.5"
                step="0.5"
                value={days}
                onChange={(e) => setDays(e.target.value)}
                required
                className="text-xs"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                Reason for Leave
              </label>
              <textarea
                placeholder="Please state the purpose of your leave..."
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                rows={3}
                required
                className="w-full text-xs p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 focus:outline-none focus:ring-1 focus:ring-purple-600"
              />
            </div>

            <DialogFooter className="pt-2">
              <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={submitting} className="bg-[#0A66C2] text-white hover:bg-[#08549e]">
                {submitting ? "Submitting..." : "Submit Application"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
