import { useEffect, useState, useCallback } from "react";
import { Link } from "react-router-dom";
import api, { formatError } from "@/lib/api";
import { toast } from "sonner";
import { useAuth } from "@/context/AuthContext";
import { PageHeader, KpiCard, Loading } from "@/components/common";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Users, UserCheck, Clock3, CircleDollarSign, LogIn, LogOut, CalendarDays, WalletCards, UserRoundCog } from "lucide-react";

function timeText(value) {
  if (!value) return "—";
  try { return new Date(value).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }); }
  catch { return value; }
}

export default function HRMS() {
  const { user } = useAuth();
  const [data, setData] = useState(null);
  const [busy, setBusy] = useState(false);
  const load = useCallback(() => api.get("/hrms/dashboard").then((r) => setData(r.data)).catch((e) => toast.error(formatError(e.response?.data?.detail))), []);
  useEffect(() => { load(); }, [load]);

  const punch = async (kind) => {
    setBusy(true);
    try {
      await api.post(`/hrms/attendance/${kind}`);
      toast.success(kind === "check-in" ? "Checked in successfully" : "Checked out successfully");
      load();
    } catch (e) { toast.error(formatError(e.response?.data?.detail)); }
    finally { setBusy(false); }
  };

  if (!data) return <Loading />;
  const att = data.my_attendance;
  const canCheckIn = !att?.check_in_at;
  const canCheckOut = !!att?.check_in_at && !att?.check_out_at;

  return (
    <div>
      <PageHeader title="HRMS" subtitle="Employees, attendance and payroll in one workspace" testid="hrms-header">
        {canCheckIn && <Button disabled={busy} onClick={() => punch("check-in")} className="bg-emerald-600 hover:bg-emerald-700"><LogIn className="w-4 h-4 mr-1" /> Check In</Button>}
        {canCheckOut && <Button disabled={busy} onClick={() => punch("check-out")} className="bg-rose-600 hover:bg-rose-700"><LogOut className="w-4 h-4 mr-1" /> Check Out</Button>}
      </PageHeader>

      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3 mb-6">
        <KpiCard label="Employees" value={data.employee_count} icon={Users} />
        <KpiCard label="Present Today" value={data.present_today} tone="green" icon={UserCheck} />
        <KpiCard label="Late Today" value={data.late_today} tone="yellow" icon={Clock3} />
        <KpiCard label="Half Day" value={data.half_day_today} tone="red" icon={CalendarDays} />
        <KpiCard label="Draft Payroll" value={data.draft_payroll} tone="blue" icon={CircleDollarSign} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
        <Card className="p-5 lg:col-span-2">
          <div className="flex items-center justify-between gap-3 mb-4">
            <div><h3 className="font-semibold font-display">My attendance today</h3><p className="text-xs text-slate-400">{data.today}</p></div>
            <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${att?.status === "Half Day" ? "bg-rose-50 text-rose-700" : att?.late ? "bg-amber-50 text-amber-700" : "bg-emerald-50 text-emerald-700"}`}>{att?.status || "Not checked in"}</span>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-sm">
            <div><p className="text-xs text-slate-400">Check in</p><p className="font-semibold mt-1">{timeText(att?.check_in_at)}</p></div>
            <div><p className="text-xs text-slate-400">Check out</p><p className="font-semibold mt-1">{timeText(att?.check_out_at)}</p></div>
            <div><p className="text-xs text-slate-400">Working hours</p><p className="font-semibold mt-1">{att?.working_hours ?? "—"}</p></div>
            <div><p className="text-xs text-slate-400">Late instance</p><p className="font-semibold mt-1">{att?.late_instance_number || "—"}</p></div>
          </div>
          {att?.auto_half_day_for_late && <p className="mt-4 p-3 rounded-lg bg-rose-50 text-rose-700 text-sm">Half-day applied automatically because the monthly late-instance allowance was exceeded.</p>}
        </Card>
        <Card className="p-5">
          <h3 className="font-semibold font-display mb-3">Attendance policy</h3>
          <div className="space-y-2 text-sm text-slate-600 dark:text-slate-300">
            <p><span className="text-slate-400">Office:</span> {data.settings.office_start_time} – {data.settings.office_end_time}</p>
            <p><span className="text-slate-400">Grace:</span> {data.settings.attendance_grace_minutes} minutes</p>
            <p><span className="text-slate-400">Late allowance:</span> {data.settings.late_instances_allowed} / month</p>
            <p><span className="text-slate-400">Payroll days:</span> {data.settings.standard_working_days}</p>
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Link to="/admin/attendance"><Card className="p-5 hover:shadow-md transition-shadow"><CalendarDays className="w-6 h-6 text-[#2B1055] mb-3" /><h3 className="font-semibold">Attendance</h3><p className="text-sm text-slate-400 mt-1">Daily punches, monthly register and corrections.</p></Card></Link>
        <Link to="/admin/payroll"><Card className="p-5 hover:shadow-md transition-shadow"><WalletCards className="w-6 h-6 text-emerald-600 mb-3" /><h3 className="font-semibold">Payroll & Payslips</h3><p className="text-sm text-slate-400 mt-1">Salary calculation, deductions, approval and payment status.</p></Card></Link>
        {(user.role === "admin" || user.role === "team_leader") && <Link to="/admin/employees"><Card className="p-5 hover:shadow-md transition-shadow"><UserRoundCog className="w-6 h-6 text-violet-600 mb-3" /><h3 className="font-semibold">Employees</h3><p className="text-sm text-slate-400 mt-1">HR profiles, designations and salary structure.</p></Card></Link>}
      </div>
    </div>
  );
}
