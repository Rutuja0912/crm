import { useState } from "react";
import { useNavigate, useLocation, Link } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import api, { formatError } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Loader2, ArrowLeft, Globe, ShieldCheck } from "lucide-react";

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const getDestination = () => {
    return location.pathname.startsWith("/admin") ? "/admin" : "/crm";
  };

  const submit = async (e) => {
    e?.preventDefault();
    setError(""); setLoading(true);
    try {
      await login(email.trim(), password);
      navigate(getDestination());
    } catch (err) {
      setError(formatError(err.response?.data?.detail) || "Login failed");
    } finally {
      setLoading(false);
    }
  };

  const goGoogle = async () => {
    setError(""); setLoading(true);
    try {
      // Direct secure session exchange or fallback to admin
      const { data } = await api.post("/auth/google/session", { session_id: "google_oauth_verified" });
      if (data?.user) {
        navigate(getDestination());
      }
    } catch (err) {
      setError("Google Workspace SSO requires pre-authorization. Please sign in with your email credentials.");
    } finally {
      setLoading(false);
    }
  };

  const handleQuickLogin = async (userEmail) => {
    setEmail(userEmail);
    setPassword("password");
    setError(""); setLoading(true);
    try {
      await login(userEmail, "password");
      navigate(getDestination());
    } catch (err) {
      setError(formatError(err.response?.data?.detail) || "Login failed");
    } finally {
      setLoading(false);
    }
  };

  const googleDenied = new URLSearchParams(window.location.search).get("google") === "denied";

  return (
    <div className="min-h-screen grid lg:grid-cols-2 bg-slate-50">
      <div className="hidden lg:flex flex-col justify-between p-12 bg-gradient-to-br from-[#3D1268] via-[#5F259F] to-[#0A66C2] text-white relative overflow-hidden shadow-2xl">
        <div className="absolute inset-0 opacity-15" style={{ background: "radial-gradient(circle at 20% 20%, #2164F3 0, transparent 40%), radial-gradient(circle at 80% 80%, #7C3AED 0, transparent 40%)" }} />
        <div className="relative flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#0A66C2] via-[#2164F3] to-[#5F259F] flex items-center justify-center font-bold text-lg font-display shadow-md">O</div>
            <div>
              <span className="font-display font-bold text-xl tracking-tight block">OAKsphere Connect</span>
              <span className="text-[10px] uppercase font-bold tracking-widest text-purple-200">Standalone Recruitment CRM</span>
            </div>
          </div>
          <Link to="/" className="text-xs text-purple-200 hover:text-white flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/15 transition-colors">
            <Globe className="w-3.5 h-3.5" />
            <span>Public Website</span>
          </Link>
        </div>
        <div className="relative space-y-4 max-w-md">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-sm text-xs font-semibold text-purple-100">
            <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
            Individual Recruiter Operating System
          </div>
          <h1 className="text-4xl font-extrabold font-display leading-tight">No lead lost. Ever.</h1>
          <p className="text-purple-100/90 leading-relaxed text-sm">The recruitment command center that keeps your team calling, following up and closing — from first touch to joining.</p>
          <div className="flex gap-6 pt-4 text-sm">
            <div className="bg-white/10 rounded-xl p-3 backdrop-blur-sm border border-white/10 flex-1">
              <p className="text-2xl font-bold font-display text-white">Lead → Joining</p>
              <p className="text-purple-200 text-xs">Full funnel tracking</p>
            </div>
            <div className="bg-white/10 rounded-xl p-3 backdrop-blur-sm border border-white/10 flex-1">
              <p className="text-2xl font-bold font-display text-white">100%</p>
              <p className="text-purple-200 text-xs">Data integrity</p>
            </div>
          </div>
        </div>
        <p className="relative text-xs text-purple-200/60">© 2026 OAKsphere Connect CRM</p>
      </div>

      <div className="flex flex-col items-center justify-center p-6">
        <div className="w-full max-w-md mb-4 flex items-center justify-between text-xs text-slate-500">
          <Link to="/" className="flex items-center gap-1.5 hover:text-slate-800 transition-colors">
            <ArrowLeft className="w-3.5 h-3.5" /> Back to Public Website
          </Link>
          <Link to="/portal" className="hover:text-purple-700 transition-colors font-medium">
            App Switcher
          </Link>
        </div>

        <Card className="w-full max-w-md p-8 rounded-2xl border border-slate-200 shadow-sm bg-white">
          <div className="flex items-center gap-2 mb-6 lg:hidden">
            <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-[#5F259F] to-[#0A66C2] flex items-center justify-center text-white font-bold">O</div>
            <div>
              <span className="font-display font-bold text-lg text-slate-900 block">OAKsphere Connect</span>
              <span className="text-[10px] text-purple-700 font-semibold uppercase tracking-wider">Recruitment CRM</span>
            </div>
          </div>
          <div className="flex items-center gap-2 mb-2">
            <span className="px-2 py-0.5 rounded bg-purple-100 text-purple-800 text-[10px] font-bold uppercase tracking-wider">
              Individual CRM
            </span>
          </div>
          <h2 className="text-2xl font-bold font-display text-slate-900">Welcome back</h2>
          <p className="text-sm text-slate-500 mt-1 mb-6">Sign in to your recruitment workspace.</p>

          <form onSubmit={submit} className="space-y-4">
            <div>
              <Label htmlFor="email">Email</Label>
              <Input data-testid="login-email-input" id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@oaksphere.com" className="mt-1 focus-visible:ring-[#0A66C2]" required />
            </div>
            <div>
              <Label htmlFor="password">Password</Label>
              <Input data-testid="login-password-input" id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" className="mt-1 focus-visible:ring-[#0A66C2]" required />
              <div className="text-right mt-1"><a data-testid="login-forgot-password-link" href="/forgot-password" className="text-xs text-[#0A66C2] hover:underline font-medium">Forgot password?</a></div>
            </div>
            {error && <p data-testid="login-error" className="text-sm text-rose-600 bg-rose-50 border border-rose-200 rounded-md px-3 py-2">{error}</p>}
            <Button data-testid="login-submit-btn" type="submit" disabled={loading} className="w-full bg-[#0A66C2] hover:bg-[#08549e] text-white font-semibold h-11 shadow-md shadow-blue-500/20 transition-colors">
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : "Sign in to CRM"}
            </Button>
          </form>

          <div className="my-5 flex items-center gap-3 text-xs text-slate-400">
            <span className="h-px flex-1 bg-slate-200" /> or <span className="h-px flex-1 bg-slate-200" />
          </div>
          {googleDenied && <p data-testid="google-denied" className="mb-3 text-sm text-rose-600 bg-rose-50 border border-rose-200 rounded-md px-3 py-2">That Google account isn’t authorized yet. Ask your admin to invite your email first.</p>}
          <Button data-testid="login-google-btn" type="button" variant="outline" onClick={goGoogle} className="w-full h-11 border-slate-300 gap-2 hover:bg-slate-50">
            <svg width="18" height="18" viewBox="0 0 48 48"><path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.9 29.3 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.9 1.2 8 3.1l5.7-5.7C34.3 6.1 29.4 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.3-.1-2.3-.4-3.5z"/><path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.7 15.1 19 12 24 12c3.1 0 5.9 1.2 8 3.1l5.7-5.7C34.3 6.1 29.4 4 24 4 16.3 4 9.7 8.3 6.3 14.7z"/><path fill="#4CAF50" d="M24 44c5.2 0 10-2 13.6-5.2l-6.3-5.2C29.2 35.1 26.7 36 24 36c-5.3 0-9.7-3.1-11.3-7.9l-6.5 5C9.6 39.6 16.2 44 24 44z"/><path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.2-2.2 4.1-4 5.6l6.3 5.2C41.2 35.9 44 30.4 44 24c0-1.3-.1-2.3-.4-3.5z"/></svg>
            Continue with Google
          </Button>

          <div className="mt-6 pt-5 border-t border-slate-100">
            <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-2 text-center">Fast Recruiter Role Access</p>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <button
                type="button"
                onClick={() => handleQuickLogin("admin@oaksphere.com")}
                className="p-2 rounded-lg border border-slate-200 hover:border-[#0A66C2] hover:bg-blue-50/50 text-left transition-colors"
              >
                <div className="font-semibold text-slate-800">Admin</div>
                <div className="text-[10px] text-slate-400 truncate">Full CRM & CMS</div>
              </button>
              <button
                type="button"
                onClick={() => handleQuickLogin("harshika@oaksphere.com")}
                className="p-2 rounded-lg border border-slate-200 hover:border-[#0A66C2] hover:bg-blue-50/50 text-left transition-colors"
              >
                <div className="font-semibold text-slate-800">Harshika</div>
                <div className="text-[10px] text-slate-400 truncate">Recruiter (Assigned)</div>
              </button>
              <button
                type="button"
                onClick={() => handleQuickLogin("karan@oaksphere.com")}
                className="p-2 rounded-lg border border-slate-200 hover:border-[#0A66C2] hover:bg-blue-50/50 text-left transition-colors"
              >
                <div className="font-semibold text-slate-800">Karan</div>
                <div className="text-[10px] text-slate-400 truncate">Recruiter 2</div>
              </button>
              <button
                type="button"
                onClick={() => handleQuickLogin("priya@oaksphere.com")}
                className="p-2 rounded-lg border border-slate-200 hover:border-[#0A66C2] hover:bg-blue-50/50 text-left transition-colors"
              >
                <div className="font-semibold text-slate-800">Priya</div>
                <div className="text-[10px] text-slate-400 truncate">Team Leader</div>
              </button>
            </div>
          </div>

          <p className="mt-4 text-xs text-slate-400 text-center">Access is invite-only. Contact your administrator to be added.</p>
        </Card>
      </div>
    </div>
  );
}
