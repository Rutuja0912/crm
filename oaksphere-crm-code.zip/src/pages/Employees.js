import { useCallback, useEffect, useState } from "react";
import api, { formatError } from "@/lib/api";
import { toast } from "sonner";
import { useAuth } from "@/context/AuthContext";
import { PageHeader, Loading } from "@/components/common";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Pencil, Search, IndianRupee, UserPlus, FileText, Send } from "lucide-react";

const money = (n) => `₹${Number(n || 0).toLocaleString("en-IN")}`;

export default function Employees() {
  const { user } = useAuth();
  const [rows, setRows] = useState(null);
  const [q, setQ] = useState("");
  const [form, setForm] = useState(null);
  const [createForm, setCreateForm] = useState(null);
  const [offer, setOffer] = useState(null);
  const isAdmin = user.role === "admin";
  const load = useCallback(() => api.get("/hrms/employees").then((r) => setRows(r.data)).catch((e) => { setRows([]); toast.error(formatError(e.response?.data?.detail)); }), []);
  useEffect(() => { load(); }, [load]);

  const edit = (r) => setForm({ ...r, salary_earnings: { basic: 0, hra: 0, special_allowance: 0, other_allowance: 0, ...(r.salary_earnings || {}) }, salary_deductions: { pf: 0, esi: 0, professional_tax: 0, tds: 0, other_deductions: 0, ...(r.salary_deductions || {}) } });
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));
  const setSalary = (group, k, v) => setForm((f) => ({ ...f, [group]: { ...f[group], [k]: Number(v || 0) } }));
  const save = async () => {
    const payload = { employee_code: form.employee_code, designation: form.designation, department: form.department, date_of_joining: form.date_of_joining || null, employment_type: form.employment_type, work_location: form.work_location, manager_id: form.manager_id || null, emergency_contact: form.emergency_contact, active_in_hrms: form.active_in_hrms !== false, salary_earnings: form.salary_earnings, salary_deductions: form.salary_deductions, standard_working_days_override: form.standard_working_days_override ? Number(form.standard_working_days_override) : null };
    try { await api.patch(`/hrms/employees/${form.user_id}`, payload); toast.success("Employee profile updated"); setForm(null); load(); }
    catch (e) { toast.error(formatError(e.response?.data?.detail)); }
  };

  const createEmployee = async () => {
    if (!createForm.name || !createForm.email) { toast.error("Name and email are required"); return; }
    try {
      const { data } = await api.post("/hrms/employees", {
        name: createForm.name, email: createForm.email, role: createForm.role || "recruiter",
        password: createForm.password || null, phone: createForm.phone || null,
        designation: createForm.designation || null, department: createForm.department || null,
        date_of_joining: createForm.date_of_joining || null,
      });
      toast.success(data.temp_password ? `Employee added. Temp password: ${data.temp_password}` : "Employee added");
      setCreateForm(null); load();
    } catch (e) { toast.error(formatError(e.response?.data?.detail)); }
  };

  const sendOffer = async () => {
    try {
      const { data } = await api.post(`/hrms/employees/${offer.user_id}/offer-letter`, { designation: offer.designation, annual_ctc: offer.annual_ctc, date_of_joining: offer.date_of_joining });
      toast.success(`Offer letter emailed to ${data.sent_to}`); setOffer(null);
    } catch (e) { toast.error(formatError(e.response?.data?.detail)); }
  };

  const sendPayslip = async (r) => {
    try { const { data } = await api.post(`/hrms/employees/${r.user_id}/send-payslip`); toast.success(`Payslip (${data.month}) emailed to ${data.sent_to}`); }
    catch (e) { toast.error(formatError(e.response?.data?.detail)); }
  };

  const shown = (rows || []).filter((r) => !q || `${r.name} ${r.email} ${r.employee_code} ${r.department}`.toLowerCase().includes(q.toLowerCase()));

  return <div>
    <PageHeader title="Employees" subtitle="HR profiles and salary structures">
      <div className="relative"><Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" /><Input value={q} onChange={(e) => setQ(e.target.value)} className="pl-9 h-9 w-56" placeholder="Search employees…" /></div>
      {isAdmin && <Button data-testid="add-employee-btn" onClick={() => setCreateForm({ role: "recruiter" })} className="bg-[#2B1055] hover:bg-[#3a1f66]"><UserPlus className="w-4 h-4 mr-1" /> Add Employee</Button>}
    </PageHeader>
    {rows === null ? <Loading /> : <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">{shown.map((r) => <Card key={r.user_id} data-testid={`employee-card-${r.user_id}`} className="p-5">
      <div className="flex items-start justify-between gap-3"><div><h3 className="font-semibold font-display">{r.name}</h3><p className="text-xs text-slate-400">{r.employee_code || "No employee code"} • {r.role}</p></div>{isAdmin && <Button size="icon" variant="ghost" onClick={() => edit(r)}><Pencil className="w-4 h-4" /></Button>}</div>
      <div className="mt-4 grid grid-cols-2 gap-3 text-sm"><div><p className="text-xs text-slate-400">Designation</p><p>{r.designation || "—"}</p></div><div><p className="text-xs text-slate-400">Department</p><p>{r.department || "—"}</p></div><div><p className="text-xs text-slate-400">Joining</p><p>{r.date_of_joining || "—"}</p></div><div><p className="text-xs text-slate-400">Type</p><p>{r.employment_type || "—"}</p></div></div>
      {(isAdmin || r.user_id === user.id) && <div className="mt-4 pt-4 border-t flex items-center justify-between"><div><p className="text-xs text-slate-400">Monthly gross</p><p className="font-bold text-emerald-600">{money(r.monthly_gross)}</p></div><IndianRupee className="w-5 h-5 text-slate-300" /></div>}
      {isAdmin && <div className="mt-3 grid grid-cols-2 gap-2">
        <Button size="sm" variant="outline" className="h-8 text-xs" data-testid={`offer-letter-${r.user_id}`} onClick={() => setOffer({ user_id: r.user_id, name: r.name, designation: r.designation || "", annual_ctc: "", date_of_joining: r.date_of_joining || "" })}><FileText className="w-3.5 h-3.5 mr-1" /> Offer letter</Button>
        <Button size="sm" variant="outline" className="h-8 text-xs" data-testid={`send-payslip-${r.user_id}`} onClick={() => sendPayslip(r)}><Send className="w-3.5 h-3.5 mr-1" /> Payslip</Button>
      </div>}
    </Card>)}</div>}

    {/* Edit profile */}
    <Dialog open={!!form} onOpenChange={(o) => !o && setForm(null)}><DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto bg-white dark:bg-slate-900"><DialogHeader><DialogTitle>Edit Employee — {form?.name}</DialogTitle><DialogDescription className="sr-only">Update employee details, salary structure, and designations</DialogDescription></DialogHeader>{form && <div className="space-y-5">
      <div className="grid grid-cols-2 gap-3"><div><Label>Employee Code</Label><Input value={form.employee_code || ""} onChange={(e) => set("employee_code", e.target.value)} className="mt-1" /></div><div><Label>Date of Joining</Label><Input type="date" value={form.date_of_joining || ""} onChange={(e) => set("date_of_joining", e.target.value)} className="mt-1" /></div><div><Label>Designation</Label><Input value={form.designation || ""} onChange={(e) => set("designation", e.target.value)} className="mt-1" /></div><div><Label>Department</Label><Input value={form.department || ""} onChange={(e) => set("department", e.target.value)} className="mt-1" /></div><div><Label>Employment Type</Label><Input value={form.employment_type || ""} onChange={(e) => set("employment_type", e.target.value)} className="mt-1" /></div><div><Label>Work Location</Label><Input value={form.work_location || ""} onChange={(e) => set("work_location", e.target.value)} className="mt-1" /></div></div>
      <div><h4 className="font-semibold mb-2">Monthly Earnings</h4><div className="grid grid-cols-2 md:grid-cols-4 gap-3">{[["basic","Basic"],["hra","HRA"],["special_allowance","Special Allowance"],["other_allowance","Other Allowance"]].map(([k,l]) => <div key={k}><Label className="text-xs">{l}</Label><Input type="number" value={form.salary_earnings[k]} onChange={(e) => setSalary("salary_earnings", k, e.target.value)} className="mt-1" /></div>)}</div></div>
      <div><h4 className="font-semibold mb-2">Monthly Fixed Deductions <span className="text-xs text-slate-400 font-normal">(configure per employee; verify statutory compliance separately)</span></h4><div className="grid grid-cols-2 md:grid-cols-5 gap-3">{[["pf","PF"],["esi","ESI"],["professional_tax","Prof. Tax"],["tds","TDS"],["other_deductions","Other"]].map(([k,l]) => <div key={k}><Label className="text-xs">{l}</Label><Input type="number" value={form.salary_deductions[k]} onChange={(e) => setSalary("salary_deductions", k, e.target.value)} className="mt-1" /></div>)}</div></div>
      <div><Label>Working days override</Label><Input type="number" min="1" max="31" value={form.standard_working_days_override || ""} onChange={(e) => set("standard_working_days_override", e.target.value)} placeholder="Use global setting" className="mt-1 max-w-xs" /></div>
    </div>}<DialogFooter><Button variant="outline" onClick={() => setForm(null)}>Cancel</Button><Button onClick={save} className="bg-[#2B1055] hover:bg-[#3a1f66]">Save Employee</Button></DialogFooter></DialogContent></Dialog>

    {/* Add employee */}
    <Dialog open={!!createForm} onOpenChange={(o) => !o && setCreateForm(null)}><DialogContent className="max-w-lg bg-white dark:bg-slate-900" data-testid="add-employee-dialog"><DialogHeader><DialogTitle>Add Employee</DialogTitle><DialogDescription className="sr-only">Add new employee credentials and team role</DialogDescription></DialogHeader>{createForm && <div className="grid grid-cols-2 gap-3">
      <div className="col-span-2"><Label>Full name *</Label><Input data-testid="emp-name" value={createForm.name || ""} onChange={(e) => setCreateForm((f) => ({ ...f, name: e.target.value }))} className="mt-1" /></div>
      <div className="col-span-2"><Label>Email *</Label><Input data-testid="emp-email" type="email" value={createForm.email || ""} onChange={(e) => setCreateForm((f) => ({ ...f, email: e.target.value }))} className="mt-1" /></div>
      <div><Label>Role</Label><Select value={createForm.role} onValueChange={(v) => setCreateForm((f) => ({ ...f, role: v }))}><SelectTrigger data-testid="emp-role" className="mt-1"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="recruiter">Recruiter</SelectItem><SelectItem value="team_leader">Team Leader</SelectItem><SelectItem value="admin">Admin</SelectItem></SelectContent></Select></div>
      <div><Label>Phone</Label><Input value={createForm.phone || ""} onChange={(e) => setCreateForm((f) => ({ ...f, phone: e.target.value }))} className="mt-1" /></div>
      <div><Label>Designation</Label><Input value={createForm.designation || ""} onChange={(e) => setCreateForm((f) => ({ ...f, designation: e.target.value }))} className="mt-1" /></div>
      <div><Label>Department</Label><Input value={createForm.department || ""} onChange={(e) => setCreateForm((f) => ({ ...f, department: e.target.value }))} className="mt-1" /></div>
      <div><Label>Date of joining</Label><Input type="date" value={createForm.date_of_joining || ""} onChange={(e) => setCreateForm((f) => ({ ...f, date_of_joining: e.target.value }))} className="mt-1" /></div>
      <div><Label>Password <span className="text-slate-400 text-xs">(optional)</span></Label><Input type="password" value={createForm.password || ""} onChange={(e) => setCreateForm((f) => ({ ...f, password: e.target.value }))} placeholder="Auto-generated if blank" className="mt-1" /></div>
    </div>}<DialogFooter><Button variant="outline" onClick={() => setCreateForm(null)}>Cancel</Button><Button data-testid="emp-create-btn" onClick={createEmployee} className="bg-[#2B1055] hover:bg-[#3a1f66]">Add Employee</Button></DialogFooter></DialogContent></Dialog>

    {/* Offer letter */}
    <Dialog open={!!offer} onOpenChange={(o) => !o && setOffer(null)}><DialogContent className="max-w-md bg-white dark:bg-slate-900" data-testid="offer-dialog"><DialogHeader><DialogTitle>Send offer letter — {offer?.name}</DialogTitle><DialogDescription className="sr-only">Generate and email offer letter to candidate</DialogDescription></DialogHeader>{offer && <div className="space-y-3">
      <div><Label>Designation</Label><Input data-testid="offer-designation" value={offer.designation} onChange={(e) => setOffer((o) => ({ ...o, designation: e.target.value }))} className="mt-1" /></div>
      <div><Label>Annual CTC</Label><Input data-testid="offer-ctc" value={offer.annual_ctc} onChange={(e) => setOffer((o) => ({ ...o, annual_ctc: e.target.value }))} placeholder="e.g. ₹6,00,000" className="mt-1" /></div>
      <div><Label>Joining date</Label><Input type="date" value={offer.date_of_joining || ""} onChange={(e) => setOffer((o) => ({ ...o, date_of_joining: e.target.value }))} className="mt-1" /></div>
    </div>}<DialogFooter><Button variant="outline" onClick={() => setOffer(null)}>Cancel</Button><Button data-testid="offer-send-btn" onClick={sendOffer} className="bg-[#2B1055] hover:bg-[#3a1f66]">Email offer letter</Button></DialogFooter></DialogContent></Dialog>
  </div>;
}
