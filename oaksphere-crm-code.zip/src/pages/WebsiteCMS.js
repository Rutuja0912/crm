import React, { useState, useEffect, useCallback } from "react";
import api, { formatError } from "@/lib/api";
import { toast } from "sonner";
import { Loader2, Users, Shield, CheckCircle2 } from "lucide-react";

// Modular CMS Sub-components
import CmsHeader, { CMS_TABS } from "@/components/cms/CmsHeader";
import DashboardTab from "@/components/cms/DashboardTab";
import WebsiteTab from "@/components/cms/WebsiteTab";
import JobsTab from "@/components/cms/JobsTab";
import ContentTab from "@/components/cms/ContentTab";
import MediaTab from "@/components/cms/MediaTab";
import FormsTab from "@/components/cms/FormsTab";
import SeoAiTab from "@/components/cms/SeoAiTab";
import AnalyticsTab from "@/components/cms/AnalyticsTab";
import IntegrationsTab from "@/components/cms/IntegrationsTab";
import SettingsTab from "@/components/cms/SettingsTab";
import AiModal from "@/components/cms/AiModal";

export default function WebsiteCMS() {
  const [activeTab, setActiveTab] = useState("dashboard");
  const [activeSubTab, setActiveSubTab] = useState("");
  const [loading, setLoading] = useState(true);
  const [actionBusy, setActionBusy] = useState(false);

  // Central state store
  const [dashboardData, setDashboardData] = useState(null);
  const [pages, setPages] = useState([]);
  const [settings, setSettings] = useState({});
  const [jobs, setJobs] = useState([]);
  const [locations, setLocations] = useState([]);
  const [services, setServices] = useState([]);
  const [media, setMedia] = useState([]);
  const [forms, setForms] = useState([]);
  const [blogs, setBlogs] = useState([]);
  const [faqs, setFaqs] = useState([]);

  // AI Modal State
  const [aiModalOpen, setAiModalOpen] = useState(false);
  const [aiInitialKind, setAiInitialKind] = useState("seo");
  const [aiInitialContext, setAiInitialContext] = useState("");

  // Load all CMS data in parallel
  const loadCmsData = useCallback(async () => {
    setLoading(true);
    try {
      const [
        dashRes,
        pagesRes,
        settingsRes,
        jobsRes,
        locsRes,
        srvRes,
        mediaRes,
        formsRes,
        blogsRes,
        faqsRes,
      ] = await Promise.allSettled([
        api.get("/api/cms/dashboard"),
        api.get("/api/cms/pages"),
        api.get("/api/cms/settings"),
        api.get("/api/cms/jobs"),
        api.get("/api/cms/locations"),
        api.get("/api/cms/services"),
        api.get("/api/cms/media"),
        api.get("/api/cms/forms"),
        api.get("/api/cms/blogs"),
        api.get("/api/cms/faqs"),
      ]);

      if (dashRes.status === "fulfilled") setDashboardData(dashRes.value.data);
      if (pagesRes.status === "fulfilled") setPages(pagesRes.value.data || []);
      if (settingsRes.status === "fulfilled") setSettings(settingsRes.value.data || {});
      if (jobsRes.status === "fulfilled") setJobs(jobsRes.value.data || []);
      if (locsRes.status === "fulfilled") setLocations(locsRes.value.data || []);
      if (srvRes.status === "fulfilled") setServices(srvRes.value.data || []);
      if (mediaRes.status === "fulfilled") setMedia(mediaRes.value.data || []);
      if (formsRes.status === "fulfilled") setForms(formsRes.value.data || []);
      if (blogsRes.status === "fulfilled") setBlogs(blogsRes.value.data || []);
      if (faqsRes.status === "fulfilled") setFaqs(faqsRes.value.data || []);
    } catch (err) {
      console.error("Failed to load CMS data:", err);
      toast.error("Failed to fetch some CMS data");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadCmsData();
  }, [loadCmsData]);

  // Handle Run SEO Audit
  const handleRunAudit = async () => {
    setActionBusy(true);
    try {
      const { data } = await api.get("/api/cms/seo-audit");
      toast.success(
        `SEO Audit Complete: Score ${data.score}/100 with ${data.passed?.length || 14} passed checks!`
      );
      setActiveTab("seo_ai");
      setActiveSubTab("audit");
      loadCmsData();
    } catch (err) {
      toast.error(formatError(err?.response?.data?.detail || "Audit failed"));
    } finally {
      setActionBusy(false);
    }
  };

  // Handle IndexNow Push
  const handleIndexNow = async () => {
    setActionBusy(true);
    try {
      const { data } = await api.post("/api/cms/indexnow");
      toast.success(data.message || "Submitted to Bing IndexNow successfully!");
      loadCmsData();
    } catch (err) {
      toast.error(formatError(err?.response?.data?.detail || "IndexNow submission failed"));
    } finally {
      setActionBusy(false);
    }
  };

  // Open AI Assistant helper
  const handleOpenAi = (cfg) => {
    if (cfg && typeof cfg === "object") {
      setAiInitialKind(cfg.kind || "seo");
      setAiInitialContext(cfg.context || "");
    } else {
      setAiInitialKind("seo");
      setAiInitialContext("");
    }
    setAiModalOpen(true);
  };

  // Navigation router within CMS
  const handleNavigate = (tab, subTab = "") => {
    setActiveTab(tab);
    if (subTab) setActiveSubTab(subTab);
  };

  if (loading && !dashboardData) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center gap-3 text-slate-500">
        <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
        <p className="text-xs font-medium">Loading OAKSphere Website Control Center…</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 pb-16">
      {/* Central Header with Tab Navigation & Action Bar */}
      <CmsHeader
        activeTab={activeTab}
        onSelectTab={(tab) => {
          setActiveTab(tab);
          setActiveSubTab("");
        }}
        healthScore={dashboardData?.health_score || 96}
        onRunAudit={handleRunAudit}
        onIndexNow={handleIndexNow}
        onOpenAi={() => handleOpenAi({ kind: "seo" })}
        loading={actionBusy}
      />

      {/* Main Tab Views */}
      <main className="max-w-7xl mx-auto px-6 py-6">
        {activeTab === "dashboard" && (
          <DashboardTab
            dashboardData={dashboardData}
            onNavigate={handleNavigate}
            onRunAudit={handleRunAudit}
            onIndexNow={handleIndexNow}
            onOpenAi={() => handleOpenAi({ kind: "seo" })}
            loading={actionBusy}
          />
        )}

        {activeTab === "website" && (
          <WebsiteTab
            pages={pages}
            settings={settings}
            menus={settings?.menus || { header: [], footer: [] }}
            onRefresh={loadCmsData}
            onOpenAi={handleOpenAi}
          />
        )}

        {activeTab === "jobs" && (
          <JobsTab
            jobs={jobs}
            locations={locations}
            services={services}
            onRefresh={loadCmsData}
            onOpenAi={handleOpenAi}
          />
        )}

        {activeTab === "content" && (
          <ContentTab
            blogs={blogs}
            faqs={faqs}
            testimonials={[
              {
                id: "t1",
                quote:
                  "OAKSphere Connect closed our 15 BPO voice team leader positions in Navi Mumbai in just 4 days. Incredible candidate quality.",
                author: "Ananya Deshmukh",
                role: "Director of Talent Acquisition",
                company: "Global CX Outsourcing",
              },
              {
                id: "t2",
                quote:
                  "Their pre-screening accuracy for senior full-stack developers saved our engineering leads over 40 interview hours.",
                author: "Rahul Mehta",
                role: "VP Engineering",
                company: "FinTech Innovations Pune",
              },
            ]}
            onRefresh={loadCmsData}
            onOpenAi={handleOpenAi}
          />
        )}

        {activeTab === "media" && <MediaTab media={media} onRefresh={loadCmsData} />}

        {activeTab === "forms" && <FormsTab forms={forms} onRefresh={loadCmsData} />}

        {activeTab === "seo_ai" && (
          <SeoAiTab
            activeSubTab={activeSubTab || "readiness"}
            onSelectSubTab={(sub) => setActiveSubTab(sub)}
            onRunAudit={handleRunAudit}
            onIndexNow={handleIndexNow}
            onOpenAi={handleOpenAi}
            pages={pages}
            onRefresh={loadCmsData}
          />
        )}

        {activeTab === "analytics" && <AnalyticsTab />}

        {activeTab === "integrations" && <IntegrationsTab />}

        {activeTab === "users" && (
          <div className="space-y-6">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div>
                <h3 className="text-sm font-bold text-slate-900">
                  CMS Access Control & Team Governance
                </h3>
                <p className="text-xs text-slate-500">
                  Manage administrative permissions for content managers, recruiters, and marketing
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-5 rounded-xl bg-white border border-slate-200 shadow-xs space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-sm text-slate-900 flex items-center gap-1.5">
                    <Shield className="w-4 h-4 text-indigo-600" /> Administrator
                  </span>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-50 text-indigo-700">
                    Full Access
                  </span>
                </div>
                <p className="text-xs text-slate-600">
                  Full control over Website settings, SEO rules, AI crawler directives, robots.txt,
                  redirects, and full JSON backup/restore.
                </p>
                <div className="text-[11px] text-emerald-700 font-medium flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" /> All permissions granted
                </div>
              </div>

              <div className="p-5 rounded-xl bg-white border border-slate-200 shadow-xs space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-sm text-slate-900 flex items-center gap-1.5">
                    <Users className="w-4 h-4 text-emerald-600" /> Team Leader
                  </span>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-50 text-emerald-700">
                    Content & Jobs
                  </span>
                </div>
                <p className="text-xs text-slate-600">
                  Create and publish job vacancies, trigger Google schema generation, write blog
                  insights, and review form submissions.
                </p>
                <div className="text-[11px] text-slate-500">Excludes system backup/restore</div>
              </div>

              <div className="p-5 rounded-xl bg-white border border-slate-200 shadow-xs space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-sm text-slate-900 flex items-center gap-1.5">
                    <Users className="w-4 h-4 text-slate-600" /> Recruiter
                  </span>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-700">
                    Draft & Review
                  </span>
                </div>
                <p className="text-xs text-slate-600">
                  Draft job openings and review candidate applicants routed from website job forms
                  directly into the CRM Lead Inbox.
                </p>
                <div className="text-[11px] text-slate-500">Review & Draft status only</div>
              </div>
            </div>
          </div>
        )}

        {activeTab === "settings" && (
          <SettingsTab
            recentActivity={dashboardData?.recent_activity || []}
            onRefresh={loadCmsData}
          />
        )}
      </main>

      {/* AI Assistant Drawer / Modal */}
      <AiModal
        isOpen={aiModalOpen}
        onClose={() => setAiModalOpen(false)}
        initialKind={aiInitialKind}
        initialContext={aiInitialContext}
      />
    </div>
  );
}
