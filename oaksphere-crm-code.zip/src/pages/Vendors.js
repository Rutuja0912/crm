import { useState, useEffect, useCallback } from "react";
import api, { formatError } from "@/lib/api";
import { toast } from "sonner";
import { useAuth } from "@/context/AuthContext";
import { PageHeader, Loading, EmptyState } from "@/components/common";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Building2,
  Plus,
  Phone,
  Mail,
  Linkedin,
  FileText,
  Search,
  CheckCircle,
  ExternalLink,
  Briefcase,
  Calendar,
  DollarSign,
  User,
  Trash2,
} from "lucide-react";

const STAGES = [
  "New",
  "Contacted",
  "Follow-up",
  "Meeting",
  "Proposal Sent",
  "Negotiation",
  "Empanelled",
  "Rejected",
];

const INDUSTRIES = [
  "IT Services",
  "BFSI",
  "BPO / ITES",
  "Healthcare & Pharma",
  "Manufacturing",
  "Retail & E-commerce",
  "EdTech",
];

export default function Vendors() {
  const { user } = useAuth();
  const [vendors, setVendors] = useState(null);
  const [stageFilter, setStageFilter] = useState("all");
  const [search, setSearch] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  // Form state
  const [company, setCompany] = useState("");
  const [contactPerson, setContactPerson] = useState("");
  const [designation, setDesignation] = useState("Head of Talent Acquisition");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [linkedin, setLinkedin] = useState("");
  const [industry, setIndustry] = useState("IT Services");
  const [status, setStatus] = useState("New");
  const [proposalSent, setProposalSent] = useState(false);
  const [commercialProposed, setCommercialProposed] = useState("8.33% of CTC (90-day replacement)");
  const [nextAction, setNextAction] = useState("");
  const [notes, setNotes] = useState("");

  const loadVendors = useCallback(() => {
    setVendors(null);
    const params = new URLSearchParams();
    if (stageFilter !== "all") params.set("status", stageFilter);
    if (search) params.set("search", search);
    api
      .get(`/vendors?${params.toString()}`)
      .then((r) => setVendors(r.data))
      .catch(() => {
        toast.error("Failed to load vendor records");
        setVendors([]);
      });
  }, [stageFilter, search]);

  useEffect(() => {
    loadVendors();
  }, [loadVendors]);

  const handleCreate = async (e) => {
    e.preventDefault();
    if (!company.trim()) {
      toast.error("Company name is required");
      return;
    }
    setSubmitting(true);
    try {
      await api.post("/vendors", {
        company,
        contact_person: contactPerson,
        designation,
        email,
        phone,
        linkedin,
        industry,
        status,
        proposal_sent: proposalSent,
        commercial_proposed: commercialProposed,
        next_action: nextAction,
        notes,
      });
      toast.success("Vendor empanelment record created");
      setDialogOpen(false);
      setCompany("");
      setContactPerson("");
      setEmail("");
      setPhone("");
      setLinkedin("");
      setNextAction("");
      setNotes("");
      loadVendors();
    } catch (err) {
      toast.error(formatError(err.response?.data?.detail));
    } finally {
      setSubmitting(false);
    }
  };

  const updateStage = async (vendorId, newStage) => {
    try {
      await api.patch(`/vendors/${vendorId}`, { status: newStage });
      toast.success(`Moved to ${newStage}`);
      loadVendors();
    } catch (err) {
      toast.error("Could not update vendor stage");
    }
  };

  const deleteVendor = async (id) => {
    try {
      await api.delete(`/vendors/${id}`);
      toast.success("Vendor record deleted");
      loadVendors();
    } catch (err) {
      toast.error("Could not delete vendor");
    }
  };

  const empanelledCount = (vendors || []).filter((v) => v.status === "Empanelled").length;
  const proposalCount = (vendors || []).filter((v) => v.status === "Proposal Sent" || v.status === "Negotiation").length;
  const inPipelineCount = (vendors || []).filter((v) => v.status !== "Empanelled" && v.status !== "Rejected").length;

  return (
    <div className="space-y-6" id="vendors-module-page">
      <PageHeader
        title="Vendors & Corporate Empanelment"
        description="Manage B2B client empanelment proposals, recruitment contracts, SLA terms, and vendor procurement stages."
        action={
          <Button
            onClick={() => setDialogOpen(true)}
            className="bg-[#0A66C2] hover:bg-[#08549e] text-white shadow-sm flex items-center gap-2"
            id="btn-new-vendor"
          >
            <Plus className="w-4 h-4" /> New Vendor Lead
          </Button>
        }
      />

      {/* Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card className="p-4 border-l-4 border-l-emerald-500 bg-white dark:bg-slate-900 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Empanelled Partners</p>
              <p className="text-2xl font-bold text-emerald-600 mt-1">{empanelledCount}</p>
            </div>
            <CheckCircle className="w-8 h-8 text-emerald-500 opacity-80" />
          </div>
        </Card>

        <Card className="p-4 border-l-4 border-l-purple-500 bg-white dark:bg-slate-900 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Proposals & Negotiation</p>
              <p className="text-2xl font-bold text-[#5F259F] dark:text-purple-400 mt-1">{proposalCount}</p>
            </div>
            <FileText className="w-8 h-8 text-purple-500 opacity-80" />
          </div>
        </Card>

        <Card className="p-4 border-l-4 border-l-blue-500 bg-white dark:bg-slate-900 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Active Pipeline</p>
              <p className="text-2xl font-bold text-blue-600 mt-1">{inPipelineCount}</p>
            </div>
            <Building2 className="w-8 h-8 text-blue-500 opacity-80" />
          </div>
        </Card>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row gap-3 items-center justify-between bg-white dark:bg-slate-900 p-3.5 rounded-lg border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex items-center gap-2 w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400" />
          <Input
            placeholder="Search company, contact person, phone..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="h-9 text-sm"
          />
        </div>

        <div className="flex items-center gap-3 w-full sm:w-auto">
          <Select value={stageFilter} onValueChange={setStageFilter}>
            <SelectTrigger className="w-44 h-9 text-xs">
              <SelectValue placeholder="Pipeline Stage" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Stages</SelectItem>
              {STAGES.map((s) => (
                <SelectItem key={s} value={s.toLowerCase()}>
                  {s}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Vendor Cards Grid */}
      {vendors === null ? (
        <Loading />
      ) : vendors.length === 0 ? (
        <EmptyState
          icon={Building2}
          title="No vendor leads found"
          description="Track outreach to HR managers and staffing procurement heads to expand empanelled clients."
          action={
            <Button onClick={() => setDialogOpen(true)} variant="outline" size="sm">
              <Plus className="w-4 h-4 mr-1" /> Add Vendor Lead
            </Button>
          }
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {vendors.map((v) => {
            const isEmpanelled = v.status === "Empanelled";
            const isRejected = v.status === "Rejected";

            return (
              <Card
                key={v.id}
                id={`vendor-card-${v.id}`}
                className="p-5 flex flex-col justify-between border-slate-200 dark:border-slate-800 hover:border-purple-300 transition-all bg-white dark:bg-slate-900 shadow-sm"
              >
                <div>
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h4 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                        {v.company}
                      </h4>
                      <p className="text-xs text-slate-500">{v.industry}</p>
                    </div>

                    <span
                      className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider ${
                        isEmpanelled
                          ? "bg-emerald-100 text-emerald-800"
                          : isRejected
                          ? "bg-rose-100 text-rose-800"
                          : "bg-purple-100 text-purple-800"
                      }`}
                    >
                      {v.status}
                    </span>
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 space-y-2 text-xs">
                    {v.contact_person && (
                      <div className="flex items-center gap-2 text-slate-700 dark:text-slate-300">
                        <User className="w-3.5 h-3.5 text-slate-400" />
                        <span className="font-semibold">{v.contact_person}</span>
                        {v.designation && <span className="text-slate-400">({v.designation})</span>}
                      </div>
                    )}

                    {v.phone && (
                      <div className="flex items-center gap-2 text-slate-600 dark:text-slate-400">
                        <Phone className="w-3.5 h-3.5 text-slate-400" />
                        <a href={`tel:${v.phone}`} className="hover:underline text-slate-700 dark:text-slate-300 font-mono">
                          {v.phone}
                        </a>
                      </div>
                    )}

                    {v.email && (
                      <div className="flex items-center gap-2 text-slate-600 dark:text-slate-400">
                        <Mail className="w-3.5 h-3.5 text-slate-400" />
                        <a href={`mailto:${v.email}`} className="hover:underline break-all">
                          {v.email}
                        </a>
                      </div>
                    )}

                    {v.commercial_proposed && (
                      <div className="flex items-start gap-2 text-slate-700 dark:text-slate-300 bg-slate-50 dark:bg-slate-800/50 p-2 rounded">
                        <DollarSign className="w-3.5 h-3.5 text-emerald-600 mt-0.5" />
                        <div>
                          <span className="font-semibold text-[11px] block text-slate-500 uppercase">Commercials</span>
                          <span>{v.commercial_proposed}</span>
                        </div>
                      </div>
                    )}

                    {v.next_action && (
                      <div className="text-[11px] text-amber-700 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/30 p-2 rounded border border-amber-200/50">
                        <span className="font-bold">Next Action:</span> {v.next_action}
                      </div>
                    )}
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2">
                  <Select value={v.status} onValueChange={(val) => updateStage(v.id, val)}>
                    <SelectTrigger className="h-7 text-[11px] w-36">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {STAGES.map((s) => (
                        <SelectItem key={s} value={s}>
                          {s}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => deleteVendor(v.id)}
                    className="h-7 w-7 p-0 text-slate-400 hover:text-rose-600"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </Button>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      {/* New Vendor Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg bg-white dark:bg-slate-900">
          <DialogHeader>
            <DialogTitle>Add Corporate Vendor Lead</DialogTitle>
            <DialogDescription className="sr-only">Add new corporate vendor or client company</DialogDescription>
          </DialogHeader>

          <form onSubmit={handleCreate} className="space-y-3 mt-2">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Company Name *
                </label>
                <Input
                  placeholder="e.g. Wipro / TCS"
                  value={company}
                  onChange={(e) => setCompany(e.target.value)}
                  required
                  className="text-xs"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Industry
                </label>
                <Select value={industry} onValueChange={setIndustry}>
                  <SelectTrigger className="text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {INDUSTRIES.map((ind) => (
                      <SelectItem key={ind} value={ind}>
                        {ind}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Contact Person
                </label>
                <Input
                  placeholder="e.g. Shruti Kulkarni"
                  value={contactPerson}
                  onChange={(e) => setContactPerson(e.target.value)}
                  className="text-xs"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Designation
                </label>
                <Input
                  placeholder="e.g. Head of Talent Procurement"
                  value={designation}
                  onChange={(e) => setDesignation(e.target.value)}
                  className="text-xs"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Phone Number
                </label>
                <Input
                  placeholder="+91 98..."
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="text-xs font-mono"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Work Email
                </label>
                <Input
                  type="email"
                  placeholder="hr@company.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="text-xs"
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                Commercials Proposed
              </label>
              <Input
                placeholder="e.g. 8.33% of CTC with 90-day replacement guarantee"
                value={commercialProposed}
                onChange={(e) => setCommercialProposed(e.target.value)}
                className="text-xs"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                Next Follow-up Action
              </label>
              <Input
                placeholder="e.g. Pitch deck presentation next Tuesday"
                value={nextAction}
                onChange={(e) => setNextAction(e.target.value)}
                className="text-xs"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                Notes
              </label>
              <textarea
                placeholder="Hiring volumes, preferred tech stacks, payment terms..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                rows={2}
                className="w-full text-xs p-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 focus:outline-none focus:ring-1 focus:ring-purple-600"
              />
            </div>

            <DialogFooter className="pt-2">
              <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={submitting} className="bg-[#0A66C2] text-white hover:bg-[#08549e]">
                {submitting ? "Saving..." : "Create Vendor Record"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
