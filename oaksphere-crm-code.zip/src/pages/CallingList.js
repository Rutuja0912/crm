import { useState, useEffect, useCallback } from "react";
import api from "@/lib/api";
import { PageHeader, Loading, EmptyState } from "@/components/common";
import { PriorityBadge, fmtDate } from "@/lib/ui";
import CallActionModal from "@/components/CallActionModal";
import CallDispositionModal from "@/components/CallDispositionModal";
import { TagPickerDialog } from "@/components/LeadDialogs";
import LeadDrawer from "@/components/LeadDrawer";
import WhatsAppModal from "@/components/WhatsAppModal";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { PhoneCall, MessageCircle, ListChecks, ClipboardCheck, Tag } from "lucide-react";

const REASON_COLORS = {
  "Overdue Follow-up": "bg-rose-50 text-rose-700 border-rose-200",
  "Hot Candidate": "bg-red-50 text-red-700 border-red-200",
  "Interview Tomorrow": "bg-blue-50 text-blue-700 border-blue-200",
  "Today's Follow-up": "bg-amber-50 text-amber-700 border-amber-200",
  "New High-Priority": "bg-orange-50 text-orange-700 border-orange-200",
  "New Lead": "bg-slate-50 text-slate-600 border-slate-200",
  "Reattempt": "bg-slate-50 text-slate-600 border-slate-200",
  "Old Lead": "bg-slate-50 text-slate-500 border-slate-200",
};

export default function CallingList() {
  const [leads, setLeads] = useState(null);
  const [callModalLead, setCallModalLead] = useState(null);
  const [dispositionLead, setDispositionLead] = useState(null);
  const [callDuration, setCallDuration] = useState(0);
  const [tagLead, setTagLead] = useState(null);
  const [drawerId, setDrawerId] = useState(null);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [waLead, setWaLead] = useState(null);

  const load = useCallback(() => {
    setLeads(null);
    api.get("/calling-list").then((r) => setLeads(r.data)).catch(() => setLeads([]));
  }, []);
  useEffect(() => { load(); }, [load]);

  const openCall = (l) => {
    setCallModalLead(l);
  };

  const openDisposition = (l, duration = 0) => {
    setDispositionLead(l);
    setCallDuration(duration || 0);
  };

  const openTagging = (l) => {
    setTagLead(l);
  };

  const safeLeads = Array.isArray(leads) ? leads : [];

  return (
    <div>
      <PageHeader title="My Calling List" subtitle={safeLeads.length ? `${safeLeads.length} candidates in your prioritized queue` : ""} testid="calling-header" />
      {leads === null ? <Loading /> : safeLeads.length === 0 ? <EmptyState icon={ListChecks} title="Your queue is clear!" subtitle="No pending candidates to call right now." /> : (
        <div className="space-y-2">
          {safeLeads.map((l, i) => (
            <Card key={l.id} data-testid={`calling-row-${l.id}`} className="p-3 flex items-center gap-3 hover:shadow-md transition-shadow">
              <span className="w-7 h-7 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-xs font-bold text-slate-500 flex-shrink-0">{i + 1}</span>
              <div className="flex-1 min-w-0">
                <button onClick={() => { setDrawerId(l.id); setDrawerOpen(true); }} className="text-left">
                  <p className="font-medium text-slate-800 dark:text-slate-100 truncate hover:text-[#0A66C2] transition-colors">{l.name}</p>
                  <p className="text-[11px] text-slate-400 font-mono">{l.phone} • {l.city}</p>
                </button>
              </div>
              <span className={`text-[10px] px-2 py-0.5 rounded-full border font-medium hidden sm:inline ${REASON_COLORS[l.queue_reason] || "bg-slate-50 border-slate-200"}`}>{l.queue_reason}</span>
              <PriorityBadge priority={l.priority} />
              {l.next_followup_date && <span className="text-[11px] text-slate-400 hidden md:inline">{fmtDate(l.next_followup_date)}</span>}
              <div className="flex items-center gap-1 flex-shrink-0">
                {/* 1st: Call */}
                <Button size="sm" data-testid={`calling-call-${l.id}`} onClick={() => openCall(l)} title="Call candidate / Dial options" className="bg-emerald-600 hover:bg-emerald-700 h-8">
                  <PhoneCall className="w-4 h-4 sm:mr-1" /><span className="hidden sm:inline">Call</span>
                </Button>
                {/* 2nd: Disposition */}
                <Button size="sm" variant="outline" data-testid={`calling-disp-${l.id}`} onClick={() => openDisposition(l)} title="Log Call Disposition & Follow-up" className="text-[#5F259F] border-purple-200 hover:bg-purple-50 h-8">
                  <ClipboardCheck className="w-4 h-4" />
                </Button>
                {/* 3rd: WhatsApp */}
                <Button size="sm" variant="outline" data-testid={`calling-wa-${l.id}`} onClick={() => setWaLead(l)} title="WhatsApp" className="text-emerald-600 border-emerald-200 hover:bg-emerald-50 h-8">
                  <MessageCircle className="w-4 h-4" />
                </Button>
                {/* 4th: Tagging */}
                <Button size="sm" variant="outline" data-testid={`calling-tag-${l.id}`} onClick={() => openTagging(l)} title="Manage Tags (Candidate Tagging)" className="text-amber-600 border-amber-200 hover:bg-amber-50 h-8">
                  <Tag className="w-4 h-4" />
                </Button>
              </div>
            </Card>
          ))}
        </div>
      )}
      <CallActionModal
        open={!!callModalLead}
        onOpenChange={(o) => !o && setCallModalLead(null)}
        lead={callModalLead}
        onOpenDisposition={(lead, duration) => {
          setCallModalLead(null);
          openDisposition(lead, duration);
        }}
        onDone={load}
      />
      <CallDispositionModal
        open={!!dispositionLead}
        onOpenChange={(o) => !o && setDispositionLead(null)}
        lead={dispositionLead}
        initialDuration={callDuration}
        onDone={load}
      />
      <TagPickerDialog
        open={!!tagLead}
        onOpenChange={(o) => !o && setTagLead(null)}
        lead={tagLead}
        onDone={load}
      />
      <LeadDrawer leadId={drawerId} open={drawerOpen} onOpenChange={setDrawerOpen} onCall={openCall} onDisposition={openDisposition} onChanged={load} />
      <WhatsAppModal open={!!waLead} onOpenChange={(o) => !o && setWaLead(null)} lead={waLead} onDone={load} />
    </div>
  );
}
