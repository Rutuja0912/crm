import { useCallback, useEffect, useState } from "react";
import api, { formatError } from "@/lib/api";
import { toast } from "sonner";
import { useAuth } from "@/context/AuthContext";
import { PageHeader, Loading, EmptyState } from "@/components/common";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { WalletCards, Calculator, Pencil, Eye, Trash2 } from "lucide-react";

const currentMonth = () => new Date().toISOString().slice(0, 7);
const money = (n) => `₹${Number(n || 0).toLocaleString("en-IN", { maximumFractionDigits: 2 })}`;
const statusClass = (s) => s === "Paid" ? "bg-emerald-50 text-emerald-700" : s === "Approved" ? "bg-blue-50 text-blue-700" : "bg-amber-50 text-amber-700";

export default function Payroll() {
  const { user } = useAuth();
  const [month, setMonth] = useState(currentMonth());
  const [rows, setRows] = useState(null);
  const [form, setForm] = useState(null);
  const [view, setView] = useState(null);
  const isAdmin = user.role === "admin";
  const load = useCallback(() => { setRows(null); api.get(`/hrms/payroll?month=${month}`).then((r) => setRows(r.data)).catch((e) => { setRows([]); toast.error(formatError(e.response?.data?.detail)); }); }, [month]);
  useEffect(() => { load(); }, [load]);

  const generate = async () => {
    try {
      const { data } = await api.post("/hrms/payroll/generate", { month });
      toast.success(`${data.generated.length} payroll record(s) generated${data.skipped_existing.length ? ` • ${data.skipped_existing.length} already existed` : ""}`);
      load();
    } catch (e) { toast.error(formatError(e.response?.data?.detail)); }
  };
  const save = async () => {
    try { await api.patch(`/hrms/payroll/${form.id}`, { paid_days: Number(form.paid_days || 0), bonus: Number(form.bonus || 0), adjustment: Number(form.adjustment || 0), status: form.status, note: form.note || "" }); toast.success("Payroll updated"); setForm(null); load(); }
    catch (e) { toast.error(formatError(e.response?.data?.detail)); }
  };
  const remove = async (r) => {
    if (!window.confirm(`Delete ${r.month} payroll for ${r.employee_name}?`)) return;
    try { await api.delete(`/hrms/payroll/${r.id}`); toast.success("Payroll deleted"); load(); }
    catch (e) { toast.error(formatError(e.response?.data?.detail)); }
  };

  return <div>
    <PageHeader title="Payroll & Payslips" subtitle={isAdmin ? "Generate, review, approve and mark salaries paid" : "View your monthly salary records"}>
      <Input type="month" value={month} onChange={(e) => setMonth(e.target.value)} className="h-9 w-40" />
      {isAdmin && <Button size="sm" onClick={generate} className="bg-[#0A66C2] hover:bg-[#08549e]"><Calculator className="w-4 h-4 mr-1" /> Generate Payroll</Button>}
    </PageHeader>
    {isAdmin && <Card className="p-3 mb-4 bg-amber-50 border-amber-200 text-amber-800 text-sm">Payroll is generated as <b>Draft</b>. Review attendance/paid days and configured deductions before approving or paying. Missing attendance records can reduce paid days, so review is mandatory.</Card>}
    <Card className="overflow-hidden">{rows === null ? <Loading /> : rows.length === 0 ? <EmptyState icon={WalletCards} title="No payroll for this month" subtitle={isAdmin ? "Generate payroll after attendance is reviewed." : "Your payslip is not generated yet."} /> : <div className="overflow-x-auto"><table className="w-full text-sm"><thead className="bg-slate-50 dark:bg-slate-900"><tr className="text-left text-xs text-slate-400"><th className="px-4 py-3">Employee</th><th className="px-4 py-3">Paid / Working</th><th className="px-4 py-3">Gross</th><th className="px-4 py-3">Deductions</th><th className="px-4 py-3">Net Pay</th><th className="px-4 py-3">Status</th><th className="px-4 py-3"></th></tr></thead><tbody className="divide-y divide-slate-100 dark:divide-slate-800">{rows.map((r) => <tr key={r.id}><td className="px-4 py-3"><p className="font-medium">{r.employee_name}</p><p className="text-xs text-slate-400">{r.employee_code}</p></td><td className="px-4 py-3">{r.paid_days} / {r.working_days}{r.review_required && <span className="ml-2 text-[10px] font-semibold text-amber-600">REVIEW</span>}</td><td className="px-4 py-3">{r.gross === undefined ? "Private" : money(r.total_earnings)}</td><td className="px-4 py-3">{r.total_deductions === undefined ? "Private" : money(r.total_deductions)}</td><td className="px-4 py-3 font-bold text-emerald-600">{r.net_pay === undefined ? "Private" : money(r.net_pay)}</td><td className="px-4 py-3"><span className={`text-xs font-semibold px-2 py-1 rounded-full ${statusClass(r.status)}`}>{r.status}</span></td><td className="px-4 py-3"><div className="flex gap-1"><Button size="icon" variant="ghost" onClick={() => setView(r)}><Eye className="w-4 h-4" /></Button>{isAdmin && r.status !== "Paid" && <Button size="icon" variant="ghost" onClick={() => setForm({ ...r })}><Pencil className="w-4 h-4" /></Button>}{isAdmin && r.status !== "Paid" && <Button size="icon" variant="ghost" className="text-rose-600" onClick={() => remove(r)}><Trash2 className="w-4 h-4" /></Button>}</div></td></tr>)}</tbody></table></div>}</Card>

    <Dialog open={!!form} onOpenChange={(o) => !o && setForm(null)}><DialogContent className="max-w-md bg-white dark:bg-slate-900"><DialogHeader><DialogTitle>Review Payroll — {form?.employee_name}</DialogTitle><DialogDescription className="sr-only">Adjust employee paid days, bonus, and payroll approval status</DialogDescription></DialogHeader>{form && <div className="space-y-3"><div className="grid grid-cols-2 gap-3"><div><Label>Paid Days</Label><Input type="number" step="0.5" value={form.paid_days} onChange={(e) => setForm((f) => ({ ...f, paid_days: e.target.value }))} className="mt-1" /></div><div><Label>Working Days</Label><Input value={form.working_days} disabled className="mt-1" /></div><div><Label>Bonus</Label><Input type="number" value={form.bonus || 0} onChange={(e) => setForm((f) => ({ ...f, bonus: e.target.value }))} className="mt-1" /></div><div><Label>Adjustment (+/-)</Label><Input type="number" value={form.adjustment || 0} onChange={(e) => setForm((f) => ({ ...f, adjustment: e.target.value }))} className="mt-1" /></div></div><div><Label>Status</Label><Select value={form.status} onValueChange={(v) => setForm((f) => ({ ...f, status: v }))}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="Draft">Draft</SelectItem><SelectItem value="Approved">Approved</SelectItem>{form.status === "Approved" && <SelectItem value="Paid">Paid</SelectItem>}</SelectContent></Select></div><div><Label>Note</Label><Input value={form.note || ""} onChange={(e) => setForm((f) => ({ ...f, note: e.target.value }))} className="mt-1" /></div></div>}<DialogFooter><Button variant="outline" onClick={() => setForm(null)}>Cancel</Button><Button onClick={save} className="bg-[#0A66C2] hover:bg-[#08549e]">Save Payroll</Button></DialogFooter></DialogContent></Dialog>

    <Dialog open={!!view} onOpenChange={(o) => !o && setView(null)}><DialogContent className="max-w-lg bg-white dark:bg-slate-900"><DialogHeader><DialogTitle>Payslip — {view?.month}</DialogTitle><DialogDescription className="sr-only">Monthly payslip breakdown, earnings, and statutory deductions</DialogDescription></DialogHeader>{view && <div className="space-y-4"><div><p className="text-xl font-bold">{view.employee_name}</p><p className="text-sm text-slate-400">{view.employee_code}</p></div>{view.net_pay === undefined ? <p className="text-sm text-slate-500">Salary amounts are private. Team leaders can see payroll status but not employee salary details.</p> : <><div className="grid grid-cols-2 gap-3 text-sm"><div className="p-3 rounded-lg bg-slate-50"><p className="text-xs text-slate-400">Gross earnings</p><p className="font-bold">{money(view.total_earnings)}</p></div><div className="p-3 rounded-lg bg-slate-50"><p className="text-xs text-slate-400">Total deductions</p><p className="font-bold">{money(view.total_deductions)}</p></div><div className="p-3 rounded-lg bg-slate-50"><p className="text-xs text-slate-400">LOP deduction</p><p className="font-bold">{money(view.lop_deduction)}</p></div><div className="p-3 rounded-lg bg-emerald-50"><p className="text-xs text-emerald-600">Net pay</p><p className="font-bold text-emerald-700">{money(view.net_pay)}</p></div></div><div className="text-xs text-slate-400">Paid days: {view.paid_days} / {view.working_days} • Status: {view.status}</div></>}</div>}<DialogFooter><Button variant="outline" onClick={() => window.print()}>Print</Button><Button onClick={() => setView(null)}>Close</Button></DialogFooter></DialogContent></Dialog>
  </div>;
}
