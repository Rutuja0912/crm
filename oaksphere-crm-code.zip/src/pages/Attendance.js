import { useCallback, useEffect, useMemo, useState } from "react";
import api, { formatError } from "@/lib/api";
import { toast } from "sonner";
import { useAuth } from "@/context/AuthContext";
import { PageHeader, Loading, EmptyState } from "@/components/common";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { CalendarDays, Plus, Pencil, Trash2 } from "lucide-react";

const currentMonth = () => new Date().toISOString().slice(0, 7);
const today = () => { const d = new Date(); const p = (n) => String(n).padStart(2, "0"); return `${d.getFullYear()}-${p(d.getMonth()+1)}-${p(d.getDate())}`; };
const statuses = ["Present", "Late", "Half Day", "Absent", "Leave"];
const badge = (s) => s === "Present" ? "bg-emerald-50 text-emerald-700" : s === "Late" ? "bg-amber-50 text-amber-700" : s === "Half Day" ? "bg-orange-50 text-orange-700" : s === "Absent" ? "bg-rose-50 text-rose-700" : "bg-blue-50 text-blue-700";
const dt = (v) => v ? new Date(v).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) : "—";

export default function Attendance() {
  const { user } = useAuth();
  const [month, setMonth] = useState(currentMonth());
  const [rows, setRows] = useState(null);
  const [employees, setEmployees] = useState([]);
  const [employee, setEmployee] = useState(user.role === "recruiter" ? user.id : "all");
  const [form, setForm] = useState(null);
  const isAdmin = user.role === "admin";

  const load = useCallback(() => {
    const qs = new URLSearchParams({ month });
    if (employee && employee !== "all") qs.set("user_id", employee);
    setRows(null);
    api.get(`/hrms/attendance?${qs}`).then((r) => setRows(r.data)).catch((e) => { setRows([]); toast.error(formatError(e.response?.data?.detail)); });
  }, [month, employee]);
  useEffect(() => { load(); }, [load]);
  useEffect(() => {
    if (user.role !== "recruiter") api.get("/hrms/employees").then((r) => setEmployees(r.data)).catch(() => setEmployees([]));
  }, [user.role]);

  const summary = useMemo(() => {
    const s = { Present: 0, Late: 0, "Half Day": 0, Absent: 0, Leave: 0 };
    (rows || []).forEach((r) => { if (s[r.status] !== undefined) s[r.status] += 1; });
    return s;
  }, [rows]);

  const save = async () => {
    try {
      await api.post("/hrms/attendance", form);
      toast.success("Attendance saved"); setForm(null); load();
    } catch (e) { toast.error(formatError(e.response?.data?.detail)); }
  };
  const remove = async (r) => {
    if (!window.confirm(`Delete attendance for ${r.employee_name} on ${r.date}?`)) return;
    try { await api.delete(`/hrms/attendance/${r.id}`); toast.success("Attendance deleted"); load(); }
    catch (e) { toast.error(formatError(e.response?.data?.detail)); }
  };

  return (
    <div>
      <PageHeader title="Attendance" subtitle="Monthly attendance register and punch history">
        <Input type="month" value={month} onChange={(e) => setMonth(e.target.value)} className="h-9 w-40" />
        {user.role !== "recruiter" && <Select value={employee} onValueChange={setEmployee}><SelectTrigger className="h-9 w-48"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">All employees</SelectItem>{employees.map((e) => <SelectItem key={e.user_id} value={e.user_id}>{e.name}</SelectItem>)}</SelectContent></Select>}
        {isAdmin && <Button size="sm" onClick={() => setForm({ user_id: employees[0]?.user_id || "", date: today(), status: "Present", note: "" })} className="bg-[#0A66C2] hover:bg-[#08549e]"><Plus className="w-4 h-4 mr-1" /> Mark Attendance</Button>}
      </PageHeader>

      <div className="grid grid-cols-5 gap-2 mb-4">
        {Object.entries(summary).map(([k, v]) => <Card key={k} className="p-3 text-center"><p className="text-xl font-bold">{v}</p><p className="text-[10px] uppercase text-slate-400">{k}</p></Card>)}
      </div>

      <Card className="overflow-hidden">
        {rows === null ? <Loading /> : rows.length === 0 ? <EmptyState icon={CalendarDays} title="No attendance records" subtitle="No records found for this month." /> : (
          <div className="overflow-x-auto"><table className="w-full text-sm"><thead className="bg-slate-50 dark:bg-slate-900"><tr className="text-left text-xs text-slate-400"><th className="px-4 py-3">Date</th><th className="px-4 py-3">Employee</th><th className="px-4 py-3">Status</th><th className="px-4 py-3">Check In</th><th className="px-4 py-3">Check Out</th><th className="px-4 py-3">Hours</th><th className="px-4 py-3">Note</th>{isAdmin && <th className="px-4 py-3">Actions</th>}</tr></thead><tbody className="divide-y divide-slate-100 dark:divide-slate-800">
            {rows.map((r) => <tr key={r.id}><td className="px-4 py-3 font-medium">{r.date}</td><td className="px-4 py-3">{r.employee_name}</td><td className="px-4 py-3"><span className={`text-xs font-semibold px-2 py-1 rounded-full ${badge(r.status)}`}>{r.status}</span></td><td className="px-4 py-3">{dt(r.check_in_at)}</td><td className="px-4 py-3">{dt(r.check_out_at)}</td><td className="px-4 py-3">{r.working_hours ?? "—"}</td><td className="px-4 py-3 text-slate-500">{r.note || (r.auto_half_day_for_late ? "Auto half-day: late limit exceeded" : "—")}</td>{isAdmin && <td className="px-4 py-3"><div className="flex gap-1"><Button size="icon" variant="ghost" onClick={() => setForm({ user_id: r.user_id, date: r.date, status: r.status, note: r.note || "" })}><Pencil className="w-4 h-4" /></Button><Button size="icon" variant="ghost" className="text-rose-600" onClick={() => remove(r)}><Trash2 className="w-4 h-4" /></Button></div></td>}</tr>)}
          </tbody></table></div>
        )}
      </Card>

      <Dialog open={!!form} onOpenChange={(o) => !o && setForm(null)}><DialogContent className="max-w-md bg-white dark:bg-slate-900"><DialogHeader><DialogTitle>Mark / Correct Attendance</DialogTitle><DialogDescription className="sr-only">Mark or adjust employee attendance record and status</DialogDescription></DialogHeader>{form && <div className="space-y-3">
        <div><Label>Employee</Label><Select value={form.user_id} onValueChange={(v) => setForm((f) => ({ ...f, user_id: v }))}><SelectTrigger className="mt-1"><SelectValue placeholder="Select employee" /></SelectTrigger><SelectContent>{employees.map((e) => <SelectItem key={e.user_id} value={e.user_id}>{e.name}</SelectItem>)}</SelectContent></Select></div>
        <div><Label>Date</Label><Input type="date" value={form.date} onChange={(e) => setForm((f) => ({ ...f, date: e.target.value }))} className="mt-1" /></div>
        <div><Label>Status</Label><Select value={form.status} onValueChange={(v) => setForm((f) => ({ ...f, status: v }))}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent>{statuses.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent></Select></div>
        <div><Label>Note</Label><Input value={form.note || ""} onChange={(e) => setForm((f) => ({ ...f, note: e.target.value }))} className="mt-1" /></div>
      </div>}<DialogFooter><Button variant="outline" onClick={() => setForm(null)}>Cancel</Button><Button onClick={save} className="bg-[#0A66C2] hover:bg-[#08549e]">Save</Button></DialogFooter></DialogContent></Dialog>
    </div>
  );
}
