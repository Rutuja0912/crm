import { useEffect, useMemo, useState } from "react";
import api, { formatError } from "@/lib/api";
import { toast } from "sonner";
import { PageHeader } from "@/components/common";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Upload, FileSpreadsheet, ShieldCheck, AlertTriangle, CheckCircle2, Download, Link2, Copy } from "lucide-react";

const LABELS = {
  name: "Candidate Name", phone: "Phone Number", alt_phone: "Alternate Phone", email: "Email", city: "City",
  age: "Age", gender: "Gender", qualification: "Qualification", experience: "Experience", current_salary: "Current Salary",
  expected_salary: "Expected Salary", notice_period: "Notice Period / Joining", source: "Source", priority: "Priority", notes: "Notes / Remarks",
};

export default function ImportLeads() {
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState(null);
  const [mapping, setMapping] = useState({});
  const [recruiters, setRecruiters] = useState([]);
  const [assigned, setAssigned] = useState("none");
  const [dupPolicy, setDupPolicy] = useState("skip");
  const [invalidPolicy, setInvalidPolicy] = useState("import_flagged");
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState(null);

  useEffect(() => {
    api.get("/recruiters").then((r) => {
      const list = Array.isArray(r.data) ? r.data : [];
      setRecruiters(list.filter((x) => x.active !== false));
    }).catch(() => setRecruiters([]));
  }, []);

  const backendUrl = process.env.REACT_APP_BACKEND_URL;
  const gformUrl = `${backendUrl}/api/webhooks/google-forms`;
  const copy = (t) => { navigator.clipboard?.writeText(t); toast.success("Copied to clipboard"); };
  const downloadTemplate = async () => {
    try {
      const { data } = await api.get("/imports/leads/template.xlsx", { responseType: "blob" });
      const url = URL.createObjectURL(new Blob([data]));
      const a = document.createElement("a"); a.href = url; a.download = "oaksphere_leads_template.xlsx"; a.click(); URL.revokeObjectURL(url);
    } catch (e) { toast.error("Could not download the template"); }
  };

  const upload = async () => {
    if (!file) { toast.error("Choose a CSV or XLSX file first"); return; }
    setBusy(true); setResult(null);
    try {
      const fd = new FormData(); fd.append("file", file);
      const { data } = await api.post("/imports/leads/preview", fd, { headers: { "Content-Type": "multipart/form-data" } });
      setPreview(data); setMapping(data.mapping || {});
      toast.success(`${data.row_count} row(s) loaded for preview`);
    } catch (e) { toast.error(formatError(e.response?.data?.detail)); }
    finally { setBusy(false); }
  };

  const commit = async () => {
    if (!mapping.phone) { toast.error("Phone Number mapping is required"); return; }
    setBusy(true);
    try {
      const { data } = await api.post("/imports/leads/commit", {
        batch_id: preview.batch_id, mapping,
        assigned_recruiter_id: (assigned === "none" || assigned === "auto") ? null : assigned,
        default_source: "Import", default_priority: "Medium",
        duplicate_policy: dupPolicy, invalid_policy: invalidPolicy,
      });
      let allocation = null;
      if (assigned === "auto" && data.lead_ids?.length) {
        allocation = await api.post("/leads/auto-distribute", { lead_ids: data.lead_ids });
      }
      setResult({ ...data, auto_distributed: allocation?.data?.assigned || 0 });
      toast.success(`${data.imported} lead(s) imported${allocation ? ` • ${allocation.data.assigned} auto-distributed` : ""}`);
    } catch (e) { toast.error(formatError(e.response?.data?.detail)); }
    finally { setBusy(false); }
  };

  const mappedPreview = useMemo(() => {
    if (!preview) return [];
    return preview.preview_rows.slice(0, 10).map((row) => {
      const out = {};
      Object.entries(mapping).forEach(([field, col]) => { if (col) out[field] = row[col] ?? ""; });
      return out;
    });
  }, [preview, mapping]);

  return (
    <div>
      <PageHeader title="Import Leads" subtitle="CSV / XLSX upload with mapping, duplicate checks and preview" testid="import-header" />

      <Card className="p-5 mb-5 max-w-5xl">
        <div className="grid grid-cols-1 md:grid-cols-[1fr_auto] gap-3 items-end">
          <div><Label>Lead file</Label><Input type="file" accept=".csv,.xlsx" onChange={(e) => setFile(e.target.files?.[0] || null)} className="mt-1" /></div>
          <Button onClick={upload} disabled={busy || !file} className="bg-[#0A66C2] hover:bg-[#08549e]"><Upload className="w-4 h-4 mr-1" /> {busy ? "Reading…" : "Upload & Preview"}</Button>
        </div>
        <div className="mt-4 flex flex-wrap gap-4 text-xs text-slate-500">
          <span className="flex items-center gap-1"><ShieldCheck className="w-4 h-4 text-emerald-600" /> Phone digits are stored exactly as read from the file.</span>
          <span className="flex items-center gap-1"><AlertTriangle className="w-4 h-4 text-amber-600" /> Invalid/duplicate rows are flagged or skipped based on your choice.</span>
        </div>
      </Card>

      <Card className="p-5 mb-5 max-w-5xl">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div>
            <h3 className="font-semibold font-display flex items-center gap-2"><FileSpreadsheet className="w-4 h-4 text-[#0A66C2]" /> Excel / CSV template</h3>
            <p className="text-xs text-slate-400 mt-1 mb-3">Download the ready-made Excel with the exact columns. Fill it in and upload above — the columns auto-map.</p>
            <Button variant="outline" data-testid="download-template-btn" onClick={downloadTemplate}><Download className="w-4 h-4 mr-1" /> Download Excel template</Button>
          </div>
          <div>
            <h3 className="font-semibold font-display flex items-center gap-2"><Link2 className="w-4 h-4 text-[#0A66C2]" /> Get leads from an online Google Form</h3>
            <p className="text-xs text-slate-400 mt-1 mb-2">Pipe Google Form responses straight into your leads:</p>
            <ol className="text-xs text-slate-500 list-decimal ml-4 space-y-1 mb-3">
              <li>Open <b>Integrations → Google Forms</b> and set a <b>shared secret</b>.</li>
              <li>In your Form → <b>Apps Script</b>, add an <code>onFormSubmit</code> trigger that POSTs the answers (name, phone, email, city…) to the URL below with header <code>x-webhook-secret</code>.</li>
              <li>New submissions appear instantly as leads (source “Google Form”).</li>
            </ol>
            <div className="flex items-center gap-2">
              <Input readOnly value={gformUrl} data-testid="gform-webhook-url" className="h-9 text-xs font-mono" />
              <Button size="icon" variant="outline" onClick={() => copy(gformUrl)} data-testid="gform-copy-btn"><Copy className="w-4 h-4" /></Button>
            </div>
            <a href="/admin/integrations" className="inline-block text-xs text-[#0A66C2] hover:underline font-semibold mt-2">Open Integrations →</a>
          </div>
        </div>
      </Card>

      {preview && <>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-5 max-w-5xl">
          <Card className="p-4"><p className="text-xs text-slate-400">Rows</p><p className="text-2xl font-bold">{preview.row_count}</p></Card>
          <Card className="p-4"><p className="text-xs text-slate-400">Columns</p><p className="text-2xl font-bold">{preview.columns.length}</p></Card>
          <Card className="p-4"><p className="text-xs text-slate-400">Invalid phones</p><p className="text-2xl font-bold text-amber-600">{preview.quality.invalid_phone_rows}</p></Card>
          <Card className="p-4"><p className="text-xs text-slate-400">Duplicates in file</p><p className="text-2xl font-bold text-rose-600">{preview.quality.duplicate_phone_rows_in_file}</p></Card>
        </div>

        <Card className="p-5 mb-5 max-w-5xl">
          <h3 className="font-semibold font-display mb-1">1. Map your columns</h3>
          <p className="text-xs text-slate-400 mb-4">Phone Number is required. Other fields are optional.</p>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {preview.lead_fields.map((field) => <div key={field}><Label className="text-xs">{LABELS[field] || field}</Label><Select value={mapping[field] || "none"} onValueChange={(v) => setMapping((m) => ({ ...m, [field]: v === "none" ? "" : v }))}><SelectTrigger className="mt-1"><SelectValue placeholder="Not mapped" /></SelectTrigger><SelectContent><SelectItem value="none">Not mapped</SelectItem>{preview.columns.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent></Select></div>)}
          </div>
        </Card>

        <Card className="p-5 mb-5 max-w-5xl">
          <h3 className="font-semibold font-display mb-4">2. Import rules</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div><Label>Assign all imported leads</Label><Select value={assigned} onValueChange={setAssigned}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="none">Keep unassigned</SelectItem><SelectItem value="auto">Auto-distribute evenly</SelectItem>{recruiters.map((r) => <SelectItem key={r.id} value={r.id}>{r.name}</SelectItem>)}</SelectContent></Select></div>
            <div><Label>Duplicate phones</Label><Select value={dupPolicy} onValueChange={setDupPolicy}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="skip">Skip duplicates</SelectItem><SelectItem value="import_flagged">Import but flag duplicate</SelectItem></SelectContent></Select></div>
            <div><Label>Invalid phones</Label><Select value={invalidPolicy} onValueChange={setInvalidPolicy}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="import_flagged">Import but mark INVALID / VERIFY</SelectItem><SelectItem value="skip">Skip invalid numbers</SelectItem></SelectContent></Select></div>
          </div>
        </Card>

        <Card className="overflow-hidden mb-5 max-w-5xl">
          <div className="p-4 border-b"><h3 className="font-semibold font-display">3. Preview mapped data</h3><p className="text-xs text-slate-400">Showing first {mappedPreview.length} rows before commit.</p></div>
          {mappedPreview.length === 0 ? <div className="p-8 text-center text-slate-400"><FileSpreadsheet className="w-8 h-8 mx-auto mb-2" />Map at least one field to preview.</div> : <div className="overflow-x-auto"><table className="w-full text-sm"><thead className="bg-slate-50"><tr>{Object.keys(mappedPreview[0]).map((k) => <th key={k} className="px-3 py-2 text-left text-xs text-slate-400 whitespace-nowrap">{LABELS[k] || k}</th>)}</tr></thead><tbody className="divide-y">{mappedPreview.map((r, i) => <tr key={i}>{Object.keys(mappedPreview[0]).map((k) => <td key={k} className={`px-3 py-2 whitespace-nowrap ${k === "phone" ? "font-mono" : ""}`}>{r[k] || "—"}</td>)}</tr>)}</tbody></table></div>}
        </Card>

        <div className="max-w-5xl flex justify-end"><Button onClick={commit} disabled={busy || !mapping.phone || !!result} className="bg-emerald-600 hover:bg-emerald-700"><CheckCircle2 className="w-4 h-4 mr-1" /> {busy ? "Importing…" : "Import Leads"}</Button></div>
      </>}

      {result && <Card className="p-5 mt-5 max-w-5xl border-emerald-200 bg-emerald-50"><h3 className="font-semibold text-emerald-800">Import complete</h3><div className="grid grid-cols-2 md:grid-cols-5 gap-3 mt-3 text-sm"><div><p className="text-xs text-emerald-700/70">Imported</p><p className="font-bold text-lg">{result.imported}</p></div><div><p className="text-xs text-emerald-700/70">Skipped duplicates</p><p className="font-bold text-lg">{result.skipped_duplicate}</p></div><div><p className="text-xs text-emerald-700/70">Skipped invalid</p><p className="font-bold text-lg">{result.skipped_invalid}</p></div><div><p className="text-xs text-emerald-700/70">Flagged duplicate</p><p className="font-bold text-lg">{result.imported_flagged_duplicate}</p></div><div><p className="text-xs text-emerald-700/70">Flagged invalid</p><p className="font-bold text-lg">{result.imported_flagged_invalid}</p></div></div>{result.auto_distributed > 0 && <p className="text-sm text-emerald-800 mt-3">{result.auto_distributed} imported leads were balanced automatically across active recruiters.</p>}</Card>}
    </div>
  );
}
