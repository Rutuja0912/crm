import React from "react";
import api, { formatError } from "@/lib/api";
import { toast } from "sonner";
import { Plug, CheckCircle2, XCircle, Loader2, Copy, Save, Zap, Link2Off } from "lucide-react";

const BACKEND = process.env.REACT_APP_BACKEND_URL;

// Config field schema per integration key
const FIELDS = {
  whatsapp: [
    { k: "phone_number_id", label: "Phone Number ID" },
    { k: "business_account_id", label: "WhatsApp Business Account ID" },
    { k: "access_token", label: "Permanent Access Token", secret: true },
    { k: "verify_token", label: "Webhook Verify Token", secret: true },
    { k: "app_secret", label: "Meta App Secret (for webhook signature verification)", secret: true },
  ],
  instagram: [
    { k: "page_id", label: "Instagram / Page ID" },
    { k: "access_token", label: "Page Access Token", secret: true },
    { k: "verify_token", label: "Webhook Verify Token", secret: true },
    { k: "app_secret", label: "Meta App Secret (for webhook signature verification)", secret: true },
  ],
  facebook: [
    { k: "page_id", label: "Facebook Page ID" },
    { k: "access_token", label: "Page Access Token", secret: true },
    { k: "verify_token", label: "Webhook Verify Token", secret: true },
    { k: "app_secret", label: "Meta App Secret (for webhook signature verification)", secret: true },
  ],
  google_forms: [
    { k: "shared_secret", label: "Shared Secret (X-Webhook-Secret header)", secret: true },
  ],
  search_console: [
    { k: "verification_code", label: "Site Verification Code (meta tag content)" },
    { k: "analytics_id", label: "Google Analytics Measurement ID (optional)" },
  ],
  mobile_calling: [],
  website: [],
};

const WEBHOOKS = {
  whatsapp: "/api/webhooks/whatsapp",
  instagram: "/api/webhooks/meta",
  facebook: "/api/webhooks/meta",
  google_forms: "/api/webhooks/google-forms",
  website: "/api/public/leads",
};

function StatusPill({ status }) {
  const connected = status === "connected";
  return (
    <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold ${connected ? "bg-emerald-100 text-emerald-700" : "bg-slate-100 text-slate-500"}`}>
      {connected ? <CheckCircle2 className="w-3.5 h-3.5" /> : <XCircle className="w-3.5 h-3.5" />}
      {connected ? "Connected" : "Not Connected"}
    </span>
  );
}

function IntegrationCard({ integ, onChange }) {
  const [config, setConfig] = React.useState(integ.config || {});
  const [busy, setBusy] = React.useState(false);
  const fields = FIELDS[integ.key] || [];
  const webhook = WEBHOOKS[integ.key];

  const save = async () => {
    setBusy(true);
    try {
      const { data } = await api.patch(`/cms/integrations/${integ.key}`, { config });
      toast.success(`${integ.name} settings saved`);
      onChange(data);
    } catch (e) { toast.error(formatError(e.response?.data?.detail)); } finally { setBusy(false); }
  };
  const test = async () => {
    setBusy(true);
    try {
      const { data } = await api.post(`/cms/integrations/${integ.key}/test`);
      data.ok ? toast.success(data.message) : toast.warning(data.message);
    } catch (e) { toast.error(formatError(e.response?.data?.detail)); } finally { setBusy(false); }
  };
  const disconnect = async () => {
    setBusy(true);
    try {
      const { data } = await api.post(`/cms/integrations/${integ.key}/disconnect`);
      setConfig({}); toast.success(`${integ.name} disconnected`); onChange(data);
    } catch (e) { toast.error(formatError(e.response?.data?.detail)); } finally { setBusy(false); }
  };
  const copy = (t) => { navigator.clipboard.writeText(t); toast.success("Copied"); };

  return (
    <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-5">
      <div className="flex items-start justify-between">
        <div>
          <h3 className="font-semibold text-slate-900 dark:text-white">{integ.name}</h3>
          <p className="text-xs text-slate-500 mt-1 max-w-md">{integ.help}</p>
        </div>
        <StatusPill status={integ.status} />
      </div>

      {webhook && (
        <div className="mt-4 text-xs">
          <p className="text-slate-400 uppercase tracking-wide mb-1">{integ.key === "website" ? "Lead intake endpoint" : "Webhook URL"}</p>
          <div className="flex items-center gap-2 bg-slate-50 dark:bg-slate-800 rounded-lg px-3 py-2 font-mono text-slate-600 break-all">
            <span className="flex-1">{BACKEND}{webhook}</span>
            <button onClick={() => copy(`${BACKEND}${webhook}`)} className="text-slate-400 hover:text-cyan-600"><Copy className="w-4 h-4" /></button>
          </div>
        </div>
      )}

      {fields.length > 0 && (
        <div className="mt-4 space-y-3">
          {fields.map((f) => (
            <div key={f.k}>
              <label className="text-xs font-medium text-slate-600">{f.label}</label>
              <input type={f.secret ? "password" : "text"} value={config[f.k] || ""}
                onChange={(e) => setConfig({ ...config, [f.k]: e.target.value })}
                className="mt-1 w-full h-10 px-3 rounded-lg border border-slate-300 text-sm outline-none focus:border-cyan-500"
                placeholder={f.secret ? "••••••••" : ""} data-testid={`integ-${integ.key}-${f.k}`} />
            </div>
          ))}
        </div>
      )}

      {fields.length === 0 && integ.key === "website" && (
        <p className="mt-4 text-sm text-emerald-700 bg-emerald-50 rounded-lg px-3 py-2">Built-in — all website job applications & contact forms post directly to the CRM.</p>
      )}
      {integ.key === "mobile_calling" && (
        <p className="mt-4 text-sm text-slate-500 bg-slate-50 rounded-lg px-3 py-2">Recruiter Android companion / PWA dialer push. Configuration arrives in Phase 3.</p>
      )}

      {integ.last_error && <p className="mt-3 text-xs text-rose-600">Last error: {integ.last_error}</p>}
      {integ.last_sync && <p className="mt-1 text-xs text-slate-400">Last sync: {new Date(integ.last_sync).toLocaleString()}</p>}

      <div className="mt-4 flex flex-wrap gap-2">
        {fields.length > 0 && <button onClick={save} disabled={busy} className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-cyan-600 text-white text-sm font-medium hover:bg-cyan-700 disabled:opacity-60"><Save className="w-4 h-4" /> Save</button>}
        <button onClick={test} disabled={busy} className="flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-300 text-sm font-medium hover:bg-slate-50"><Zap className="w-4 h-4" /> Test connection</button>
        {integ.status === "connected" && <button onClick={disconnect} disabled={busy} className="flex items-center gap-1.5 px-3 py-2 rounded-lg border border-rose-200 text-rose-600 text-sm font-medium hover:bg-rose-50"><Link2Off className="w-4 h-4" /> Disconnect</button>}
        {busy && <Loader2 className="w-4 h-4 animate-spin text-cyan-600 self-center" />}
      </div>
    </div>
  );
}

export default function Integrations() {
  const [items, setItems] = React.useState([]);
  const [loading, setLoading] = React.useState(true);
  const load = () => { setLoading(true); api.get("/cms/integrations").then((r) => setItems(Array.isArray(r.data) ? r.data : [])).catch(() => setItems([])).finally(() => setLoading(false)); };
  React.useEffect(load, []);
  const onChange = (updated) => setItems((prev) => (Array.isArray(prev) ? prev : []).map((i) => (i.key === updated.key ? updated : i)));

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2"><Plug className="w-6 h-6 text-cyan-600" /> Integrations</h1>
        <p className="text-slate-500 text-sm mt-1">Connect lead channels & tools. All secrets are stored securely on the server — never exposed to the public website.</p>
      </div>
      {loading ? (
        <div className="py-16 flex justify-center"><Loader2 className="w-6 h-6 animate-spin text-cyan-600" /></div>
      ) : (
        <div className="grid gap-5 md:grid-cols-2">
          {(Array.isArray(items) ? items : []).map((i) => <IntegrationCard key={i.key} integ={i} onChange={onChange} />)}
        </div>
      )}
    </div>
  );
}
