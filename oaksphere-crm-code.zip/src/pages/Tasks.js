import { useState, useEffect, useCallback } from "react";
import api, { formatError } from "@/lib/api";
import { toast } from "sonner";
import { useAuth } from "@/context/AuthContext";
import { PageHeader, Loading, EmptyState } from "@/components/common";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  CheckSquare,
  Plus,
  Clock,
  AlertCircle,
  Calendar,
  User,
  Trash2,
  CheckCircle2,
  Filter,
  Search,
} from "lucide-react";

const CATEGORIES = [
  "Candidate follow-up",
  "Client follow-up",
  "Vendor follow-up",
  "Interview prep",
  "Marketing task",
  "General admin",
];

export default function Tasks() {
  const { user } = useAuth();
  const [tasks, setTasks] = useState(null);
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterPriority, setFilterPriority] = useState("all");
  const [search, setSearch] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  // Form state
  const [title, setTitle] = useState("");
  const [priority, setPriority] = useState("Medium");
  const [category, setCategory] = useState("Candidate follow-up");
  const [dueDate, setDueDate] = useState("");
  const [relatedName, setRelatedName] = useState("");
  const [notes, setNotes] = useState("");

  const loadTasks = useCallback(() => {
    setTasks(null);
    const params = new URLSearchParams();
    if (filterStatus !== "all") params.set("status", filterStatus);
    if (filterPriority !== "all") params.set("priority", filterPriority);
    api
      .get(`/tasks?${params.toString()}`)
      .then((r) => setTasks(r.data))
      .catch((err) => {
        toast.error("Failed to load tasks");
        setTasks([]);
      });
  }, [filterStatus, filterPriority]);

  useEffect(() => {
    loadTasks();
  }, [loadTasks]);

  const handleCreate = async (e) => {
    e.preventDefault();
    if (!title.trim()) {
      toast.error("Please enter a task title");
      return;
    }
    setSubmitting(true);
    try {
      await api.post("/tasks", {
        title,
        priority,
        category,
        due_date: dueDate ? new Date(dueDate).toISOString() : new Date(Date.now() + 86400000).toISOString(),
        related_name: relatedName,
        notes,
      });
      toast.success("Task created successfully");
      setDialogOpen(false);
      setTitle("");
      setRelatedName("");
      setNotes("");
      loadTasks();
    } catch (err) {
      toast.error(formatError(err.response?.data?.detail));
    } finally {
      setSubmitting(false);
    }
  };

  const toggleStatus = async (task) => {
    const nextStatus = task.status === "Completed" ? "Pending" : "Completed";
    try {
      await api.patch(`/tasks/${task.id}`, { status: nextStatus });
      toast.success(`Task marked as ${nextStatus}`);
      loadTasks();
    } catch (err) {
      toast.error("Could not update task status");
    }
  };

  const deleteTask = async (id) => {
    try {
      await api.delete(`/tasks/${id}`);
      toast.success("Task deleted");
      loadTasks();
    } catch (err) {
      toast.error("Could not delete task");
    }
  };

  const filteredTasks = (tasks || []).filter((t) => {
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return (
      t.title?.toLowerCase().includes(q) ||
      t.related_name?.toLowerCase().includes(q) ||
      t.owner_name?.toLowerCase().includes(q) ||
      t.notes?.toLowerCase().includes(q)
    );
  });

  const pendingCount = (tasks || []).filter((t) => t.status !== "Completed").length;
  const completedCount = (tasks || []).filter((t) => t.status === "Completed").length;
  const highPriorityCount = (tasks || []).filter((t) => t.priority === "High" && t.status !== "Completed").length;

  return (
    <div className="space-y-6" id="tasks-module-page">
      <PageHeader
        title="Tasks & Reminders"
        description="Track daily recruiter action items, client deadlines, lineup checks, and operational tasks."
        action={
          <Button
            onClick={() => setDialogOpen(true)}
            className="bg-[#2B1055] hover:bg-[#3d1878] text-white shadow-sm flex items-center gap-2"
            id="btn-new-task"
          >
            <Plus className="w-4 h-4" /> New Task
          </Button>
        }
      />

      {/* Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card className="p-4 border-l-4 border-l-amber-500 bg-white dark:bg-slate-900 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Pending Action Items</p>
              <p className="text-2xl font-bold text-slate-800 dark:text-white mt-1">{pendingCount}</p>
            </div>
            <Clock className="w-8 h-8 text-amber-500 opacity-80" />
          </div>
        </Card>

        <Card className="p-4 border-l-4 border-l-rose-500 bg-white dark:bg-slate-900 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">High Priority Tasks</p>
              <p className="text-2xl font-bold text-rose-600 mt-1">{highPriorityCount}</p>
            </div>
            <AlertCircle className="w-8 h-8 text-rose-500 opacity-80" />
          </div>
        </Card>

        <Card className="p-4 border-l-4 border-l-emerald-500 bg-white dark:bg-slate-900 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Completed Tasks</p>
              <p className="text-2xl font-bold text-emerald-600 mt-1">{completedCount}</p>
            </div>
            <CheckCircle2 className="w-8 h-8 text-emerald-500 opacity-80" />
          </div>
        </Card>
      </div>

      {/* Filters & Search */}
      <div className="flex flex-col sm:flex-row gap-3 items-center justify-between bg-white dark:bg-slate-900 p-3.5 rounded-lg border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex items-center gap-2 w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400" />
          <Input
            placeholder="Search tasks, candidate, company..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="h-9 text-sm"
          />
        </div>

        <div className="flex items-center gap-3 w-full sm:w-auto">
          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="w-36 h-9 text-xs">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="in progress">In Progress</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
            </SelectContent>
          </Select>

          <Select value={filterPriority} onValueChange={setFilterPriority}>
            <SelectTrigger className="w-36 h-9 text-xs">
              <SelectValue placeholder="Priority" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Priorities</SelectItem>
              <SelectItem value="high">High Priority</SelectItem>
              <SelectItem value="medium">Medium Priority</SelectItem>
              <SelectItem value="low">Low Priority</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Tasks List */}
      {tasks === null ? (
        <Loading />
      ) : filteredTasks.length === 0 ? (
        <EmptyState
          icon={CheckSquare}
          title="No tasks found"
          description="Everything is caught up! Create a new task to stay organized."
          action={
            <Button onClick={() => setDialogOpen(true)} variant="outline" size="sm">
              <Plus className="w-4 h-4 mr-1" /> Add First Task
            </Button>
          }
        />
      ) : (
        <div className="space-y-3">
          {filteredTasks.map((t) => {
            const isCompleted = t.status === "Completed";
            const isOverdue = !isCompleted && t.due_date && new Date(t.due_date) < new Date();

            return (
              <div
                key={t.id}
                id={`task-item-${t.id}`}
                className={`p-4 rounded-xl border bg-white dark:bg-slate-900 shadow-sm transition-all flex flex-col md:flex-row md:items-center justify-between gap-4 ${
                  isCompleted ? "opacity-60 bg-slate-50 border-slate-200 dark:border-slate-800" : "border-slate-200 dark:border-slate-800 hover:border-purple-300"
                }`}
              >
                <div className="flex items-start gap-3">
                  <button
                    onClick={() => toggleStatus(t)}
                    title={isCompleted ? "Mark as Pending" : "Mark as Completed"}
                    className={`mt-1 flex-shrink-0 w-5 h-5 rounded border flex items-center justify-center transition-colors ${
                      isCompleted ? "bg-emerald-600 border-emerald-600 text-white" : "border-slate-300 hover:border-purple-600 text-transparent"
                    }`}
                  >
                    <CheckCircle2 className="w-4 h-4" />
                  </button>

                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <h4
                        className={`text-sm font-semibold text-slate-900 dark:text-white ${
                          isCompleted ? "line-through text-slate-500" : ""
                        }`}
                      >
                        {t.title}
                      </h4>

                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase ${
                          t.priority === "High"
                            ? "bg-rose-100 text-rose-700"
                            : t.priority === "Medium"
                            ? "bg-amber-100 text-amber-700"
                            : "bg-blue-100 text-blue-700"
                        }`}
                      >
                        {t.priority}
                      </span>

                      <span className="text-[10px] font-medium bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 px-2 py-0.5 rounded">
                        {t.category}
                      </span>

                      {isOverdue && (
                        <span className="text-[10px] font-bold bg-rose-50 text-rose-600 border border-rose-200 px-2 py-0.5 rounded">
                          OVERDUE
                        </span>
                      )}
                    </div>

                    {t.notes && <p className="text-xs text-slate-500 mt-1 max-w-2xl">{t.notes}</p>}

                    <div className="flex items-center gap-4 mt-2 text-[11px] text-slate-400">
                      {t.due_date && (
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3.5 h-3.5" />
                          Due: {new Date(t.due_date).toLocaleDateString("en-IN", { month: "short", day: "numeric" })}
                        </span>
                      )}
                      {t.owner_name && (
                        <span className="flex items-center gap-1">
                          <User className="w-3.5 h-3.5" /> Assigned to: {t.owner_name}
                        </span>
                      )}
                      {t.related_name && (
                        <span className="font-medium text-slate-600 dark:text-slate-300">
                          Related: {t.related_name}
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-end md:self-center">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => toggleStatus(t)}
                    className="h-8 text-xs font-medium"
                  >
                    {isCompleted ? "Reopen" : "Done"}
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => deleteTask(t.id)}
                    className="h-8 w-8 p-0 text-slate-400 hover:text-rose-600"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Create Task Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-md bg-white dark:bg-slate-900">
          <DialogHeader>
            <DialogTitle>Create New Task</DialogTitle>
            <DialogDescription className="sr-only">Assign task, set priority, and schedule due date</DialogDescription>
          </DialogHeader>

          <form onSubmit={handleCreate} className="space-y-4 mt-2">
            <div>
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                Task Title *
              </label>
              <Input
                placeholder="e.g. Confirm Google Meet lineup for Pooja"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                required
                className="text-sm"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Category
                </label>
                <Select value={category} onValueChange={setCategory}>
                  <SelectTrigger className="text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {CATEGORIES.map((c) => (
                      <SelectItem key={c} value={c}>
                        {c}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Priority
                </label>
                <Select value={priority} onValueChange={setPriority}>
                  <SelectTrigger className="text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="High">High</SelectItem>
                    <SelectItem value="Medium">Medium</SelectItem>
                    <SelectItem value="Low">Low</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Due Date
                </label>
                <Input
                  type="date"
                  value={dueDate}
                  onChange={(e) => setDueDate(e.target.value)}
                  className="text-xs"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Related Contact / Entity
                </label>
                <Input
                  placeholder="e.g. Pooja Deshmukh"
                  value={relatedName}
                  onChange={(e) => setRelatedName(e.target.value)}
                  className="text-xs"
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                Notes & Reminders
              </label>
              <textarea
                placeholder="Specific instructions, meeting agenda, or follow-up details..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                rows={3}
                className="w-full text-xs p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 focus:outline-none focus:ring-1 focus:ring-purple-600"
              />
            </div>

            <DialogFooter className="pt-2">
              <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={submitting} className="bg-[#2B1055] text-white hover:bg-[#3c1775]">
                {submitting ? "Saving..." : "Create Task"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
