import React, { useState } from "react";
import {
  Briefcase,
  MapPin,
  Clock,
  Plus,
  Pencil,
  Copy,
  Trash2,
  CheckCircle2,
  AlertTriangle,
  ExternalLink,
  Code,
  Save,
  X,
  Layers,
  Search,
  Sparkles,
  ArrowRight,
} from "lucide-react";
import { toast } from "sonner";
import api, { formatError } from "@/lib/api";

export default function JobsTab({
  jobs = [],
  locations = [],
  services = [],
  onRefresh,
  onOpenAi,
}) {
  const [subTab, setSubTab] = useState("jobs"); // 'jobs' | 'locations' | 'services'
  const [jobStatusFilter, setJobStatusFilter] = useState("all");
  const [jobSearch, setJobSearch] = useState("");

  // Job Modal State
  const [editingJob, setEditingJob] = useState(null);
  const [isNewJob, setIsNewJob] = useState(false);
  const [savingJob, setSavingJob] = useState(false);
  const [schemaJob, setSchemaJob] = useState(null);

  // Location Modal State
  const [editingLocation, setEditingLocation] = useState(null);
  const [isNewLocation, setIsNewLocation] = useState(false);
  const [savingLocation, setSavingLocation] = useState(false);

  // Service Modal State
  const [editingService, setEditingService] = useState(null);
  const [isNewService, setIsNewService] = useState(false);
  const [savingService, setSavingService] = useState(false);

  // Filtered jobs
  const filteredJobs = jobs.filter((j) => {
    const matchesStatus =
      jobStatusFilter === "all" ||
      (j.status || "Active").toLowerCase() === jobStatusFilter.toLowerCase();
    const matchesSearch =
      (j.title || "").toLowerCase().includes(jobSearch.toLowerCase()) ||
      (j.location || "").toLowerCase().includes(jobSearch.toLowerCase()) ||
      (j.client_name || "").toLowerCase().includes(jobSearch.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  // Handle Save Job
  const handleSaveJob = async (e) => {
    e.preventDefault();
    setSavingJob(true);
    try {
      if (isNewJob) {
        await api.post("/api/cms/jobs", editingJob);
        toast.success(`Job "${editingJob.title}" posted successfully!`);
      } else {
        await api.patch(`/api/cms/jobs/${editingJob.id}`, editingJob);
        toast.success(`Job "${editingJob.title}" updated!`);
      }
      setEditingJob(null);
      setIsNewJob(false);
      onRefresh();
    } catch (err) {
      toast.error(formatError(err?.response?.data?.detail));
    } finally {
      setSavingJob(false);
    }
  };

  // Handle Expire Job (Google-compliant expired job automation)
  const handleExpireJob = async (id) => {
    try {
      const { data } = await api.post(`/api/cms/jobs/${id}/expire`);
      toast.success(data.message || "Job marked Expired with validThrough past date.");
      onRefresh();
    } catch (err) {
      toast.error(formatError(err?.response?.data?.detail));
    }
  };

  // Handle Duplicate Job
  const handleDuplicateJob = async (id) => {
    try {
      await api.post(`/api/cms/jobs/${id}/duplicate`);
      toast.success("Job vacancy cloned as Draft");
      onRefresh();
    } catch (err) {
      toast.error(formatError(err?.response?.data?.detail));
    }
  };

  // Handle Delete Job
  const handleDeleteJob = async (id) => {
    if (!window.confirm("Are you sure you want to delete this vacancy?")) return;
    try {
      await api.delete(`/api/cms/jobs/${id}`);
      toast.success("Job vacancy deleted");
      onRefresh();
    } catch (err) {
      toast.error(formatError(err?.response?.data?.detail));
    }
  };

  // Handle Save Location
  const handleSaveLocation = async (e) => {
    e.preventDefault();
    setSavingLocation(true);
    try {
      if (isNewLocation) {
        await api.post("/api/cms/locations", editingLocation);
        toast.success(`City location "${editingLocation.name}" created!`);
      } else {
        await api.patch(`/api/cms/locations/${editingLocation.id}`, editingLocation);
        toast.success(`Location "${editingLocation.name}" updated!`);
      }
      setEditingLocation(null);
      setIsNewLocation(false);
      onRefresh();
    } catch (err) {
      toast.error(formatError(err?.response?.data?.detail));
    } finally {
      setSavingLocation(false);
    }
  };

  // Handle Save Service
  const handleSaveService = async (e) => {
    e.preventDefault();
    setSavingService(true);
    try {
      if (isNewService) {
        await api.post("/api/cms/services", editingService);
        toast.success(`Service "${editingService.name}" created!`);
      } else {
        await api.patch(`/api/cms/services/${editingService.id}`, editingService);
        toast.success(`Service "${editingService.name}" updated!`);
      }
      setEditingService(null);
      setIsNewService(false);
      onRefresh();
    } catch (err) {
      toast.error(formatError(err?.response?.data?.detail));
    } finally {
      setSavingService(false);
    }
  };

  // Generate Google Job Schema JSON-LD for preview
  const generateJobSchema = (job) => {
    const validThrough =
      job.valid_through || new Date(Date.now() + 60 * 24 * 60 * 60 * 1000).toISOString();
    return {
      "@context": "https://schema.org",
      "@type": "JobPosting",
      title: job.title,
      description: job.description || "Exciting vacancy with verified enterprise employer.",
      identifier: {
        "@type": "PropertyValue",
        name: "OAKSphere Connect",
        value: job.id,
      },
      datePosted: job.created_at ? job.created_at.split("T")[0] : "2026-09-01",
      validThrough: validThrough.split("T")[0],
      employmentType: job.employment_type || "FULL_TIME",
      hiringOrganization: {
        "@type": "Organization",
        name: job.client_name || "Enterprise Client via OAKSphere Connect",
        sameAs: "https://oaksphereconnect.com",
      },
      jobLocation: {
        "@type": "Place",
        address: {
          "@type": "PostalAddress",
          addressLocality: job.location || "Pune",
          addressRegion: "Maharashtra",
          addressCountry: "IN",
        },
      },
      baseSalary: {
        "@type": "MonetaryAmount",
        currency: "INR",
        value: {
          "@type": "QuantitativeValue",
          value: job.salary_range || "Competitive",
          unitText: "YEAR",
        },
      },
      applicantLocationRequirements: {
        "@type": "Country",
        name: "India",
      },
      directApply: true,
    };
  };

  return (
    <div className="space-y-6">
      {/* Sub-navigation tabs */}
      <div className="flex items-center justify-between border-b border-slate-200 pb-3">
        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => setSubTab("jobs")}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-colors ${
              subTab === "jobs"
                ? "bg-slate-900 text-white"
                : "bg-slate-100 text-slate-700 hover:bg-slate-200"
            }`}
          >
            Job Vacancies & Schema ({jobs.length})
          </button>
          <button
            type="button"
            onClick={() => setSubTab("locations")}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-colors ${
              subTab === "locations"
                ? "bg-slate-900 text-white"
                : "bg-slate-100 text-slate-700 hover:bg-slate-200"
            }`}
          >
            Location Hubs ({locations.length})
          </button>
          <button
            type="button"
            onClick={() => setSubTab("services")}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-colors ${
              subTab === "services"
                ? "bg-slate-900 text-white"
                : "bg-slate-100 text-slate-700 hover:bg-slate-200"
            }`}
          >
            Hiring Services ({services.length})
          </button>
        </div>

        {subTab === "jobs" && (
          <button
            type="button"
            onClick={() => {
              setIsNewJob(true);
              setEditingJob({
                title: "Senior Full Stack Developer",
                slug: "senior-full-stack-developer-pune",
                client_name: "FinTech Enterprise Client",
                location: "Pune, India (Hybrid)",
                experience: "3-6 years",
                salary_range: "₹12,00,000 - ₹18,00,000 / year",
                positions: 2,
                status: "Active",
                category: "IT / Software",
                industry: "Information Technology",
                employment_type: "FULL_TIME",
                valid_through: new Date(Date.now() + 45 * 24 * 60 * 60 * 1000).toISOString(),
                description:
                  "Lead full-stack engineering across Node.js and React architectures with our premier client in Pune.",
                requirements: [
                  "3+ years React & Node.js experience",
                  "Strong REST API and database knowledge",
                  "Excellent analytical problem solving",
                ],
                direct_apply_url: "",
              });
            }}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 text-white text-xs font-semibold shadow-xs hover:bg-indigo-700 transition-colors cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" /> Post Job Vacancy
          </button>
        )}

        {subTab === "locations" && (
          <button
            type="button"
            onClick={() => {
              setIsNewLocation(true);
              setEditingLocation({
                name: "Nagpur",
                slug: "nagpur",
                state: "Maharashtra",
                address: "MIHAN SEZ, Nagpur, Maharashtra 441108",
                pincodes: "440001, 440010, 441108",
                landmark: "Near Airport Metro Station",
                phone: "+91 91728 55909",
                email: "nagpur@oaksphereconnect.com",
                lat: 21.1458,
                lng: 79.0882,
                hiring_focus: ["IT SEZ", "BPO & KPO", "Manufacturing"],
                active_jobs_count: 8,
                meta_title: "Jobs in Nagpur 2026 | Recruitment Agency | OAKSphere Connect",
                meta_description:
                  "Explore top job openings in Nagpur. Premier staffing and placement partner for MIHAN SEZ and IT corridors.",
                h1: "Leading Recruitment Agency in Nagpur",
                intro_content:
                  "OAKSphere Connect is the verified hiring partner for top IT, BPO, and enterprise brands in Nagpur.",
                geo_radius_km: 30,
              });
            }}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 text-white text-xs font-semibold shadow-xs hover:bg-indigo-700 transition-colors cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" /> Add City Hub
          </button>
        )}

        {subTab === "services" && (
          <button
            type="button"
            onClick={() => {
              setIsNewService(true);
              setEditingService({
                name: "Executive Search & Leadership",
                slug: "executive-search",
                category: "Leadership",
                icon: "Shield",
                short_desc: "Confidential C-suite and VP talent acquisition.",
                full_desc: "Bespoke headhunting and leadership recruitment with 98% retention.",
                deliverables: ["Dedicated Partner Consultant", "Confidential Mandate", "30-Day SLA"],
                turnaround: "14 Days",
                commercial_model: "Retained / Milestone",
                roles_covered: ["CTO", "VP Engineering", "Head of HR", "Director"],
                meta_title: "Executive Search India | C-Suite Recruitment | OAKSphere Connect",
                meta_description: "Confidential executive search services for leadership roles across India.",
                h1: "Executive Search & Leadership Recruitment",
                active: true,
              });
            }}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 text-white text-xs font-semibold shadow-xs hover:bg-indigo-700 transition-colors cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" /> Add Service
          </button>
        )}
      </div>

      {/* SUBTAB 1: JOB VACANCIES */}
      {subTab === "jobs" && (
        <div className="space-y-4">
          {/* Filter Bar */}
          <div className="flex flex-col sm:flex-row gap-3 items-center justify-between">
            <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto">
              {["all", "active", "expired", "draft", "closed"].map((st) => (
                <button
                  key={st}
                  type="button"
                  onClick={() => setJobStatusFilter(st)}
                  className={`px-2.5 py-1 rounded-md text-xs font-medium capitalize whitespace-nowrap cursor-pointer ${
                    jobStatusFilter === st
                      ? "bg-indigo-50 text-indigo-700 border border-indigo-200"
                      : "text-slate-600 hover:bg-slate-100"
                  }`}
                >
                  {st === "all" ? "All Statuses" : st}
                </button>
              ))}
            </div>

            <div className="w-full sm:w-64">
              <input
                type="text"
                value={jobSearch}
                onChange={(e) => setJobSearch(e.target.value)}
                placeholder="Search job title, city, client..."
                className="w-full h-8 px-3 rounded-lg border border-slate-300 text-xs outline-none focus:border-indigo-500"
              />
            </div>
          </div>

          {/* Jobs Table */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-600">
                <thead className="bg-slate-50 text-[11px] font-semibold text-slate-700 uppercase tracking-wider border-b border-slate-200">
                  <tr>
                    <th className="px-4 py-3">Job Title & Slug</th>
                    <th className="px-4 py-3">Client</th>
                    <th className="px-4 py-3">Location</th>
                    <th className="px-4 py-3">Salary & Exp</th>
                    <th className="px-4 py-3">Status</th>
                    <th className="px-4 py-3">Google Schema</th>
                    <th className="px-4 py-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredJobs.map((job) => (
                    <tr key={job.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="px-4 py-3">
                        <div className="font-semibold text-slate-900">{job.title}</div>
                        <div className="text-[11px] text-indigo-600 font-mono flex items-center gap-1">
                          /jobs/{job.slug}
                          <a
                            href={`/jobs/${job.slug}`}
                            target="_blank"
                            rel="noreferrer"
                            className="text-slate-400 hover:text-indigo-600"
                          >
                            <ExternalLink className="w-3 h-3" />
                          </a>
                        </div>
                      </td>
                      <td className="px-4 py-3 font-medium text-slate-800">
                        {job.client_name || "Enterprise"}
                      </td>
                      <td className="px-4 py-3">
                        <span className="inline-flex items-center gap-1 text-slate-700">
                          <MapPin className="w-3 h-3 text-slate-400" /> {job.location || "Pune"}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <div className="font-semibold text-slate-900">
                          {job.salary_range || "Competitive"}
                        </div>
                        <span className="text-[11px] text-slate-500">
                          {job.experience || "2-5 yrs"}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                            job.status === "Active" || job.status === "published"
                              ? "bg-emerald-100 text-emerald-800"
                              : job.status === "Expired"
                              ? "bg-red-100 text-red-800"
                              : "bg-slate-100 text-slate-800"
                          }`}
                        >
                          {job.status || "Active"}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <button
                          type="button"
                          onClick={() => setSchemaJob(job)}
                          className="inline-flex items-center gap-1 text-[11px] font-semibold text-indigo-600 hover:text-indigo-800 bg-indigo-50 px-2 py-1 rounded"
                        >
                          <Code className="w-3 h-3" /> JobPosting LD
                        </button>
                      </td>
                      <td className="px-4 py-3 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {job.status !== "Expired" && (
                            <button
                              type="button"
                              onClick={() => handleExpireJob(job.id)}
                              className="px-2 py-1 rounded text-[10px] font-semibold text-amber-700 bg-amber-50 hover:bg-amber-100 cursor-pointer"
                              title="Set status to Expired and validThrough in past for Google SEO compliance"
                            >
                              Expire Vacancy
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => {
                              setIsNewJob(false);
                              setEditingJob({ ...job });
                            }}
                            className="p-1.5 rounded-md hover:bg-slate-100 text-slate-600 hover:text-indigo-600 cursor-pointer"
                            title="Edit Job"
                          >
                            <Pencil className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDuplicateJob(job.id)}
                            className="p-1.5 rounded-md hover:bg-slate-100 text-slate-600 hover:text-slate-900 cursor-pointer"
                            title="Clone Job"
                          >
                            <Copy className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeleteJob(job.id)}
                            className="p-1.5 rounded-md hover:bg-red-50 text-slate-400 hover:text-red-600 cursor-pointer"
                            title="Delete Job"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* SUBTAB 2: LOCATION HUBS */}
      {subTab === "locations" && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {locations.map((loc) => (
            <div
              key={loc.id}
              className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between">
                  <div>
                    <h4 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                      <MapPin className="w-4 h-4 text-indigo-600" /> {loc.name}, {loc.state}
                    </h4>
                    <span className="text-[11px] font-mono text-indigo-600">
                      /location/{loc.slug}
                    </span>
                  </div>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-50 text-indigo-700">
                    {loc.active_jobs_count || 0} Vacancies
                  </span>
                </div>

                <p className="text-xs text-slate-600 mt-3 line-clamp-2">
                  {loc.address || "Local branch details configured for NAP consistency."}
                </p>

                <div className="mt-3 flex flex-wrap gap-1">
                  {(loc.hiring_focus || []).map((tag, i) => (
                    <span
                      key={i}
                      className="px-1.5 py-0.5 rounded text-[10px] bg-slate-100 text-slate-600"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>

              <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                <span className="text-[11px] text-slate-400">
                  Geo: {loc.lat?.toFixed(2)}, {loc.lng?.toFixed(2)}
                </span>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setIsNewLocation(false);
                      setEditingLocation({ ...loc });
                    }}
                    className="font-semibold text-indigo-600 hover:text-indigo-800"
                  >
                    Edit Hub
                  </button>
                  <a
                    href={`/location/${loc.slug}`}
                    target="_blank"
                    rel="noreferrer"
                    className="text-slate-400 hover:text-slate-600"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* SUBTAB 3: SERVICES */}
      {subTab === "services" && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {services.map((srv) => (
            <div
              key={srv.id}
              className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between">
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-slate-100 text-slate-700">
                    {srv.category}
                  </span>
                  <span className="text-[11px] font-semibold text-emerald-600">
                    {srv.turnaround}
                  </span>
                </div>

                <h4 className="text-sm font-bold text-slate-900 mt-2">{srv.name}</h4>
                <p className="text-xs text-slate-600 mt-1 line-clamp-2">
                  {srv.short_desc || srv.full_desc}
                </p>

                <div className="mt-3 space-y-1">
                  {(srv.deliverables || []).map((d, i) => (
                    <div key={i} className="flex items-center gap-1.5 text-[11px] text-slate-600">
                      <CheckCircle2 className="w-3 h-3 text-indigo-600 shrink-0" />
                      <span>{d}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                <span className="text-[11px] text-slate-400 font-mono">
                  {srv.commercial_model}
                </span>
                <button
                  type="button"
                  onClick={() => {
                    setIsNewService(false);
                    setEditingService({ ...srv });
                  }}
                  className="font-semibold text-indigo-600 hover:text-indigo-800"
                >
                  Edit Service
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* EDIT JOB MODAL */}
      {editingJob && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-3xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-2">
                <Briefcase className="w-5 h-5 text-indigo-600" />
                <h3 className="text-base font-bold text-slate-900">
                  {isNewJob ? "Post New Vacancy" : `Edit Job: ${editingJob.title}`}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setEditingJob(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200/60"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveJob} className="p-6 overflow-y-auto space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="sm:col-span-2">
                  <label className="font-semibold text-slate-700">Job Title</label>
                  <input
                    type="text"
                    required
                    value={editingJob.title || ""}
                    onChange={(e) => setEditingJob({ ...editingJob, title: e.target.value })}
                    className="w-full h-9 px-3 mt-1 rounded-lg border border-slate-300"
                  />
                </div>

                <div>
                  <label className="font-semibold text-slate-700">URL Slug</label>
                  <input
                    type="text"
                    required
                    value={editingJob.slug || ""}
                    onChange={(e) => setEditingJob({ ...editingJob, slug: e.target.value })}
                    className="w-full h-9 px-3 mt-1 rounded-lg border border-slate-300 font-mono"
                  />
                </div>

                <div>
                  <label className="font-semibold text-slate-700">Hiring Client / Company</label>
                  <input
                    type="text"
                    value={editingJob.client_name || ""}
                    onChange={(e) => setEditingJob({ ...editingJob, client_name: e.target.value })}
                    className="w-full h-9 px-3 mt-1 rounded-lg border border-slate-300"
                  />
                </div>

                <div>
                  <label className="font-semibold text-slate-700">Location (City, Work Model)</label>
                  <input
                    type="text"
                    value={editingJob.location || ""}
                    onChange={(e) => setEditingJob({ ...editingJob, location: e.target.value })}
                    placeholder="E.g. Pune, India (Hybrid)"
                    className="w-full h-9 px-3 mt-1 rounded-lg border border-slate-300"
                  />
                </div>

                <div>
                  <label className="font-semibold text-slate-700">Employment Type</label>
                  <select
                    value={editingJob.employment_type || "FULL_TIME"}
                    onChange={(e) => setEditingJob({ ...editingJob, employment_type: e.target.value })}
                    className="w-full h-9 px-3 mt-1 rounded-lg border border-slate-300 bg-white"
                  >
                    <option value="FULL_TIME">FULL_TIME</option>
                    <option value="PART_TIME">PART_TIME</option>
                    <option value="CONTRACT">CONTRACT</option>
                    <option value="INTERN">INTERN</option>
                  </select>
                </div>

                <div>
                  <label className="font-semibold text-slate-700">Salary Range (Annual CTC)</label>
                  <input
                    type="text"
                    value={editingJob.salary_range || ""}
                    onChange={(e) => setEditingJob({ ...editingJob, salary_range: e.target.value })}
                    placeholder="E.g. ₹6,00,000 - ₹10,00,000"
                    className="w-full h-9 px-3 mt-1 rounded-lg border border-slate-300"
                  />
                </div>

                <div>
                  <label className="font-semibold text-slate-700">Experience Required</label>
                  <input
                    type="text"
                    value={editingJob.experience || ""}
                    onChange={(e) => setEditingJob({ ...editingJob, experience: e.target.value })}
                    placeholder="E.g. 2-5 years"
                    className="w-full h-9 px-3 mt-1 rounded-lg border border-slate-300"
                  />
                </div>

                <div>
                  <label className="font-semibold text-slate-700">Job Status</label>
                  <select
                    value={editingJob.status || "Active"}
                    onChange={(e) => setEditingJob({ ...editingJob, status: e.target.value })}
                    className="w-full h-9 px-3 mt-1 rounded-lg border border-slate-300 bg-white"
                  >
                    <option value="Active">Active (Indexed)</option>
                    <option value="Draft">Draft</option>
                    <option value="Expired">Expired (Auto 410 / validThrough past)</option>
                    <option value="Closed">Closed</option>
                  </select>
                </div>

                <div>
                  <label className="font-semibold text-slate-700">Valid Through (Expiry Date)</label>
                  <input
                    type="date"
                    value={
                      editingJob.valid_through
                        ? editingJob.valid_through.split("T")[0]
                        : ""
                    }
                    onChange={(e) =>
                      setEditingJob({
                        ...editingJob,
                        valid_through: new Date(e.target.value).toISOString(),
                      })
                    }
                    className="w-full h-9 px-3 mt-1 rounded-lg border border-slate-300"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="font-semibold text-slate-700">Job Description</label>
                  <textarea
                    rows={4}
                    value={editingJob.description || ""}
                    onChange={(e) => setEditingJob({ ...editingJob, description: e.target.value })}
                    className="w-full p-2.5 mt-1 rounded-lg border border-slate-300"
                  />
                </div>
              </div>

              <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setEditingJob(null)}
                  className="px-4 py-2 rounded-lg border border-slate-300 text-xs font-semibold text-slate-700 hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={savingJob}
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-indigo-600 text-white text-xs font-semibold shadow-xs hover:bg-indigo-700 disabled:opacity-60"
                >
                  <Save className="w-3.5 h-3.5" />
                  {savingJob ? "Saving..." : "Save Vacancy"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* SCHEMA VALIDATOR MODAL */}
      {schemaJob && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[85vh] flex flex-col shadow-2xl overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <div>
                <h3 className="text-sm font-bold text-slate-900">
                  Google Job Search JSON-LD Schema
                </h3>
                <p className="text-[11px] text-slate-500">
                  Compliant with Schema.org & Google India Job Search specifications
                </p>
              </div>
              <button
                type="button"
                onClick={() => setSchemaJob(null)}
                className="p-1 rounded text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 overflow-y-auto space-y-4">
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="flex items-center gap-1.5 text-emerald-700 font-medium">
                  <CheckCircle2 className="w-4 h-4" /> title verified
                </div>
                <div className="flex items-center gap-1.5 text-emerald-700 font-medium">
                  <CheckCircle2 className="w-4 h-4" /> hiringOrganization verified
                </div>
                <div className="flex items-center gap-1.5 text-emerald-700 font-medium">
                  <CheckCircle2 className="w-4 h-4" /> datePosted & validThrough
                </div>
                <div className="flex items-center gap-1.5 text-emerald-700 font-medium">
                  <CheckCircle2 className="w-4 h-4" /> jobLocation & baseSalary
                </div>
              </div>

              <div className="relative">
                <pre className="p-4 rounded-xl bg-slate-900 text-slate-100 font-mono text-[11px] overflow-x-auto max-h-80 leading-relaxed">
                  {JSON.stringify(generateJobSchema(schemaJob), null, 2)}
                </pre>
              </div>
            </div>

            <div className="px-6 py-3 border-t border-slate-200 flex justify-between items-center bg-slate-50 text-xs">
              <a
                href="https://search.google.com/test/rich-results"
                target="_blank"
                rel="noreferrer"
                className="text-indigo-600 hover:underline inline-flex items-center gap-1"
              >
                Test in Google Rich Results Test <ExternalLink className="w-3 h-3" />
              </a>
              <button
                type="button"
                onClick={() => {
                  navigator.clipboard.writeText(
                    JSON.stringify(generateJobSchema(schemaJob), null, 2)
                  );
                  toast.success("JobPosting JSON-LD copied to clipboard!");
                }}
                className="px-3 py-1.5 rounded-lg bg-slate-800 text-white font-semibold hover:bg-slate-700"
              >
                Copy JSON-LD
              </button>
            </div>
          </div>
        </div>
      )}

      {/* EDIT LOCATION MODAL */}
      {editingLocation && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-xl w-full shadow-2xl p-6 space-y-4">
            <h3 className="text-base font-bold text-slate-900">
              {isNewLocation ? "Add City Location Hub" : `Edit Hub: ${editingLocation.name}`}
            </h3>
            <form onSubmit={handleSaveLocation} className="space-y-3 text-xs">
              <div>
                <label className="font-semibold text-slate-700">City Name</label>
                <input
                  type="text"
                  required
                  value={editingLocation.name}
                  onChange={(e) =>
                    setEditingLocation({ ...editingLocation, name: e.target.value })
                  }
                  className="w-full h-9 px-3 mt-1 rounded-lg border border-slate-300"
                />
              </div>
              <div>
                <label className="font-semibold text-slate-700">Office Address (Local NAP)</label>
                <input
                  type="text"
                  value={editingLocation.address || ""}
                  onChange={(e) =>
                    setEditingLocation({ ...editingLocation, address: e.target.value })
                  }
                  className="w-full h-9 px-3 mt-1 rounded-lg border border-slate-300"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700">Latitude</label>
                  <input
                    type="number"
                    step="0.0001"
                    value={editingLocation.lat || 18.52}
                    onChange={(e) =>
                      setEditingLocation({ ...editingLocation, lat: parseFloat(e.target.value) })
                    }
                    className="w-full h-9 px-3 mt-1 rounded-lg border border-slate-300"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700">Longitude</label>
                  <input
                    type="number"
                    step="0.0001"
                    value={editingLocation.lng || 73.85}
                    onChange={(e) =>
                      setEditingLocation({ ...editingLocation, lng: parseFloat(e.target.value) })
                    }
                    className="w-full h-9 px-3 mt-1 rounded-lg border border-slate-300"
                  />
                </div>
              </div>
              <div className="pt-3 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setEditingLocation(null)}
                  className="px-4 py-2 rounded-lg border border-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={savingLocation}
                  className="px-4 py-2 rounded-lg bg-indigo-600 text-white font-semibold"
                >
                  Save Hub
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* EDIT SERVICE MODAL */}
      {editingService && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-xl w-full shadow-2xl p-6 space-y-4">
            <h3 className="text-base font-bold text-slate-900">
              {isNewService ? "Create Service" : `Edit Service: ${editingService.name}`}
            </h3>
            <form onSubmit={handleSaveService} className="space-y-3 text-xs">
              <div>
                <label className="font-semibold text-slate-700">Service Name</label>
                <input
                  type="text"
                  required
                  value={editingService.name}
                  onChange={(e) =>
                    setEditingService({ ...editingService, name: e.target.value })
                  }
                  className="w-full h-9 px-3 mt-1 rounded-lg border border-slate-300"
                />
              </div>
              <div>
                <label className="font-semibold text-slate-700">Category</label>
                <input
                  type="text"
                  value={editingService.category || ""}
                  onChange={(e) =>
                    setEditingService({ ...editingService, category: e.target.value })
                  }
                  className="w-full h-9 px-3 mt-1 rounded-lg border border-slate-300"
                />
              </div>
              <div>
                <label className="font-semibold text-slate-700">Turnaround SLA</label>
                <input
                  type="text"
                  value={editingService.turnaround || ""}
                  onChange={(e) =>
                    setEditingService({ ...editingService, turnaround: e.target.value })
                  }
                  placeholder="E.g. 48 Hours"
                  className="w-full h-9 px-3 mt-1 rounded-lg border border-slate-300"
                />
              </div>
              <div className="pt-3 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setEditingService(null)}
                  className="px-4 py-2 rounded-lg border border-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={savingService}
                  className="px-4 py-2 rounded-lg bg-indigo-600 text-white font-semibold"
                >
                  Save Service
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
