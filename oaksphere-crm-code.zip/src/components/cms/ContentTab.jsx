import React, { useState } from "react";
import {
  FileText,
  MessageSquare,
  HelpCircle,
  Users,
  Award,
  Plus,
  Pencil,
  Trash2,
  ExternalLink,
  Save,
  X,
  Sparkles,
  CheckCircle2,
} from "lucide-react";
import { toast } from "sonner";
import api, { formatError } from "@/lib/api";

export default function ContentTab({
  blogs = [],
  faqs = [],
  testimonials = [],
  clientLogos = [],
  onRefresh,
  onOpenAi,
}) {
  const [subTab, setSubTab] = useState("blogs"); // 'blogs' | 'faqs' | 'testimonials' | 'clients'

  // Blog State
  const [editingBlog, setEditingBlog] = useState(null);
  const [isNewBlog, setIsNewBlog] = useState(false);
  const [savingBlog, setSavingBlog] = useState(false);

  // FAQ State
  const [editingFaq, setEditingFaq] = useState(null);
  const [isNewFaq, setIsNewFaq] = useState(false);
  const [savingFaq, setSavingFaq] = useState(false);

  // Save Blog
  const handleSaveBlog = async (e) => {
    e.preventDefault();
    setSavingBlog(true);
    try {
      if (isNewBlog) {
        await api.post("/api/cms/blogs", editingBlog);
        toast.success(`Article "${editingBlog.title}" published!`);
      } else {
        await api.patch(`/api/cms/blogs/${editingBlog.id}`, editingBlog);
        toast.success(`Article "${editingBlog.title}" updated!`);
      }
      setEditingBlog(null);
      setIsNewBlog(false);
      onRefresh();
    } catch (err) {
      toast.error(formatError(err?.response?.data?.detail));
    } finally {
      setSavingBlog(false);
    }
  };

  // Delete Blog
  const handleDeleteBlog = async (id) => {
    if (!window.confirm("Are you sure you want to delete this blog post?")) return;
    try {
      await api.delete(`/api/cms/blogs/${id}`);
      toast.success("Blog post deleted");
      onRefresh();
    } catch (err) {
      toast.error(formatError(err?.response?.data?.detail));
    }
  };

  // Save FAQ
  const handleSaveFaq = async (e) => {
    e.preventDefault();
    setSavingFaq(true);
    try {
      if (isNewFaq) {
        await api.post("/api/cms/faqs", editingFaq);
        toast.success("FAQ created!");
      } else {
        await api.patch(`/api/cms/faqs/${editingFaq.id}`, editingFaq);
        toast.success("FAQ updated!");
      }
      setEditingFaq(null);
      setIsNewFaq(false);
      onRefresh();
    } catch (err) {
      toast.error(formatError(err?.response?.data?.detail));
    } finally {
      setSavingFaq(false);
    }
  };

  // Delete FAQ
  const handleDeleteFaq = async (id) => {
    try {
      await api.delete(`/api/cms/faqs/${id}`);
      toast.success("FAQ deleted");
      onRefresh();
    } catch (err) {
      toast.error(formatError(err?.response?.data?.detail));
    }
  };

  return (
    <div className="space-y-6">
      {/* Sub-nav */}
      <div className="flex items-center justify-between border-b border-slate-200 pb-3">
        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => setSubTab("blogs")}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold cursor-pointer ${
              subTab === "blogs" ? "bg-slate-900 text-white" : "bg-slate-100 text-slate-700"
            }`}
          >
            Insights & Articles ({blogs.length})
          </button>
          <button
            type="button"
            onClick={() => setSubTab("faqs")}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold cursor-pointer ${
              subTab === "faqs" ? "bg-slate-900 text-white" : "bg-slate-100 text-slate-700"
            }`}
          >
            FAQs ({faqs.length})
          </button>
          <button
            type="button"
            onClick={() => setSubTab("testimonials")}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold cursor-pointer ${
              subTab === "testimonials" ? "bg-slate-900 text-white" : "bg-slate-100 text-slate-700"
            }`}
          >
            Client Reviews ({testimonials.length})
          </button>
        </div>

        {subTab === "blogs" && (
          <button
            type="button"
            onClick={() => {
              setIsNewBlog(true);
              setEditingBlog({
                title: "Top IT & BPO Hiring Trends in Maharashtra 2026",
                slug: "it-bpo-hiring-trends-maharashtra-2026",
                excerpt:
                  "How GCC expansion in Pune and Navi Mumbai is redefining salary benchmarks and skill requirements.",
                content:
                  "Enterprise GCCs and Fortune 500 delivery centers across Pune and Mumbai are accelerating lateral hiring...",
                author: "OAKSphere Research",
                read_time: "5 min read",
                tags: ["BPO Hiring", "IT Staffing", "Market Insights"],
                status: "published",
                meta_title: "IT & BPO Hiring Trends 2026 | OAKSphere Connect Insights",
                meta_description:
                  "Explore recruitment trends and salary benchmarks across Pune and Mumbai GCC corridors.",
              });
            }}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 text-white text-xs font-semibold"
          >
            <Plus className="w-3.5 h-3.5" /> Write Article
          </button>
        )}

        {subTab === "faqs" && (
          <button
            type="button"
            onClick={() => {
              setIsNewFaq(true);
              setEditingFaq({
                question: "What is OAKSphere's recruitment turnaround SLA for urgent mandates?",
                answer:
                  "For critical BPO and IT requirements, our dedicated recruiters deliver the first batch of prescreened candidates within 48 hours.",
                category: "general",
              });
            }}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 text-white text-xs font-semibold"
          >
            <Plus className="w-3.5 h-3.5" /> Add FAQ
          </button>
        )}
      </div>

      {/* SUBTAB 1: BLOGS */}
      {subTab === "blogs" && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {blogs.map((b) => (
            <div
              key={b.id}
              className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between text-slate-400 text-xs">
                  <span>{b.read_time}</span>
                  <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-50 text-emerald-700">
                    {b.status}
                  </span>
                </div>
                <h4 className="font-bold text-sm text-slate-900 mt-2">{b.title}</h4>
                <p className="text-xs text-slate-600 mt-1 line-clamp-3">{b.excerpt}</p>
                <div className="mt-3 flex flex-wrap gap-1">
                  {(b.tags || []).map((t, i) => (
                    <span
                      key={i}
                      className="px-1.5 py-0.5 rounded text-[10px] bg-slate-100 text-slate-600"
                    >
                      {t}
                    </span>
                  ))}
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                <span className="text-slate-400 font-mono text-[11px]">/insights/{b.slug}</span>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setIsNewBlog(false);
                      setEditingBlog({ ...b });
                    }}
                    className="text-indigo-600 font-semibold hover:underline"
                  >
                    Edit
                  </button>
                  <button
                    type="button"
                    onClick={() => handleDeleteBlog(b.id)}
                    className="text-slate-400 hover:text-red-600"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* SUBTAB 2: FAQS */}
      {subTab === "faqs" && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs divide-y divide-slate-100">
          {faqs.map((f) => (
            <div key={f.id} className="p-4 flex items-start justify-between gap-4">
              <div className="space-y-1 flex-1">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-xs text-slate-900">{f.question}</span>
                  <span className="px-1.5 py-0.5 rounded text-[10px] bg-slate-100 text-slate-600 capitalize">
                    {f.category}
                  </span>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">{f.answer}</p>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => {
                    setIsNewFaq(false);
                    setEditingFaq({ ...f });
                  }}
                  className="p-1 rounded text-slate-500 hover:text-indigo-600"
                >
                  <Pencil className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() => handleDeleteFaq(f.id)}
                  className="p-1 rounded text-slate-400 hover:text-red-600"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* SUBTAB 3: TESTIMONIALS */}
      {subTab === "testimonials" && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {testimonials.map((t) => (
            <div
              key={t.id}
              className="p-5 rounded-xl bg-white border border-slate-200 shadow-xs space-y-2 flex flex-col justify-between"
            >
              <p className="text-xs text-slate-700 italic">"{t.quote}"</p>
              <div className="pt-2 border-t border-slate-100">
                <div className="font-bold text-xs text-slate-900">{t.author}</div>
                <div className="text-[11px] text-slate-500">
                  {t.role}, {t.company}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* EDIT BLOG MODAL */}
      {editingBlog && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[85vh] flex flex-col shadow-2xl p-6 space-y-4">
            <h3 className="text-base font-bold text-slate-900">
              {isNewBlog ? "Write Blog Article" : `Edit Article: ${editingBlog.title}`}
            </h3>
            <form onSubmit={handleSaveBlog} className="space-y-3 overflow-y-auto text-xs">
              <div>
                <label className="font-semibold text-slate-700">Article Title</label>
                <input
                  type="text"
                  required
                  value={editingBlog.title}
                  onChange={(e) => setEditingBlog({ ...editingBlog, title: e.target.value })}
                  className="w-full h-9 px-3 mt-1 rounded-lg border border-slate-300"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700">Slug</label>
                <input
                  type="text"
                  required
                  value={editingBlog.slug}
                  onChange={(e) => setEditingBlog({ ...editingBlog, slug: e.target.value })}
                  className="w-full h-9 px-3 mt-1 rounded-lg border border-slate-300 font-mono"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700">Summary / Excerpt</label>
                <textarea
                  rows={2}
                  value={editingBlog.excerpt || ""}
                  onChange={(e) => setEditingBlog({ ...editingBlog, excerpt: e.target.value })}
                  className="w-full p-2 mt-1 rounded-lg border border-slate-300"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700">Article Content (Markdown)</label>
                <textarea
                  rows={6}
                  value={editingBlog.content || ""}
                  onChange={(e) => setEditingBlog({ ...editingBlog, content: e.target.value })}
                  className="w-full p-2 mt-1 rounded-lg border border-slate-300 font-mono text-xs"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setEditingBlog(null)}
                  className="px-4 py-2 rounded-lg border border-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={savingBlog}
                  className="px-4 py-2 rounded-lg bg-indigo-600 text-white font-semibold"
                >
                  Save Article
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* EDIT FAQ MODAL */}
      {editingFaq && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full shadow-2xl p-6 space-y-4">
            <h3 className="text-base font-bold text-slate-900">
              {isNewFaq ? "Create FAQ" : "Edit FAQ"}
            </h3>
            <form onSubmit={handleSaveFaq} className="space-y-3 text-xs">
              <div>
                <label className="font-semibold text-slate-700">Question</label>
                <input
                  type="text"
                  required
                  value={editingFaq.question}
                  onChange={(e) => setEditingFaq({ ...editingFaq, question: e.target.value })}
                  className="w-full h-9 px-3 mt-1 rounded-lg border border-slate-300"
                />
              </div>
              <div>
                <label className="font-semibold text-slate-700">Answer</label>
                <textarea
                  rows={4}
                  required
                  value={editingFaq.answer}
                  onChange={(e) => setEditingFaq({ ...editingFaq, answer: e.target.value })}
                  className="w-full p-2.5 mt-1 rounded-lg border border-slate-300"
                />
              </div>
              <div className="pt-3 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setEditingFaq(null)}
                  className="px-4 py-2 rounded-lg border border-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={savingFaq}
                  className="px-4 py-2 rounded-lg bg-indigo-600 text-white font-semibold"
                >
                  Save FAQ
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
