import React from "react";
import {
  BarChart3,
  TrendingUp,
  Search,
  Bot,
  Users,
  Eye,
  ArrowUpRight,
  Sparkles,
} from "lucide-react";

export default function AnalyticsTab() {
  const topQueries = [
    { query: "recruitment agency in pune", clicks: 312, impressions: 3410, ctr: "9.1%", pos: 3.2 },
    { query: "bpo jobs navi mumbai", clicks: 284, impressions: 2980, ctr: "9.5%", pos: 2.8 },
    { query: "it staffing company maharashtra", clicks: 195, impressions: 2450, ctr: "8.0%", pos: 4.1 },
    { query: "oaksphere connect", clicks: 420, impressions: 1100, ctr: "38.2%", pos: 1.0 },
    { query: "bulk hiring consultancy india", clicks: 118, impressions: 1890, ctr: "6.2%", pos: 5.4 },
  ];

  const topPages = [
    { path: "/jobs", views: "6,420", apps: 210, conversion: "3.3%" },
    { path: "/location/pune", views: "3,810", apps: 84, conversion: "2.2%" },
    { path: "/employers", views: "2,940", apps: 62, conversion: "2.1%" },
    { path: "/location/navi-mumbai", views: "2,410", apps: 58, conversion: "2.4%" },
    { path: "/insights/bpo-hiring-trends-2026", views: "1,890", apps: 19, conversion: "1.0%" },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between border-b border-slate-200 pb-3">
        <div>
          <h3 className="text-sm font-bold text-slate-900">
            Organic Search & AI Visibility Analytics
          </h3>
          <p className="text-xs text-slate-500">
            Combined Google Search Console metrics, AI engine crawl logs, and recruitment conversion
          </p>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-xl bg-white border border-slate-200 shadow-xs">
          <span className="text-xs font-semibold text-slate-500 uppercase">Organic Search Clicks</span>
          <div className="mt-2 text-3xl font-extrabold text-slate-900">1,420</div>
          <span className="text-xs font-semibold text-emerald-600 flex items-center gap-1 mt-1">
            <TrendingUp className="w-3.5 h-3.5" /> +24% vs last month
          </span>
        </div>

        <div className="p-5 rounded-xl bg-white border border-slate-200 shadow-xs">
          <span className="text-xs font-semibold text-slate-500 uppercase">Total Impressions</span>
          <div className="mt-2 text-3xl font-extrabold text-slate-900">18.4K</div>
          <span className="text-xs font-semibold text-emerald-600 flex items-center gap-1 mt-1">
            <TrendingUp className="w-3.5 h-3.5" /> +32% across Maharashtra
          </span>
        </div>

        <div className="p-5 rounded-xl bg-white border border-slate-200 shadow-xs">
          <span className="text-xs font-semibold text-slate-500 uppercase">Average SERP CTR</span>
          <div className="mt-2 text-3xl font-extrabold text-slate-900">7.7%</div>
          <span className="text-xs text-slate-500 mt-1 block">Industry avg: 4.2%</span>
        </div>

        <div className="p-5 rounded-xl bg-white border border-slate-200 shadow-xs">
          <span className="text-xs font-semibold text-slate-500 uppercase">AI Bot Crawl Requests</span>
          <div className="mt-2 text-3xl font-extrabold text-indigo-600">6,920</div>
          <span className="text-xs text-slate-500 mt-1 block">Googlebot & OAI-SearchBot</span>
        </div>
      </div>

      {/* Tables: Top Queries & Pages */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top Queries */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-3">
          <h4 className="font-bold text-xs text-slate-900 uppercase tracking-wider">
            Top Search Queries (Google India)
          </h4>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-600">
              <thead className="bg-slate-50 text-[10px] font-semibold text-slate-700 uppercase border-b border-slate-200">
                <tr>
                  <th className="px-3 py-2">Query</th>
                  <th className="px-2 py-2 text-right">Clicks</th>
                  <th className="px-2 py-2 text-right">Impr</th>
                  <th className="px-2 py-2 text-right">CTR</th>
                  <th className="px-2 py-2 text-right">Avg Pos</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {topQueries.map((q, i) => (
                  <tr key={i} className="hover:bg-slate-50">
                    <td className="px-3 py-2.5 font-medium text-slate-900">{q.query}</td>
                    <td className="px-2 py-2.5 text-right font-semibold text-slate-900">{q.clicks}</td>
                    <td className="px-2 py-2.5 text-right text-slate-500">{q.impressions}</td>
                    <td className="px-2 py-2.5 text-right font-semibold text-emerald-600">{q.ctr}</td>
                    <td className="px-2 py-2.5 text-right font-mono text-slate-600">{q.pos}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Top Pages */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-3">
          <h4 className="font-bold text-xs text-slate-900 uppercase tracking-wider">
            Top Pages & Application Conversion
          </h4>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-600">
              <thead className="bg-slate-50 text-[10px] font-semibold text-slate-700 uppercase border-b border-slate-200">
                <tr>
                  <th className="px-3 py-2">Page Path</th>
                  <th className="px-2 py-2 text-right">Views</th>
                  <th className="px-2 py-2 text-right">Inquiries</th>
                  <th className="px-2 py-2 text-right">Conversion</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {topPages.map((p, i) => (
                  <tr key={i} className="hover:bg-slate-50">
                    <td className="px-3 py-2.5 font-mono text-indigo-600">{p.path}</td>
                    <td className="px-2 py-2.5 text-right font-semibold text-slate-900">{p.views}</td>
                    <td className="px-2 py-2.5 text-right text-slate-700">{p.apps}</td>
                    <td className="px-2 py-2.5 text-right font-semibold text-emerald-600">
                      {p.conversion}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
