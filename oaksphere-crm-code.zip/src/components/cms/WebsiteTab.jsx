import React, { useState } from "react";
import {
  FileText,
  Settings,
  Menu as MenuIcon,
  Plus,
  Pencil,
  Copy,
  Trash2,
  ExternalLink,
  Eye,
  CheckCircle2,
  AlertTriangle,
  ArrowUp,
  ArrowDown,
  Sparkles,
  Save,
  X,
  Layers,
  HelpCircle,
  Link as LinkIcon,
} from "lucide-react";
import { toast } from "sonner";
import api, { formatError } from "@/lib/api";

export default function WebsiteTab({
  pages = [],
  settings = {},
  menus = { header: [], footer: [] },
  onRefresh,
  onOpenAi,
}) {
  const [subTab, setSubTab] = useState("pages"); // 'pages' | 'settings' | 'menus'
  const [pageCategoryFilter, setPageCategoryFilter] = useState("all");
  const [pageSearch, setPageSearch] = useState("");

  // Edit Page Modal State
  const [editingPage, setEditingPage] = useState(null);
  const [isNewPage, setIsNewPage] = useState(false);
  const [savingPage, setSavingPage] = useState(false);

  // Settings State
  const [settingsForm, setSettingsForm] = useState(settings);
  const [savingSettings, setSavingSettings] = useState(false);

  // Menus State
  const [headerLinks, setHeaderLinks] = useState(menus.header || []);
  const [footerLinks, setFooterLinks] = useState(menus.footer || []);
  const [savingMenus, setSavingMenus] = useState(false);

  // Update local forms when props change
  React.useEffect(() => {
    setSettingsForm(settings);
  }, [settings]);

  React.useEffect(() => {
    setHeaderLinks(menus.header || []);
    setFooterLinks(menus.footer || []);
  }, [menus]);

  // Filtered pages
  const filteredPages = pages.filter((p) => {
    const matchesCat = pageCategoryFilter === "all" || p.category === pageCategoryFilter;
    const matchesSearch =
      p.title.toLowerCase().includes(pageSearch.toLowerCase()) ||
      p.slug.toLowerCase().includes(pageSearch.toLowerCase());
    return matchesCat && matchesSearch;
  });

  // Handle Save Page
  const handleSavePage = async (e) => {
    e.preventDefault();
    setSavingPage(true);
    try {
      if (isNewPage) {
        await api.post("/api/cms/pages", editingPage);
        toast.success(`Page "${editingPage.title}" created successfully!`);
      } else {
        await api.patch(`/api/cms/pages/${editingPage.id}`, editingPage);
        toast.success(`Page "${editingPage.title}" updated successfully!`);
      }
      setEditingPage(null);
      setIsNewPage(false);
      onRefresh();
    } catch (err) {
      toast.error(formatError(err?.response?.data?.detail || "Failed to save page"));
    } finally {
      setSavingPage(false);
    }
  };

  // Handle Duplicate Page
  const handleDuplicatePage = async (id) => {
    try {
      await api.post(`/api/cms/pages/${id}/duplicate`);
      toast.success("Page duplicated as draft");
      onRefresh();
    } catch (err) {
      toast.error(formatError(err?.response?.data?.detail));
    }
  };

  // Handle Delete Page
  const handleDeletePage = async (page) => {
    if (page.slug === "/") {
      toast.error("The root homepage cannot be deleted.");
      return;
    }
    if (!window.confirm(`Are you sure you want to delete the page "${page.title}" (${page.slug})?`)) {
      return;
    }
    try {
      await api.delete(`/api/cms/pages/${page.id}`);
      toast.success("Page deleted");
      onRefresh();
    } catch (err) {
      toast.error(formatError(err?.response?.data?.detail));
    }
  };

  // Handle Save Settings
  const handleSaveSettings = async (e) => {
    e.preventDefault();
    setSavingSettings(true);
    try {
      await api.patch("/api/cms/settings", settingsForm);
      toast.success("Website global settings saved successfully!");
      onRefresh();
    } catch (err) {
      toast.error(formatError(err?.response?.data?.detail));
    } finally {
      setSavingSettings(false);
    }
  };

  // Handle Save Menus
  const handleSaveMenus = async () => {
    setSavingMenus(true);
    try {
      await api.patch("/api/cms/menus", {
        header: headerLinks,
        footer: footerLinks,
      });
      toast.success("Navigation menus saved successfully!");
      onRefresh();
    } catch (err) {
      toast.error(formatError(err?.response?.data?.detail));
    } finally {
      setSavingMenus(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Sub-navigation tabs */}
      <div className="flex items-center justify-between border-b border-slate-200 pb-3">
        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => setSubTab("pages")}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-colors ${
              subTab === "pages"
                ? "bg-slate-900 text-white"
                : "bg-slate-100 text-slate-700 hover:bg-slate-200"
            }`}
          >
            Pages & Landing Pages ({pages.length})
          </button>
          <button
            type="button"
            onClick={() => setSubTab("settings")}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-colors ${
              subTab === "settings"
                ? "bg-slate-900 text-white"
                : "bg-slate-100 text-slate-700 hover:bg-slate-200"
            }`}
          >
            Global Website Settings
          </button>
          <button
            type="button"
            onClick={() => setSubTab("menus")}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-colors ${
              subTab === "menus"
                ? "bg-slate-900 text-white"
                : "bg-slate-100 text-slate-700 hover:bg-slate-200"
            }`}
          >
            Menu Manager
          </button>
        </div>

        {subTab === "pages" && (
          <button
            type="button"
            onClick={() => {
              setIsNewPage(true);
              setEditingPage({
                id: "p-" + Date.now(),
                title: "New Landing Page",
                slug: "/new-page",
                category: "landing",
                status: "published",
                h1: "Verified Recruitment & Staffing",
                meta_title: "Recruitment Services | OAKSphere Connect",
                meta_description:
                  "Discover verified hiring solutions and career opportunities across India with OAKSphere Connect.",
                canonical_url: "https://oaksphereconnect.com/new-page",
                robots_index: true,
                robots_follow: true,
                og_title: "Recruitment Services | OAKSphere Connect",
                og_description:
                  "Discover verified hiring solutions and career opportunities across India.",
                og_image: "https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=1200&q=80",
                schema_type: "WebPage",
                sections: [
                  {
                    id: "sec-hero",
                    type: "hero",
                    title: "Recruitment Excellence in India",
                    subtitle: "Empowering enterprises and top talent with speed and precision.",
                    cta_text: "Hire Talent",
                    cta_url: "/employers",
                  },
                ],
                aeo_qa: [
                  {
                    q: "What hiring services does OAKSphere provide?",
                    a: "OAKSphere Connect delivers verified permanent recruitment, IT staffing, BPO workforce solutions, and bulk executive search across India with an average 48-hour interview turnaround.",
                  },
                ],
                target_keywords: ["recruitment agency", "staffing solutions"],
              });
            }}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 text-white text-xs font-semibold shadow-xs hover:bg-indigo-700 transition-colors cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            Create Page
          </button>
        )}

        {subTab === "menus" && (
          <button
            type="button"
            onClick={handleSaveMenus}
            disabled={savingMenus}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 text-white text-xs font-semibold shadow-xs hover:bg-indigo-700 transition-colors cursor-pointer disabled:opacity-60"
          >
            <Save className="w-3.5 h-3.5" />
            Save Menu Changes
          </button>
        )}
      </div>

      {/* SUBTAB 1: PAGES CMS */}
      {subTab === "pages" && (
        <div className="space-y-4">
          {/* Filter Bar */}
          <div className="flex flex-col sm:flex-row gap-3 items-center justify-between">
            <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto">
              {["all", "core", "landing", "directory", "service", "info", "legal"].map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setPageCategoryFilter(cat)}
                  className={`px-2.5 py-1 rounded-md text-xs font-medium capitalize whitespace-nowrap cursor-pointer ${
                    pageCategoryFilter === cat
                      ? "bg-indigo-50 text-indigo-700 border border-indigo-200"
                      : "text-slate-600 hover:bg-slate-100"
                  }`}
                >
                  {cat === "all" ? "All Categories" : cat}
                </button>
              ))}
            </div>

            <div className="w-full sm:w-64">
              <input
                type="text"
                value={pageSearch}
                onChange={(e) => setPageSearch(e.target.value)}
                placeholder="Search page title or slug..."
                className="w-full h-8 px-3 rounded-lg border border-slate-300 text-xs outline-none focus:border-indigo-500"
              />
            </div>
          </div>

          {/* Pages Table */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-600">
                <thead className="bg-slate-50 text-[11px] font-semibold text-slate-700 uppercase tracking-wider border-b border-slate-200">
                  <tr>
                    <th className="px-4 py-3">Page Title & Slug</th>
                    <th className="px-4 py-3">Category</th>
                    <th className="px-4 py-3">Status</th>
                    <th className="px-4 py-3">Schema</th>
                    <th className="px-4 py-3">Index / Follow</th>
                    <th className="px-4 py-3">Last Reviewed</th>
                    <th className="px-4 py-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredPages.map((page) => (
                    <tr key={page.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="px-4 py-3">
                        <div className="font-semibold text-slate-900">{page.title}</div>
                        <div className="text-[11px] text-indigo-600 font-mono flex items-center gap-1">
                          {page.slug}
                          <a
                            href={page.slug}
                            target="_blank"
                            rel="noreferrer"
                            className="text-slate-400 hover:text-indigo-600"
                            title="Open in new tab"
                          >
                            <ExternalLink className="w-3 h-3" />
                          </a>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <span className="capitalize px-2 py-0.5 rounded-full text-[10px] font-medium bg-slate-100 text-slate-700">
                          {page.category}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                            page.status === "published"
                              ? "bg-emerald-100 text-emerald-800"
                              : "bg-amber-100 text-amber-800"
                          }`}
                        >
                          {page.status}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <span className="font-mono text-[11px] text-slate-700 bg-slate-100 px-1.5 py-0.5 rounded">
                          {page.schema_type || "WebPage"}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <span
                          className={`text-[11px] font-medium ${
                            page.robots_index !== false ? "text-emerald-700" : "text-red-700"
                          }`}
                        >
                          {page.robots_index !== false ? "index" : "noindex"},{" "}
                          {page.robots_follow !== false ? "follow" : "nofollow"}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-slate-500 text-[11px]">
                        {page.last_reviewed || "13 Sep 2026"}
                      </td>
                      <td className="px-4 py-3 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            type="button"
                            onClick={() => {
                              setIsNewPage(false);
                              setEditingPage({ ...page });
                            }}
                            className="p-1.5 rounded-md hover:bg-slate-100 text-slate-600 hover:text-indigo-600 cursor-pointer"
                            title="Edit Page SEO & Content"
                          >
                            <Pencil className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDuplicatePage(page.id)}
                            className="p-1.5 rounded-md hover:bg-slate-100 text-slate-600 hover:text-slate-900 cursor-pointer"
                            title="Duplicate Page"
                          >
                            <Copy className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeletePage(page)}
                            className="p-1.5 rounded-md hover:bg-red-50 text-slate-400 hover:text-red-600 cursor-pointer"
                            title="Delete Page"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* SUBTAB 2: GLOBAL WEBSITE SETTINGS */}
      {subTab === "settings" && (
        <form onSubmit={handleSaveSettings} className="space-y-6 max-w-4xl">
          {/* Identity & Core URLs */}
          <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-4">
            <h3 className="text-sm font-bold text-slate-900 border-b border-slate-100 pb-2">
              Website Identity & URLs
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-semibold text-slate-700">Website Name</label>
                <input
                  type="text"
                  value={settingsForm.site_name || ""}
                  onChange={(e) =>
                    setSettingsForm({ ...settingsForm, site_name: e.target.value })
                  }
                  className="w-full h-9 px-3 mt-1 rounded-lg border border-slate-300 text-xs outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700">Production URL</label>
                <input
                  type="url"
                  value={settingsForm.site_url || ""}
                  onChange={(e) =>
                    setSettingsForm({ ...settingsForm, site_url: e.target.value })
                  }
                  className="w-full h-9 px-3 mt-1 rounded-lg border border-slate-300 text-xs outline-none focus:border-indigo-500"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="text-xs font-semibold text-slate-700">Website Tagline</label>
                <input
                  type="text"
                  value={settingsForm.tagline || ""}
                  onChange={(e) =>
                    setSettingsForm({ ...settingsForm, tagline: e.target.value })
                  }
                  className="w-full h-9 px-3 mt-1 rounded-lg border border-slate-300 text-xs outline-none focus:border-indigo-500"
                />
              </div>
            </div>
          </div>

          {/* Brand Palette */}
          <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-4">
            <h3 className="text-sm font-bold text-slate-900 border-b border-slate-100 pb-2">
              Brand Colors & Styling
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="text-xs font-semibold text-slate-700">Primary Color</label>
                <div className="flex items-center gap-2 mt-1">
                  <input
                    type="color"
                    value={settingsForm.brand_colors?.primary || "#5F259F"}
                    onChange={(e) =>
                      setSettingsForm({
                        ...settingsForm,
                        brand_colors: {
                          ...settingsForm.brand_colors,
                          primary: e.target.value,
                        },
                      })
                    }
                    className="w-8 h-8 rounded border border-slate-300 cursor-pointer p-0.5"
                  />
                  <input
                    type="text"
                    value={settingsForm.brand_colors?.primary || "#5F259F"}
                    onChange={(e) =>
                      setSettingsForm({
                        ...settingsForm,
                        brand_colors: {
                          ...settingsForm.brand_colors,
                          primary: e.target.value,
                        },
                      })
                    }
                    className="flex-1 h-9 px-3 rounded-lg border border-slate-300 text-xs font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700">Secondary Color</label>
                <div className="flex items-center gap-2 mt-1">
                  <input
                    type="color"
                    value={settingsForm.brand_colors?.secondary || "#0A66C2"}
                    onChange={(e) =>
                      setSettingsForm({
                        ...settingsForm,
                        brand_colors: {
                          ...settingsForm.brand_colors,
                          secondary: e.target.value,
                        },
                      })
                    }
                    className="w-8 h-8 rounded border border-slate-300 cursor-pointer p-0.5"
                  />
                  <input
                    type="text"
                    value={settingsForm.brand_colors?.secondary || "#0A66C2"}
                    onChange={(e) =>
                      setSettingsForm({
                        ...settingsForm,
                        brand_colors: {
                          ...settingsForm.brand_colors,
                          secondary: e.target.value,
                        },
                      })
                    }
                    className="flex-1 h-9 px-3 rounded-lg border border-slate-300 text-xs font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700">Accent Color</label>
                <div className="flex items-center gap-2 mt-1">
                  <input
                    type="color"
                    value={settingsForm.brand_colors?.accent || "#2164F3"}
                    onChange={(e) =>
                      setSettingsForm({
                        ...settingsForm,
                        brand_colors: {
                          ...settingsForm.brand_colors,
                          accent: e.target.value,
                        },
                      })
                    }
                    className="w-8 h-8 rounded border border-slate-300 cursor-pointer p-0.5"
                  />
                  <input
                    type="text"
                    value={settingsForm.brand_colors?.accent || "#2164F3"}
                    onChange={(e) =>
                      setSettingsForm({
                        ...settingsForm,
                        brand_colors: {
                          ...settingsForm.brand_colors,
                          accent: e.target.value,
                        },
                      })
                    }
                    className="flex-1 h-9 px-3 rounded-lg border border-slate-300 text-xs font-mono"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Announcement Bar */}
          <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <h3 className="text-sm font-bold text-slate-900">Announcement Bar</h3>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={settingsForm.announcement_bar?.enabled || false}
                  onChange={(e) =>
                    setSettingsForm({
                      ...settingsForm,
                      announcement_bar: {
                        ...settingsForm.announcement_bar,
                        enabled: e.target.checked,
                      },
                    })
                  }
                  className="rounded text-indigo-600 focus:ring-0"
                />
                <span className="text-xs font-semibold text-slate-700">Enable Bar</span>
              </label>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="sm:col-span-2">
                <label className="text-xs font-semibold text-slate-700">Announcement Message</label>
                <input
                  type="text"
                  value={settingsForm.announcement_bar?.text || ""}
                  onChange={(e) =>
                    setSettingsForm({
                      ...settingsForm,
                      announcement_bar: {
                        ...settingsForm.announcement_bar,
                        text: e.target.value,
                      },
                    })
                  }
                  placeholder="E.g. Now Hiring: 150+ Openings across Pune, Mumbai and Navi Mumbai."
                  className="w-full h-9 px-3 mt-1 rounded-lg border border-slate-300 text-xs outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700">Target Link URL</label>
                <input
                  type="text"
                  value={settingsForm.announcement_bar?.link || ""}
                  onChange={(e) =>
                    setSettingsForm({
                      ...settingsForm,
                      announcement_bar: {
                        ...settingsForm.announcement_bar,
                        link: e.target.value,
                      },
                    })
                  }
                  placeholder="/jobs"
                  className="w-full h-9 px-3 mt-1 rounded-lg border border-slate-300 text-xs outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700">Background Tone</label>
                <select
                  value={settingsForm.announcement_bar?.bg_color || "indigo"}
                  onChange={(e) =>
                    setSettingsForm({
                      ...settingsForm,
                      announcement_bar: {
                        ...settingsForm.announcement_bar,
                        bg_color: e.target.value,
                      },
                    })
                  }
                  className="w-full h-9 px-3 mt-1 rounded-lg border border-slate-300 text-xs outline-none focus:border-indigo-500"
                >
                  <option value="indigo">Purple / Indigo Gradient</option>
                  <option value="emerald">Emerald Success</option>
                  <option value="amber">Amber Alert</option>
                  <option value="dark">Slate Dark</option>
                </select>
              </div>
            </div>
          </div>

          {/* Contact NAP (Name, Address, Phone) & Schema Entity */}
          <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-4">
            <h3 className="text-sm font-bold text-slate-900 border-b border-slate-100 pb-2">
              NAP (Name, Address, Phone) & Entity Information
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-semibold text-slate-700">Legal Company Name</label>
                <input
                  type="text"
                  value={settingsForm.contact?.company_name || ""}
                  onChange={(e) =>
                    setSettingsForm({
                      ...settingsForm,
                      contact: { ...settingsForm.contact, company_name: e.target.value },
                    })
                  }
                  className="w-full h-9 px-3 mt-1 rounded-lg border border-slate-300 text-xs outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700">Primary Phone</label>
                <input
                  type="text"
                  value={settingsForm.contact?.phone || ""}
                  onChange={(e) =>
                    setSettingsForm({
                      ...settingsForm,
                      contact: { ...settingsForm.contact, phone: e.target.value },
                    })
                  }
                  className="w-full h-9 px-3 mt-1 rounded-lg border border-slate-300 text-xs outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700">Primary Email</label>
                <input
                  type="email"
                  value={settingsForm.contact?.email || ""}
                  onChange={(e) =>
                    setSettingsForm({
                      ...settingsForm,
                      contact: { ...settingsForm.contact, email: e.target.value },
                    })
                  }
                  className="w-full h-9 px-3 mt-1 rounded-lg border border-slate-300 text-xs outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700">WhatsApp Hotline</label>
                <input
                  type="text"
                  value={settingsForm.contact?.whatsapp || ""}
                  onChange={(e) =>
                    setSettingsForm({
                      ...settingsForm,
                      contact: { ...settingsForm.contact, whatsapp: e.target.value },
                    })
                  }
                  className="w-full h-9 px-3 mt-1 rounded-lg border border-slate-300 text-xs outline-none focus:border-indigo-500"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="text-xs font-semibold text-slate-700">Corporate Address</label>
                <input
                  type="text"
                  value={settingsForm.contact?.address || ""}
                  onChange={(e) =>
                    setSettingsForm({
                      ...settingsForm,
                      contact: { ...settingsForm.contact, address: e.target.value },
                    })
                  }
                  className="w-full h-9 px-3 mt-1 rounded-lg border border-slate-300 text-xs outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700">CIN Number</label>
                <input
                  type="text"
                  value={settingsForm.contact?.cin || ""}
                  onChange={(e) =>
                    setSettingsForm({
                      ...settingsForm,
                      contact: { ...settingsForm.contact, cin: e.target.value },
                    })
                  }
                  className="w-full h-9 px-3 mt-1 rounded-lg border border-slate-300 text-xs outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700">GSTIN Number</label>
                <input
                  type="text"
                  value={settingsForm.contact?.gstin || ""}
                  onChange={(e) =>
                    setSettingsForm({
                      ...settingsForm,
                      contact: { ...settingsForm.contact, gstin: e.target.value },
                    })
                  }
                  className="w-full h-9 px-3 mt-1 rounded-lg border border-slate-300 text-xs outline-none focus:border-indigo-500"
                />
              </div>
            </div>
          </div>

          {/* Social Profiles */}
          <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-4">
            <h3 className="text-sm font-bold text-slate-900 border-b border-slate-100 pb-2">
              Social Profiles & Entity sameAs Signals
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-semibold text-slate-700">LinkedIn Company Page</label>
                <input
                  type="url"
                  value={settingsForm.social_links?.linkedin || ""}
                  onChange={(e) =>
                    setSettingsForm({
                      ...settingsForm,
                      social_links: { ...settingsForm.social_links, linkedin: e.target.value },
                    })
                  }
                  placeholder="https://linkedin.com/company/oaksphere-connect"
                  className="w-full h-9 px-3 mt-1 rounded-lg border border-slate-300 text-xs outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700">Twitter / X URL</label>
                <input
                  type="url"
                  value={settingsForm.social_links?.twitter || ""}
                  onChange={(e) =>
                    setSettingsForm({
                      ...settingsForm,
                      social_links: { ...settingsForm.social_links, twitter: e.target.value },
                    })
                  }
                  placeholder="https://x.com/oaksphere"
                  className="w-full h-9 px-3 mt-1 rounded-lg border border-slate-300 text-xs outline-none focus:border-indigo-500"
                />
              </div>
            </div>
          </div>

          <div className="flex justify-end">
            <button
              type="submit"
              disabled={savingSettings}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-indigo-600 text-white text-xs font-semibold shadow-xs hover:bg-indigo-700 transition-colors disabled:opacity-60 cursor-pointer"
            >
              <Save className="w-4 h-4" />
              {savingSettings ? "Saving Settings..." : "Save Website Settings"}
            </button>
          </div>
        </form>
      )}

      {/* SUBTAB 3: NAVIGATION MENU MANAGER */}
      {subTab === "menus" && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Header Navigation Menu */}
          <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Header Main Menu</h3>
                <p className="text-[11px] text-slate-500">Primary desktop & mobile top navigation</p>
              </div>
              <button
                type="button"
                onClick={() =>
                  setHeaderLinks([
                    ...headerLinks,
                    {
                      id: "link-" + Date.now(),
                      label: "New Link",
                      url: "/link",
                      target: "_self",
                      badge: "",
                    },
                  ])
                }
                className="inline-flex items-center gap-1 text-xs font-semibold text-indigo-600 hover:text-indigo-800"
              >
                <Plus className="w-3.5 h-3.5" /> Add Link
              </button>
            </div>

            <div className="space-y-2">
              {headerLinks.map((link, idx) => (
                <div
                  key={link.id || idx}
                  className="p-3 rounded-lg border border-slate-200 bg-slate-50/50 flex items-center justify-between gap-3"
                >
                  <div className="grid grid-cols-2 gap-2 flex-1">
                    <input
                      type="text"
                      value={link.label}
                      onChange={(e) => {
                        const copy = [...headerLinks];
                        copy[idx].label = e.target.value;
                        setHeaderLinks(copy);
                      }}
                      placeholder="Label"
                      className="h-8 px-2.5 rounded border border-slate-300 text-xs bg-white"
                    />
                    <input
                      type="text"
                      value={link.url}
                      onChange={(e) => {
                        const copy = [...headerLinks];
                        copy[idx].url = e.target.value;
                        setHeaderLinks(copy);
                      }}
                      placeholder="URL (e.g. /jobs)"
                      className="h-8 px-2.5 rounded border border-slate-300 text-xs font-mono bg-white"
                    />
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      disabled={idx === 0}
                      onClick={() => {
                        const copy = [...headerLinks];
                        const temp = copy[idx - 1];
                        copy[idx - 1] = copy[idx];
                        copy[idx] = temp;
                        setHeaderLinks(copy);
                      }}
                      className="p-1 rounded hover:bg-slate-200 text-slate-600 disabled:opacity-30 cursor-pointer"
                    >
                      <ArrowUp className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      disabled={idx === headerLinks.length - 1}
                      onClick={() => {
                        const copy = [...headerLinks];
                        const temp = copy[idx + 1];
                        copy[idx + 1] = copy[idx];
                        copy[idx] = temp;
                        setHeaderLinks(copy);
                      }}
                      className="p-1 rounded hover:bg-slate-200 text-slate-600 disabled:opacity-30 cursor-pointer"
                    >
                      <ArrowDown className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setHeaderLinks(headerLinks.filter((_, i) => i !== idx));
                      }}
                      className="p-1 rounded hover:bg-red-50 text-slate-400 hover:text-red-600 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Footer Quick Links */}
          <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Footer Quick Links</h3>
                <p className="text-[11px] text-slate-500">Internal crawl paths & compliance links</p>
              </div>
              <button
                type="button"
                onClick={() =>
                  setFooterLinks([
                    ...footerLinks,
                    {
                      id: "link-" + Date.now(),
                      label: "Footer Link",
                      url: "/link",
                      target: "_self",
                    },
                  ])
                }
                className="inline-flex items-center gap-1 text-xs font-semibold text-indigo-600 hover:text-indigo-800"
              >
                <Plus className="w-3.5 h-3.5" /> Add Link
              </button>
            </div>

            <div className="space-y-2">
              {footerLinks.map((link, idx) => (
                <div
                  key={link.id || idx}
                  className="p-3 rounded-lg border border-slate-200 bg-slate-50/50 flex items-center justify-between gap-3"
                >
                  <div className="grid grid-cols-2 gap-2 flex-1">
                    <input
                      type="text"
                      value={link.label}
                      onChange={(e) => {
                        const copy = [...footerLinks];
                        copy[idx].label = e.target.value;
                        setFooterLinks(copy);
                      }}
                      placeholder="Label"
                      className="h-8 px-2.5 rounded border border-slate-300 text-xs bg-white"
                    />
                    <input
                      type="text"
                      value={link.url}
                      onChange={(e) => {
                        const copy = [...footerLinks];
                        copy[idx].url = e.target.value;
                        setFooterLinks(copy);
                      }}
                      placeholder="URL (e.g. /privacy)"
                      className="h-8 px-2.5 rounded border border-slate-300 text-xs font-mono bg-white"
                    />
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => {
                        setFooterLinks(footerLinks.filter((_, i) => i !== idx));
                      }}
                      className="p-1 rounded hover:bg-red-50 text-slate-400 hover:text-red-600 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* EDIT / CREATE PAGE MODAL */}
      {editingPage && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-3xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            {/* Modal Header */}
            <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-indigo-600" />
                <h3 className="text-base font-bold text-slate-900">
                  {isNewPage ? "Create Website Page" : `Edit Page: ${editingPage.title}`}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setEditingPage(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <form onSubmit={handleSavePage} className="p-6 overflow-y-auto space-y-6 flex-1 text-xs">
              {/* Core Information */}
              <div className="space-y-3">
                <h4 className="font-bold text-slate-900 uppercase tracking-wider text-[11px] text-indigo-600">
                  1. Core URL & Identity
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="font-semibold text-slate-700 block">Page Title (Admin/CMS)</label>
                    <input
                      type="text"
                      required
                      value={editingPage.title}
                      onChange={(e) => setEditingPage({ ...editingPage, title: e.target.value })}
                      className="w-full h-9 px-3 mt-1 rounded-lg border border-slate-300"
                    />
                  </div>

                  <div>
                    <label className="font-semibold text-slate-700 block">URL Slug</label>
                    <input
                      type="text"
                      required
                      value={editingPage.slug}
                      onChange={(e) => setEditingPage({ ...editingPage, slug: e.target.value })}
                      className="w-full h-9 px-3 mt-1 rounded-lg border border-slate-300 font-mono"
                    />
                  </div>

                  <div>
                    <label className="font-semibold text-slate-700 block">Category</label>
                    <select
                      value={editingPage.category || "landing"}
                      onChange={(e) => setEditingPage({ ...editingPage, category: e.target.value })}
                      className="w-full h-9 px-3 mt-1 rounded-lg border border-slate-300 bg-white"
                    >
                      <option value="core">Core Page</option>
                      <option value="landing">Campaign Landing Page</option>
                      <option value="service">Service Solution</option>
                      <option value="directory">Directory Index</option>
                      <option value="info">Info / About</option>
                      <option value="legal">Legal & Policy</option>
                    </select>
                  </div>

                  <div>
                    <label className="font-semibold text-slate-700 block">Publication Status</label>
                    <select
                      value={editingPage.status || "published"}
                      onChange={(e) => setEditingPage({ ...editingPage, status: e.target.value })}
                      className="w-full h-9 px-3 mt-1 rounded-lg border border-slate-300 bg-white"
                    >
                      <option value="published">Published (Live)</option>
                      <option value="draft">Draft (Hidden)</option>
                      <option value="archived">Archived</option>
                    </select>
                  </div>

                  <div className="sm:col-span-2">
                    <label className="font-semibold text-slate-700 block">Primary Heading (H1)</label>
                    <input
                      type="text"
                      value={editingPage.h1 || ""}
                      onChange={(e) => setEditingPage({ ...editingPage, h1: e.target.value })}
                      className="w-full h-9 px-3 mt-1 rounded-lg border border-slate-300"
                    />
                  </div>
                </div>
              </div>

              {/* SEO Metadata with Live Snippet Preview */}
              <div className="space-y-3 pt-3 border-t border-slate-100">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-slate-900 uppercase tracking-wider text-[11px] text-indigo-600">
                    2. Search Engine Metadata & SERP Snippet
                  </h4>
                  <button
                    type="button"
                    onClick={() =>
                      onOpenAi({
                        kind: "seo",
                        context: `Generate SEO title and meta description for ${editingPage.title} on oaksphereconnect.com`,
                      })
                    }
                    className="inline-flex items-center gap-1 text-[11px] font-semibold text-indigo-600 hover:text-indigo-800"
                  >
                    <Sparkles className="w-3 h-3" /> AI Draft
                  </button>
                </div>

                <div>
                  <div className="flex justify-between items-center">
                    <label className="font-semibold text-slate-700">Meta Title</label>
                    <span
                      className={`text-[10px] ${
                        (editingPage.meta_title || "").length > 60
                          ? "text-red-500 font-bold"
                          : "text-slate-400"
                      }`}
                    >
                      {(editingPage.meta_title || "").length} / 60 characters
                    </span>
                  </div>
                  <input
                    type="text"
                    value={editingPage.meta_title || ""}
                    onChange={(e) => setEditingPage({ ...editingPage, meta_title: e.target.value })}
                    className="w-full h-9 px-3 mt-1 rounded-lg border border-slate-300"
                  />
                </div>

                <div>
                  <div className="flex justify-between items-center">
                    <label className="font-semibold text-slate-700">Meta Description</label>
                    <span
                      className={`text-[10px] ${
                        (editingPage.meta_description || "").length > 160
                          ? "text-red-500 font-bold"
                          : "text-slate-400"
                      }`}
                    >
                      {(editingPage.meta_description || "").length} / 160 characters
                    </span>
                  </div>
                  <textarea
                    rows={2}
                    value={editingPage.meta_description || ""}
                    onChange={(e) =>
                      setEditingPage({ ...editingPage, meta_description: e.target.value })
                    }
                    className="w-full p-2.5 mt-1 rounded-lg border border-slate-300"
                  />
                </div>

                {/* Google SERP Preview Box */}
                <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                    Google Search Preview
                  </span>
                  <div className="text-[11px] text-slate-700 truncate">
                    https://oaksphereconnect.com{editingPage.slug}
                  </div>
                  <div className="text-sm font-semibold text-blue-700 hover:underline cursor-pointer truncate">
                    {editingPage.meta_title || "Untitled Page | OAKSphere Connect"}
                  </div>
                  <div className="text-xs text-slate-600 line-clamp-2 mt-0.5">
                    {editingPage.meta_description || "Add a meta description to preview snippet."}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  <div>
                    <label className="font-semibold text-slate-700 block">Canonical URL</label>
                    <input
                      type="url"
                      value={editingPage.canonical_url || ""}
                      onChange={(e) =>
                        setEditingPage({ ...editingPage, canonical_url: e.target.value })
                      }
                      className="w-full h-9 px-3 mt-1 rounded-lg border border-slate-300 font-mono text-[11px]"
                    />
                  </div>

                  <div>
                    <label className="font-semibold text-slate-700 block">Schema.org Type</label>
                    <select
                      value={editingPage.schema_type || "WebPage"}
                      onChange={(e) =>
                        setEditingPage({ ...editingPage, schema_type: e.target.value })
                      }
                      className="w-full h-9 px-3 mt-1 rounded-lg border border-slate-300 bg-white"
                    >
                      <option value="WebPage">WebPage (General)</option>
                      <option value="AboutPage">AboutPage</option>
                      <option value="ContactPage">ContactPage</option>
                      <option value="CollectionPage">CollectionPage (Jobs/Directories)</option>
                      <option value="FAQPage">FAQPage</option>
                    </select>
                  </div>

                  <div className="flex items-center gap-4 sm:col-span-2 pt-1">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={editingPage.robots_index !== false}
                        onChange={(e) =>
                          setEditingPage({ ...editingPage, robots_index: e.target.checked })
                        }
                        className="rounded text-indigo-600"
                      />
                      <span className="font-medium text-slate-800">Allow Indexing (robots: index)</span>
                    </label>

                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={editingPage.robots_follow !== false}
                        onChange={(e) =>
                          setEditingPage({ ...editingPage, robots_follow: e.target.checked })
                        }
                        className="rounded text-indigo-600"
                      />
                      <span className="font-medium text-slate-800">Follow Links (robots: follow)</span>
                    </label>
                  </div>
                </div>
              </div>

              {/* AEO / Generative Engine Q&A Pairs */}
              <div className="space-y-3 pt-3 border-t border-slate-100">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-bold text-slate-900 uppercase tracking-wider text-[11px] text-indigo-600">
                      3. AEO / Generative Engine Direct Answers
                    </h4>
                    <p className="text-[11px] text-slate-500">
                      Clear 40-60 word authoritative answer blocks formatted for ChatGPT Search & Google AI Overviews
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() =>
                      setEditingPage({
                        ...editingPage,
                        aeo_qa: [
                          ...(editingPage.aeo_qa || []),
                          { q: "New Common Question?", a: "Direct concise answer here." },
                        ],
                      })
                    }
                    className="inline-flex items-center gap-1 text-xs font-semibold text-indigo-600 hover:text-indigo-800"
                  >
                    <Plus className="w-3 h-3" /> Add Q&A
                  </button>
                </div>

                <div className="space-y-2">
                  {(editingPage.aeo_qa || []).map((item, qIdx) => (
                    <div key={qIdx} className="p-3 rounded-lg border border-slate-200 bg-slate-50 space-y-2">
                      <div className="flex items-center justify-between gap-2">
                        <input
                          type="text"
                          value={item.q}
                          onChange={(e) => {
                            const copy = [...editingPage.aeo_qa];
                            copy[qIdx].q = e.target.value;
                            setEditingPage({ ...editingPage, aeo_qa: copy });
                          }}
                          placeholder="Question that searchers ask"
                          className="w-full h-8 px-2.5 rounded border border-slate-300 bg-white font-semibold"
                        />
                        <button
                          type="button"
                          onClick={() => {
                            const copy = editingPage.aeo_qa.filter((_, i) => i !== qIdx);
                            setEditingPage({ ...editingPage, aeo_qa: copy });
                          }}
                          className="text-slate-400 hover:text-red-600 p-1"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                      <textarea
                        rows={2}
                        value={item.a}
                        onChange={(e) => {
                          const copy = [...editingPage.aeo_qa];
                          copy[qIdx].a = e.target.value;
                          setEditingPage({ ...editingPage, aeo_qa: copy });
                        }}
                        placeholder="Concise 40-60 word authoritative response"
                        className="w-full p-2 rounded border border-slate-300 bg-white"
                      />
                    </div>
                  ))}
                </div>
              </div>

              {/* Modal Footer */}
              <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setEditingPage(null)}
                  className="px-4 py-2 rounded-lg border border-slate-300 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={savingPage}
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-indigo-600 text-white text-xs font-semibold shadow-xs hover:bg-indigo-700 transition-colors disabled:opacity-60 cursor-pointer"
                >
                  <Save className="w-3.5 h-3.5" />
                  {savingPage ? "Saving..." : "Save Page"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
