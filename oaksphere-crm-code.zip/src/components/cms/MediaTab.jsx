import React, { useState } from "react";
import {
  Image as ImageIcon,
  Plus,
  Copy,
  Trash2,
  ExternalLink,
  Search,
  Check,
  Save,
  Pencil,
} from "lucide-react";
import { toast } from "sonner";
import api, { formatError } from "@/lib/api";

export default function MediaTab({ media = [], onRefresh }) {
  const [search, setSearch] = useState("");
  const [editingMedia, setEditingMedia] = useState(null);
  const [isNew, setIsNew] = useState(false);
  const [saving, setSaving] = useState(false);

  const filtered = media.filter(
    (m) =>
      (m.name || "").toLowerCase().includes(search.toLowerCase()) ||
      (m.alt || "").toLowerCase().includes(search.toLowerCase())
  );

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      if (isNew) {
        await api.post("/api/cms/media", editingMedia);
        toast.success("Media item added!");
      } else {
        await api.patch(`/api/cms/media/${editingMedia.id}`, editingMedia);
        toast.success("Media updated!");
      }
      setEditingMedia(null);
      setIsNew(false);
      onRefresh();
    } catch (err) {
      toast.error(formatError(err?.response?.data?.detail));
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to remove this media asset?")) return;
    try {
      await api.delete(`/api/cms/media/${id}`);
      toast.success("Media asset removed");
      onRefresh();
    } catch (err) {
      toast.error(formatError(err?.response?.data?.detail));
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 border-b border-slate-200 pb-3">
        <div>
          <h3 className="text-sm font-bold text-slate-900">Media Library & Image SEO</h3>
          <p className="text-xs text-slate-500">
            Manage asset URLs, descriptive Alt text, and dimensions for search accessibility
          </p>
        </div>

        <div className="flex items-center gap-3 w-full sm:w-auto">
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search media..."
            className="h-8 px-3 rounded-lg border border-slate-300 text-xs w-full sm:w-48"
          />
          <button
            type="button"
            onClick={() => {
              setIsNew(true);
              setEditingMedia({
                name: "New Asset",
                url: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1200&q=80",
                alt: "OAKSphere Connect Corporate Headquarters",
                width: 1200,
                height: 800,
                file_size: "142 KB",
              });
            }}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 text-white text-xs font-semibold whitespace-nowrap cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" /> Add Asset
          </button>
        </div>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {filtered.map((item) => (
          <div
            key={item.id}
            className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden flex flex-col justify-between group"
          >
            <div className="h-40 bg-slate-100 overflow-hidden relative">
              <img
                src={item.url}
                alt={item.alt || item.name}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                referrerPolicy="no-referrer"
              />
              <span className="absolute bottom-2 right-2 px-1.5 py-0.5 rounded text-[10px] bg-slate-900/80 text-white font-mono">
                {item.width}x{item.height}
              </span>
            </div>

            <div className="p-3 space-y-1.5 flex-1">
              <div className="font-semibold text-xs text-slate-900 truncate">{item.name}</div>
              <p className="text-[11px] text-slate-500 line-clamp-1">
                Alt: {item.alt || <span className="text-amber-500 font-semibold">Missing Alt Text</span>}
              </p>
            </div>

            <div className="px-3 py-2 border-t border-slate-100 flex items-center justify-between text-xs bg-slate-50/50">
              <button
                type="button"
                onClick={() => {
                  navigator.clipboard.writeText(item.url);
                  toast.success("Image URL copied!");
                }}
                className="text-slate-600 hover:text-indigo-600 font-medium inline-flex items-center gap-1"
              >
                <Copy className="w-3 h-3" /> Copy URL
              </button>

              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() => {
                    setIsNew(false);
                    setEditingMedia({ ...item });
                  }}
                  className="p-1 text-slate-500 hover:text-indigo-600"
                >
                  <Pencil className="w-3 h-3" />
                </button>
                <button
                  type="button"
                  onClick={() => handleDelete(item.id)}
                  className="p-1 text-slate-400 hover:text-red-600"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Edit Modal */}
      {editingMedia && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl p-6 space-y-4">
            <h3 className="text-base font-bold text-slate-900">
              {isNew ? "Add Media Asset" : "Edit Media & Alt SEO"}
            </h3>
            <form onSubmit={handleSave} className="space-y-3 text-xs">
              <div>
                <label className="font-semibold text-slate-700">Asset Name</label>
                <input
                  type="text"
                  required
                  value={editingMedia.name}
                  onChange={(e) => setEditingMedia({ ...editingMedia, name: e.target.value })}
                  className="w-full h-9 px-3 mt-1 rounded-lg border border-slate-300"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700">Direct Image URL</label>
                <input
                  type="url"
                  required
                  value={editingMedia.url}
                  onChange={(e) => setEditingMedia({ ...editingMedia, url: e.target.value })}
                  className="w-full h-9 px-3 mt-1 rounded-lg border border-slate-300 font-mono"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700">
                  Descriptive Alt Text (Crucial for Image SEO & Screen Readers)
                </label>
                <textarea
                  rows={2}
                  required
                  value={editingMedia.alt || ""}
                  onChange={(e) => setEditingMedia({ ...editingMedia, alt: e.target.value })}
                  placeholder="E.g. OAKSphere Connect recruitment team in Pune corporate office"
                  className="w-full p-2.5 mt-1 rounded-lg border border-slate-300"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setEditingMedia(null)}
                  className="px-4 py-2 rounded-lg border border-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="px-4 py-2 rounded-lg bg-indigo-600 text-white font-semibold"
                >
                  Save Asset
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
