import React from "react";
import {
  Globe,
  FileText,
  Briefcase,
  Layers,
  MapPin,
  Bot,
  ArrowUpRight,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Sparkles,
  ShieldCheck,
  Search,
  ExternalLink,
  Plus,
  RefreshCw,
  Zap,
} from "lucide-react";

export default function DashboardTab({
  dashboardData,
  onNavigate,
  onRunAudit,
  onIndexNow,
  onOpenAi,
  loading = false,
}) {
  const counts = dashboardData?.counts || {};
  const indexing = dashboardData?.indexing_status || {};
  const recent = dashboardData?.recent_activity || [];
  const healthScore = dashboardData?.health_score || 96;

  return (
    <div className="space-y-6">
      {/* Top Banner: Health & Visibility Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Health Score Card */}
        <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                SEO & Search AI Health
              </span>
              <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800">
                Healthy
              </span>
            </div>
            <div className="mt-4 flex items-baseline gap-3">
              <span className="text-5xl font-extrabold text-slate-900 tracking-tight">
                {healthScore}
              </span>
              <span className="text-lg text-slate-400 font-medium">/ 100</span>
            </div>
            <p className="mt-2 text-xs text-slate-600 leading-relaxed">
              Based on on-page SEO, Google Job Search schema completeness, LocalBusiness NAP signals, and AI crawler visibility.
            </p>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-100 grid grid-cols-3 gap-2 text-center">
            <div className="p-2 rounded-lg bg-slate-50">
              <span className="block text-sm font-bold text-emerald-600">
                {dashboardData?.good_checks || 14}
              </span>
              <span className="text-[11px] text-slate-500">Passed</span>
            </div>
            <div className="p-2 rounded-lg bg-slate-50">
              <span className="block text-sm font-bold text-amber-600">
                {dashboardData?.warnings || 1}
              </span>
              <span className="text-[11px] text-slate-500">Warnings</span>
            </div>
            <div className="p-2 rounded-lg bg-slate-50">
              <span className="block text-sm font-bold text-red-600">
                {dashboardData?.critical_issues || 0}
              </span>
              <span className="text-[11px] text-slate-500">Critical</span>
            </div>
          </div>
        </div>

        {/* Search Engine & AI Overviews Readiness Status */}
        <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs flex flex-col justify-between lg:col-span-2">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Bot className="w-5 h-5 text-indigo-600" />
                <h3 className="text-sm font-bold text-slate-900">
                  Search Engines & Generative AI Visibility
                </h3>
              </div>
              <button
                type="button"
                onClick={() => onNavigate("seo_ai", "readiness")}
                className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1"
              >
                View 11-Point Matrix <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="p-3 rounded-lg border border-slate-200 bg-slate-50/50">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span className="text-xs font-semibold text-slate-800">Google Traditional & Mobile</span>
                </div>
                <p className="text-[11px] text-slate-500 mt-1 pl-6">
                  {indexing.google || "Indexed (All Core Pages)"}
                </p>
              </div>

              <div className="p-3 rounded-lg border border-slate-200 bg-slate-50/50">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span className="text-xs font-semibold text-slate-800">Google Job Search India</span>
                </div>
                <p className="text-[11px] text-slate-500 mt-1 pl-6">
                  {indexing.google_jobs || "Active with JobPosting Schema & Expired Protection"}
                </p>
              </div>

              <div className="p-3 rounded-lg border border-slate-200 bg-slate-50/50">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span className="text-xs font-semibold text-slate-800">ChatGPT Search (OAI-SearchBot)</span>
                </div>
                <p className="text-[11px] text-slate-500 mt-1 pl-6">
                  {indexing.chatgpt_search || "Discoverable & Allowed in robots.txt"}
                </p>
              </div>

              <div className="p-3 rounded-lg border border-slate-200 bg-slate-50/50">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span className="text-xs font-semibold text-slate-800">Bing Webmaster & IndexNow</span>
                </div>
                <p className="text-[11px] text-slate-500 mt-1 pl-6">
                  {indexing.bing_indexnow || "Connected (Real-time URL Notification active)"}
                </p>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-500">
            <span>Google May 2026 Core & AEO Strategy: Single clean content source feeds both SERP and AI Overviews.</span>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={onIndexNow}
                disabled={loading}
                className="px-2.5 py-1 rounded-md bg-indigo-50 text-indigo-700 font-semibold hover:bg-indigo-100 transition-colors"
              >
                Trigger IndexNow Sync
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Website Architecture Metrics */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
        <div
          onClick={() => onNavigate("website", "pages")}
          className="p-4 rounded-xl bg-white border border-slate-200 shadow-xs hover:border-indigo-300 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-400 group-hover:text-indigo-600">
            <span className="text-xs font-medium text-slate-500">Total Pages</span>
            <FileText className="w-4 h-4" />
          </div>
          <p className="mt-2 text-2xl font-bold text-slate-900">{counts.total_pages || 14}</p>
          <span className="text-[11px] text-slate-400 mt-1 block">
            {counts.landing_pages || 4} Campaign Landers
          </span>
        </div>

        <div
          onClick={() => onNavigate("jobs", "jobs")}
          className="p-4 rounded-xl bg-white border border-slate-200 shadow-xs hover:border-indigo-300 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-400 group-hover:text-indigo-600">
            <span className="text-xs font-medium text-slate-500">Active Jobs</span>
            <Briefcase className="w-4 h-4" />
          </div>
          <p className="mt-2 text-2xl font-bold text-slate-900">{counts.published_jobs || 15}</p>
          <span className="text-[11px] text-emerald-600 font-medium mt-1 block">
            Google Schema Active
          </span>
        </div>

        <div
          onClick={() => onNavigate("jobs", "jobs")}
          className="p-4 rounded-xl bg-white border border-slate-200 shadow-xs hover:border-indigo-300 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-400 group-hover:text-indigo-600">
            <span className="text-xs font-medium text-slate-500">Expired Jobs</span>
            <Clock className="w-4 h-4" />
          </div>
          <p className="mt-2 text-2xl font-bold text-slate-900">{counts.expired_jobs || 3}</p>
          <span className="text-[11px] text-slate-500 mt-1 block">
            Auto 410 / Past Valid
          </span>
        </div>

        <div
          onClick={() => onNavigate("jobs", "locations")}
          className="p-4 rounded-xl bg-white border border-slate-200 shadow-xs hover:border-indigo-300 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-400 group-hover:text-indigo-600">
            <span className="text-xs font-medium text-slate-500">City Hubs</span>
            <MapPin className="w-4 h-4" />
          </div>
          <p className="mt-2 text-2xl font-bold text-slate-900">{counts.total_locations || 8}</p>
          <span className="text-[11px] text-slate-400 mt-1 block">
            LocalBusiness NAP
          </span>
        </div>

        <div
          onClick={() => onNavigate("seo_ai", "redirects")}
          className="p-4 rounded-xl bg-white border border-slate-200 shadow-xs hover:border-indigo-300 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-400 group-hover:text-indigo-600">
            <span className="text-xs font-medium text-slate-500">Redirects</span>
            <Zap className="w-4 h-4" />
          </div>
          <p className="mt-2 text-2xl font-bold text-slate-900">{counts.active_redirects || 4}</p>
          <span className="text-[11px] text-emerald-600 font-medium mt-1 block">
            301 & 410 Active
          </span>
        </div>

        <div
          onClick={() => onNavigate("seo_ai", "crawlers")}
          className="p-4 rounded-xl bg-white border border-slate-200 shadow-xs hover:border-indigo-300 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-400 group-hover:text-indigo-600">
            <span className="text-xs font-medium text-slate-500">AI Crawlers</span>
            <Bot className="w-4 h-4" />
          </div>
          <p className="mt-2 text-2xl font-bold text-slate-900">{counts.allowed_crawlers || 6}</p>
          <span className="text-[11px] text-slate-400 mt-1 block">
            Configured in robots
          </span>
        </div>
      </div>

      {/* Quick Launch & Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Quick Launch Actions */}
        <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
          <h3 className="text-sm font-bold text-slate-900 mb-4">Quick Management Actions</h3>
          <div className="space-y-2.5">
            <button
              type="button"
              onClick={() => onNavigate("website", "pages")}
              className="w-full flex items-center justify-between p-3 rounded-lg border border-slate-200 hover:border-indigo-300 hover:bg-indigo-50/40 text-left transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
                  <Plus className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-xs font-semibold text-slate-900 block">Create Landing Page</span>
                  <span className="text-[11px] text-slate-500">E.g., /jobs-in-nagpur or /bfsi-hiring</span>
                </div>
              </div>
              <ArrowUpRight className="w-4 h-4 text-slate-400" />
            </button>

            <button
              type="button"
              onClick={() => onNavigate("jobs", "jobs")}
              className="w-full flex items-center justify-between p-3 rounded-lg border border-slate-200 hover:border-indigo-300 hover:bg-indigo-50/40 text-left transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
                  <Briefcase className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-xs font-semibold text-slate-900 block">Post New Job Vacancy</span>
                  <span className="text-[11px] text-slate-500">Auto-generates Google JobPosting JSON-LD</span>
                </div>
              </div>
              <ArrowUpRight className="w-4 h-4 text-slate-400" />
            </button>

            <button
              type="button"
              onClick={() => onNavigate("seo_ai", "audit")}
              className="w-full flex items-center justify-between p-3 rounded-lg border border-slate-200 hover:border-indigo-300 hover:bg-indigo-50/40 text-left transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
                  <ShieldCheck className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-xs font-semibold text-slate-900 block">Review SEO & Schema Audit</span>
                  <span className="text-[11px] text-slate-500">Scan for missing meta tags or orphaned pages</span>
                </div>
              </div>
              <ArrowUpRight className="w-4 h-4 text-slate-400" />
            </button>

            <button
              type="button"
              onClick={onOpenAi}
              className="w-full flex items-center justify-between p-3 rounded-lg border border-indigo-200 bg-gradient-to-r from-indigo-50/50 to-purple-50/50 text-left hover:border-indigo-400 transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-indigo-600 text-white flex items-center justify-center shadow-xs">
                  <Sparkles className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-xs font-semibold text-indigo-950 block">AI Content Generator</span>
                  <span className="text-[11px] text-indigo-700">Write titles, meta descriptions, AEO blocks</span>
                </div>
              </div>
              <ArrowUpRight className="w-4 h-4 text-indigo-600" />
            </button>
          </div>
        </div>

        {/* Recent Website & SEO Activity Feed */}
        <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs lg:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-slate-900">Recent CMS & SEO Audit Actions</h3>
            <span className="text-xs text-slate-400">Live Audit Trail</span>
          </div>

          <div className="divide-y divide-slate-100">
            {recent.length === 0 ? (
              <p className="text-xs text-slate-400 py-6 text-center">No recent activity logged yet.</p>
            ) : (
              recent.map((item) => (
                <div key={item.id} className="py-3 flex items-start justify-between gap-4">
                  <div className="flex items-start gap-3">
                    <div className="w-2 h-2 rounded-full bg-indigo-600 mt-1.5 shrink-0" />
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-slate-900">{item.action}</span>
                        <code className="text-[10px] px-1.5 py-0.5 rounded bg-slate-100 text-slate-700 font-mono">
                          {item.target}
                        </code>
                      </div>
                      <p className="text-xs text-slate-600 mt-0.5">{item.details}</p>
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <span className="text-[11px] text-slate-400 block">{item.timestamp}</span>
                    <span className="text-[11px] text-slate-500 font-medium">{item.user}</span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
