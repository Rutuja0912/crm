import React from "react";
import {
  Plug,
  CheckCircle2,
  ExternalLink,
  Zap,
  Globe,
  MessageSquare,
  ShieldCheck,
} from "lucide-react";

export default function IntegrationsTab() {
  const integrations = [
    {
      name: "IndexNow (Bing, Copilot & Yandex)",
      category: "Search Engines",
      status: "Connected",
      desc: "Instantly pushes published job vacancies and landing pages directly into Microsoft Bing & search engine indexes.",
      config: "API Key: oaksphere2026indexnow",
      badge: "Active",
    },
    {
      name: "Google Search Console",
      category: "Search Engines",
      status: "Connected",
      desc: "Automatic sitemap submission (/sitemap.xml) and search indexing telemetry.",
      config: "Property: https://oaksphereconnect.com",
      badge: "Active",
    },
    {
      name: "Google Analytics 4",
      category: "Analytics",
      status: "Configured",
      desc: "Client-side tracking for user sessions, page views, and recruitment CTA goal completions.",
      config: "Measurement ID: G-OAKSPHERE01",
      badge: "Active",
    },
    {
      name: "WhatsApp Business API",
      category: "Messaging",
      status: "Connected",
      desc: "1-click direct apply from mobile phones for candidates in Pune, Navi Mumbai, and Nagpur.",
      config: "Hotline: +91 91728 55909",
      badge: "Active",
    },
    {
      name: "OAKSphere CRM Ingestion Engine",
      category: "Core CRM",
      status: "Connected",
      desc: "Direct native hook piping all employer staffing requests and job applications straight into the Recruiter Lead Inbox.",
      config: "Lead Pipeline: Verified Auto-Sync",
      badge: "Native Core",
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between border-b border-slate-200 pb-3">
        <div>
          <h3 className="text-sm font-bold text-slate-900">External Integrations & APIs</h3>
          <p className="text-xs text-slate-500">
            Connected search engines, indexation networks, analytics trackers, and CRM pipelines
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {integrations.map((item, idx) => (
          <div
            key={idx}
            className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                  {item.category}
                </span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-100 text-emerald-800 flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" /> {item.badge}
                </span>
              </div>

              <h4 className="text-sm font-bold text-slate-900 mt-2">{item.name}</h4>
              <p className="text-xs text-slate-600 mt-1 leading-relaxed">{item.desc}</p>

              <div className="mt-4 p-2.5 rounded-lg bg-slate-50 border border-slate-100 font-mono text-[11px] text-slate-700">
                {item.config}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
