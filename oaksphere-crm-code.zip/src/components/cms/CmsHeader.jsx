import React from "react";
import {
  Globe,
  Sparkles,
  ShieldCheck,
  RefreshCw,
  ExternalLink,
  Send,
  CheckCircle2,
  AlertTriangle,
} from "lucide-react";

export const CMS_TABS = [
  { id: "dashboard", label: "Dashboard" },
  { id: "website", label: "Website" },
  { id: "jobs", label: "Jobs" },
  { id: "content", label: "Content" },
  { id: "media", label: "Media" },
  { id: "forms", label: "Forms" },
  { id: "seo_ai", label: "SEO & AI" },
  { id: "analytics", label: "Analytics" },
  { id: "integrations", label: "Integrations" },
  { id: "users", label: "Users" },
  { id: "settings", label: "Settings" },
];

export default function CmsHeader({
  activeTab,
  onSelectTab,
  healthScore = 96,
  onRunAudit,
  onIndexNow,
  onOpenAi,
  loading = false,
}) {
  return (
    <div className="bg-white border-b border-slate-200 sticky top-0 z-30 shadow-xs">
      {/* Top bar */}
      <div className="px-6 py-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#5F259F] to-[#2164F3] flex items-center justify-center text-white font-bold shadow-sm">
            <Globe className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2.5">
              <h1 className="text-xl font-bold text-slate-900 tracking-tight">
                OAKSphere Website Control Center
              </h1>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200 inline-flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3 text-emerald-600" /> Search & AI Ready
              </span>
            </div>
            <div className="flex items-center gap-2 text-xs text-slate-500 mt-0.5">
              <span>Production Domain:</span>
              <a
                href="https://oaksphereconnect.com"
                target="_blank"
                rel="noreferrer"
                className="font-medium text-indigo-600 hover:text-indigo-800 inline-flex items-center gap-0.5 hover:underline"
              >
                oaksphereconnect.com <ExternalLink className="w-3 h-3" />
              </a>
              <span className="text-slate-300">•</span>
              <span>Updated in Real Time</span>
            </div>
          </div>
        </div>

        {/* Action badges & buttons */}
        <div className="flex items-center flex-wrap gap-2.5">
          {/* Health Score Pill */}
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-50 border border-slate-200">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <div className="text-xs">
              <span className="text-slate-500 font-medium">Health: </span>
              <span className="font-bold text-slate-900">{healthScore}/100</span>
            </div>
          </div>

          {/* Run SEO Audit */}
          <button
            type="button"
            onClick={onRunAudit}
            disabled={loading}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors disabled:opacity-60 cursor-pointer"
            title="Scan all pages for SEO, Schema and AI Crawler indexability"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? "animate-spin text-indigo-600" : ""}`} />
            Run SEO Audit
          </button>

          {/* Submit to IndexNow */}
          <button
            type="button"
            onClick={onIndexNow}
            disabled={loading}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-indigo-200 bg-indigo-50 text-xs font-semibold text-indigo-700 hover:bg-indigo-100 transition-colors disabled:opacity-60 cursor-pointer"
            title="Instantly notify Bing, Yandex and Google of latest page updates"
          >
            <Send className="w-3.5 h-3.5" />
            IndexNow Push
          </button>

          {/* AI Copy Assistant */}
          <button
            type="button"
            onClick={onOpenAi}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-indigo-600 to-[#5F259F] text-white text-xs font-semibold shadow-xs hover:opacity-95 transition-opacity cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" />
            AI Assistant
          </button>
        </div>
      </div>

      {/* Primary Navigation Tabs */}
      <div className="px-6 flex gap-1 overflow-x-auto border-t border-slate-100 no-scrollbar">
        {CMS_TABS.map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => onSelectTab(tab.id)}
              className={`px-4 py-3 text-xs font-semibold whitespace-nowrap border-b-2 transition-colors cursor-pointer ${
                isActive
                  ? "border-indigo-600 text-indigo-700 bg-indigo-50/40"
                  : "border-transparent text-slate-600 hover:text-slate-900 hover:border-slate-300"
              }`}
            >
              {tab.label}
              {tab.id === "seo_ai" && (
                <span className="ml-1.5 px-1.5 py-0.5 rounded text-[10px] bg-amber-100 text-amber-800 font-bold">
                  Core
                </span>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}
