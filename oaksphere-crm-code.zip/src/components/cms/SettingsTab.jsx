import React, { useState } from "react";
import {
  Shield,
  Download,
  Upload,
  History,
  CheckCircle2,
  AlertTriangle,
  Lock,
  Save,
} from "lucide-react";
import { toast } from "sonner";
import api, { formatError } from "@/lib/api";

export default function SettingsTab({ recentActivity = [], onRefresh }) {
  const [restoreJson, setRestoreJson] = useState("");
  const [restoring, setRestoring] = useState(false);

  // Download Backup
  const handleDownloadBackup = async () => {
    try {
      const { data } = await api.get("/api/cms/backup");
      const blob = new Blob([JSON.stringify(data, null, 2)], {
        type: "application/json",
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `oaksphere-cms-backup-${new Date().toISOString().split("T")[0]}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      toast.success("CMS snapshot downloaded successfully!");
    } catch (err) {
      toast.error(formatError(err?.response?.data?.detail));
    }
  };

  // Restore from JSON
  const handleRestore = async () => {
    if (!restoreJson.trim()) {
      toast.error("Please paste valid CMS JSON backup content.");
      return;
    }
    if (!window.confirm("Restoring will overwrite current CMS data. Continue?")) return;
    setRestoring(true);
    try {
      const parsed = JSON.parse(restoreJson);
      await api.post("/api/cms/restore", parsed);
      toast.success("CMS data restored successfully from backup!");
      setRestoreJson("");
      onRefresh();
    } catch (err) {
      toast.error("Failed to restore: " + (err.message || "Invalid JSON"));
    } finally {
      setRestoring(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between border-b border-slate-200 pb-3">
        <div>
          <h3 className="text-sm font-bold text-slate-900">CMS Administration, Backup & Governance</h3>
          <p className="text-xs text-slate-500">
            Export full system snapshots, restore previous configurations, and audit activity
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Full Snapshot Backup */}
        <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
            <Download className="w-5 h-5 text-indigo-600" />
            <div>
              <h4 className="text-sm font-bold text-slate-900">Download Full System Snapshot</h4>
              <p className="text-xs text-slate-500">
                Exports all pages, jobs, schema, redirects, and crawler rules into a portable JSON file
              </p>
            </div>
          </div>

          <p className="text-xs text-slate-600 leading-relaxed">
            Create an immutable backup before major marketing campaigns, URL restructurings, or bulk job updates.
          </p>

          <button
            type="button"
            onClick={handleDownloadBackup}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-indigo-600 text-white text-xs font-semibold shadow-xs hover:bg-indigo-700 cursor-pointer"
          >
            <Download className="w-4 h-4" /> Export CMS Snapshot (.json)
          </button>
        </div>

        {/* Restore from JSON */}
        <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
            <Upload className="w-5 h-5 text-amber-600" />
            <div>
              <h4 className="text-sm font-bold text-slate-900">Restore Snapshot</h4>
              <p className="text-xs text-slate-500">
                Paste JSON snapshot to immediately roll back or synchronize environment
              </p>
            </div>
          </div>

          <textarea
            rows={3}
            value={restoreJson}
            onChange={(e) => setRestoreJson(e.target.value)}
            placeholder="Paste exported CMS JSON backup here..."
            className="w-full p-2.5 rounded-lg border border-slate-300 font-mono text-[11px]"
          />

          <button
            type="button"
            onClick={handleRestore}
            disabled={restoring || !restoreJson.trim()}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-slate-900 text-white text-xs font-semibold shadow-xs hover:bg-slate-800 disabled:opacity-50 cursor-pointer"
          >
            <Upload className="w-3.5 h-3.5" />
            {restoring ? "Restoring..." : "Restore Snapshot"}
          </button>
        </div>
      </div>

      {/* Audit Trail */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <History className="w-4 h-4 text-indigo-600" />
            <h4 className="text-sm font-bold text-slate-900">CMS Activity Audit Log</h4>
          </div>
          <span className="text-xs text-slate-400">Chronological history of edits</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-600">
            <thead className="bg-slate-50 text-[10px] font-semibold text-slate-700 uppercase border-b border-slate-200">
              <tr>
                <th className="px-3 py-2">Timestamp</th>
                <th className="px-3 py-2">User</th>
                <th className="px-3 py-2">Action</th>
                <th className="px-3 py-2">Target</th>
                <th className="px-3 py-2">Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {recentActivity.map((item) => (
                <tr key={item.id} className="hover:bg-slate-50">
                  <td className="px-3 py-2.5 text-slate-400 font-mono whitespace-nowrap">
                    {item.timestamp}
                  </td>
                  <td className="px-3 py-2.5 font-medium text-slate-900">{item.user}</td>
                  <td className="px-3 py-2.5 font-semibold text-indigo-700">{item.action}</td>
                  <td className="px-3 py-2.5 font-mono text-slate-700">{item.target}</td>
                  <td className="px-3 py-2.5 text-slate-600">{item.details}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
