import React, { useState } from "react";
import { Sparkles, X, Copy, Check, Send, Bot } from "lucide-react";
import { toast } from "sonner";
import api, { formatError } from "@/lib/api";

export default function AiModal({ isOpen, onClose, initialKind = "seo", initialContext = "" }) {
  const [kind, setKind] = useState(initialKind);
  const [promptContext, setPromptContext] = useState(initialContext);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleGenerate = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const { data } = await api.post("/api/cms/ai-generate", {
        kind,
        context: promptContext,
      });
      setResult(data);
      toast.success("AI content generated successfully!");
    } catch (err) {
      toast.error(formatError(err?.response?.data?.detail || "Generation failed"));
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    toast.success("Copied to clipboard!");
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-xl w-full shadow-2xl flex flex-col max-h-[90vh] overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-gradient-to-r from-indigo-50/70 to-purple-50/70">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-indigo-600 text-white flex items-center justify-center">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                OAKSphere AI Search & Content Assistant
              </h3>
              <p className="text-[11px] text-slate-500">
                Trained on Google SEO guidelines & Answer Engine direct-citation formats
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded text-slate-400 hover:text-slate-700"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 overflow-y-auto space-y-4 text-xs">
          <form onSubmit={handleGenerate} className="space-y-3">
            <div>
              <label className="font-semibold text-slate-700 block">Content Target</label>
              <select
                value={kind}
                onChange={(e) => setKind(e.target.value)}
                className="w-full h-9 px-3 mt-1 rounded-lg border border-slate-300 bg-white"
              >
                <option value="seo">Meta Title & Description (SERP Compliant)</option>
                <option value="aeo">AEO Direct Answer (40-60 Words Concise)</option>
                <option value="job">Job Vacancy Description & Schema Bullets</option>
                <option value="location">Location Hub Intro & Local SEO Keywords</option>
              </select>
            </div>

            <div>
              <label className="font-semibold text-slate-700 block">Context / Topic / Keyword</label>
              <textarea
                rows={3}
                required
                value={promptContext}
                onChange={(e) => setPromptContext(e.target.value)}
                placeholder="E.g. Pune BPO Hiring for international voice process, 3-5 LPA CTC..."
                className="w-full p-2.5 mt-1 rounded-lg border border-slate-300"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 rounded-lg bg-indigo-600 text-white font-semibold flex items-center justify-center gap-2 shadow-xs hover:bg-indigo-700 disabled:opacity-60 cursor-pointer"
            >
              <Sparkles className="w-4 h-4" />
              {loading ? "Generating Draft..." : "Generate AI Draft"}
            </button>
          </form>

          {/* Generated Result */}
          {result && (
            <div className="mt-4 p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
              <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                <span className="font-bold text-slate-900 text-xs">AI Generated Output</span>
                <button
                  type="button"
                  onClick={() =>
                    copyToClipboard(
                      typeof result.generated === "object"
                        ? JSON.stringify(result.generated, null, 2)
                        : result.generated
                    )
                  }
                  className="inline-flex items-center gap-1 text-[11px] font-semibold text-indigo-600 hover:underline"
                >
                  {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  {copied ? "Copied" : "Copy All"}
                </button>
              </div>

              {typeof result.generated === "object" ? (
                <div className="space-y-2">
                  {Object.entries(result.generated).map(([k, v]) => (
                    <div key={k} className="p-2.5 rounded bg-white border border-slate-200">
                      <span className="font-bold text-[10px] uppercase text-slate-500 block mb-1">
                        {k.replace(/_/g, " ")}
                      </span>
                      <p className="text-slate-800 text-xs">{String(v)}</p>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-slate-800 text-xs whitespace-pre-wrap">{result.generated}</p>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
