import React, { useState } from "react";
import {
  Inbox,
  CheckCircle2,
  Mail,
  Send,
  Plus,
  Trash2,
  Pencil,
  Save,
  Users,
  Eye,
  Sliders,
} from "lucide-react";
import { toast } from "sonner";
import api, { formatError } from "@/lib/api";

export default function FormsTab({ forms = [], onRefresh }) {
  const [editingForm, setEditingForm] = useState(null);
  const [viewingSubmissions, setViewingSubmissions] = useState(null);
  const [saving, setSaving] = useState(false);

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await api.patch(`/api/cms/forms/${editingForm.id}`, editingForm);
      toast.success(`Form "${editingForm.name}" updated!`);
      setEditingForm(null);
      onRefresh();
    } catch (err) {
      toast.error(formatError(err?.response?.data?.detail));
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between border-b border-slate-200 pb-3">
        <div>
          <h3 className="text-sm font-bold text-slate-900">Lead Generation Forms & CRM Sync</h3>
          <p className="text-xs text-slate-500">
            Configure website form fields, alert emails, and automated CRM lead pipeline ingestion
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {forms.map((form) => (
          <div
            key={form.id}
            className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-sm text-slate-900">{form.name}</h4>
                <span
                  className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                    form.crm_sync_enabled
                      ? "bg-emerald-100 text-emerald-800"
                      : "bg-slate-100 text-slate-600"
                  }`}
                >
                  {form.crm_sync_enabled ? "CRM Ingestion Active" : "Internal Only"}
                </span>
              </div>

              <p className="text-xs text-slate-600 mt-1">{form.description}</p>

              <div className="mt-4 pt-3 border-t border-slate-100 space-y-1.5 text-xs text-slate-600">
                <div className="flex items-center justify-between">
                  <span>Target Lead Type:</span>
                  <span className="font-semibold text-slate-800 capitalize">{form.lead_type}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>Notification Email:</span>
                  <span className="font-mono text-[11px] text-slate-700">{form.recipient_email}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>Fields Configured:</span>
                  <span className="font-semibold text-slate-800">
                    {(form.fields || []).length} fields
                  </span>
                </div>
              </div>
            </div>

            <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-between">
              <span className="text-xs text-slate-400">
                Submissions: <strong>{form.submissions_count || 0}</strong>
              </span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setViewingSubmissions(form)}
                  className="text-xs font-semibold text-slate-700 hover:text-slate-900"
                >
                  View Logs
                </button>
                <button
                  type="button"
                  onClick={() => setEditingForm({ ...form })}
                  className="text-xs font-semibold text-indigo-600 hover:text-indigo-800"
                >
                  Configure
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* EDIT MODAL */}
      {editingForm && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full shadow-2xl p-6 space-y-4">
            <h3 className="text-base font-bold text-slate-900">Configure {editingForm.name}</h3>
            <form onSubmit={handleSave} className="space-y-3 text-xs">
              <div>
                <label className="font-semibold text-slate-700">Form Name</label>
                <input
                  type="text"
                  required
                  value={editingForm.name}
                  onChange={(e) => setEditingForm({ ...editingForm, name: e.target.value })}
                  className="w-full h-9 px-3 mt-1 rounded-lg border border-slate-300"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700">Recipient Notification Email</label>
                <input
                  type="email"
                  required
                  value={editingForm.recipient_email}
                  onChange={(e) =>
                    setEditingForm({ ...editingForm, recipient_email: e.target.value })
                  }
                  className="w-full h-9 px-3 mt-1 rounded-lg border border-slate-300"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700">CRM Lead Type</label>
                <select
                  value={editingForm.lead_type || "candidate"}
                  onChange={(e) => setEditingForm({ ...editingForm, lead_type: e.target.value })}
                  className="w-full h-9 px-3 mt-1 rounded-lg border border-slate-300 bg-white"
                >
                  <option value="candidate">Candidate (Job Seeker)</option>
                  <option value="employer">Employer (Hiring Mandate)</option>
                  <option value="general">General Contact Inquiry</option>
                </select>
              </div>

              <div className="pt-2">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={editingForm.crm_sync_enabled}
                    onChange={(e) =>
                      setEditingForm({ ...editingForm, crm_sync_enabled: e.target.checked })
                    }
                    className="rounded text-indigo-600"
                  />
                  <span className="font-medium text-slate-800">
                    Auto-ingest submissions directly into CRM Leads pipeline
                  </span>
                </label>
              </div>

              <div className="pt-3 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setEditingForm(null)}
                  className="px-4 py-2 rounded-lg border border-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="px-4 py-2 rounded-lg bg-indigo-600 text-white font-semibold"
                >
                  Save Form
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* VIEW SUBMISSIONS MODAL */}
      {viewingSubmissions && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-xl w-full shadow-2xl p-6 space-y-4">
            <h3 className="text-base font-bold text-slate-900">
              Submissions: {viewingSubmissions.name}
            </h3>
            <p className="text-xs text-slate-500">
              All website form submissions are automatically routed to the CRM Lead Inbox.
            </p>
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-600 space-y-2">
              <div className="flex items-center gap-2 text-emerald-700 font-semibold">
                <CheckCircle2 className="w-4 h-4" /> Live CRM Hook Active
              </div>
              <p>
                To view incoming resumes, applicant contact details, and employer mandates in real time, check the <strong>Lead Inbox</strong> or <strong>Leads</strong> module in the CRM sidebar.
              </p>
            </div>
            <div className="flex justify-end">
              <button
                type="button"
                onClick={() => setViewingSubmissions(null)}
                className="px-4 py-2 rounded-lg bg-slate-900 text-white text-xs font-semibold"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
