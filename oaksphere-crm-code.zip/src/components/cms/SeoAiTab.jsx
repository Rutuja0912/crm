import React, { useState, useEffect } from "react";
import {
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  RefreshCw,
  Send,
  Bot,
  ExternalLink,
  Code,
  FileCode,
  MapPin,
  Sparkles,
  Zap,
  Sliders,
  Plus,
  Trash2,
  Save,
  Check,
  Search,
  Layers,
  HelpCircle,
  Globe,
  ArrowUpRight,
  Info,
} from "lucide-react";
import { toast } from "sonner";
import api, { formatError } from "@/lib/api";

const SEO_SUBTABS = [
  { id: "readiness", label: "Search & AI Readiness" },
  { id: "audit", label: "SEO Audit" },
  { id: "page_seo", label: "Page SEO Matrix" },
  { id: "technical", label: "Technical & Sitemap" },
  { id: "schema", label: "Schema Manager" },
  { id: "local_seo", label: "Local SEO" },
  { id: "aeo_geo", label: "AEO / GEO Strategy" },
  { id: "crawlers", label: "AI Crawlers" },
  { id: "redirects", label: "Redirects" },
  { id: "indexnow", label: "Search Console & IndexNow" },
  { id: "rules", label: "Search & AI Rules" },
];

export default function SeoAiTab({
  activeSubTab = "readiness",
  onSelectSubTab,
  onRunAudit,
  onIndexNow,
  onOpenAi,
  pages = [],
  onRefresh,
}) {
  const [subTab, setSubTab] = useState(activeSubTab || "readiness");

  // Sync incoming subTab prop if provided
  useEffect(() => {
    if (activeSubTab) setSubTab(activeSubTab);
  }, [activeSubTab]);

  const handleTabChange = (id) => {
    setSubTab(id);
    if (onSelectSubTab) onSelectSubTab(id);
  };

  // Readiness State
  const [readinessData, setReadinessData] = useState([]);
  const [loadingReadiness, setLoadingReadiness] = useState(false);
  const [selectedReadinessPage, setSelectedReadinessPage] = useState(null);

  // Audit State
  const [auditData, setAuditData] = useState(null);
  const [loadingAudit, setLoadingAudit] = useState(false);

  // Crawlers State
  const [crawlers, setCrawlers] = useState([]);
  const [savingCrawlers, setSavingCrawlers] = useState(false);

  // Redirects State
  const [redirects, setRedirects] = useState([]);
  const [newRedirect, setNewRedirect] = useState({
    source: "",
    destination: "",
    type: 301,
    active: true,
  });

  // Rules State
  const [rules, setRules] = useState(null);
  const [savingRules, setSavingRules] = useState(false);

  // Robots / Sitemap Live Content
  const [robotsTxt, setRobotsTxt] = useState("");
  const [sitemapXml, setSitemapXml] = useState("");

  // Load readiness data
  const fetchReadiness = async () => {
    setLoadingReadiness(true);
    try {
      const { data } = await api.get("/api/cms/readiness");
      const list = Array.isArray(data) ? data : data?.items || [];
      setReadinessData(list);
      if (list && list.length > 0 && !selectedReadinessPage) {
        setSelectedReadinessPage(list[0]);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingReadiness(false);
    }
  };

  // Load audit data
  const fetchAudit = async () => {
    setLoadingAudit(true);
    try {
      const { data } = await api.get("/api/cms/seo-audit");
      setAuditData(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingAudit(false);
    }
  };

  // Load crawlers data
  const fetchCrawlers = async () => {
    try {
      const { data } = await api.get("/api/cms/crawlers");
      setCrawlers(data || []);
    } catch (err) {
      console.error(err);
    }
  };

  // Load redirects data
  const fetchRedirects = async () => {
    try {
      const { data } = await api.get("/api/cms/redirects");
      setRedirects(data || []);
    } catch (err) {
      console.error(err);
    }
  };

  // Load rules data
  const fetchRules = async () => {
    try {
      const { data } = await api.get("/api/cms/rules");
      setRules(data);
    } catch (err) {
      console.error(err);
    }
  };

  // Load robots & sitemap preview
  const fetchRobotsAndSitemap = async () => {
    try {
      const rRes = await fetch("/robots.txt");
      setRobotsTxt(await rRes.text());
      const sRes = await fetch("/sitemap.xml");
      setSitemapXml(await sRes.text());
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchReadiness();
    fetchAudit();
    fetchCrawlers();
    fetchRedirects();
    fetchRules();
    fetchRobotsAndSitemap();
  }, []);

  // Save Crawlers
  const handleSaveCrawlers = async () => {
    setSavingCrawlers(true);
    try {
      await api.patch("/api/cms/crawlers", { crawlers });
      toast.success("AI Crawler permissions updated and synced to robots.txt!");
      fetchRobotsAndSitemap();
    } catch (err) {
      toast.error(formatError(err?.response?.data?.detail));
    } finally {
      setSavingCrawlers(false);
    }
  };

  // Add Redirect
  const handleAddRedirect = async (e) => {
    e.preventDefault();
    if (!newRedirect.source || !newRedirect.destination) return;
    try {
      await api.post("/api/cms/redirects", newRedirect);
      toast.success(`Redirect added: ${newRedirect.source} → ${newRedirect.destination}`);
      setNewRedirect({ source: "", destination: "", type: 301, active: true });
      fetchRedirects();
    } catch (err) {
      toast.error(formatError(err?.response?.data?.detail));
    }
  };

  // Delete Redirect
  const handleDeleteRedirect = async (id) => {
    try {
      await api.delete(`/api/cms/redirects/${id}`);
      toast.success("Redirect deleted");
      fetchRedirects();
    } catch (err) {
      toast.error(formatError(err?.response?.data?.detail));
    }
  };

  // Save Rules
  const handleSaveRules = async (e) => {
    e.preventDefault();
    setSavingRules(true);
    try {
      await api.patch("/api/cms/rules", rules);
      toast.success("Search & AI Rules updated successfully!");
    } catch (err) {
      toast.error(formatError(err?.response?.data?.detail));
    } finally {
      setSavingRules(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Subtab navigation */}
      <div className="flex items-center gap-1.5 overflow-x-auto border-b border-slate-200 pb-2 no-scrollbar">
        {SEO_SUBTABS.map((tab) => {
          const isActive = subTab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => handleTabChange(tab.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap cursor-pointer transition-colors ${
                isActive
                  ? "bg-indigo-600 text-white shadow-xs"
                  : "bg-slate-100 text-slate-700 hover:bg-slate-200"
              }`}
            >
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* 1. SEARCH & AI READINESS 11-POINT SCORECARD */}
      {subTab === "readiness" && (
        <div className="space-y-6">
          {/* Header Description */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-600" />
                <h3 className="text-sm font-bold text-slate-900">
                  Search & AI Readiness Evaluation Matrix
                </h3>
              </div>
              <p className="text-xs text-slate-600 mt-1 max-w-2xl">
                Every critical URL is evaluated against 11 pillars: Google SEO, Google Job Search, Local SEO,
                Structured Data, Bing/IndexNow, ChatGPT Search, Canonical, Sitemap, Mobile, Performance, and
                AI-readable content.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={fetchReadiness}
                disabled={loadingReadiness}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-300 text-xs font-semibold text-slate-700 hover:bg-slate-50 disabled:opacity-60"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${loadingReadiness ? "animate-spin" : ""}`} />
                Re-evaluate All
              </button>
            </div>
          </div>

          {/* 11-Point Matrix Table */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-600">
                <thead className="bg-slate-50 text-[10px] font-semibold text-slate-700 uppercase tracking-wider border-b border-slate-200">
                  <tr>
                    <th className="px-3 py-3">Page / URL</th>
                    <th className="px-2 py-3 text-center">Google SEO</th>
                    <th className="px-2 py-3 text-center">Google Jobs</th>
                    <th className="px-2 py-3 text-center">Local SEO</th>
                    <th className="px-2 py-3 text-center">Structured Data</th>
                    <th className="px-2 py-3 text-center">Bing / IndexNow</th>
                    <th className="px-2 py-3 text-center">ChatGPT Search</th>
                    <th className="px-2 py-3 text-center">Canonical</th>
                    <th className="px-2 py-3 text-center">Sitemap</th>
                    <th className="px-2 py-3 text-center">Mobile</th>
                    <th className="px-2 py-3 text-center">Perf</th>
                    <th className="px-2 py-3 text-center">AI Readable</th>
                    <th className="px-3 py-3 text-right">Reviewed</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {readinessData.map((row) => {
                    const rowId = row.id || row.page_id;
                    const isSelected =
                      selectedReadinessPage?.id === rowId ||
                      selectedReadinessPage?.page_id === rowId;
                    const chk = row.checks || {};
                    const isJobNa =
                      String(chk.google_job_search ?? chk.google_jobs).toLowerCase() === "n/a";
                    const isLocalNa = String(chk.local_seo).toLowerCase() === "n/a";
                    const chatgptAllowed =
                      chk.chatgpt_search_crawl ?? chk.chatgpt_search;
                    const isAiReadable =
                      chk.ai_readable_content ?? chk.ai_readable;

                    return (
                      <tr
                        key={rowId}
                        onClick={() => setSelectedReadinessPage(row)}
                        className={`hover:bg-indigo-50/40 transition-colors cursor-pointer ${
                          isSelected ? "bg-indigo-50/60" : ""
                        }`}
                      >
                        <td className="px-3 py-3">
                          <div className="font-semibold text-slate-900">{row.title}</div>
                          <div className="text-[11px] font-mono text-indigo-600">{row.slug}</div>
                        </td>
                        <td className="px-2 py-3 text-center">
                          {chk.google_seo ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-600 inline" />
                          ) : (
                            <AlertTriangle className="w-4 h-4 text-amber-500 inline" />
                          )}
                        </td>
                        <td className="px-2 py-3 text-center">
                          {isJobNa ? (
                            <span className="text-slate-300 text-[11px]">N/A</span>
                          ) : (chk.google_job_search ?? chk.google_jobs) ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-600 inline" />
                          ) : (
                            <AlertTriangle className="w-4 h-4 text-amber-500 inline" />
                          )}
                        </td>
                        <td className="px-2 py-3 text-center">
                          {isLocalNa ? (
                            <span className="text-slate-300 text-[11px]">N/A</span>
                          ) : chk.local_seo ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-600 inline" />
                          ) : (
                            <AlertTriangle className="w-4 h-4 text-amber-500 inline" />
                          )}
                        </td>
                        <td className="px-2 py-3 text-center">
                          {chk.structured_data ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-600 inline" />
                          ) : (
                            <AlertTriangle className="w-4 h-4 text-amber-500 inline" />
                          )}
                        </td>
                        <td className="px-2 py-3 text-center">
                          {chk.bing_indexnow ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-600 inline" />
                          ) : (
                            <AlertTriangle className="w-4 h-4 text-amber-500 inline" />
                          )}
                        </td>
                        <td className="px-2 py-3 text-center">
                          {chatgptAllowed ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-600 inline" />
                          ) : (
                            <AlertTriangle className="w-4 h-4 text-amber-500 inline" />
                          )}
                        </td>
                        <td className="px-2 py-3 text-center">
                          {chk.canonical ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-600 inline" />
                          ) : (
                            <AlertTriangle className="w-4 h-4 text-amber-500 inline" />
                          )}
                        </td>
                        <td className="px-2 py-3 text-center">
                          {chk.sitemap ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-600 inline" />
                          ) : (
                            <AlertTriangle className="w-4 h-4 text-amber-500 inline" />
                          )}
                        </td>
                        <td className="px-2 py-3 text-center">
                          {chk.mobile ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-600 inline" />
                          ) : (
                            <AlertTriangle className="w-4 h-4 text-amber-500 inline" />
                          )}
                        </td>
                        <td className="px-2 py-3 text-center">
                          {chk.performance ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-600 inline" />
                          ) : (
                            <AlertTriangle className="w-4 h-4 text-amber-500 inline" />
                          )}
                        </td>
                        <td className="px-2 py-3 text-center">
                          {isAiReadable ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-600 inline" />
                          ) : (
                            <AlertTriangle className="w-4 h-4 text-amber-500 inline" />
                          )}
                        </td>
                        <td className="px-3 py-3 text-right text-[11px] text-slate-500 font-mono">
                          {row.last_reviewed || "13 Sep 2026"}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Selected Page Deep-Dive Card */}
          {selectedReadinessPage && (
            <div className="bg-white rounded-xl border border-indigo-200 p-6 shadow-xs">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-600">
                    Selected Page Readiness Scorecard
                  </span>
                  <h4 className="text-base font-bold text-slate-900">
                    {selectedReadinessPage.title} ({selectedReadinessPage.slug})
                  </h4>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-slate-500">
                    Last reviewed: <strong>{selectedReadinessPage.last_reviewed}</strong>
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4 text-xs">
                <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200 space-y-2">
                  <span className="font-bold text-slate-800 block">Search Engine Crawlers</span>
                  <div className="flex items-center justify-between">
                    <span>Google SEO (Mobile & Core):</span>
                    <span className="font-semibold text-emerald-700 flex items-center gap-1">
                      <Check className="w-3.5 h-3.5" /> Pass
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Bing & IndexNow sync:</span>
                    <span className="font-semibold text-emerald-700 flex items-center gap-1">
                      <Check className="w-3.5 h-3.5" /> Active
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>In /sitemap.xml:</span>
                    <span className="font-semibold text-emerald-700 flex items-center gap-1">
                      <Check className="w-3.5 h-3.5" /> Yes
                    </span>
                  </div>
                </div>

                <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200 space-y-2">
                  <span className="font-bold text-slate-800 block">AI & Answer Engines</span>
                  <div className="flex items-center justify-between">
                    <span>ChatGPT Search (OAI-SearchBot):</span>
                    <span className="font-semibold text-emerald-700 flex items-center gap-1">
                      <Check className="w-3.5 h-3.5" /> Allowed
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>AI-Readable Q&A Content:</span>
                    <span className="font-semibold text-emerald-700 flex items-center gap-1">
                      <Check className="w-3.5 h-3.5" /> Formatted
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Entity JSON-LD Schema:</span>
                    <span className="font-semibold text-emerald-700 flex items-center gap-1">
                      <Check className="w-3.5 h-3.5" /> Present
                    </span>
                  </div>
                </div>

                <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200 space-y-2">
                  <span className="font-bold text-slate-800 block">Technical Quality</span>
                  <div className="flex items-center justify-between">
                    <span>Canonical Consistency:</span>
                    <span className="font-semibold text-emerald-700 flex items-center gap-1">
                      <Check className="w-3.5 h-3.5" /> Verified
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Mobile Viewport & Touch:</span>
                    <span className="font-semibold text-emerald-700 flex items-center gap-1">
                      <Check className="w-3.5 h-3.5" /> Responsive
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Core Web Vitals Est:</span>
                    <span className="font-semibold text-emerald-700 flex items-center gap-1">
                      <Check className="w-3.5 h-3.5" /> Fast
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 2. SEO AUDIT */}
      {subTab === "audit" && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
            <div className="p-5 rounded-xl bg-white border border-slate-200 shadow-xs">
              <span className="text-xs font-semibold text-slate-500 uppercase">Audit Score</span>
              <div className="mt-2 flex items-baseline gap-2">
                <span className="text-4xl font-extrabold text-slate-900">
                  {auditData?.score || 96}
                </span>
                <span className="text-slate-400 font-bold">/ 100</span>
              </div>
              <span className="text-[11px] text-emerald-600 font-medium mt-1 block">
                Top 5% Recruitment Sites
              </span>
            </div>

            <div className="p-5 rounded-xl bg-white border border-slate-200 shadow-xs">
              <span className="text-xs font-semibold text-slate-500 uppercase">Passed Checks</span>
              <div className="mt-2 text-3xl font-bold text-emerald-600">
                {auditData?.passed?.length || 14}
              </div>
              <span className="text-[11px] text-slate-400 mt-1 block">Zero blocking errors</span>
            </div>

            <div className="p-5 rounded-xl bg-white border border-slate-200 shadow-xs">
              <span className="text-xs font-semibold text-slate-500 uppercase">Warnings</span>
              <div className="mt-2 text-3xl font-bold text-amber-600">
                {auditData?.warnings?.length || 1}
              </div>
              <span className="text-[11px] text-slate-400 mt-1 block">Non-blocking suggestions</span>
            </div>

            <div className="p-5 rounded-xl bg-white border border-slate-200 shadow-xs">
              <span className="text-xs font-semibold text-slate-500 uppercase">Critical</span>
              <div className="mt-2 text-3xl font-bold text-red-600">
                {auditData?.critical?.length || 0}
              </div>
              <span className="text-[11px] text-slate-400 mt-1 block">All clear</span>
            </div>
          </div>

          <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h4 className="text-sm font-bold text-slate-900">Audit Findings & Verification Log</h4>
              <button
                type="button"
                onClick={fetchAudit}
                disabled={loadingAudit}
                className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1"
              >
                <RefreshCw className={`w-3 h-3 ${loadingAudit ? "animate-spin" : ""}`} /> Re-run Scan
              </button>
            </div>

            <div className="space-y-2.5">
              {(auditData?.passed || []).map((item, idx) => (
                <div
                  key={idx}
                  className="p-3 rounded-lg border border-emerald-100 bg-emerald-50/40 flex items-start gap-3"
                >
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 mt-0.5 shrink-0" />
                  <div className="text-xs">
                    <span className="font-semibold text-slate-900">{item.title}</span>
                    <p className="text-slate-600 mt-0.5">{item.desc}</p>
                  </div>
                </div>
              ))}

              {(auditData?.warnings || []).map((item, idx) => (
                <div
                  key={idx}
                  className="p-3 rounded-lg border border-amber-200 bg-amber-50/50 flex items-start gap-3"
                >
                  <AlertTriangle className="w-4 h-4 text-amber-600 mt-0.5 shrink-0" />
                  <div className="text-xs">
                    <span className="font-semibold text-slate-900">{item.title}</span>
                    <p className="text-slate-600 mt-0.5">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 3. PAGE SEO MATRIX */}
      {subTab === "page_seo" && (
        <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h4 className="text-sm font-bold text-slate-900">Bulk Page SEO Matrix</h4>
              <p className="text-xs text-slate-500">
                Quickly audit and edit titles, meta descriptions, and index tags across all site pages
              </p>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-600">
              <thead className="bg-slate-50 text-[10px] font-semibold text-slate-700 uppercase tracking-wider border-b border-slate-200">
                <tr>
                  <th className="px-3 py-2.5">Page</th>
                  <th className="px-3 py-2.5">Meta Title (50-60 chars)</th>
                  <th className="px-3 py-2.5">Meta Description (140-160 chars)</th>
                  <th className="px-3 py-2.5">Robots</th>
                  <th className="px-3 py-2.5 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {pages.map((p) => (
                  <tr key={p.id} className="hover:bg-slate-50">
                    <td className="px-3 py-3 font-semibold text-slate-900">
                      <div>{p.title}</div>
                      <span className="text-[11px] font-mono text-indigo-600">{p.slug}</span>
                    </td>
                    <td className="px-3 py-3 max-w-xs">
                      <div className="text-slate-900 truncate" title={p.meta_title}>
                        {p.meta_title || "—"}
                      </div>
                      <span className="text-[10px] text-slate-400">
                        {(p.meta_title || "").length} chars
                      </span>
                    </td>
                    <td className="px-3 py-3 max-w-sm">
                      <div className="text-slate-600 line-clamp-2" title={p.meta_description}>
                        {p.meta_description || "—"}
                      </div>
                      <span className="text-[10px] text-slate-400">
                        {(p.meta_description || "").length} chars
                      </span>
                    </td>
                    <td className="px-3 py-3">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                          p.robots_index !== false
                            ? "bg-emerald-50 text-emerald-700"
                            : "bg-red-50 text-red-700"
                        }`}
                      >
                        {p.robots_index !== false ? "index, follow" : "noindex"}
                      </span>
                    </td>
                    <td className="px-3 py-3 text-right">
                      <a
                        href={p.slug}
                        target="_blank"
                        rel="noreferrer"
                        className="text-indigo-600 hover:underline inline-flex items-center gap-0.5"
                      >
                        Visit <ExternalLink className="w-3 h-3" />
                      </a>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 4. TECHNICAL SEO & SITEMAP */}
      {subTab === "technical" && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Dynamic Sitemap.xml */}
          <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-3">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <div>
                <h4 className="text-sm font-bold text-slate-900">Dynamic sitemap.xml</h4>
                <p className="text-xs text-slate-500">
                  Real-time generated XML index for all published pages and active jobs
                </p>
              </div>
              <a
                href="/sitemap.xml"
                target="_blank"
                rel="noreferrer"
                className="text-xs font-semibold text-indigo-600 hover:underline inline-flex items-center gap-1"
              >
                Open live <ExternalLink className="w-3 h-3" />
              </a>
            </div>

            <pre className="p-4 rounded-xl bg-slate-900 text-slate-200 font-mono text-[11px] overflow-x-auto max-h-96 leading-relaxed">
              {sitemapXml || "Loading /sitemap.xml..."}
            </pre>
          </div>

          {/* Dynamic Robots.txt */}
          <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-3">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <div>
                <h4 className="text-sm font-bold text-slate-900">Dynamic robots.txt</h4>
                <p className="text-xs text-slate-500">
                  Governs Googlebot, Bingbot, and Generative AI Crawlers
                </p>
              </div>
              <a
                href="/robots.txt"
                target="_blank"
                rel="noreferrer"
                className="text-xs font-semibold text-indigo-600 hover:underline inline-flex items-center gap-1"
              >
                Open live <ExternalLink className="w-3 h-3" />
              </a>
            </div>

            <pre className="p-4 rounded-xl bg-slate-900 text-slate-200 font-mono text-[11px] overflow-x-auto max-h-96 leading-relaxed">
              {robotsTxt || "Loading /robots.txt..."}
            </pre>
          </div>
        </div>
      )}

      {/* 5. SCHEMA MANAGER */}
      {subTab === "schema" && (
        <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-6">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h4 className="text-sm font-bold text-slate-900">Structured Data & JSON-LD Schemas</h4>
              <p className="text-xs text-slate-500">
                Automated Schema.org schemas injected into all frontend pages
              </p>
            </div>
            <a
              href="https://search.google.com/test/rich-results"
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1 text-xs font-semibold text-indigo-600 hover:underline"
            >
              Google Rich Results Tool <ExternalLink className="w-3 h-3" />
            </a>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs text-slate-900">Organization Schema</span>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">
                  Active (All Pages)
                </span>
              </div>
              <p className="text-xs text-slate-600">
                Includes official name, logo, contact points, GSTIN, CIN, and sameAs social graph profiles.
              </p>
            </div>

            <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs text-slate-900">JobPosting Schema</span>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">
                  Active (/jobs/*)
                </span>
              </div>
              <p className="text-xs text-slate-600">
                Complete salary range in INR, employmentType, hiringOrganization, validThrough, directApply.
              </p>
            </div>

            <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs text-slate-900">LocalBusiness Schema</span>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">
                  Active (/location/*)
                </span>
              </div>
              <p className="text-xs text-slate-600">
                Includes office coordinates, phone hotline, postal codes, and city service coverage.
              </p>
            </div>

            <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs text-slate-900">FAQPage & Article Schema</span>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">
                  Active (/faqs, /insights/*)
                </span>
              </div>
              <p className="text-xs text-slate-600">
                Structured Q&A pairs and editorial article metadata formatted for AI quotation.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* 6. LOCAL SEO */}
      {subTab === "local_seo" && (
        <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-6">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h4 className="text-sm font-bold text-slate-900">
                Local SEO & NAP Consistency Control
              </h4>
              <p className="text-xs text-slate-500">
                Maintain identical Name, Address, and Phone citations across Maharashtra and pan-India hubs
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="p-4 rounded-xl border border-slate-200 space-y-2">
              <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                <MapPin className="w-4 h-4 text-indigo-600" /> Pune Headquarters
              </span>
              <p className="text-xs text-slate-600">
                Viman Nagar / Magarpatta Cybercity corridor, Pune, MH 411014
              </p>
              <div className="text-[11px] text-slate-500">Phone: +91 91728 55909</div>
              <span className="inline-block px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-50 text-emerald-700">
                NAP Verified
              </span>
            </div>

            <div className="p-4 rounded-xl border border-slate-200 space-y-2">
              <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                <MapPin className="w-4 h-4 text-indigo-600" /> Navi Mumbai Hub
              </span>
              <p className="text-xs text-slate-600">
                Sector 30A, Vashi / Mahape Millennium Business Park, Navi Mumbai 400703
              </p>
              <div className="text-[11px] text-slate-500">Phone: +91 91728 55909</div>
              <span className="inline-block px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-50 text-emerald-700">
                NAP Verified
              </span>
            </div>

            <div className="p-4 rounded-xl border border-slate-200 space-y-2">
              <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                <MapPin className="w-4 h-4 text-indigo-600" /> Mumbai Branch
              </span>
              <p className="text-xs text-slate-600">
                Bandra Kurla Complex (BKC) & Andheri East, Mumbai 400051
              </p>
              <div className="text-[11px] text-slate-500">Phone: +91 91728 55909</div>
              <span className="inline-block px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-50 text-emerald-700">
                NAP Verified
              </span>
            </div>
          </div>
        </div>
      )}

      {/* 7. AEO / GEO STRATEGY */}
      {subTab === "aeo_geo" && (
        <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-6">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-indigo-600" />
                <h4 className="text-sm font-bold text-slate-900">
                  Answer Engine Optimization (AEO) & Generative Engine Optimization (GEO)
                </h4>
              </div>
              <p className="text-xs text-slate-600 mt-1">
                Optimizing for ChatGPT Search, Google AI Overviews, Copilot, and Perplexity by establishing clear entity definition, concise answers, and factual transparency.
              </p>
            </div>
            <button
              type="button"
              onClick={onOpenAi}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 text-white text-xs font-semibold shadow-xs"
            >
              <Sparkles className="w-3.5 h-3.5" /> AI Generator
            </button>
          </div>

          <div className="space-y-4">
            <div className="p-4 rounded-xl border border-indigo-100 bg-indigo-50/40 space-y-2">
              <span className="text-xs font-bold text-indigo-900 block">
                Primary Entity Fact Sheet (Used by LLM crawlers)
              </span>
              <p className="text-xs text-indigo-950 leading-relaxed">
                <strong>Entity Name:</strong> OAKSphere Connect<br />
                <strong>Type:</strong> Recruitment, HRMS, and Verified Staffing Solutions Firm<br />
                <strong>Primary Markets:</strong> Pune, Mumbai, Navi Mumbai, Nagpur, Bangalore, Hyderabad, Pan-India<br />
                <strong>Core Offerings:</strong> BPO Workforce, Permanent IT Staffing, Non-IT & BFSI Hiring, Executive Leadership Search<br />
                <strong>Performance SLA:</strong> 48-hour interview turnaround with 98% candidate retention
              </p>
            </div>

            <div className="space-y-3">
              <h5 className="text-xs font-bold text-slate-900">
                Key Search Q&A Blocks (Direct AI Quotation Target)
              </h5>

              <div className="p-3.5 rounded-lg border border-slate-200 bg-slate-50 space-y-1">
                <span className="font-semibold text-xs text-slate-900">
                  Q: Who is the top recruitment agency for BPO and IT jobs in Pune?
                </span>
                <p className="text-xs text-slate-700">
                  A: OAKSphere Connect is a premier recruitment agency headquartered in Pune, specializing in verified placements across BPO, IT software development, and BFSI sectors with verified candidate credentials and direct enterprise mandates.
                </p>
              </div>

              <div className="p-3.5 rounded-lg border border-slate-200 bg-slate-50 space-y-1">
                <span className="font-semibold text-xs text-slate-900">
                  Q: How do employers hire talent through OAKSphere Connect?
                </span>
                <p className="text-xs text-slate-700">
                  A: Employers submit hiring mandates via oaksphereconnect.com/employers. Dedicated recruiter pods source, prescreen, and deliver vetted candidate interview slates within 48 hours under flexible contingency or retained engagement models.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 8. AI CRAWLERS */}
      {subTab === "crawlers" && (
        <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h4 className="text-sm font-bold text-slate-900">AI Crawler & Search Bot Matrix</h4>
              <p className="text-xs text-slate-500">
                Control permissions in dynamic robots.txt for search indexing vs. generative AI models
              </p>
            </div>
            <button
              type="button"
              onClick={handleSaveCrawlers}
              disabled={savingCrawlers}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-indigo-600 text-white text-xs font-semibold shadow-xs hover:bg-indigo-700 disabled:opacity-60 cursor-pointer"
            >
              <Save className="w-3.5 h-3.5" />
              {savingCrawlers ? "Saving..." : "Save Crawler Permissions"}
            </button>
          </div>

          <div className="divide-y divide-slate-100">
            {crawlers.map((crawler, idx) => (
              <div key={crawler.bot_name} className="py-3 flex items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-900">{crawler.bot_name}</span>
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-100 text-slate-700">
                      {crawler.user_agent}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5">{crawler.purpose}</p>
                </div>

                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={crawler.status === "allowed"}
                    onChange={(e) => {
                      const copy = [...crawlers];
                      copy[idx].status = e.target.checked ? "allowed" : "disallowed";
                      setCrawlers(copy);
                    }}
                    className="rounded text-indigo-600 focus:ring-0"
                  />
                  <span
                    className={`text-xs font-semibold ${
                      crawler.status === "allowed" ? "text-emerald-700" : "text-slate-400"
                    }`}
                  >
                    {crawler.status === "allowed" ? "Allowed" : "Disallowed"}
                  </span>
                </label>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 9. REDIRECTS */}
      {subTab === "redirects" && (
        <div className="space-y-6">
          {/* Add Redirect Form */}
          <form
            onSubmit={handleAddRedirect}
            className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex flex-col sm:flex-row gap-3 items-end"
          >
            <div className="flex-1">
              <label className="text-xs font-semibold text-slate-700 block">
                Old URL Path (Source)
              </label>
              <input
                type="text"
                required
                value={newRedirect.source}
                onChange={(e) => setNewRedirect({ ...newRedirect, source: e.target.value })}
                placeholder="/careers or /old-job"
                className="w-full h-9 px-3 mt-1 rounded-lg border border-slate-300 text-xs font-mono"
              />
            </div>

            <div className="flex-1">
              <label className="text-xs font-semibold text-slate-700 block">
                New Target (Destination)
              </label>
              <input
                type="text"
                required
                value={newRedirect.destination}
                onChange={(e) => setNewRedirect({ ...newRedirect, destination: e.target.value })}
                placeholder="/jobs"
                className="w-full h-9 px-3 mt-1 rounded-lg border border-slate-300 text-xs font-mono"
              />
            </div>

            <div className="w-28">
              <label className="text-xs font-semibold text-slate-700 block">Type</label>
              <select
                value={newRedirect.type}
                onChange={(e) =>
                  setNewRedirect({ ...newRedirect, type: parseInt(e.target.value) })
                }
                className="w-full h-9 px-2 mt-1 rounded-lg border border-slate-300 text-xs bg-white"
              >
                <option value={301}>301 Perm</option>
                <option value={302}>302 Temp</option>
                <option value={410}>410 Gone</option>
              </select>
            </div>

            <button
              type="submit"
              className="h-9 px-4 rounded-lg bg-indigo-600 text-white text-xs font-semibold shadow-xs hover:bg-indigo-700 cursor-pointer"
            >
              Add Redirect
            </button>
          </form>

          {/* Redirects Table */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
            <table className="w-full text-left text-xs text-slate-600">
              <thead className="bg-slate-50 text-[10px] font-semibold text-slate-700 uppercase tracking-wider border-b border-slate-200">
                <tr>
                  <th className="px-4 py-3">Source URL</th>
                  <th className="px-4 py-3">Destination</th>
                  <th className="px-4 py-3">Type</th>
                  <th className="px-4 py-3">Hits</th>
                  <th className="px-4 py-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {redirects.map((r) => (
                  <tr key={r.id} className="hover:bg-slate-50">
                    <td className="px-4 py-3 font-mono text-slate-900 font-semibold">{r.source}</td>
                    <td className="px-4 py-3 font-mono text-indigo-600">{r.destination}</td>
                    <td className="px-4 py-3">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-800">
                        {r.type}
                      </span>
                    </td>
                    <td className="px-4 py-3 font-mono text-slate-500">{r.hits || 0}</td>
                    <td className="px-4 py-3 text-right">
                      <button
                        type="button"
                        onClick={() => handleDeleteRedirect(r.id)}
                        className="p-1 rounded text-slate-400 hover:text-red-600 cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 10. SEARCH CONSOLE & INDEXNOW */}
      {subTab === "indexnow" && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <h4 className="text-sm font-bold text-slate-900">IndexNow Live Submission</h4>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-50 text-emerald-700">
                Bing & Yandex Ready
              </span>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              IndexNow instantly informs participating search engines (including Bing, Copilot, Seznam, and Yandex) whenever content, job vacancies, or city landing pages are published, modified, or expired.
            </p>

            <button
              type="button"
              onClick={onIndexNow}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-indigo-600 text-white text-xs font-semibold shadow-xs hover:bg-indigo-700 cursor-pointer"
            >
              <Send className="w-4 h-4" /> Submit All Current URLs to IndexNow
            </button>
          </div>

          <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <h4 className="text-sm font-bold text-slate-900">Google Search Console Integration</h4>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-50 text-emerald-700">
                Sitemap Verified
              </span>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              Sitemap URL submitted to Google Search Console:
            </p>
            <div className="p-3 rounded-lg bg-slate-100 font-mono text-xs text-slate-800 break-all">
              https://oaksphereconnect.com/sitemap.xml
            </div>

            <div className="flex gap-2">
              <a
                href="https://search.google.com/search-console"
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-300 text-xs font-semibold text-slate-700 hover:bg-slate-50"
              >
                Open Google Search Console <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>
        </div>
      )}

      {/* 11. SEARCH & AI RULES */}
      {subTab === "rules" && rules && (
        <form onSubmit={handleSaveRules} className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-4 max-w-3xl">
          <div className="flex items-center justify-between border-b border-slate-100 pb-2">
            <h4 className="text-sm font-bold text-slate-900">Global Search & AI Rules</h4>
            <button
              type="submit"
              disabled={savingRules}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-indigo-600 text-white text-xs font-semibold shadow-xs hover:bg-indigo-700 disabled:opacity-60 cursor-pointer"
            >
              <Save className="w-3.5 h-3.5" />
              {savingRules ? "Saving..." : "Save Global Rules"}
            </button>
          </div>

          <div className="space-y-3 text-xs">
            <div>
              <label className="font-semibold text-slate-700 block">Title Tag Template</label>
              <input
                type="text"
                value={rules.title_template || "%title% | OAKSphere Connect"}
                onChange={(e) => setRules({ ...rules, title_template: e.target.value })}
                className="w-full h-9 px-3 mt-1 rounded-lg border border-slate-300"
              />
            </div>

            <div>
              <label className="font-semibold text-slate-700 block">Default Meta Description</label>
              <textarea
                rows={2}
                value={rules.default_meta_description || ""}
                onChange={(e) =>
                  setRules({ ...rules, default_meta_description: e.target.value })
                }
                className="w-full p-2.5 mt-1 rounded-lg border border-slate-300"
              />
            </div>

            <div>
              <label className="font-semibold text-slate-700 block">
                Action on Expired Job Vacancy
              </label>
              <select
                value={rules.expired_job_action || "410_gone"}
                onChange={(e) => setRules({ ...rules, expired_job_action: e.target.value })}
                className="w-full h-9 px-3 mt-1 rounded-lg border border-slate-300 bg-white"
              >
                <option value="410_gone">HTTP 410 Gone (Google Job Search Recommended)</option>
                <option value="redirect_city">Redirect 301 to City Job Hub</option>
                <option value="keep_page_banner">Keep Page Live with "Expired" Banner & Similar Openings</option>
              </select>
            </div>
          </div>
        </form>
      )}
    </div>
  );
}
