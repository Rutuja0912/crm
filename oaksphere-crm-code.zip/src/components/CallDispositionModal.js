import { useState, useEffect } from "react";
import api, { formatError } from "@/lib/api";
import { toast } from "sonner";
import { isFinal, REASON_STATUSES, LOST_REASONS, tomorrow10Local } from "@/lib/ui";
import { dialNumber, cleanPhone, formatPhoneDisplay, copyPhoneNumber } from "@/lib/calling";
import { QRCodeSVG } from "qrcode.react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { PhoneCall, Smartphone, Copy, QrCode, MessageCircle } from "lucide-react";

const CONNECTED = ["Connected–Interested", "Not Interested", "Callback Requested", "Interview Scheduled", "Already Working", "Salary Issue", "Location Issue", "Job Mismatch"];
const NOT_CONNECTED = ["No Answer", "Busy", "Switched Off", "Unreachable", "Invalid Number", "WhatsApp Only", "Call Back Later"];
const REQUIRES_FOLLOWUP = ["Callback Requested", "Call Back Later"];
const AUTO_FINAL = { "Not Interested": "Not Interested", "Invalid Number": "Invalid Lead" };
const DEFAULT_STATUSES = ["Contacted", "Interested", "Follow-up", "Selected", "Not Interested", "Rejected", "Closed", "Lost"];

export default function CallDispositionModal({ open, onOpenChange, lead, initialDuration = 0, onDone }) {
  const [disposition, setDisposition] = useState("");
  const [notes, setNotes] = useState("");
  const [callDuration, setCallDuration] = useState(initialDuration || 0);
  const [followupDate, setFollowupDate] = useState("");
  const [followupReason, setFollowupReason] = useState("");
  const [interviewDate, setInterviewDate] = useState("");
  const [interviewType, setInterviewType] = useState("Telephonic");
  const [clientId, setClientId] = useState("");
  const [jobId, setJobId] = useState("");
  const [expectedJoining, setExpectedJoining] = useState("");
  const [lostReason, setLostReason] = useState("");
  const [leadStatus, setLeadStatus] = useState("");
  const [clients, setClients] = useState([]);
  const [jobs, setJobs] = useState([]);
  const [statuses, setStatuses] = useState(DEFAULT_STATUSES);
  const [saving, setSaving] = useState(false);
  const [showQr, setShowQr] = useState(false);

  useEffect(() => {
    if (open) {
      setDisposition(""); setNotes(""); setFollowupDate(tomorrow10Local()); setFollowupReason("");
      setCallDuration(initialDuration || 0);
      setInterviewDate(""); setClientId(lead?.client_id || ""); setJobId(lead?.job_id || "");
      setExpectedJoining(""); setLostReason(""); setLeadStatus(""); setShowQr(false);
      api.get("/clients").then((r) => setClients(r.data)).catch(() => {});
      api.get("/jobs").then((r) => setJobs(r.data)).catch(() => {});
      api.get("/settings").then((r) => r.data?.lead_statuses?.length && setStatuses(r.data.lead_statuses.filter((s) => s !== "New"))).catch(() => {});
    }
  }, [open, lead, initialDuration]);

  const needInterview = disposition === "Interview Scheduled";
  const predicted = leadStatus || AUTO_FINAL[disposition] || (needInterview ? "Interview" : lead?.lead_status);
  const finalOutcome = isFinal(predicted);
  const mustFollowup = REQUIRES_FOLLOWUP.includes(disposition);
  const showFollowup = disposition && !finalOutcome && !needInterview;
  const isSelected = leadStatus === "Selected";
  const needReason = REASON_STATUSES.includes(leadStatus);

  const setPreset = (type) => {
    const d = new Date();
    if (type === "1h") {
      d.setHours(d.getHours() + 1);
    } else if (type === "today5pm") {
      d.setHours(17, 0, 0, 0);
    } else if (type === "tomorrow10am") {
      d.setDate(d.getDate() + 1);
      d.setHours(10, 0, 0, 0);
    } else if (type === "2days") {
      d.setDate(d.getDate() + 2);
      d.setHours(11, 0, 0, 0);
    }
    const pad = (n) => String(n).padStart(2, "0");
    const str = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
    setFollowupDate(str);
  };

  const save = async () => {
    if (!disposition) { toast.error("Select a call outcome"); return; }
    if (showFollowup && !followupDate) { toast.error("Next follow-up date is required until the lead reaches a final status"); return; }
    if (mustFollowup && !followupReason) { toast.error("Follow-up reason is required for callbacks"); return; }
    setSaving(true);
    try {
      await api.post(`/leads/${lead.id}/call`, {
        disposition, notes,
        duration: callDuration || 120,
        followup_date: showFollowup && followupDate ? new Date(followupDate).toISOString() : null,
        followup_reason: followupReason || (showFollowup ? `After: ${disposition}` : ""),
        interview_date: interviewDate ? new Date(interviewDate).toISOString() : null,
        interview_type: interviewType,
        client_id: clientId || null, job_id: jobId || null,
        expected_joining_date: expectedJoining ? new Date(expectedJoining).toISOString() : null,
        lost_reason: lostReason || null,
        lead_status: leadStatus || null,
      });
      toast.success("Call disposition & follow-up saved");
      onOpenChange(false);
      onDone?.();
    } catch (e) {
      toast.error(formatError(e.response?.data?.detail));
    } finally {
      setSaving(false);
    }
  };

  if (!lead) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto bg-white dark:bg-slate-900" data-testid="disposition-modal">
        <DialogHeader>
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-bold uppercase tracking-wider bg-purple-100 text-[#5F259F] dark:bg-purple-950 dark:text-purple-300 px-2 py-0.5 rounded-full">
              Call Disposition
            </span>
            {callDuration > 0 && (
              <span className="text-xs text-slate-500 font-mono">
                Duration: {Math.floor(callDuration / 60)}m {callDuration % 60}s
              </span>
            )}
          </div>
          <DialogTitle className="font-display">Log Call Disposition — {lead.name}</DialogTitle>
          <DialogDescription className="text-sm text-slate-400 font-mono">{lead.phone}</DialogDescription>
        </DialogHeader>

        {/* Mobile Dialing & Connection Card */}
        <div className="bg-gradient-to-r from-emerald-50 via-teal-50 to-blue-50 dark:from-slate-800 dark:to-slate-800/90 p-3.5 rounded-xl border border-emerald-200/80 dark:border-slate-700 shadow-sm" data-testid="mobile-call-card">
          <div className="flex flex-wrap items-center justify-between gap-2.5">
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700 dark:text-emerald-400 flex items-center gap-1">
                <Smartphone className="w-3.5 h-3.5" /> Mobile Call
              </span>
              <p className="text-base font-bold font-mono text-slate-900 dark:text-white mt-0.5" data-testid="modal-display-phone">
                {formatPhoneDisplay(lead.phone)}
              </p>
            </div>

            <div className="flex items-center gap-1.5 flex-wrap">
              <Button
                type="button"
                size="sm"
                data-testid="modal-dial-mobile-btn"
                onClick={() => dialNumber(lead.phone)}
                className="bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs shadow-sm h-8 flex items-center gap-1.5"
              >
                <PhoneCall className="w-3.5 h-3.5" /> Dial on Mobile
              </Button>
              <Button
                type="button"
                size="sm"
                variant="outline"
                data-testid="modal-copy-phone-btn"
                onClick={() => copyPhoneNumber(lead.phone)}
                className="h-8 text-xs bg-white dark:bg-slate-900 border-slate-200 hover:bg-slate-50"
                title="Copy phone number"
              >
                <Copy className="w-3.5 h-3.5" />
              </Button>
              <Button
                type="button"
                size="sm"
                variant="outline"
                data-testid="modal-qr-toggle-btn"
                onClick={() => setShowQr(!showQr)}
                className={`h-8 text-xs bg-white dark:bg-slate-900 border-slate-200 hover:bg-slate-50 ${showQr ? "border-emerald-500 text-emerald-600" : ""}`}
                title="Scan QR code with phone camera to dial immediately"
              >
                <QrCode className="w-3.5 h-3.5 mr-1" />
                {showQr ? "Hide QR" : "Scan QR"}
              </Button>
              {cleanPhone(lead.phone) && (
                <a
                  href={`https://wa.me/${cleanPhone(lead.phone).replace("+", "")}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  data-testid="modal-whatsapp-call-btn"
                  className="inline-flex items-center gap-1 h-8 px-2.5 rounded-md text-xs font-semibold bg-[#25D366] text-white hover:opacity-90 shadow-sm transition-opacity"
                  title="WhatsApp Call or Message"
                >
                  <MessageCircle className="w-3.5 h-3.5" /> WhatsApp
                </a>
              )}
            </div>
          </div>

          {showQr && (
            <div className="mt-3 p-3 bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-700 flex items-center gap-3.5 animate-in fade-in" data-testid="modal-qr-container">
              <div className="p-1.5 bg-white rounded border border-slate-200 shadow-sm flex-shrink-0">
                <QRCodeSVG value={`tel:${cleanPhone(lead.phone)}`} size={80} />
              </div>
              <div className="text-xs text-slate-600 dark:text-slate-300">
                <p className="font-bold text-slate-900 dark:text-white flex items-center gap-1 text-xs">
                  <QrCode className="w-3.5 h-3.5 text-emerald-600" /> Point Phone Camera to Dial
                </p>
                <p className="mt-1 text-[11px] leading-relaxed text-slate-500 dark:text-slate-400">
                  Using CRM on a laptop or desktop? Scan this QR code with your smartphone camera to immediately dial <b>{formatPhoneDisplay(lead.phone)}</b> without typing the number.
                </p>
              </div>
            </div>
          )}
        </div>

        <div className="space-y-4 py-2">
          <div>
            <Label>Call outcome *</Label>
            <div className="grid grid-cols-2 gap-1.5 mt-2">
              <p className="col-span-2 text-[11px] font-semibold text-emerald-600 uppercase">Connected</p>
              {CONNECTED.map((d) => (
                <button key={d} data-testid={`disposition-opt-${d}`} onClick={() => setDisposition(d)}
                  className={`text-xs px-2 py-1.5 rounded-md border text-left transition-colors ${disposition === d ? "bg-[#0A66C2] text-white border-[#0A66C2] font-semibold shadow-sm" : "border-slate-200 hover:border-[#0A66C2] text-slate-700"}`}>{d}</button>
              ))}
              <p className="col-span-2 text-[11px] font-semibold text-rose-600 uppercase mt-1">Not Connected</p>
              {NOT_CONNECTED.map((d) => (
                <button key={d} data-testid={`disposition-opt-${d}`} onClick={() => setDisposition(d)}
                  className={`text-xs px-2 py-1.5 rounded-md border text-left transition-colors ${disposition === d ? "bg-[#5F259F] text-white border-[#5F259F] font-semibold shadow-sm" : "border-slate-200 hover:border-[#5F259F] text-slate-700"}`}>{d}</button>
              ))}
            </div>
          </div>

          {needInterview && (
            <div className="grid gap-2 p-3 rounded-lg bg-blue-50 border border-blue-200">
              <p className="text-xs font-semibold text-blue-700">Interview details required</p>
              <div>
                <Label className="text-xs">Interview date & time *</Label>
                <Input data-testid="interview-date-input" type="datetime-local" value={interviewDate} onChange={(e) => setInterviewDate(e.target.value)} className="mt-1" />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Label className="text-xs">Client *</Label>
                  <Select value={clientId} onValueChange={setClientId}>
                    <SelectTrigger data-testid="interview-client-select" className="mt-1"><SelectValue placeholder="Client" /></SelectTrigger>
                    <SelectContent>{clients.map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-xs">Job *</Label>
                  <Select value={jobId} onValueChange={setJobId}>
                    <SelectTrigger data-testid="interview-job-select" className="mt-1"><SelectValue placeholder="Job" /></SelectTrigger>
                    <SelectContent>{jobs.filter((j) => !clientId || j.client_id === clientId).map((j) => <SelectItem key={j.id} value={j.id}>{j.title}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
              </div>
              <div>
                <Label className="text-xs">Type</Label>
                <Select value={interviewType} onValueChange={setInterviewType}>
                  <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent>{["Walk-in", "Telephonic", "Virtual", "F2F"].map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
          )}

          <div>
            <Label className="text-xs">Update lead status (optional)</Label>
            <Select value={leadStatus} onValueChange={setLeadStatus}>
              <SelectTrigger data-testid="lead-status-select" className="mt-1"><SelectValue placeholder="Keep current / auto" /></SelectTrigger>
              <SelectContent>{statuses.map((s) => <SelectItem key={s} value={s}>{s}{isFinal(s) ? " (final)" : ""}</SelectItem>)}</SelectContent>
            </Select>
          </div>

          {showFollowup && (
            <div className="grid gap-2 p-3 rounded-lg bg-amber-50 border border-amber-200" data-testid="followup-section">
              <p className="text-xs font-semibold text-amber-700">{mustFollowup ? "Callback follow-up required" : "Next follow-up required (lead is still active)"}</p>
              <div>
                <Label className="text-xs">Next follow-up date & time *</Label>
                <Input data-testid="followup-date-input" type="datetime-local" value={followupDate} onChange={(e) => setFollowupDate(e.target.value)} className="mt-1" />
                <div className="flex flex-wrap gap-1.5 mt-2">
                  <button type="button" onClick={() => setPreset("1h")} className="text-[10px] px-2 py-0.5 rounded bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 hover:border-purple-600 font-medium text-slate-700 dark:text-slate-300">
                    +1 Hour
                  </button>
                  <button type="button" onClick={() => setPreset("today5pm")} className="text-[10px] px-2 py-0.5 rounded bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 hover:border-purple-600 font-medium text-slate-700 dark:text-slate-300">
                    Today 5 PM
                  </button>
                  <button type="button" onClick={() => setPreset("tomorrow10am")} className="text-[10px] px-2 py-0.5 rounded bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 hover:border-purple-600 font-medium text-slate-700 dark:text-slate-300">
                    Tomorrow 10 AM
                  </button>
                  <button type="button" onClick={() => setPreset("2days")} className="text-[10px] px-2 py-0.5 rounded bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 hover:border-purple-600 font-medium text-slate-700 dark:text-slate-300">
                    In 2 Days
                  </button>
                </div>
              </div>
              <div>
                <Label className="text-xs">Reason {mustFollowup ? "*" : ""}</Label>
                <Input data-testid="followup-reason-input" value={followupReason} onChange={(e) => setFollowupReason(e.target.value)} placeholder="e.g. candidate will confirm availability" className="mt-1" />
              </div>
            </div>
          )}
          {disposition && finalOutcome && <p className="text-xs text-slate-500 bg-slate-50 border border-slate-200 rounded-md px-3 py-2" data-testid="final-status-note">Lead will be closed as <b>{predicted}</b> — no further follow-up needed.</p>}

          {isSelected && (
            <div>
              <Label className="text-xs">Expected joining date *</Label>
              <Input data-testid="expected-joining-input" type="date" value={expectedJoining} onChange={(e) => setExpectedJoining(e.target.value)} className="mt-1" />
            </div>
          )}

          {needReason && (
            <div>
              <Label className="text-xs">Reason *</Label>
              <Select value={lostReason} onValueChange={setLostReason}>
                <SelectTrigger data-testid="lost-reason-select" className="mt-1"><SelectValue placeholder="Select reason" /></SelectTrigger>
                <SelectContent>{LOST_REASONS.map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          )}

          <div>
            <Label className="text-xs">Notes</Label>
            <Textarea data-testid="call-notes-input" value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Add call notes…" className="mt-1" rows={2} />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button data-testid="disposition-submit-button" onClick={save} disabled={saving} className="bg-[#0A66C2] hover:bg-[#08549e] text-white shadow-sm font-semibold">
            {saving ? "Saving…" : "Save call"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
