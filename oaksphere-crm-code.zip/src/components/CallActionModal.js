import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { QRCodeSVG } from "qrcode.react";
import { cleanPhone, formatPhoneDisplay, copyPhoneNumber, dialNumber } from "@/lib/calling";
import { PriorityBadge, StatusBadge, fmtDate } from "@/lib/ui";
import {
  PhoneCall,
  Phone,
  Copy,
  Check,
  QrCode,
  MessageCircle,
  ClipboardCheck,
  Clock,
  Play,
  Pause,
  RotateCcw,
  Sparkles,
  MapPin,
  Briefcase,
  Smartphone,
  ChevronRight,
  UserCheck,
} from "lucide-react";

export default function CallActionModal({
  open,
  onOpenChange,
  lead,
  onOpenDisposition,
  onDone,
}) {
  const [showQr, setShowQr] = useState(false);
  const [copied, setCopied] = useState(false);
  const [timerRunning, setTimerRunning] = useState(false);
  const [callSeconds, setCallSeconds] = useState(0);
  const [hasDialed, setHasDialed] = useState(false);

  // Timer logic for active call
  useEffect(() => {
    let interval = null;
    if (timerRunning) {
      interval = setInterval(() => {
        setCallSeconds((s) => s + 1);
      }, 1000);
    } else {
      clearInterval(interval);
    }
    return () => clearInterval(interval);
  }, [timerRunning]);

  // Reset when dialog opens/changes
  useEffect(() => {
    if (open) {
      setShowQr(false);
      setCopied(false);
      setTimerRunning(false);
      setCallSeconds(0);
      setHasDialed(false);
    }
  }, [open, lead]);

  if (!lead) return null;

  const handleCopy = () => {
    copyPhoneNumber(lead.phone);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDial = () => {
    dialNumber(lead.phone, { showToast: true });
    setHasDialed(true);
    if (!timerRunning) {
      setTimerRunning(true);
    }
  };

  const handleAltDial = () => {
    if (lead.alt_phone) {
      dialNumber(lead.alt_phone, { showToast: true });
      setHasDialed(true);
      if (!timerRunning) {
        setTimerRunning(true);
      }
    }
  };

  const formatTimer = (totalSeconds) => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;
  };

  const handleGoToDisposition = () => {
    onOpenChange(false);
    onOpenDisposition?.(lead, callSeconds);
  };

  const telUri = `tel:${cleanPhone(lead.phone)}`;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        className="max-w-md bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-6"
        data-testid="call-action-modal"
      >
        <DialogHeader className="space-y-1">
          <div className="flex items-center justify-between">
            <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold uppercase tracking-wider bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
              <PhoneCall className="w-3.5 h-3.5" /> Call Candidate
            </span>
            <div className="flex items-center gap-1.5">
              <PriorityBadge priority={lead.priority} />
              <StatusBadge status={lead.lead_status || lead.status} />
            </div>
          </div>
          <DialogTitle className="text-xl font-bold font-display text-slate-900 dark:text-white pt-1">
            {lead.name}
          </DialogTitle>
          <DialogDescription className="sr-only">
            Direct dialing options, mobile QR connect, and call stopwatch
          </DialogDescription>
          <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
            {lead.city && (
              <span className="inline-flex items-center gap-1">
                <MapPin className="w-3 h-3 text-slate-400" /> {lead.city}
              </span>
            )}
            {lead.job_title && (
              <span className="inline-flex items-center gap-1">
                <Briefcase className="w-3 h-3 text-slate-400" /> {lead.job_title}
              </span>
            )}
            {lead.recruiter_name && (
              <span className="inline-flex items-center gap-1">
                <UserCheck className="w-3 h-3 text-slate-400" /> {lead.recruiter_name}
              </span>
            )}
          </div>
        </DialogHeader>

        {/* Primary Phone Display & Direct Dial Card */}
        <div className="bg-gradient-to-br from-emerald-50 via-teal-50/50 to-blue-50 dark:from-slate-800 dark:to-slate-800/80 p-4 rounded-xl border border-emerald-200/80 dark:border-slate-700 space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-[10px] uppercase font-bold tracking-wider text-emerald-800 dark:text-emerald-400 flex items-center gap-1">
                <Smartphone className="w-3.5 h-3.5" /> Primary Phone
              </p>
              <p
                data-testid="call-modal-phone"
                className="text-xl font-bold font-mono text-slate-900 dark:text-white tracking-tight mt-0.5"
              >
                {formatPhoneDisplay(lead.phone)}
              </p>
            </div>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={handleCopy}
              data-testid="call-modal-copy-btn"
              className="h-8 text-xs bg-white/80 dark:bg-slate-800 hover:bg-white"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 mr-1 text-emerald-600" /> Copied
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5 mr-1" /> Copy
                </>
              )}
            </Button>
          </div>

          {/* Primary Action Button: Deliberate Dial (Never automatic) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
            <Button
              type="button"
              onClick={handleDial}
              data-testid="call-modal-dial-btn"
              className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-sm h-10 shadow-sm flex items-center justify-center gap-2"
            >
              <PhoneCall className="w-4 h-4" />
              <span>Dial on Phone</span>
            </Button>

            <Button
              type="button"
              variant="outline"
              onClick={() => setShowQr(!showQr)}
              data-testid="call-modal-qr-toggle-btn"
              className="w-full text-slate-700 dark:text-slate-200 border-slate-300 dark:border-slate-700 bg-white/90 dark:bg-slate-800 text-xs h-10 flex items-center justify-center gap-1.5"
            >
              <QrCode className="w-4 h-4 text-slate-500" />
              <span>{showQr ? "Hide QR Code" : "Scan to Call (QR)"}</span>
            </Button>
          </div>

          {/* QR Code expansion */}
          {showQr && (
            <div
              className="p-3 bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-800 text-center animate-fade-in"
              data-testid="call-modal-qr-panel"
            >
              <div className="inline-block p-2 bg-white rounded-lg shadow-sm border border-slate-200">
                <QRCodeSVG value={telUri} size={130} />
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-400 mt-2 font-medium">
                Point your mobile camera to dial {lead.name} instantly
              </p>
            </div>
          )}

          {/* Alternate Phone if available */}
          {lead.alt_phone && (
            <div className="pt-2 border-t border-emerald-200/50 dark:border-slate-700/60 flex items-center justify-between text-xs">
              <span className="text-slate-500">Alt Phone: {formatPhoneDisplay(lead.alt_phone)}</span>
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={handleAltDial}
                className="h-7 text-xs text-emerald-700 hover:bg-emerald-100/50"
              >
                <Phone className="w-3 h-3 mr-1" /> Dial Alt
              </Button>
            </div>
          )}
        </div>

        {/* Live Call Duration Timer */}
        <div className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-[#0A66C2]" />
            <div>
              <p className="text-[11px] font-semibold text-slate-700 dark:text-slate-300">
                Call Duration Stopwatch
              </p>
              <p className="text-base font-mono font-bold text-[#0A66C2]">
                {formatTimer(callSeconds)}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1">
            <Button
              type="button"
              size="sm"
              variant="outline"
              onClick={() => setTimerRunning(!timerRunning)}
              className="h-8 text-xs"
            >
              {timerRunning ? (
                <>
                  <Pause className="w-3.5 h-3.5 mr-1 text-amber-600" /> Pause
                </>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5 mr-1 text-emerald-600" /> Start
                </>
              )}
            </Button>
            {callSeconds > 0 && (
              <Button
                type="button"
                size="sm"
                variant="ghost"
                onClick={() => {
                  setTimerRunning(false);
                  setCallSeconds(0);
                }}
                className="h-8 text-xs text-slate-400 hover:text-slate-600"
                title="Reset timer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </Button>
            )}
          </div>
        </div>

        {/* Separation Notice & Direct Disposition Jump */}
        <div className="p-3 rounded-lg bg-purple-50 dark:bg-purple-950/30 border border-purple-200 dark:border-purple-800 text-xs">
          <div className="flex items-center justify-between gap-2">
            <div>
              <p className="font-bold text-[#5F259F] dark:text-purple-300 flex items-center gap-1">
                <ClipboardCheck className="w-4 h-4 text-[#5F259F]" /> Call and Disposition are separated
              </p>
              <p className="text-slate-600 dark:text-slate-400 text-[11px] mt-0.5">
                Dial anytime without forced logs. When finished, log outcome & next follow-up.
              </p>
            </div>
          </div>
        </div>

        <DialogFooter className="flex flex-col sm:flex-row gap-2 pt-2 sm:justify-between items-center">
          <Button
            type="button"
            variant="outline"
            onClick={() => onOpenChange(false)}
            className="w-full sm:w-auto text-xs"
          >
            Close
          </Button>

          <Button
            type="button"
            onClick={handleGoToDisposition}
            data-testid="call-modal-open-disposition-btn"
            className="w-full sm:w-auto bg-[#5F259F] hover:bg-[#501E87] text-white font-semibold text-xs h-9 shadow-sm flex items-center justify-center gap-1.5"
          >
            <ClipboardCheck className="w-4 h-4" />
            <span>Open Disposition & Follow-up</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
