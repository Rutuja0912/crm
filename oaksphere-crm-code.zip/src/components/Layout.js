import { useState, useEffect } from "react";
import { useNavigate, useLocation, Link } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import api from "@/lib/api";
import { initials } from "@/lib/ui";
import {
  LayoutDashboard, Sun, Phone, ListChecks, CalendarClock, Users2, Briefcase,
  Building2, UserCog, BarChart3, Upload, Bell, Settings as SettingsIcon,
  Search, LogOut, Menu, X, AlertTriangle, PhoneCall, ClipboardList, ChevronRight,
  Inbox, Globe, Plug, HeartPulse, CalendarCheck2, WalletCards, ContactRound,
  CheckSquare, FileText, Megaphone, MessageSquare, CalendarDays, ShieldCheck,
  Plus, Sparkles, UserPlus, ChevronDown, ExternalLink, Layers, LayoutGrid
} from "lucide-react";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from "@/components/ui/sheet";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator, DropdownMenuLabel } from "@/components/ui/dropdown-menu";

const NAV_GROUPS = [
  {
    title: "Recruitment Pipeline",
    items: [
      { to: "/admin", label: "Dashboard", icon: LayoutDashboard, roles: ["admin", "team_leader", "recruiter"] },
      { to: "/admin/my-day", label: "My Day", icon: Sun, roles: ["recruiter", "team_leader"] },
      { to: "/admin/leads", label: "All Leads", icon: Users2, roles: ["admin", "team_leader", "recruiter"] },
      { to: "/admin/my-leads", label: "My Leads", icon: ClipboardList, roles: ["recruiter", "team_leader"] },
      { to: "/admin/calling", label: "Calling List", icon: PhoneCall, roles: ["admin", "team_leader", "recruiter"] },
      { to: "/admin/followups", label: "Follow-ups", icon: CalendarClock, roles: ["admin", "team_leader", "recruiter"] },
      { to: "/admin/tasks", label: "Tasks & To-Dos", icon: CheckSquare, roles: ["admin", "team_leader", "recruiter"] },
      { to: "/admin/applications", label: "Applications", icon: FileText, roles: ["admin", "team_leader", "recruiter"] },
      { to: "/admin/interviews", label: "Interviews", icon: Phone, roles: ["admin", "team_leader", "recruiter"] },
      { to: "/admin/joining", label: "Joining", icon: ListChecks, roles: ["admin", "team_leader", "recruiter"] },
    ],
  },
  {
    title: "Clients & Mandates",
    items: [
      { to: "/admin/jobs", label: "Jobs (CRM)", icon: Briefcase, roles: ["admin", "team_leader", "recruiter"] },
      { to: "/admin/clients", label: "Clients", icon: Building2, roles: ["admin", "team_leader", "recruiter"] },
      { to: "/admin/vendors", label: "Vendors & Empanelment", icon: Building2, roles: ["admin", "team_leader", "recruiter"] },
      { to: "/admin/marketing", label: "Lead Sources & Ads", icon: Megaphone, roles: ["admin", "team_leader"] },
      { to: "/admin/templates", label: "Templates", icon: MessageSquare, roles: ["admin", "team_leader", "recruiter"] },
    ],
  },
  {
    title: "HRMS & Workforce",
    items: [
      { to: "/admin/hrms", label: "HRMS Hub", icon: HeartPulse, roles: ["admin", "team_leader", "recruiter"] },
      { to: "/admin/attendance", label: "Attendance", icon: CalendarCheck2, roles: ["admin", "team_leader", "recruiter"] },
      { to: "/admin/leave", label: "Leave Management", icon: CalendarDays, roles: ["admin", "team_leader", "recruiter"] },
      { to: "/admin/employees", label: "Employees", icon: ContactRound, roles: ["admin", "team_leader"] },
      { to: "/admin/payroll", label: "Payroll", icon: WalletCards, roles: ["admin", "team_leader", "recruiter"] },
    ],
  },
  {
    title: "Analytics & Settings",
    items: [
      { to: "/admin/recruiters", label: "Recruiters", icon: UserCog, roles: ["admin", "team_leader"] },
      { to: "/admin/reports", label: "Reports", icon: BarChart3, roles: ["admin", "team_leader", "recruiter"] },
      { to: "/admin/action-required", label: "Action Required", icon: AlertTriangle, roles: ["admin", "team_leader"] },
      { to: "/admin/lead-inbox", label: "Lead Inbox", icon: Inbox, roles: ["admin", "team_leader"] },
      { to: "/admin/integrations", label: "Integrations", icon: Plug, roles: ["admin"] },
      { to: "/admin/import", label: "Import Leads", icon: Upload, roles: ["admin"] },
      { to: "/admin/notifications", label: "Notifications", icon: Bell, roles: ["admin", "team_leader", "recruiter"] },
      { to: "/admin/audit-logs", label: "Audit Logs", icon: ShieldCheck, roles: ["admin"] },
      { to: "/admin/settings", label: "Settings", icon: SettingsIcon, roles: ["admin"] },
    ],
  },
  {
    title: "Connected Platforms",
    items: [
      { to: "/admin/website-cms", label: "Website Control Center", icon: Globe, roles: ["admin", "team_leader"] },
    ],
  },
];

const ROLE_LABEL = { admin: "Admin / Owner", team_leader: "Team Leader", recruiter: "Recruiter" };

function SidebarContent({ user, onNav }) {
  const loc = useLocation();
  const isCrmRoute = loc.pathname.startsWith("/crm");
  const prefix = isCrmRoute ? "/crm" : "/admin";

  return (
    <div className="flex flex-col h-full bg-gradient-to-b from-[#3D1268] via-[#5F259F] to-[#250847] text-slate-100 shadow-xl">
      <div className="h-16 flex items-center justify-between px-5 border-b border-white/10 flex-shrink-0">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-[#0A66C2] via-[#2164F3] to-[#5F259F] flex items-center justify-center font-bold text-white font-display shadow-md">
            O
          </div>
          <div className="leading-tight">
            <p className="text-white font-bold font-display text-sm flex items-center gap-1.5">
              <span>OAKsphere</span>
              <span className="text-[9px] px-1.5 py-0.5 rounded bg-[#0A66C2] text-white font-mono font-bold tracking-wide">
                CRM
              </span>
            </p>
            <p className="text-[10px] text-purple-200/80 font-medium">Individual Recruiter OS</p>
          </div>
        </div>
      </div>

      <nav className="flex-1 overflow-y-auto py-3 px-3 space-y-4">
        {NAV_GROUPS.map((group) => {
          const visibleItems = group.items.filter((n) => n.roles.includes(user.role));
          if (visibleItems.length === 0) return null;

          return (
            <div key={group.title} className="space-y-1">
              <div className="px-3 text-[10px] uppercase font-bold tracking-wider text-purple-300/60 pb-1">
                {group.title}
              </div>
              {visibleItems.map((n) => {
                const targetPath = isCrmRoute ? (n.to === "/admin" ? "/crm" : n.to.replace(/^\/admin/, "/crm")) : n.to;
                const active = loc.pathname === targetPath || loc.pathname === n.to;

                return (
                  <Link
                    key={n.to}
                    to={targetPath}
                    onClick={onNav}
                    data-testid={`nav-${n.label.toLowerCase().replace(/[^a-z]+/g, "-")}`}
                    className={`flex items-center gap-3 px-3 py-1.5 rounded-lg text-xs font-medium transition-all duration-150 ${
                      active
                        ? "bg-[#0A66C2] text-white font-semibold shadow-md shadow-blue-950/40 translate-x-0.5"
                        : "text-purple-100/90 hover:bg-white/10 hover:text-white"
                    }`}
                  >
                    <n.icon className={`w-[17px] h-[17px] flex-shrink-0 ${active ? "text-white" : "text-purple-200"}`} />
                    <span className="truncate">{n.label}</span>
                  </Link>
                );
              })}
            </div>
          );
        })}
      </nav>

      {/* Public Site Fast-Switch Footer */}
      <div className="p-3 border-t border-white/10 bg-black/20 space-y-2">
        <a
          href="/"
          target="_blank"
          rel="noreferrer"
          className="flex items-center justify-between px-3 py-1.5 rounded-md bg-white/5 hover:bg-white/10 text-purple-200 hover:text-white text-xs transition-colors"
        >
          <span className="flex items-center gap-2">
            <Globe className="w-3.5 h-3.5 text-[#0A66C2]" />
            <span>Public Website</span>
          </span>
          <ExternalLink className="w-3 h-3 text-purple-300/70" />
        </a>

        <div className="text-[11px] text-purple-200/70 flex items-center justify-between px-1">
          <span>v2.0 • {ROLE_LABEL[user.role]}</span>
          <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
        </div>
      </div>
    </div>
  );
}

export default function Layout({ children }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [q, setQ] = useState("");
  const [results, setResults] = useState([]);
  const [unread, setUnread] = useState(0);
  const loc = useLocation();
  const isCrmRoute = loc.pathname.startsWith("/crm");
  const prefix = isCrmRoute ? "/crm" : "/admin";

  useEffect(() => {
    const refresh = () => api.get("/notifications/unread-count").then((r) => setUnread(r.data.count)).catch(() => {});
    refresh();
    window.addEventListener("oak:notif", refresh);
    return () => window.removeEventListener("oak:notif", refresh);
  }, [loc.pathname]);

  useEffect(() => {
    if (q.length < 2) { setResults([]); return; }
    const t = setTimeout(() => {
      api.get(`/leads/search?q=${encodeURIComponent(q)}`).then((r) => setResults(r.data)).catch(() => {});
    }, 250);
    return () => clearTimeout(t);
  }, [q]);

  if (!user) return null;

  return (
    <div className="App flex min-h-screen bg-slate-50 dark:bg-slate-950">
      <aside className="hidden lg:block w-64 flex-shrink-0 fixed inset-y-0 left-0 z-30">
        <SidebarContent user={user} />
      </aside>

      <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
        <SheetContent side="left" className="p-0 w-64 border-0">
          <SheetHeader className="sr-only">
            <SheetTitle>Navigation Menu</SheetTitle>
            <SheetDescription>Main navigation and recruitment workspaces</SheetDescription>
          </SheetHeader>
          <SidebarContent user={user} onNav={() => setMobileOpen(false)} />
        </SheetContent>
      </Sheet>

      <div className="flex-1 lg:ml-64 flex flex-col min-w-0">
        <header className="h-16 flex items-center gap-3 px-4 sm:px-6 backdrop-blur-md bg-white/95 dark:bg-slate-900/95 border-b border-slate-200/80 dark:border-slate-800 sticky top-0 z-20">
          <button data-testid="mobile-menu-btn" className="lg:hidden p-2" onClick={() => setMobileOpen(true)}>
            <Menu className="w-5 h-5" />
          </button>

          {/* Workspace Switcher Selector */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="outline"
                size="sm"
                className="h-8 px-2.5 text-xs font-semibold gap-1.5 border-purple-200 dark:border-purple-900 bg-purple-50/70 hover:bg-purple-100/70 text-[#5F259F] dark:text-purple-300 dark:bg-purple-950/40"
                id="crm-workspace-switcher-btn"
              >
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                <span className="font-bold">Recruitment CRM</span>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-64 p-1.5 shadow-xl">
              <DropdownMenuLabel className="text-[10px] font-bold uppercase tracking-wider text-slate-400 px-2 py-1">
                Active Workspace
              </DropdownMenuLabel>
              <div className="p-2.5 bg-purple-50 dark:bg-purple-950/50 rounded-md border border-purple-200 dark:border-purple-800 mb-1.5">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded bg-[#5F259F] text-white flex items-center justify-center font-bold text-xs">O</div>
                  <div>
                    <p className="text-xs font-bold text-purple-950 dark:text-purple-100">OAKSphere CRM</p>
                    <p className="text-[10px] text-purple-700 dark:text-purple-300">Standalone Recruiter OS</p>
                  </div>
                </div>
              </div>
              <DropdownMenuSeparator />
              <DropdownMenuLabel className="text-[10px] font-bold uppercase tracking-wider text-slate-400 px-2 py-1">
                Switch Platform
              </DropdownMenuLabel>
              <DropdownMenuItem onClick={() => window.open("/", "_blank")} className="cursor-pointer text-xs py-2">
                <Globe className="w-4 h-4 mr-2 text-[#0A66C2]" />
                <div className="flex-1">
                  <p className="font-medium text-slate-700 dark:text-slate-200">Public Career Website</p>
                  <p className="text-[10px] text-slate-400">Open candidate & employer site ↗</p>
                </div>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => navigate(isCrmRoute ? "/crm/website-cms" : "/admin/website-cms")} className="cursor-pointer text-xs py-2">
                <SettingsIcon className="w-4 h-4 mr-2 text-violet-600" />
                <div className="flex-1">
                  <p className="font-medium text-slate-700 dark:text-slate-200">Website CMS Studio</p>
                  <p className="text-[10px] text-slate-400">Manage pages, SEO & blogs</p>
                </div>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => navigate("/portal")} className="cursor-pointer text-xs py-2">
                <LayoutGrid className="w-4 h-4 mr-2 text-amber-600" />
                <div className="flex-1">
                  <p className="font-medium text-slate-700 dark:text-slate-200">App Switcher Gateway</p>
                  <p className="text-[10px] text-slate-400">View all platform portals</p>
                </div>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <div className="relative flex-1 max-w-md hidden sm:block">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input
              data-testid="global-search-input"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search candidate name, phone, email…"
              className="pl-9 h-9 bg-slate-50 dark:bg-slate-800 border-slate-200 text-xs"
            />
            {results.length > 0 && (
              <div className="absolute mt-1 w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg shadow-lg z-50 max-h-80 overflow-y-auto">
                {results.map((r) => (
                  <button
                    key={r.id}
                    data-testid={`search-result-${r.id}`}
                    onClick={() => { setQ(""); setResults([]); navigate(`${prefix}/leads?focus=${r.id}`); }}
                    className="w-full text-left px-3 py-2 hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center justify-between gap-2"
                  >
                    <div>
                      <p className="text-sm font-medium">{r.name}</p>
                      <p className="text-xs text-slate-400 font-mono">{r.phone}</p>
                    </div>
                    {r.duplicate_flag && <span className="text-[10px] text-rose-600 font-semibold">DUPLICATE</span>}
                    <ChevronRight className="w-4 h-4 text-slate-300" />
                  </button>
                ))}
              </div>
            )}
          </div>
          <div className="flex-1" />

          {/* Direct Link to Website */}
          <a
            href="/"
            target="_blank"
            rel="noreferrer"
            className="hidden md:flex items-center gap-1.5 px-3 py-1 rounded-md text-xs font-medium text-slate-600 hover:text-[#0A66C2] hover:bg-slate-100 transition-colors"
          >
            <Globe className="w-3.5 h-3.5 text-slate-400" />
            <span>View Website</span>
            <ExternalLink className="w-3 h-3 text-slate-400" />
          </a>

          {/* Quick Action Button */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                size="sm"
                className="bg-[#5F259F] hover:bg-[#501E87] text-white text-xs h-8 px-3 font-semibold shadow-sm flex items-center gap-1.5 transition-colors"
                id="header-quick-action-btn"
              >
                <Plus className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Quick Action</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-52 shadow-xl">
              <DropdownMenuLabel className="text-xs text-slate-500 uppercase tracking-wider">Fast Create</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => navigate(`${prefix}/leads?new=1`)} className="text-xs cursor-pointer">
                <UserPlus className="w-4 h-4 mr-2 text-[#5F259F]" /> New Candidate Lead
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => navigate(`${prefix}/jobs?new=1`)} className="text-xs cursor-pointer">
                <Briefcase className="w-4 h-4 mr-2 text-[#0A66C2]" /> New Job Opening
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => navigate(`${prefix}/tasks`)} className="text-xs cursor-pointer">
                <CheckSquare className="w-4 h-4 mr-2 text-[#2164F3]" /> Add Task / Reminder
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => navigate(`${prefix}/followups`)} className="text-xs cursor-pointer">
                <CalendarClock className="w-4 h-4 mr-2 text-emerald-600" /> Schedule Follow-up
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => navigate(`${prefix}/interviews`)} className="text-xs cursor-pointer">
                <Phone className="w-4 h-4 mr-2 text-[#0078DB]" /> Schedule Interview
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => navigate(`${prefix}/vendors`)} className="text-xs cursor-pointer">
                <Building2 className="w-4 h-4 mr-2 text-rose-600" /> Add Vendor Lead
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <Link to={`${prefix}/notifications`} data-testid="notification-bell" className="relative p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800">
            <Bell className="w-5 h-5 text-slate-500" />
            {unread > 0 && <span className="absolute top-1 right-1 min-w-[16px] h-4 px-1 rounded-full bg-rose-500 text-white text-[10px] flex items-center justify-center font-semibold">{unread}</span>}
          </Link>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button data-testid="user-menu-btn" className="flex items-center gap-2 pl-2 pr-1 py-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800">
                <Avatar className="w-8 h-8 ring-2 ring-[#0A66C2]/20">
                  {user.avatar && <AvatarImage src={user.avatar} />}
                  <AvatarFallback className="bg-[#0A66C2] text-white text-xs font-bold">{initials(user.name)}</AvatarFallback>
                </Avatar>
                <div className="hidden sm:block text-left leading-tight">
                  <p className="text-sm font-semibold text-slate-800 dark:text-slate-100">{user.name}</p>
                  <p className="text-[11px] text-slate-400">{ROLE_LABEL[user.role]}</p>
                </div>
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-52 shadow-xl">
              <DropdownMenuLabel>{user.email}</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => navigate("/portal")} className="text-xs cursor-pointer">
                <Layers className="w-4 h-4 mr-2 text-slate-500" /> Switch Workspace
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => window.open("/", "_blank")} className="text-xs cursor-pointer">
                <Globe className="w-4 h-4 mr-2 text-slate-500" /> Public Website ↗
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem data-testid="logout-btn" onClick={logout} className="text-rose-600 cursor-pointer">
                <LogOut className="w-4 h-4 mr-2" /> Log out
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </header>

        <main className="flex-1 p-4 sm:p-6 lg:p-8 animate-fade-in-up">{children}</main>
      </div>
    </div>
  );
}
