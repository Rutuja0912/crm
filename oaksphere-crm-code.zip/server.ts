import express, { Request, Response, NextFunction } from "express";
import path from "path";
import cors from "cors";
import cookieParser from "cookie-parser";
import { createServer as createViteServer } from "vite";
import {
  mockUsers,
  mockClients,
  mockJobs,
  mockLeads,
  mockInterviews,
  mockJoinings,
  mockSiteData,
  mockFaqs,
  mockBlogs,
  mockEmployees,
  mockAttendance,
  mockPayroll,
  mockTasks,
  mockVendors,
  mockLeaves,
  mockTemplates,
  mockApplications,
  Lead,
  Job,
  Client,
  User,
} from "./src/server/mockDb";
import {
  cmsStore,
  generateRobotsTxtContent,
  generateSitemapXmlContent,
  runFullSeoAudit,
  calculateSearchAiReadiness,
} from "./src/server/cmsStore";

const app = express();
const PORT = 3000;

// Security Headers Middleware
app.use((_req: Request, res: Response, next: NextFunction) => {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("X-Frame-Options", "SAMEORIGIN");
  res.setHeader("X-XSS-Protection", "1; mode=block");
  res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
  next();
});

// CORS Configuration
app.use(
  cors({
    origin: true,
    credentials: true,
    methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allowedHeaders: ["Content-Type", "Authorization", "X-Requested-With", "Accept", "X-User-Id"],
  })
);

app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true, limit: "10mb" }));
app.use(cookieParser());

// Fallback rewrite for client bundle pathing
app.use((req: Request, _res: Response, next: NextFunction) => {
  if (req.url.startsWith("/undefined/api")) {
    req.url = req.url.replace(/^\/undefined/, "");
  }
  next();
});

// Dynamic Redirects Middleware (OAKSphere SEO Control Center)
app.use((req: Request, res: Response, next: NextFunction) => {
  if (req.path.startsWith("/api") || req.path.startsWith("/@") || req.path.startsWith("/src") || req.path.includes(".")) {
    return next();
  }
  const matching = (cmsStore.redirects || []).find((r) => r.active && r.from_path === req.path);
  if (matching) {
    matching.hits = (matching.hits || 0) + 1;
    matching.last_hit = new Date().toISOString();
    if (matching.status_code === 410) {
      return res.status(410).send("410 Gone - This vacancy or resource has been permanently removed.");
    }
    return res.redirect(matching.status_code, matching.to_path);
  }
  next();
});

// ---------------- IN-MEMORY DATA STORE ----------------
let users: User[] = [...mockUsers];
let clients: Client[] = [...mockClients];
let jobs: Job[] = [...mockJobs];
let leads: Lead[] = [...mockLeads];
let interviews: any[] = [...mockInterviews];
let joinings: any[] = [...mockJoinings];
let employees: any[] = [...mockEmployees];
let attendance: any[] = [...mockAttendance];
let payroll: any[] = [...mockPayroll];
let siteData: any = {
  ...JSON.parse(JSON.stringify(mockSiteData)),
  settings: { ...mockSiteData.settings, ...cmsStore.settings },
  menus: cmsStore.menus,
  pages: cmsStore.pages,
  locations: cmsStore.locations,
  services: cmsStore.services,
  content_blocks: cmsStore.content_blocks,
  contact: cmsStore.settings.contact,
};
let faqs: any[] = [...mockFaqs];
let blogs: any[] = [...mockBlogs];
let tasks: any[] = [...mockTasks];
let vendors: any[] = [...mockVendors];
let leaves: any[] = [...mockLeaves];
let templates: any[] = [...mockTemplates];
let applications: any[] = [...mockApplications];
let notifications: any[] = [
  { id: "n1", title: "New Lead Assigned", message: "Rahul Verma was assigned to Harshika Sharma", date: new Date().toISOString(), read: false },
  { id: "n2", title: "Interview Today", message: "Pooja Deshmukh has an interview at 3:00 PM with HDFC Life", date: new Date().toISOString(), read: false },
  { id: "n3", title: "Monthly Target Reached", message: "Harshika Sharma achieved 85% of monthly target", date: new Date().toISOString(), read: true },
];

let auditLogs: any[] = [
  { id: "log-init-1", action: "SYSTEM_INITIALIZED", user: "Admin User", timestamp: new Date().toISOString(), details: "OAKsphere Security Engine active" },
  { id: "log-init-2", action: "SECURITY_AUDIT", user: "System", timestamp: new Date().toISOString(), details: "Recruiter authorization isolation enforced" },
];

// Active session fallback for development preview
let currentActiveUserId: string = "u-admin";

// ---------------- AUTHENTICATION & AUTHORIZATION HELPERS ----------------

/**
 * Resolves the authenticated user strictly per request from:
 * 1. Bearer Token in Authorization header
 * 2. access_token Cookie
 * 3. X-User-Id header (for automated testing / dev tools)
 * 4. Fallback to active session user
 */
function getAuthUser(req: Request): User {
  // 1. Bearer token in Authorization header
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith("Bearer ")) {
    const rawToken = authHeader.substring(7);
    const id = rawToken.replace(/^(mock_jwt_token_|mock_token_|token_)/, "");
    const u = users.find((x) => x.id === id);
    if (u && u.active) return u;
  }

  // 2. Cookie access_token
  const cookieToken = req.cookies?.access_token;
  if (cookieToken) {
    const id = cookieToken.replace(/^(mock_jwt_token_|mock_token_|token_)/, "");
    const u = users.find((x) => x.id === id);
    if (u && u.active) return u;
  }

  // 3. X-User-Id header (for explicit role testing)
  const xUserId = req.headers["x-user-id"] as string;
  if (xUserId) {
    const u = users.find((x) => x.id === xUserId);
    if (u && u.active) return u;
  }

  // 4. Session fallback
  if (currentActiveUserId) {
    const u = users.find((x) => x.id === currentActiveUserId);
    if (u && u.active) return u;
  }

  return users[0];
}

/**
 * Priority 2 Protection:
 * Strips protected fields from request bodies so clients cannot overwrite:
 * recruiter_id, assigned_recruiter_id, owner, role, created_by, updated_by,
 * stage, permissions, audit fields, or immutable IDs.
 */
function sanitizeLeadBody(body: any, user: User, isNew = false): any {
  if (!body || typeof body !== "object") return {};
  const cleaned = { ...body };

  // Always protected / immutable fields:
  delete cleaned.id;
  delete cleaned._id;
  delete cleaned.created_at;
  delete cleaned.audit;
  delete cleaned.audit_logs;
  delete cleaned.audit_fields;

  if (user.role === "recruiter") {
    // Recruiters cannot tamper with assignments, roles, or ownership
    delete cleaned.assigned_recruiter_id;
    delete cleaned.assigned_recruiter_name;
    delete cleaned.recruiter_id;
    delete cleaned.owner;
    delete cleaned.role;
    delete cleaned.created_by;
    delete cleaned.updated_by;
    delete cleaned.permissions;
    delete cleaned.is_admin;
  }

  if (isNew) {
    if (user.role === "recruiter") {
      cleaned.assigned_recruiter_id = user.id;
      cleaned.assigned_recruiter_name = user.name;
      cleaned.created_by = user.name;
    }
  }

  return cleaned;
}

function sanitizeGeneralBody(body: any, user: User): any {
  if (!body || typeof body !== "object") return {};
  const cleaned = { ...body };
  delete cleaned.id;
  delete cleaned._id;
  delete cleaned.created_at;
  delete cleaned.audit;
  delete cleaned.audit_fields;

  if (user.role !== "admin") {
    delete cleaned.role;
    delete cleaned.permissions;
    delete cleaned.owner;
    delete cleaned.created_by;
    delete cleaned.updated_by;
    delete cleaned.recruiter_id;
    delete cleaned.assigned_recruiter_id;
    delete cleaned.assigned_recruiter_name;
    delete cleaned.is_admin;
  }
  return cleaned;
}

function logAudit(action: string, userName: string, details: string) {
  auditLogs.unshift({
    id: "log_" + Date.now(),
    action,
    user: userName,
    timestamp: new Date().toISOString(),
    details,
  });
  if (auditLogs.length > 200) auditLogs.pop();
}

// ---------------- SITEMAP & ROBOTS ----------------
function buildSitemapXml(): string {
  const baseUrl = "https://oaksphere.com";
  const now = new Date().toISOString().split("T")[0];

  const staticUrls = [
    { loc: `${baseUrl}/`, priority: "1.0", changefreq: "daily" },
    { loc: `${baseUrl}/employers`, priority: "0.9", changefreq: "weekly" },
    { loc: `${baseUrl}/candidates`, priority: "0.9", changefreq: "weekly" },
    { loc: `${baseUrl}/jobs`, priority: "0.9", changefreq: "daily" },
    { loc: `${baseUrl}/industries`, priority: "0.8", changefreq: "weekly" },
    { loc: `${baseUrl}/about`, priority: "0.7", changefreq: "monthly" },
    { loc: `${baseUrl}/blog`, priority: "0.8", changefreq: "weekly" },
    { loc: `${baseUrl}/faqs`, priority: "0.7", changefreq: "monthly" },
    { loc: `${baseUrl}/contact`, priority: "0.8", changefreq: "monthly" },
  ];

  const jobUrls = jobs
    .filter((j) => j.status === "Active" || j.status === "published")
    .map((j) => ({
      loc: `${baseUrl}/jobs/${j.slug}`,
      priority: "0.8",
      changefreq: "weekly",
    }));

  const blogUrls = blogs.map((b) => ({
    loc: `${baseUrl}/blog/${b.slug}`,
    priority: "0.7",
    changefreq: "monthly",
  }));

  const indUrls = (siteData.industries || []).map((i: any) => ({
    loc: `${baseUrl}/industry/${i.slug}`,
    priority: "0.7",
    changefreq: "monthly",
  }));

  const locUrls = (siteData.locations || []).map((l: any) => ({
    loc: `${baseUrl}/location/${l.slug}`,
    priority: "0.7",
    changefreq: "monthly",
  }));

  const all = [...staticUrls, ...jobUrls, ...blogUrls, ...indUrls, ...locUrls];

  return `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${all
  .map(
    (u) => `  <url>
    <loc>${u.loc}</loc>
    <lastmod>${now}</lastmod>
    <changefreq>${u.changefreq}</changefreq>
    <priority>${u.priority}</priority>
  </url>`
  )
  .join("\n")}
</urlset>`;
}

app.get(["/api/health", "/health"], (_req: Request, res: Response) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

app.get(["/sitemap.xml", "/api/sitemap.xml"], (_req: Request, res: Response) => {
  res.header("Content-Type", "application/xml");
  res.send(generateSitemapXmlContent(jobs, blogs));
});

app.get(["/robots.txt", "/api/robots.txt"], (_req: Request, res: Response) => {
  res.header("Content-Type", "text/plain");
  res.send(generateRobotsTxtContent());
});

// ---------------- AUTH ROUTES ----------------
app.post("/api/auth/login", (req: Request, res: Response) => {
  const { email } = req.body;
  const user = users.find((u) => u.email.toLowerCase() === (email || "").toLowerCase().trim());
  if (!user) {
    return res.status(401).json({ detail: "Invalid email or password" });
  }

  currentActiveUserId = user.id;
  const token = "mock_jwt_token_" + user.id;
  res.cookie("access_token", token, {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: 7 * 24 * 60 * 60 * 1000,
  });

  logAudit("USER_LOGIN", user.name, `Logged in with role: ${user.role}`);

  res.json({
    token,
    user: {
      id: user.id,
      email: user.email,
      name: user.name,
      role: user.role,
      phone: user.phone,
    },
  });
});

app.get("/api/auth/me", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  res.json({
    id: user.id,
    email: user.email,
    name: user.name,
    role: user.role,
    phone: user.phone,
  });
});

app.post("/api/auth/logout", (_req: Request, res: Response) => {
  currentActiveUserId = "";
  res.clearCookie("access_token", { path: "/" });
  res.json({ success: true });
});

app.post("/api/auth/google/session", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  res.json({ user });
});

app.post("/api/auth/change-password", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  logAudit("PASSWORD_CHANGE", user.name, "User requested password change");
  res.json({ success: true, message: "Password updated successfully" });
});

app.post("/api/auth/forgot-password", (_req: Request, res: Response) => {
  res.json({ success: true, message: "Reset instructions sent to email" });
});

app.post("/api/auth/reset-password", (_req: Request, res: Response) => {
  res.json({ success: true, message: "Password reset complete" });
});

// ---------------- PUBLIC WEBSITE DATA ----------------
app.get("/api/public/site", (_req: Request, res: Response) => {
  res.json(siteData);
});

app.get("/api/public/stats", (_req: Request, res: Response) => {
  res.json({
    headline: [
      { label: "Placements Done", value: "2,500+", sub: "Across 25+ cities" },
      { label: "Client Partners", value: "150+", sub: "IT, BFSI & Healthcare" },
      { label: "Turnaround Time", value: "48h", sub: "Pre-screened profiles" },
      { label: "Satisfaction Rate", value: "98.4%", sub: "High client retention" },
      { label: "Joining Ratio", value: "94%", sub: "Minimal drop-outs" },
    ],
    live: {
      open_jobs: jobs.filter((j) => j.status === "Active" || j.status === "published").length,
      active_jobs: jobs.filter((j) => j.status === "Active" || j.status === "published").length,
      active_candidates: leads.length * 15,
    },
  });
});

app.get("/api/public/jobs", (req: Request, res: Response) => {
  const limit = parseInt(req.query.limit as string) || 50;
  const filtered = jobs.filter((j) => j.status === "Active" || j.status === "published").slice(0, limit);
  res.json({ jobs: filtered, total: jobs.length });
});

app.get("/api/public/jobs/:slug", (req: Request, res: Response) => {
  const job = jobs.find((j) => j.slug === req.params.slug || j.id === req.params.slug) || jobs[0];
  if (!job) return res.status(404).json({ error: true });
  res.json({
    available: job.status === "Active" || job.status === "published",
    job,
    related: jobs.filter((j) => j.id !== job.id && (j.status === "Active" || j.status === "published")).slice(0, 3),
  });
});

app.get("/api/public/categories", (_req: Request, res: Response) => {
  res.json(siteData.categories || []);
});

app.get("/api/public/locations", (_req: Request, res: Response) => {
  res.json(siteData.locations || []);
});

app.get("/api/public/industries", (_req: Request, res: Response) => {
  res.json(siteData.industries || []);
});

app.get("/api/public/faqs", (_req: Request, res: Response) => {
  res.json(faqs || []);
});

app.get("/api/public/blog", (_req: Request, res: Response) => {
  res.json({ posts: blogs || [], total: blogs.length });
});

app.get("/api/public/blog/:slug", (req: Request, res: Response) => {
  const post = blogs.find((b) => b.slug === req.params.slug || b.id === req.params.slug) || blogs[0];
  res.json(post);
});

app.post("/api/public/leads", (req: Request, res: Response) => {
  const newLead: Lead = {
    id: "lead_" + Date.now(),
    name: req.body.name || "Website Candidate",
    phone: req.body.phone || "+91 99999 99999",
    email: req.body.email,
    source: "Website",
    status: "New",
    city: req.body.city || "Pune",
    job_title: req.body.job_title || "General Application",
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    notes: req.body.cover_note ? [{ id: "n_" + Date.now(), text: req.body.cover_note, date: new Date().toISOString() }] : [],
  };
  leads.unshift(newLead);
  res.json({ success: true, id: newLead.id, message: "Application submitted successfully!" });
});

// ---------------- DASHBOARD METRICS ----------------
app.get("/api/dashboard/main", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  let userLeads = leads;
  let userInterviews = interviews;
  let userJoinings = joinings;

  if (user.role === "recruiter") {
    userLeads = leads.filter((l) => l.assigned_recruiter_id === user.id);
    const leadIds = userLeads.map((l) => l.id);
    userInterviews = interviews.filter((i) => leadIds.includes(i.lead_id));
    userJoinings = joinings.filter((j) => leadIds.includes(j.lead_id));
  }

  const activeRecruiters = users.filter((u) => u.role === "recruiter" || u.role === "team_leader");

  const today = {
    fresh_leads: userLeads.filter((l) => l.status === "New").length,
    leads_added: userLeads.length,
    followups_due: userLeads.filter((l) => l.next_followup_date).length,
    followups_overdue: userLeads.filter((l) => l.next_followup_date && new Date(l.next_followup_date) < new Date()).length,
    no_answer: 2,
    interested: userLeads.filter((l) => l.status === "Contacted").length,
    interviews_scheduled: userInterviews.length,
    interviews_attended: Math.max(0, userInterviews.length - 1),
    selected: Math.max(1, userJoinings.length + 1),
    joined: userJoinings.length,
    rejected: 1,
    calls_made: user.role === "recruiter" ? 42 : 124,
    connected: user.role === "recruiter" ? 28 : 88,
    not_connected: user.role === "recruiter" ? 14 : 36,
    assigned: userLeads.length,
  };

  const comparison = (user.role === "recruiter" ? activeRecruiters.filter((u) => u.id === user.id) : activeRecruiters).map((r) => {
    const rLeads = leads.filter((l) => l.assigned_recruiter_id === r.id);
    const rLeadIds = rLeads.map((l) => l.id);
    const rInterviews = interviews.filter((i) => rLeadIds.includes(i.lead_id));
    const rJoinings = joinings.filter((j) => rLeadIds.includes(j.lead_id));
    return {
      recruiter_id: r.id,
      recruiter: r.name,
      leads: rLeads.length,
      calls: 38 + rLeads.length * 2,
      connected: 24 + rLeads.length,
      followups: rLeads.filter((l) => l.next_followup_date).length,
      lineups: rInterviews.length,
      attendance: Math.max(0, rInterviews.length - 1),
      selected: Math.max(1, rJoinings.length + 1),
      joined: rJoinings.length,
    };
  });

  res.json({
    today,
    comparison,
    total_leads: userLeads.length,
    new_leads: userLeads.filter((l) => l.status === "New").length,
    in_progress: userLeads.filter((l) => l.status === "Contacted").length,
    interviews: userInterviews.length,
    joined: userJoinings.length,
    revenue: user.role === "recruiter" ? "₹1,45,000" : "₹4,25,000",
    metrics: {
      call_count: user.role === "recruiter" ? 42 : 124,
      conversions: userJoinings.length,
      avg_tat_days: 3.2,
    },
  });
});

app.get("/api/dashboard/funnel", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  let userLeads = leads;
  let userInterviews = interviews;
  let userJoinings = joinings;

  if (user.role === "recruiter") {
    userLeads = leads.filter((l) => l.assigned_recruiter_id === user.id);
    const leadIds = userLeads.map((l) => l.id);
    userInterviews = interviews.filter((i) => leadIds.includes(i.lead_id));
    userJoinings = joinings.filter((j) => leadIds.includes(j.lead_id));
  }

  res.json([
    { stage: "Sourced", count: Math.max(userLeads.length, 12) },
    { stage: "Contacted", count: Math.max(userLeads.filter((l) => l.status === "Contacted").length, 8) },
    { stage: "Screened", count: Math.max(1, Math.round(userLeads.length * 0.4)) },
    { stage: "Interview", count: Math.max(userInterviews.length, 4) },
    { stage: "Offer", count: Math.max(1, userJoinings.length + 1) },
    { stage: "Joined", count: Math.max(userJoinings.length, 2) },
  ]);
});

app.get("/api/dashboard/targets", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  const activeRecruiters = user.role === "recruiter"
    ? users.filter((u) => u.id === user.id)
    : users.filter((u) => u.role === "recruiter" || u.role === "team_leader");

  const list = activeRecruiters.map((r) => {
    const rLeads = leads.filter((l) => l.assigned_recruiter_id === r.id);
    const rLeadIds = rLeads.map((l) => l.id);
    const rInterviews = interviews.filter((i) => rLeadIds.includes(i.lead_id));
    const rJoinings = joinings.filter((j) => rLeadIds.includes(j.lead_id));
    return {
      recruiter_id: r.id,
      recruiter: r.name,
      avatar: r.avatar || "",
      metrics: [
        { label: "Calls", actual: 38 + rLeads.length * 2, target: 45, status: "On Track" },
        { label: "Connected", actual: 24 + rLeads.length, target: 30, status: "On Track" },
        { label: "Lineups", actual: rInterviews.length, target: Math.max(rInterviews.length + 1, 5), status: "On Track" },
        { label: "Joined", actual: rJoinings.length, target: Math.max(rJoinings.length + 1, 3), status: "Needs Attention" },
      ],
    };
  });
  res.json(list);
});

app.get("/api/dashboard/leaderboard", (_req: Request, res: Response) => {
  const activeRecruiters = users.filter((u) => u.role === "recruiter" || u.role === "team_leader");
  const list = activeRecruiters.map((r, idx) => {
    const rLeads = leads.filter((l) => l.assigned_recruiter_id === r.id);
    const rLeadIds = rLeads.map((l) => l.id);
    const rInterviews = interviews.filter((i) => rLeadIds.includes(i.lead_id));
    const rJoinings = joinings.filter((j) => rLeadIds.includes(j.lead_id));
    const calls = 50 + (3 - idx) * 14;
    const connected = Math.round(calls * 0.65);
    const lineups = rInterviews.length + (2 - idx);
    const attendance = Math.max(0, lineups - 1);
    const selected = Math.max(1, rJoinings.length + 1);
    const joined = rJoinings.length + (idx === 0 ? 3 : 1);
    const score = calls * 1 + connected * 2 + lineups * 5 + joined * 20;
    return {
      rank: idx + 1,
      recruiter_id: r.id,
      recruiter: r.name,
      calls,
      connected,
      lineups,
      attendance,
      selected,
      joined,
      missed_followups: idx,
      score,
    };
  });
  res.json(list);
});

app.get("/api/dashboard/action-required", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  let userLeads = leads;
  let userInterviews = interviews;
  let userJoinings = joinings;

  if (user.role === "recruiter") {
    userLeads = leads.filter((l) => l.assigned_recruiter_id === user.id);
    const leadIds = userLeads.map((l) => l.id);
    userInterviews = interviews.filter((i) => leadIds.includes(i.lead_id));
    userJoinings = joinings.filter((j) => leadIds.includes(j.lead_id));
  }

  res.json({
    overdue_followups: userLeads.filter((l) => l.next_followup_date && new Date(l.next_followup_date) < new Date()),
    missing_followup: userLeads.filter((l) => !l.next_followup_date && (l.status === "New" || l.status === "Contacted")),
    never_called: userLeads.filter((l) => l.status === "New"),
    unassigned: user.role === "recruiter" ? [] : leads.filter((l) => !l.assigned_recruiter_id),
    stale_leads: userLeads.filter((l) => l.status === "Contacted").map((l) => ({ ...l, age_days: 18 })),
    selected_no_joining_date: userLeads.filter((l) => l.status === "Selected" || l.status === "Offer").map((l) => ({ ...l, recruiter_name: l.assigned_recruiter_name || "Harshika Sharma" })),
    unconfirmed_tomorrow_interviews: userInterviews.map((iv) => {
      const lead = leads.find((l) => l.id === iv.lead_id);
      return {
        id: iv.id,
        lead_name: lead?.name || "Candidate",
        client_name: iv.client_name || "Tech Corp",
        datetime: iv.scheduled_at || new Date().toISOString(),
      };
    }),
    unconfirmed_joinings: userJoinings.map((j) => {
      const lead = leads.find((l) => l.id === j.lead_id);
      return {
        id: j.id,
        lead_name: lead?.name || "Candidate",
        client_name: j.client_name || "Enterprise Client",
        status: j.status || "Offer Accepted",
      };
    }),
    recruiters_below_target: user.role === "recruiter" ? [] : [
      { recruiter: "Karan Mehta", calls: 28, target: 45 },
    ],
  });
});

app.get("/api/dashboard/my-day", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  let userLeads = leads;
  let userInterviews = interviews;

  if (user.role === "recruiter") {
    userLeads = leads.filter((l) => l.assigned_recruiter_id === user.id);
    const leadIds = userLeads.map((l) => l.id);
    userInterviews = interviews.filter((i) => leadIds.includes(i.lead_id));
  }

  const overdue = userLeads.filter((l) => l.next_followup_date && new Date(l.next_followup_date) < new Date());
  const todayFollowups = userLeads.filter((l) => l.next_followup_date);
  const interviewItems = userInterviews.map((iv) => {
    const lead = leads.find((l) => l.id === iv.lead_id);
    return {
      id: iv.id,
      lead_name: lead?.name || "Candidate",
      phone: lead?.phone || "+91 99999 99999",
      datetime: iv.scheduled_at || iv.date || new Date().toISOString(),
      priority: "High",
    };
  });
  const priorityCalls = userLeads.filter((l) => l.priority === "High" || l.status === "New").slice(0, 5);
  const freshLeads = userLeads.filter((l) => l.status === "New");

  const steps = [
    { key: "overdue", title: "Clear Overdue Follow-ups", done: overdue.length === 0, items: overdue },
    { key: "today", title: "Complete Today's Follow-ups", done: todayFollowups.length === 0, items: todayFollowups },
    { key: "interviews", title: "Confirm Tomorrow's Interviews", done: interviewItems.length === 0, items: interviewItems },
    { key: "calls", title: "Make Priority Calls", done: priorityCalls.length === 0, items: priorityCalls },
    { key: "fresh", title: "Screen Fresh Leads", done: freshLeads.length === 0, items: freshLeads },
  ];

  const completed = steps.filter((s) => s.done).length;
  const progress = Math.round((completed / steps.length) * 100);

  res.json({
    completed_steps: completed,
    total_steps: steps.length,
    progress,
    steps,
  });
});

app.get("/api/dashboard/scorecard/:rid", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  // Authorization check: Recruiter cannot view another recruiter's scorecard
  if (user.role === "recruiter" && req.params.rid !== user.id) {
    return res.status(403).json({ detail: "Access denied. You can only view your own scorecard." });
  }

  res.json({
    recruiter_id: req.params.rid,
    placements: 6,
    interviews_conducted: 19,
    calls_made: 124,
    avg_call_duration_mins: 3.5,
    conversion_rate: "18.4%",
  });
});

// ---------------- LEADS MANAGEMENT & RECRUITER ISOLATION ----------------

// Priority 1: Authorization check - Recruiters CAN NEVER view other recruiters' leads
app.get("/api/leads", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  const query = ((req.query.q as string) || (req.query.search as string) || "").toLowerCase();
  const status = (req.query.status as string) || (req.query.lead_status as string);
  const mine = req.query.mine === "true";
  const requestedRecruiterId = req.query.recruiter_id as string;

  let result = [...leads];

  // Hard Enforced Rule: Recruiter is strictly locked to their assigned leads
  if (user.role === "recruiter") {
    result = result.filter((l) => l.assigned_recruiter_id === user.id);
  } else if (mine) {
    result = result.filter((l) => l.assigned_recruiter_id === user.id);
  } else if (requestedRecruiterId && requestedRecruiterId !== "all") {
    result = result.filter((l) => l.assigned_recruiter_id === requestedRecruiterId);
  }

  if (query) {
    result = result.filter(
      (l) =>
        (l.name && l.name.toLowerCase().includes(query)) ||
        (l.email && l.email.toLowerCase().includes(query)) ||
        (l.phone && l.phone.includes(query)) ||
        (l.city && l.city.toLowerCase().includes(query)) ||
        (l.job_title && l.job_title.toLowerCase().includes(query))
    );
  }

  if (status && status !== "All" && status !== "all" && status !== "") {
    result = result.filter((l) => l.status === status);
  }

  res.json(result);
});

app.get("/api/leads/search", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role === "recruiter") {
    return res.json(leads.filter((l) => l.assigned_recruiter_id === user.id));
  }
  res.json(leads);
});

app.get("/api/leads/check-duplicate", (req: Request, res: Response) => {
  const phone = req.query.phone as string;
  const match = leads.find((l) => l.phone === phone);
  res.json({ is_duplicate: !!match, lead: match || null });
});

// Create lead with Priority 2 field protection
app.post("/api/leads", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  const sanitized = sanitizeLeadBody(req.body, user, true);

  const newLead: Lead = {
    id: "l" + (leads.length + 1),
    name: sanitized.name || "Untitled Lead",
    phone: sanitized.phone || "",
    email: sanitized.email,
    source: sanitized.source || "Manual",
    status: sanitized.status || "New",
    city: sanitized.city || "Pune",
    assigned_recruiter_id:
      user.role === "recruiter"
        ? user.id
        : sanitized.assigned_recruiter_id || user.id,
    assigned_recruiter_name:
      user.role === "recruiter"
        ? user.name
        : sanitized.assigned_recruiter_name || user.name,
    job_title: sanitized.job_title,
    next_followup_date: sanitized.next_followup_date,
    next_followup_reason: sanitized.next_followup_reason,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    tags: sanitized.tags || [],
    notes: sanitized.notes
      ? typeof sanitized.notes === "string"
        ? [{ id: "n_" + Date.now(), text: sanitized.notes, date: new Date().toISOString() }]
        : sanitized.notes
      : [],
  };

  leads.unshift(newLead);
  logAudit("LEAD_CREATE", user.name, `Created lead: ${newLead.name} (${newLead.id})`);
  res.json(newLead);
});

// Get single lead with Priority 1 authorization
app.get("/api/leads/:lid", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  const lead = leads.find((l) => l.id === req.params.lid);
  if (!lead) {
    return res.status(404).json({ detail: "Lead not found" });
  }

  // Authorization check: Recruiter cannot view another recruiter's lead
  if (user.role === "recruiter" && lead.assigned_recruiter_id !== user.id) {
    return res.status(403).json({ detail: "Access denied. You do not have permission to view this lead." });
  }

  res.json(lead);
});

// Patch lead with Priority 1 & 2 protections
app.patch("/api/leads/:lid", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  const idx = leads.findIndex((l) => l.id === req.params.lid);
  if (idx === -1) {
    return res.status(404).json({ detail: "Lead not found" });
  }

  const existingLead = leads[idx];

  // Recruiter authorization check
  if (user.role === "recruiter" && existingLead.assigned_recruiter_id !== user.id) {
    return res.status(403).json({ detail: "Access denied. You cannot modify another recruiter's lead." });
  }

  // Sanitize to prevent overriding protected fields
  const cleanBody = sanitizeLeadBody(req.body, user, false);

  leads[idx] = {
    ...existingLead,
    ...cleanBody,
    updated_at: new Date().toISOString(),
  };

  logAudit("LEAD_UPDATE", user.name, `Updated lead: ${existingLead.id}`);
  res.json(leads[idx]);
});

// Delete lead
app.delete("/api/leads/:lid", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  const lead = leads.find((l) => l.id === req.params.lid);
  if (!lead) return res.status(404).json({ detail: "Lead not found" });

  // Recruiter cannot delete leads
  if (user.role === "recruiter") {
    return res.status(403).json({ detail: "Recruiters are not permitted to delete leads." });
  }

  leads = leads.filter((l) => l.id !== req.params.lid);
  logAudit("LEAD_DELETE", user.name, `Deleted lead: ${req.params.lid}`);
  res.json({ success: true });
});

app.get("/api/leads/:lid/activities", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  const lead = leads.find((l) => l.id === req.params.lid);
  if (!lead) return res.status(404).json({ detail: "Lead not found" });

  if (user.role === "recruiter" && lead.assigned_recruiter_id !== user.id) {
    return res.status(403).json({ detail: "Access denied." });
  }

  res.json([
    { id: "act1", type: "system", text: `Lead created from ${lead.source || "Manual"}`, date: lead.created_at },
    { id: "act2", type: "call", text: "Connected via phone — candidate showed interest", date: new Date().toISOString() },
  ]);
});

app.post("/api/leads/:lid/call", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  const lead = leads.find((l) => l.id === req.params.lid);
  if (!lead) return res.status(404).json({ detail: "Lead not found" });

  if (user.role === "recruiter" && lead.assigned_recruiter_id !== user.id) {
    return res.status(403).json({ detail: "Access denied. Cannot log call on another recruiter's lead." });
  }

  lead.calls = lead.calls || [];
  lead.calls.push({
    id: "call_" + Date.now(),
    disposition: req.body.disposition || "Connected",
    duration: req.body.duration || 120,
    notes: req.body.notes || "",
    date: new Date().toISOString(),
  });

  if (req.body.status) lead.status = req.body.status;
  if (req.body.next_followup_date) lead.next_followup_date = req.body.next_followup_date;
  lead.updated_at = new Date().toISOString();

  res.json({ success: true });
});

app.post("/api/leads/:lid/notes", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  const lead = leads.find((l) => l.id === req.params.lid);
  if (!lead) return res.status(404).json({ detail: "Lead not found" });

  if (user.role === "recruiter" && lead.assigned_recruiter_id !== user.id) {
    return res.status(403).json({ detail: "Access denied. Cannot add notes to another recruiter's lead." });
  }

  lead.notes = lead.notes || [];
  lead.notes.push({
    id: "n_" + Date.now(),
    text: req.body.text || req.body.note || "",
    author: user.name,
    date: new Date().toISOString(),
  });
  lead.updated_at = new Date().toISOString();

  res.json({ success: true, lead });
});

app.post("/api/leads/:lid/whatsapp", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  const lead = leads.find((l) => l.id === req.params.lid);
  if (!lead) return res.status(404).json({ detail: "Lead not found" });

  if (user.role === "recruiter" && lead.assigned_recruiter_id !== user.id) {
    return res.status(403).json({ detail: "Access denied." });
  }

  res.json({ success: true, message: "WhatsApp message dispatched successfully" });
});

app.post("/api/leads/:lid/tags", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  const lead = leads.find((l) => l.id === req.params.lid);
  if (!lead) return res.status(404).json({ detail: "Lead not found" });

  if (user.role === "recruiter" && lead.assigned_recruiter_id !== user.id) {
    return res.status(403).json({ detail: "Access denied." });
  }

  lead.tags = req.body.tags || [];
  lead.updated_at = new Date().toISOString();
  res.json({ success: true, lead });
});

app.post("/api/leads/assign", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  // Authorization check: Only Admin and Team Leader can assign leads
  if (user.role === "recruiter") {
    return res.status(403).json({ detail: "Access denied. Only administrators and team leaders can assign leads." });
  }

  const { lead_ids, recruiter_id } = req.body;
  const rec = users.find((u) => u.id === recruiter_id);
  leads.forEach((l) => {
    if ((lead_ids || []).includes(l.id)) {
      l.assigned_recruiter_id = recruiter_id;
      l.assigned_recruiter_name = rec?.name || "Assigned Recruiter";
      l.updated_at = new Date().toISOString();
    }
  });

  logAudit("LEADS_ASSIGNED", user.name, `Assigned ${(lead_ids || []).length} leads to ${rec?.name}`);
  res.json({ success: true, count: (lead_ids || []).length });
});

app.post("/api/leads/auto-distribute", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role === "recruiter") {
    return res.status(403).json({ detail: "Access denied. Auto-distribution requires administrative rights." });
  }
  res.json({ success: true, message: "Leads distributed round-robin among active recruiters" });
});

// ---------------- CALLING & FOLLOWUPS ----------------
app.get("/api/calling-list", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  let list = leads.filter((l) => l.status === "New" || l.status === "Contacted");

  // Recruiter authorization rule
  if (user.role === "recruiter") {
    list = list.filter((l) => l.assigned_recruiter_id === user.id);
  }

  const callingQueue = list.map((l, idx) => {
    let reason = "New Lead";
    if (l.next_followup_date && new Date(l.next_followup_date) < new Date()) {
      reason = "Overdue Follow-up";
    } else if (l.priority === "High" || l.tags?.includes("Hot")) {
      reason = "Hot Candidate";
    } else if (l.next_followup_date) {
      reason = "Today's Follow-up";
    }
    return {
      ...l,
      queue_reason: l.queue_reason || reason,
      priority: l.priority || (idx % 2 === 0 ? "High" : "Medium"),
    };
  });

  res.json(callingQueue);
});

app.get("/api/followups", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  let list = leads.filter((l) => l.next_followup_date || l.status === "Contacted");

  // Recruiter authorization rule
  if (user.role === "recruiter") {
    list = list.filter((l) => l.assigned_recruiter_id === user.id);
  }

  const view = (req.query.view as string) || "today";
  const search = ((req.query.search as string) || "").toLowerCase();
  const todayStr = new Date().toISOString().split("T")[0];
  const tomorrowStr = new Date(Date.now() + 86400000).toISOString().split("T")[0];

  let filtered = list;
  if (view === "overdue") {
    filtered = list.filter((l) => l.next_followup_date && l.next_followup_date < todayStr);
  } else if (view === "today") {
    filtered = list.filter((l) => !l.next_followup_date || l.next_followup_date.startsWith(todayStr));
  } else if (view === "tomorrow") {
    filtered = list.filter((l) => l.next_followup_date && l.next_followup_date.startsWith(tomorrowStr));
  } else if (view === "upcoming") {
    filtered = list.filter((l) => l.next_followup_date && l.next_followup_date > tomorrowStr);
  } else if (view === "missed") {
    filtered = list.filter((l) => l.next_followup_date && l.next_followup_date < todayStr);
  } else if (view === "completed") {
    filtered = leads.filter((l) => l.calls && l.calls.length > 0 && (user.role !== "recruiter" || l.assigned_recruiter_id === user.id));
  }

  if (search) {
    filtered = filtered.filter((l) => (l.name || "").toLowerCase().includes(search) || (l.phone || "").toLowerCase().includes(search));
  }

  const rows = filtered.map((l) => {
    const isOverdue = l.next_followup_date ? l.next_followup_date < todayStr : false;
    const isCompleted = view === "completed" || (l.calls && l.calls.length > 0 && !l.next_followup_date);
    return {
      id: "fu_" + l.id,
      lead_id: l.id,
      lead_name: l.name,
      phone: l.phone,
      priority: l.priority || "High",
      lead_status: l.status,
      due_date: l.next_followup_date || new Date().toISOString(),
      is_overdue: isOverdue,
      overdue_by: isOverdue ? "24h" : undefined,
      reason: "Scheduled follow-up check",
      outcome: l.status === "Contacted" ? "Interested" : undefined,
      recruiter_name: l.assigned_recruiter_name || "Harshika Sharma",
      status: isCompleted ? "completed" : "pending",
      completed_at: isCompleted ? new Date().toISOString() : undefined,
    };
  });

  res.json(rows);
});

app.get("/api/followups/counts", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  let list = leads.filter((l) => l.next_followup_date || l.status === "Contacted");

  // Scoped to recruiter
  if (user.role === "recruiter") {
    list = list.filter((l) => l.assigned_recruiter_id === user.id);
  }

  const todayStr = new Date().toISOString().split("T")[0];
  const tomorrowStr = new Date(Date.now() + 86400000).toISOString().split("T")[0];

  let today = 0,
    overdue = 0,
    tomorrow = 0,
    upcoming = 0,
    missed = 0,
    completed = 0;

  list.forEach((l) => {
    if (!l.next_followup_date || l.next_followup_date.startsWith(todayStr)) today++;
    else if (l.next_followup_date < todayStr) {
      overdue++;
      missed++;
    } else if (l.next_followup_date.startsWith(tomorrowStr)) tomorrow++;
    else if (l.next_followup_date > tomorrowStr) upcoming++;
  });

  const userCompleted = leads.filter((l) => l.calls && l.calls.length > 0 && (user.role !== "recruiter" || l.assigned_recruiter_id === user.id));
  completed = userCompleted.length;

  res.json({ today, overdue, tomorrow, upcoming, missed, completed, total: today + overdue + tomorrow + upcoming });
});

app.post("/api/followups/:fid/complete", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  const cleanId = req.params.fid.replace(/^fu_/, "");
  const lead = leads.find((l) => l.id === cleanId || l.id === req.params.fid);
  if (lead && user.role === "recruiter" && lead.assigned_recruiter_id !== user.id) {
    return res.status(403).json({ detail: "Access denied. Cannot complete follow-up on another recruiter's lead." });
  }

  if (lead) {
    lead.next_followup_date = undefined;
    lead.updated_at = new Date().toISOString();
  }

  res.json({ success: true });
});

app.delete("/api/followups/:fid", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role === "recruiter") {
    return res.status(403).json({ detail: "Recruiters cannot delete follow-up records." });
  }
  const cleanId = req.params.fid.replace(/^fu_/, "");
  const lead = leads.find((l) => l.id === cleanId || l.id === req.params.fid);
  if (lead) {
    lead.next_followup_date = undefined;
    lead.updated_at = new Date().toISOString();
  }
  res.json({ success: true });
});

// ---------------- INTERVIEWS & JOININGS ----------------
app.get("/api/interviews", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  let list = interviews;
  // Recruiter authorization rule: ONLY interviews for recruiter's leads
  if (user.role === "recruiter") {
    const recruiterLeadIds = leads.filter((l) => l.assigned_recruiter_id === user.id).map((l) => l.id);
    list = interviews.filter((i) => recruiterLeadIds.includes(i.lead_id));
  }

  const enriched = list.map((iv) => {
    const lead = leads.find((l) => l.id === iv.lead_id);
    return {
      id: iv.id,
      lead_id: iv.lead_id,
      lead_name: iv.candidate_name || lead?.name || "Candidate",
      phone: lead?.phone || "+91 98221 44556",
      client_name: iv.client || iv.client_name || "Enterprise Client",
      job_title: iv.role || iv.job_title || lead?.job_title || "Full Stack Developer",
      datetime: iv.date || iv.datetime || new Date().toISOString(),
      location: iv.location || lead?.city || "Pune",
      type: iv.type || "Online / Google Meet",
      recruiter_name: iv.recruiter || lead?.assigned_recruiter_name || "Harshika Sharma",
      stage: iv.stage || iv.status || "Scheduled",
      confirmation: iv.confirmation || "Confirmed",
      notes: iv.notes || "",
    };
  });

  if (req.query.view === "tomorrow") {
    const tomorrowStr = new Date(Date.now() + 86400000).toISOString().split("T")[0];
    return res.json(enriched.filter((iv) => iv.datetime.startsWith(tomorrowStr)));
  }

  res.json(enriched);
});

app.post("/api/interviews", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  // If recruiter, check that lead_id belongs to this recruiter
  if (user.role === "recruiter") {
    const lead = leads.find((l) => l.id === req.body.lead_id);
    if (!lead || lead.assigned_recruiter_id !== user.id) {
      return res.status(403).json({ detail: "Access denied. You can only schedule interviews for your own assigned leads." });
    }
  }

  const clean = sanitizeGeneralBody(req.body, user);
  const newInt = { id: "i" + (interviews.length + 1), ...clean, status: "Scheduled" };
  interviews.unshift(newInt);
  res.json(newInt);
});

app.patch("/api/interviews/:iid", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  const idx = interviews.findIndex((i) => i.id === req.params.iid);
  if (idx === -1) return res.status(404).json({ detail: "Interview not found" });

  const existing = interviews[idx];
  if (user.role === "recruiter") {
    const lead = leads.find((l) => l.id === existing.lead_id);
    if (!lead || lead.assigned_recruiter_id !== user.id) {
      return res.status(403).json({ detail: "Access denied. Cannot modify another recruiter's interview." });
    }
  }

  const clean = sanitizeGeneralBody(req.body, user);
  interviews[idx] = { ...existing, ...clean };
  res.json(interviews[idx]);
});

app.delete("/api/interviews/:iid", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role === "recruiter") {
    return res.status(403).json({ detail: "Recruiters cannot delete interview records." });
  }
  interviews = interviews.filter((i) => i.id !== req.params.iid);
  res.json({ success: true });
});

app.get("/api/joinings", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  let list = joinings;
  // Recruiter authorization rule: ONLY joinings for recruiter's leads
  if (user.role === "recruiter") {
    const recruiterLeadIds = leads.filter((l) => l.assigned_recruiter_id === user.id).map((l) => l.id);
    list = joinings.filter((j) => recruiterLeadIds.includes(j.lead_id));
  }

  const enriched = list.map((j) => {
    const lead = leads.find((l) => l.id === j.lead_id);
    return {
      id: j.id,
      lead_id: j.lead_id,
      lead_name: j.candidate_name || lead?.name || "Candidate",
      phone: lead?.phone || "+91 98221 44556",
      client_name: j.client || j.client_name || "Enterprise Client",
      salary: j.offered_salary || j.salary || 650000,
      joining_date: j.joining_date || new Date(Date.now() + 86400000 * 5).toISOString(),
      actual_joining_date: j.actual_joining_date || null,
      recruiter_name: j.recruiter || lead?.assigned_recruiter_name || "Harshika Sharma",
      status: j.status || "Offer Released",
      confirmation: j.confirmation || "Confirmed",
      remarks: j.remarks || "",
    };
  });

  res.json(enriched);
});

app.post("/api/joinings", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role === "recruiter") {
    const lead = leads.find((l) => l.id === req.body.lead_id);
    if (!lead || lead.assigned_recruiter_id !== user.id) {
      return res.status(403).json({ detail: "Access denied. Cannot add joining for another recruiter's lead." });
    }
  }

  const clean = sanitizeGeneralBody(req.body, user);
  const newJ = { id: "jn" + (joinings.length + 1), ...clean };
  joinings.unshift(newJ);
  res.json(newJ);
});

app.patch("/api/joinings/:jid", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  const idx = joinings.findIndex((j) => j.id === req.params.jid);
  if (idx === -1) return res.status(404).json({ detail: "Joining not found" });

  const existing = joinings[idx];
  if (user.role === "recruiter") {
    const lead = leads.find((l) => l.id === existing.lead_id);
    if (!lead || lead.assigned_recruiter_id !== user.id) {
      return res.status(403).json({ detail: "Access denied. Cannot modify another recruiter's joining." });
    }
  }

  const clean = sanitizeGeneralBody(req.body, user);
  joinings[idx] = { ...existing, ...clean };
  res.json(joinings[idx]);
});

app.delete("/api/joinings/:jid", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role === "recruiter") {
    return res.status(403).json({ detail: "Recruiters cannot delete joining records." });
  }
  joinings = joinings.filter((j) => j.id !== req.params.jid);
  res.json({ success: true });
});

// ---------------- TASKS MODULE ----------------
app.get("/api/tasks", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  const { status, priority, owner_id } = req.query;
  let list = [...tasks];
  if (user.role === "recruiter") {
    list = list.filter((t) => !t.owner_id || t.owner_id === user.id);
  } else if (owner_id) {
    list = list.filter((t) => t.owner_id === owner_id);
  }
  if (status && status !== "all") {
    list = list.filter((t) => t.status.toLowerCase() === (status as string).toLowerCase());
  }
  if (priority && priority !== "all") {
    list = list.filter((t) => t.priority.toLowerCase() === (priority as string).toLowerCase());
  }
  res.json(list.sort((a, b) => new Date(b.created_at || 0).getTime() - new Date(a.created_at || 0).getTime()));
});

app.post("/api/tasks", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  const body = req.body || {};
  if (!body.title?.trim()) {
    return res.status(400).json({ detail: "Task title is required." });
  }
  const newTask = {
    id: `tsk-${Date.now()}`,
    title: body.title.trim(),
    owner_id: body.owner_id || user.id,
    owner_name: body.owner_name || user.name,
    priority: body.priority || "Medium",
    due_date: body.due_date || new Date(Date.now() + 86400000).toISOString(),
    status: body.status || "Pending",
    category: body.category || "Candidate follow-up",
    related_type: body.related_type || "candidate",
    related_name: body.related_name || "",
    notes: body.notes || "",
    created_at: new Date().toISOString(),
  };
  tasks.unshift(newTask);
  logAudit("TASK_CREATED", user.name, `Created task: ${newTask.title}`);
  res.status(201).json(newTask);
});

app.patch("/api/tasks/:id", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  const idx = tasks.findIndex((t) => t.id === req.params.id);
  if (idx === -1) return res.status(404).json({ detail: "Task not found" });
  tasks[idx] = { ...tasks[idx], ...req.body, updated_at: new Date().toISOString() };
  logAudit("TASK_UPDATED", user.name, `Updated task: ${tasks[idx].title} -> ${tasks[idx].status}`);
  res.json(tasks[idx]);
});

app.delete("/api/tasks/:id", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  tasks = tasks.filter((t) => t.id !== req.params.id);
  logAudit("TASK_DELETED", user.name, `Deleted task ${req.params.id}`);
  res.json({ success: true });
});

// ---------------- VENDOR / EMPANELMENT CRM ----------------
app.get("/api/vendors", (req: Request, res: Response) => {
  const { status, search } = req.query;
  let list = [...vendors];
  if (status && status !== "all") {
    list = list.filter((v) => v.status.toLowerCase() === (status as string).toLowerCase());
  }
  if (search) {
    const q = (search as string).toLowerCase();
    list = list.filter(
      (v) =>
        v.company.toLowerCase().includes(q) ||
        v.contact_person.toLowerCase().includes(q) ||
        v.email.toLowerCase().includes(q) ||
        v.phone.includes(q)
    );
  }
  res.json(list);
});

app.post("/api/vendors", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  const body = req.body || {};
  if (!body.company?.trim()) {
    return res.status(400).json({ detail: "Company name is required." });
  }
  const newVendor = {
    id: `v-${Date.now()}`,
    company: body.company.trim(),
    contact_person: body.contact_person || "",
    designation: body.designation || "HR Procurement",
    email: body.email || "",
    phone: body.phone || "",
    linkedin: body.linkedin || "",
    industry: body.industry || "IT Services",
    date_contacted: body.date_contacted || new Date().toISOString().split("T")[0],
    status: body.status || "New",
    proposal_sent: !!body.proposal_sent,
    commercial_proposed: body.commercial_proposed || "8.33% of CTC",
    next_action: body.next_action || "Schedule initial partnership call",
    owner_id: body.owner_id || user.id,
    owner_name: body.owner_name || user.name,
    notes: body.notes || "",
    created_at: new Date().toISOString(),
  };
  vendors.unshift(newVendor);
  logAudit("VENDOR_CREATED", user.name, `Added vendor lead: ${newVendor.company}`);
  res.status(201).json(newVendor);
});

app.patch("/api/vendors/:id", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  const idx = vendors.findIndex((v) => v.id === req.params.id);
  if (idx === -1) return res.status(404).json({ detail: "Vendor not found" });
  vendors[idx] = { ...vendors[idx], ...req.body, updated_at: new Date().toISOString() };
  logAudit("VENDOR_UPDATED", user.name, `Updated vendor: ${vendors[idx].company} (${vendors[idx].status})`);
  res.json(vendors[idx]);
});

app.delete("/api/vendors/:id", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role === "recruiter") {
    return res.status(403).json({ detail: "Recruiters cannot delete vendor empanelment records." });
  }
  vendors = vendors.filter((v) => v.id !== req.params.id);
  logAudit("VENDOR_DELETED", user.name, `Deleted vendor: ${req.params.id}`);
  res.json({ success: true });
});

// ---------------- APPLICATIONS MODULE ----------------
app.get("/api/applications", (req: Request, res: Response) => {
  const { status, search } = req.query;
  let list = [...applications];
  if (status && status !== "all") {
    list = list.filter((a) => a.status.toLowerCase() === (status as string).toLowerCase());
  }
  if (search) {
    const q = (search as string).toLowerCase();
    list = list.filter(
      (a) =>
        a.candidate_name.toLowerCase().includes(q) ||
        a.phone.includes(q) ||
        a.email.toLowerCase().includes(q) ||
        a.job_title.toLowerCase().includes(q)
    );
  }
  res.json(list);
});

app.post("/api/applications", (req: Request, res: Response) => {
  const body = req.body || {};
  if (!body.candidate_name || !body.phone) {
    return res.status(400).json({ detail: "Candidate name and phone are required." });
  }
  const newApp = {
    id: `app-${Date.now()}`,
    candidate_name: body.candidate_name.trim(),
    phone: body.phone.trim(),
    email: body.email || "",
    job_id: body.job_id || "",
    job_title: body.job_title || "General Application",
    city: body.city || "PAN India",
    experience: body.experience || "Fresher / 1+ yr",
    resume_url: body.resume_url || "",
    source: body.source || "Website Job Portal",
    utm_source: body.utm_source || "direct",
    utm_medium: body.utm_medium || "website",
    utm_campaign: body.utm_campaign || "career_portal",
    status: "New",
    applied_at: new Date().toISOString(),
  };
  applications.unshift(newApp);
  notifications.unshift({
    id: `n-${Date.now()}`,
    title: "New Job Application Received",
    message: `${newApp.candidate_name} applied for ${newApp.job_title}`,
    date: new Date().toISOString(),
    read: false,
  });
  res.status(201).json(newApp);
});

app.post("/api/applications/:id/convert-lead", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  const appItem = applications.find((a) => a.id === req.params.id);
  if (!appItem) return res.status(404).json({ detail: "Application not found" });

  // Check if lead already exists with this phone
  const existingLead = leads.find((l) => l.phone === appItem.phone);
  if (existingLead) {
    appItem.status = "Converted";
    return res.json({ message: "Lead already exists", lead: existingLead });
  }

  const assignedRecruiter = users.find((u) => u.role === "recruiter" && u.active) || user;
  const newLead: Lead = {
    id: `l-${Date.now()}`,
    name: appItem.candidate_name,
    phone: appItem.phone,
    email: appItem.email,
    source: appItem.source || "Website Application",
    status: "New",
    city: appItem.city || "Pune",
    assigned_recruiter_id: assignedRecruiter.id,
    assigned_recruiter_name: assignedRecruiter.name,
    job_title: appItem.job_title,
    next_followup_date: new Date(Date.now() + 3600000 * 2).toISOString(),
    next_followup_reason: "Initial candidate screening after job portal application",
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    tags: ["Website Applicant", "Immediate Joiner"],
    notes: [
      {
        id: `note-${Date.now()}`,
        author: user.name,
        date: new Date().toISOString(),
        text: `Converted from application for ${appItem.job_title} via ${appItem.source}. Resume: ${appItem.resume_url || "Attached"}`,
      },
    ],
  };

  leads.unshift(newLead);
  appItem.status = "Converted";
  logAudit("APPLICATION_CONVERTED", user.name, `Converted application ${appItem.candidate_name} to CRM lead`);
  res.json({ success: true, lead: newLead });
});

app.delete("/api/applications/:id", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role === "recruiter") {
    return res.status(403).json({ detail: "Recruiters cannot delete applications." });
  }
  applications = applications.filter((a) => a.id !== req.params.id);
  res.json({ success: true });
});

// ---------------- TEMPLATES MODULE ----------------
app.get("/api/templates", (req: Request, res: Response) => {
  const { type } = req.query;
  if (type) {
    return res.json(templates.filter((t) => t.type === type));
  }
  res.json(templates);
});

app.post("/api/templates", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  const body = req.body || {};
  if (!body.name || !body.body) {
    return res.status(400).json({ detail: "Template name and content are required." });
  }
  const newTpl = {
    id: `tpl-${Date.now()}`,
    type: body.type || "whatsapp",
    category: body.category || "General",
    name: body.name.trim(),
    subject: body.subject || "",
    body: body.body.trim(),
  };
  templates.push(newTpl);
  logAudit("TEMPLATE_CREATED", user.name, `Created ${newTpl.type} template: ${newTpl.name}`);
  res.status(201).json(newTpl);
});

app.patch("/api/templates/:id", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  const idx = templates.findIndex((t) => t.id === req.params.id);
  if (idx === -1) return res.status(404).json({ detail: "Template not found" });
  templates[idx] = { ...templates[idx], ...req.body };
  logAudit("TEMPLATE_UPDATED", user.name, `Updated template: ${templates[idx].name}`);
  res.json(templates[idx]);
});

app.delete("/api/templates/:id", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role === "recruiter") {
    return res.status(403).json({ detail: "Recruiters cannot delete templates." });
  }
  templates = templates.filter((t) => t.id !== req.params.id);
  res.json({ success: true });
});

// ---------------- HRMS LEAVE MANAGEMENT ----------------
app.get("/api/hrms/leaves", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role === "recruiter") {
    const emp = employees.find((e) => e.email === user.email);
    if (emp) {
      return res.json(leaves.filter((l) => l.employee_id === emp.id));
    }
  }
  res.json(leaves);
});

app.post("/api/hrms/leaves", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  const body = req.body || {};
  const emp = employees.find((e) => e.email === user.email) || employees[0];
  const newLeave = {
    id: `lv-${Date.now()}`,
    employee_id: body.employee_id || emp.id,
    employee_name: body.employee_name || emp.name,
    leave_type: body.leave_type || "Casual Leave",
    start_date: body.start_date,
    end_date: body.end_date,
    days: Number(body.days) || 1,
    reason: body.reason || "",
    status: "Pending",
    applied_at: new Date().toISOString(),
    approved_by: null,
    comments: "",
  };
  leaves.unshift(newLeave);
  logAudit("LEAVE_APPLIED", user.name, `Applied for ${newLeave.days} day(s) ${newLeave.leave_type}`);
  res.status(201).json(newLeave);
});

app.post("/api/hrms/leaves/:id/approve", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role === "recruiter") {
    return res.status(403).json({ detail: "Only managers and admins can approve leave." });
  }
  const idx = leaves.findIndex((l) => l.id === req.params.id);
  if (idx === -1) return res.status(404).json({ detail: "Leave application not found" });
  leaves[idx].status = "Approved";
  leaves[idx].approved_by = user.name;
  leaves[idx].comments = req.body.comments || "Approved by manager";
  logAudit("LEAVE_APPROVED", user.name, `Approved leave for ${leaves[idx].employee_name}`);
  res.json(leaves[idx]);
});

app.post("/api/hrms/leaves/:id/reject", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role === "recruiter") {
    return res.status(403).json({ detail: "Only managers and admins can reject leave." });
  }
  const idx = leaves.findIndex((l) => l.id === req.params.id);
  if (idx === -1) return res.status(404).json({ detail: "Leave application not found" });
  leaves[idx].status = "Rejected";
  leaves[idx].approved_by = user.name;
  leaves[idx].comments = req.body.comments || "Rejected due to operational exigencies";
  logAudit("LEAVE_REJECTED", user.name, `Rejected leave for ${leaves[idx].employee_name}`);
  res.json(leaves[idx]);
});

// ---------------- MARKETING DASHBOARD & WEBHOOKS ----------------
app.get("/api/marketing/stats", (_req: Request, res: Response) => {
  const metaLeads = leads.filter((l) => l.source === "Meta Ads" || l.source === "Facebook Ads" || l.source === "Instagram");
  const googleLeads = leads.filter((l) => l.source === "Google Forms" || l.source === "Google Ads");
  const websiteLeads = leads.filter((l) => l.source === "Website" || l.source === "Website Job Portal");
  const whatsappLeads = leads.filter((l) => l.source === "WhatsApp");

  res.json({
    totals: {
      total_leads: leads.length,
      meta_leads: metaLeads.length + 18,
      google_form_leads: googleLeads.length + 12,
      website_leads: websiteLeads.length,
      whatsapp_leads: whatsappLeads.length,
      applications: applications.length,
    },
    sources: [
      { name: "Meta Ads (IG & FB)", count: metaLeads.length + 18, share: "36%" },
      { name: "Google Forms / Sheets", count: googleLeads.length + 12, share: "24%" },
      { name: "Website Portal", count: websiteLeads.length, share: "20%" },
      { name: "WhatsApp Direct", count: whatsappLeads.length, share: "12%" },
      { name: "Referrals & Walk-ins", count: 8, share: "8%" },
    ],
    campaigns: [
      { name: "pune_tech_hiring_q3", platform: "Meta Ads", leads: 24, cost_per_lead: "₹42", status: "Active" },
      { name: "mumbai_bfsi_relationship_mgrs", platform: "Instagram", leads: 18, cost_per_lead: "₹38", status: "Active" },
      { name: "bpo_bulk_freshers_walkin", platform: "Google Forms", leads: 32, cost_per_lead: "₹15", status: "Active" },
      { name: "pan_india_react_express", platform: "LinkedIn / Web", leads: 14, cost_per_lead: "₹65", status: "Active" },
    ],
  });
});

app.post("/api/webhooks/meta-leads", (req: Request, res: Response) => {
  const body = req.body || {};
  const name = body.name || body.full_name || body.candidate_name || "Meta Candidate";
  const phone = body.phone || body.phone_number || "+91 98000 11223";
  const email = body.email || "";
  const campaign = body.campaign || "Meta Lead Ads";

  // Check duplicate without altering phone digits
  const existing = leads.find((l) => l.phone === phone);
  if (existing) {
    logAudit("WEBHOOK_META_DUPLICATE", "System", `Duplicate lead suppressed: ${phone}`);
    return res.json({ status: "duplicate_skipped", lead_id: existing.id });
  }

  // Auto round-robin recruiter assignment
  const activeRecruiters = users.filter((u) => u.role === "recruiter" && u.active);
  const assigned = activeRecruiters[leads.length % (activeRecruiters.length || 1)] || users[0];

  const newLead: Lead = {
    id: `l-meta-${Date.now()}`,
    name,
    phone,
    email,
    source: "Meta Ads",
    status: "New",
    city: body.city || "Pune",
    assigned_recruiter_id: assigned.id,
    assigned_recruiter_name: assigned.name,
    job_title: body.job_title || "General Candidate Pool",
    next_followup_date: new Date(Date.now() + 1800000).toISOString(), // 30 min follow-up SLA
    next_followup_reason: "Immediate Meta Lead Ads outreach",
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    tags: ["Meta Ads", "Fresh Lead"],
  };

  leads.unshift(newLead);
  notifications.unshift({
    id: `n-meta-${Date.now()}`,
    title: "Fresh Meta Ads Lead!",
    message: `${newLead.name} (${newLead.phone}) auto-assigned to ${assigned.name}`,
    date: new Date().toISOString(),
    read: false,
  });

  logAudit("WEBHOOK_META_INGEST", "System", `Ingested Meta Lead ${name} -> assigned to ${assigned.name}`);
  res.status(201).json({ status: "success", lead: newLead });
});

app.post("/api/webhooks/google-forms", (req: Request, res: Response) => {
  const body = req.body || {};
  const name = body.name || body.candidate_name || "Google Form Candidate";
  const phone = body.phone || body.phone_number || "+91 97000 44556";
  const email = body.email || "";

  const existing = leads.find((l) => l.phone === phone);
  if (existing) {
    logAudit("WEBHOOK_GFORM_DUPLICATE", "System", `Duplicate Google Form lead: ${phone}`);
    return res.json({ status: "duplicate_skipped", lead_id: existing.id });
  }

  const activeRecruiters = users.filter((u) => u.role === "recruiter" && u.active);
  const assigned = activeRecruiters[leads.length % (activeRecruiters.length || 1)] || users[0];

  const newLead: Lead = {
    id: `l-gform-${Date.now()}`,
    name,
    phone,
    email,
    source: "Google Forms",
    status: "New",
    city: body.city || "Mumbai",
    assigned_recruiter_id: assigned.id,
    assigned_recruiter_name: assigned.name,
    job_title: body.job_title || "Walk-in Requisition",
    next_followup_date: new Date(Date.now() + 3600000).toISOString(),
    next_followup_reason: "Screen candidate from Google Form submission",
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    tags: ["Google Form"],
  };

  leads.unshift(newLead);
  logAudit("WEBHOOK_GFORM_INGEST", "System", `Google Form candidate synced: ${name} -> ${assigned.name}`);
  res.status(201).json({ status: "success", lead: newLead });
});

// ---------------- LEAD INBOX ISOLATION ----------------
app.get("/api/inbox/leads", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  // Recruiter authorization rule: Recruiters are forbidden from accessing the raw Lead Inbox
  if (user.role === "recruiter") {
    return res.status(403).json({ detail: "Access denied. Lead Inbox is restricted to administrators and team leaders." });
  }

  res.json(leads.filter((l) => l.source === "Website" || l.source === "WhatsApp" || !l.assigned_recruiter_id));
});

// ---------------- JOBS & CLIENTS ----------------
app.get("/api/jobs", (_req: Request, res: Response) => {
  res.json(jobs);
});

app.post("/api/jobs", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role === "recruiter") {
    return res.status(403).json({ detail: "Recruiters cannot create job postings." });
  }

  const clean = sanitizeGeneralBody(req.body, user);
  const newJob: Job = {
    id: "j" + (jobs.length + 1),
    slug: (clean.title || "job").toLowerCase().replace(/[^a-z0-9]+/g, "-"),
    title: clean.title,
    client_id: clean.client_id,
    client_name: clean.client_name,
    location: clean.location || "Pune",
    experience: clean.experience || "2-5 years",
    salary_range: clean.salary_range || "Negotiable",
    positions: clean.positions || 1,
    status: clean.status || "Active",
    category: clean.category || "IT",
    industry: clean.industry || "Information Technology",
    description: clean.description || "",
    requirements: clean.requirements || [],
    created_at: new Date().toISOString(),
  };
  jobs.unshift(newJob);
  res.json(newJob);
});

app.patch("/api/jobs/:jid", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role === "recruiter") {
    return res.status(403).json({ detail: "Recruiters cannot modify job postings." });
  }

  const idx = jobs.findIndex((j) => j.id === req.params.jid);
  if (idx !== -1) {
    const clean = sanitizeGeneralBody(req.body, user);
    jobs[idx] = { ...jobs[idx], ...clean };
    res.json(jobs[idx]);
  } else {
    res.status(404).json({ detail: "Job not found" });
  }
});

app.delete("/api/jobs/:jid", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role === "recruiter") {
    return res.status(403).json({ detail: "Recruiters cannot delete job postings." });
  }
  jobs = jobs.filter((j) => j.id !== req.params.jid);
  res.json({ success: true });
});

app.get("/api/clients", (_req: Request, res: Response) => {
  res.json(clients);
});

app.post("/api/clients", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role === "recruiter") {
    return res.status(403).json({ detail: "Recruiters cannot create clients." });
  }

  const clean = sanitizeGeneralBody(req.body, user);
  const newClient: Client = {
    id: "c" + (clients.length + 1),
    name: clean.name,
    industry: clean.industry || "General",
    contact_person: clean.contact_person || "",
    contact_email: clean.contact_email || "",
    contact_phone: clean.contact_phone || "",
    city: clean.city || "Pune",
    status: clean.status || "Active",
    active_jobs: 0,
  };
  clients.unshift(newClient);
  res.json(newClient);
});

app.patch("/api/clients/:cid", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role === "recruiter") {
    return res.status(403).json({ detail: "Recruiters cannot modify clients." });
  }

  const idx = clients.findIndex((c) => c.id === req.params.cid);
  if (idx !== -1) {
    const clean = sanitizeGeneralBody(req.body, user);
    clients[idx] = { ...clients[idx], ...clean };
    res.json(clients[idx]);
  } else {
    res.status(404).json({ detail: "Client not found" });
  }
});

app.delete("/api/clients/:cid", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role === "recruiter") {
    return res.status(403).json({ detail: "Recruiters cannot delete clients." });
  }
  clients = clients.filter((c) => c.id !== req.params.cid);
  res.json({ success: true });
});

// ---------------- RECRUITERS & USERS (STRICT ACCESS) ----------------
app.get("/api/recruiters", (_req: Request, res: Response) => {
  const activeRecruiters = users.filter((u) => u.role === "recruiter" || u.role === "team_leader");
  const enriched = activeRecruiters.map((r) => {
    const rLeads = leads.filter((l) => l.assigned_recruiter_id === r.id);
    const rLeadIds = rLeads.map((l) => l.id);
    const rJoinings = joinings.filter((j) => rLeadIds.includes(j.lead_id));
    return {
      ...r,
      stats: {
        leads: rLeads.length,
        calls_today: 30 + rLeads.length * 3,
        connected_today: 18 + rLeads.length * 2,
        joined_month: rJoinings.length || 1,
      },
    };
  });
  res.json(enriched);
});

app.get("/api/users", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role === "recruiter") {
    // Recruiters only see active recruiters
    return res.json(users.filter((u) => u.role === "recruiter" || u.id === user.id));
  }
  res.json(users);
});

app.post("/api/users", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role !== "admin") {
    return res.status(403).json({ detail: "Access denied. Only administrators can create users." });
  }

  const clean = sanitizeGeneralBody(req.body, user);
  const newUser: User = {
    id: "u" + (users.length + 1),
    name: clean.name,
    email: clean.email,
    role: clean.role || "recruiter",
    active: true,
    phone: clean.phone,
    target: clean.target || 10,
  };
  users.push(newUser);
  logAudit("USER_CREATE", user.name, `Created user: ${newUser.email}`);
  res.json(newUser);
});

app.patch("/api/users/:uid", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role !== "admin") {
    return res.status(403).json({ detail: "Access denied. Only administrators can modify users." });
  }

  const idx = users.findIndex((u) => u.id === req.params.uid);
  if (idx !== -1) {
    const clean = sanitizeGeneralBody(req.body, user);
    users[idx] = { ...users[idx], ...clean };
    res.json(users[idx]);
  } else {
    res.status(404).json({ detail: "User not found" });
  }
});

app.delete("/api/users/:uid", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role !== "admin") {
    return res.status(403).json({ detail: "Access denied. Only administrators can delete users." });
  }
  users = users.filter((u) => u.id !== req.params.uid);
  res.json({ success: true });
});

// ---------------- HRMS & PAYROLL (STRICT ACCESS) ----------------
app.get("/api/hrms/dashboard", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  const me = employees.find((e) => e.email?.toLowerCase() === user.email?.toLowerCase()) || employees[0];
  const todayStr = new Date().toISOString().split("T")[0];
  const userAtt = attendance.find((a) => (a.employeeId === me.id || a.name === me.name) && a.date === todayStr);

  const my_attendance = {
    check_in_at: userAtt ? todayStr + "T09:15:00.000Z" : undefined,
    check_out_at: userAtt?.checkOut && userAtt.checkOut !== "-" ? todayStr + "T18:30:00.000Z" : undefined,
    status: userAtt?.status || "Present",
  };

  if (user.role === "recruiter") {
    return res.json({
      employee_count: 1,
      present_today: 1,
      late_today: 0,
      half_day_today: 0,
      draft_payroll: "Confidential",
      today: new Date().toLocaleDateString("en-IN", { weekday: "long", year: "numeric", month: "long", day: "numeric" }),
      my_attendance,
    });
  }

  res.json({
    employee_count: employees.length,
    present_today: attendance.filter((a) => a.status === "Present").length,
    late_today: 1,
    half_day_today: 0,
    draft_payroll: "₹1,64,000",
    today: new Date().toLocaleDateString("en-IN", { weekday: "long", year: "numeric", month: "long", day: "numeric" }),
    my_attendance,
  });
});

app.get("/api/hrms/employees", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  let list = employees;
  // Recruiter authorization rule: Cannot view other employee HRMS/salary data
  if (user.role === "recruiter") {
    list = employees.filter((e) => e.email.toLowerCase() === user.email.toLowerCase());
  }

  const formatted = list.map((emp, idx) => {
    const matchedUser = users.find((u) => u.email.toLowerCase() === emp.email.toLowerCase());
    return {
      id: emp.id,
      user_id: matchedUser?.id || "u" + (idx + 1),
      name: emp.name,
      email: emp.email,
      role: matchedUser?.role || "recruiter",
      employee_code: "OAK-EMP0" + (idx + 1),
      designation: emp.designation || (matchedUser?.role === "admin" ? "Director & Founder" : "Talent Acquisition Partner"),
      department: emp.department || "Talent Acquisition",
      employment_type: "Full-Time",
      work_location: "Office (Pune)",
      gross_salary: 55000,
      active_in_hrms: true,
      salary_earnings: {
        basic: 30000,
        hra: 15000,
        special_allowance: 10000,
        other_allowance: 0,
      },
      salary_deductions: {
        pf: 1800,
        esi: 0,
        professional_tax: 200,
        tds: 500,
        other_deductions: 0,
      },
    };
  });

  res.json(formatted);
});

app.get("/api/hrms/employees/me", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  const me = employees.find((e) => e.email.toLowerCase() === user.email.toLowerCase()) || employees[0];
  res.json(me);
});

app.post("/api/hrms/employees", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role === "recruiter") {
    return res.status(403).json({ detail: "Access denied. Recruiters cannot add employee records." });
  }

  const emp = { id: "emp" + (employees.length + 1), ...req.body };
  employees.push(emp);
  res.json(emp);
});

app.patch("/api/hrms/employees/:uid", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role === "recruiter") {
    return res.status(403).json({ detail: "Access denied. Recruiters cannot modify employee profiles." });
  }
  res.json({ success: true, message: "Employee profile updated" });
});

app.get("/api/hrms/attendance", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  let list = attendance;
  // Recruiter authorization rule: Only view own attendance
  if (user.role === "recruiter") {
    const me = employees.find((e) => e.email.toLowerCase() === user.email.toLowerCase());
    if (me) {
      list = attendance.filter((a) => a.employeeId === me.id || a.name === me.name);
    }
  }

  const formatted = list.map((a, idx) => ({
    id: a.id || "att" + idx,
    employee_name: a.name || "Employee",
    employee_code: "OAK-EMP0" + (idx + 1),
    date: a.date || new Date().toISOString().split("T")[0],
    status: a.status || "Present",
    check_in_at: a.date ? `${a.date}T09:15:00.000Z` : new Date().toISOString(),
    check_out_at: a.checkOut && a.checkOut !== "-" ? `${a.date}T18:30:00.000Z` : null,
    total_hours: a.checkOut && a.checkOut !== "-" ? 9.25 : 8.5,
    late_minutes: idx === 1 ? 28 : 0,
    remarks: "",
  }));

  res.json(formatted);
});

app.get("/api/hrms/attendance/summary", (_req: Request, res: Response) => {
  res.json({
    total_days: 22,
    present_days: 21,
    absent_days: 1,
    late_days: 2,
  });
});

app.post("/api/hrms/attendance/check-in", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  const me = employees.find((e) => e.email.toLowerCase() === user.email.toLowerCase()) || employees[0];
  const time = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });

  attendance.push({
    id: "att_" + Date.now(),
    employeeId: me.id,
    name: me.name,
    date: new Date().toISOString().split("T")[0],
    checkIn: time,
    checkOut: "-",
    status: "Present",
  });
  res.json({ success: true, message: `Checked in at ${time}` });
});

app.post("/api/hrms/attendance/check-out", (_req: Request, res: Response) => {
  const time = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  res.json({ success: true, message: `Checked out at ${time}` });
});

app.get("/api/hrms/payroll", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  let list = payroll;
  // Recruiter authorization rule: Only view own payroll slip
  if (user.role === "recruiter") {
    const me = employees.find((e) => e.email.toLowerCase() === user.email.toLowerCase());
    if (me) {
      list = payroll.filter((p) => p.employeeId === me.id || p.name === me.name);
    } else {
      list = [];
    }
  }

  const formatted = list.map((p, idx) => ({
    id: p.id,
    employee_name: p.name,
    employee_code: "OAK-EMP0" + (idx + 1),
    month: p.month || "August 2026",
    paid_days: 25,
    working_days: 26,
    total_earnings: (p.basic || 45000) + (p.allowances || 10000),
    total_deductions: p.deductions || 2500,
    lop_deduction: 0,
    net_pay: p.net || 52500,
    status: p.status || "Paid",
  }));

  res.json(formatted);
});

app.post("/api/hrms/payroll/generate", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role !== "admin") {
    return res.status(403).json({ detail: "Access denied. Only administrators can generate payroll." });
  }
  res.json({ success: true, message: "Payroll generated for current month", generated: ["August 2026 Batch"], skipped_existing: [] });
});

// ---------------- CONFIG, SETTINGS, TAGS & NOTIFICATIONS ----------------
app.get("/api/tags", (_req: Request, res: Response) => {
  res.json([
    { id: "t1", name: "Hot" },
    { id: "t2", name: "High Priority" },
    { id: "t3", name: "React" },
    { id: "t4", name: "NodeJS" },
    { id: "t5", name: "BFSI" },
  ]);
});

app.get("/api/wa-templates", (_req: Request, res: Response) => {
  res.json([
    { id: "wt1", name: "Interview Confirmation", text: "Hello {{name}}, your interview for {{job_title}} is scheduled for {{scheduled_at}}." },
    { id: "wt2", name: "Follow-up Check-in", text: "Hi {{name}}, checking in from OakSphere Connect regarding your job application." },
    { id: "wt3", name: "Offer Letter Release", text: "Congratulations {{name}}! We are thrilled to share the offer letter for {{job_title}}." },
  ]);
});

app.get("/api/notifications", (_req: Request, res: Response) => {
  res.json(notifications);
});

app.get("/api/notifications/unread-count", (_req: Request, res: Response) => {
  res.json({ count: notifications.filter((n) => !n.read).length });
});

app.post("/api/notifications/:nid/read", (req: Request, res: Response) => {
  const n = notifications.find((item) => item.id === req.params.nid);
  if (n) n.read = true;
  res.json({ success: true });
});

app.post("/api/notifications/read-all", (_req: Request, res: Response) => {
  notifications.forEach((n) => (n.read = true));
  res.json({ success: true });
});

app.get("/api/settings", (_req: Request, res: Response) => {
  res.json({
    company_name: "OAKsphere Connect",
    email: "contact@oaksphere.com",
    phone: "+91 98605 00768",
    address: "World Trade Center, Kharadi, Pune, Maharashtra 411014",
    auto_assign_leads: true,
    require_2fa: false,
    currency: "INR (₹)",
    theme: "light",
    priorities: ["High", "Medium", "Low"],
    lead_statuses: ["New", "Contacted", "Screening", "Interview", "Offer", "Joined", "Rejected"],
    sources: ["Website", "WhatsApp", "LinkedIn", "Naukri", "Referral", "Manual"],
  });
});

app.patch("/api/settings", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role !== "admin") {
    return res.status(403).json({ detail: "Only administrators can modify settings." });
  }
  res.json({ success: true, message: "Settings updated" });
});

app.get("/api/audit-logs", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role === "recruiter") {
    return res.status(403).json({ detail: "Access denied." });
  }
  res.json(auditLogs);
});

// ---------------- OAKSPHERE WEBSITE CONTROL CENTER & CMS ENDPOINTS ----------------

// 1. Dashboard Overview
app.get("/api/cms/dashboard", (_req: Request, res: Response) => {
  const audit = runFullSeoAudit(jobs, blogs);
  const activeJobs = jobs.filter((j) => j.status === "Active" || j.status === "published");
  const expiredJobs = jobs.filter((j) => j.status === "Expired" || j.status === "Closed");
  const landingPages = cmsStore.pages.filter((p) => p.category === "landing");
  const oaiCrawler = cmsStore.crawlers.find((c) => c.user_agent === "OAI-SearchBot");

  res.json({
    health_score: audit.overall_score,
    critical_issues: audit.critical_count,
    warnings: audit.warning_count,
    good_checks: audit.good_count,
    counts: {
      total_pages: cmsStore.pages.length,
      landing_pages: landingPages.length,
      published_jobs: activeJobs.length,
      expired_jobs: expiredJobs.length,
      total_locations: cmsStore.locations.length,
      total_services: cmsStore.services.length,
      total_blogs: blogs.length,
      total_media: cmsStore.media.length,
      total_forms: cmsStore.forms.length,
      total_applications: applications.length + 86,
      active_redirects: cmsStore.redirects.filter((r) => r.active).length,
      allowed_crawlers: cmsStore.crawlers.filter((c) => c.allow).length,
    },
    indexing_status: {
      google: "Indexed (All Core Pages)",
      google_jobs: `${activeJobs.length} Jobs Active in Google Job Search India`,
      bing_indexnow: "Connected (IndexNow Live)",
      chatgpt_search: oaiCrawler?.allow ? "Discoverable (OAI-SearchBot Allowed)" : "Blocked in robots.txt",
    },
    search_readiness: {
      average_score: 96,
      pages_analyzed: cmsStore.pages.length,
      status: "Optimal",
    },
    recent_activity: cmsStore.activity_log.slice(0, 6),
  });
});

// 2. Global Settings & Contact
app.get("/api/cms/settings", (_req: Request, res: Response) => {
  res.json(cmsStore.settings);
});

app.patch("/api/cms/settings", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role !== "admin") return res.status(403).json({ detail: "Access denied." });
  cmsStore.settings = { ...cmsStore.settings, ...req.body };
  siteData.settings = { ...siteData.settings, ...cmsStore.settings };
  if (req.body.contact) {
    cmsStore.settings.contact = { ...cmsStore.settings.contact, ...req.body.contact };
    siteData.contact = cmsStore.settings.contact;
  }
  cmsStore.activity_log.unshift({
    id: "act-" + Date.now(),
    timestamp: new Date().toISOString().replace("T", " ").substring(0, 16),
    user: user.name || "Admin",
    action: "Updated Website Settings",
    target: "Global Configuration",
    details: "Settings, brand assets, or announcement bar saved",
  });
  res.json({ success: true, settings: cmsStore.settings });
});

app.get("/api/cms/contact", (_req: Request, res: Response) => {
  res.json(cmsStore.settings.contact);
});

app.patch("/api/cms/contact", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role !== "admin") return res.status(403).json({ detail: "Access denied." });
  cmsStore.settings.contact = { ...cmsStore.settings.contact, ...req.body };
  siteData.contact = cmsStore.settings.contact;
  res.json({ success: true, data: cmsStore.settings.contact });
});

// 3. Menu Manager
app.get("/api/cms/menus", (_req: Request, res: Response) => {
  res.json(cmsStore.menus);
});

app.patch("/api/cms/menus", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role !== "admin") return res.status(403).json({ detail: "Access denied." });
  if (req.body.header) cmsStore.menus.header = req.body.header;
  if (req.body.footer) cmsStore.menus.footer = req.body.footer;
  siteData.menus = cmsStore.menus;
  cmsStore.activity_log.unshift({
    id: "act-" + Date.now(),
    timestamp: new Date().toISOString().replace("T", " ").substring(0, 16),
    user: user.name || "Admin",
    action: "Updated Navigation Menus",
    target: "Header / Footer Menus",
    details: "Reordered or added menu navigation items",
  });
  res.json({ success: true, menus: cmsStore.menus });
});

// 4. Pages CMS & Landing Page Builder
app.get("/api/cms/pages", (_req: Request, res: Response) => {
  res.json(cmsStore.pages);
});

app.post("/api/cms/pages", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role !== "admin") return res.status(403).json({ detail: "Access denied." });
  const rawSlug = (req.body.slug || req.body.title || "page").toLowerCase().trim();
  const slug = rawSlug.startsWith("/") ? rawSlug : `/${rawSlug.replace(/[^a-z0-9]+/g, "-")}`;
  const newPage: any = {
    id: "p-" + Date.now(),
    slug,
    title: req.body.title || "New Page",
    category: req.body.category || "landing",
    status: req.body.status || "published",
    last_reviewed: new Date().toISOString().split("T")[0],
    h1: req.body.h1 || req.body.title || "New Page",
    meta_title: req.body.meta_title || `${req.body.title || "New Page"} | OAKSphere Connect`,
    meta_description: req.body.meta_description || "Verified recruitment and staffing solutions across India with OAKSphere Connect.",
    canonical_url: req.body.canonical_url || `https://oaksphereconnect.com${slug}`,
    robots_index: req.body.robots_index ?? true,
    robots_follow: req.body.robots_follow ?? true,
    og_title: req.body.og_title || req.body.title || "New Page",
    og_description: req.body.og_description || req.body.meta_description || "",
    og_image: req.body.og_image || cmsStore.settings.seo_defaults.default_og_image,
    schema_type: req.body.schema_type || "WebPage",
    sections: req.body.sections || [],
    aeo_qa: req.body.aeo_qa || [],
    target_keywords: req.body.target_keywords || [],
  };
  cmsStore.pages.push(newPage);
  siteData.pages = cmsStore.pages;
  cmsStore.activity_log.unshift({
    id: "act-" + Date.now(),
    timestamp: new Date().toISOString().replace("T", " ").substring(0, 16),
    user: user.name || "Admin",
    action: "Created Page",
    target: newPage.slug,
    details: `Page "${newPage.title}" created with SEO metadata`,
  });
  res.json(newPage);
});

app.patch("/api/cms/pages/:id", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role !== "admin") return res.status(403).json({ detail: "Access denied." });
  const idx = cmsStore.pages.findIndex((p) => p.id === req.params.id);
  if (idx !== -1) {
    cmsStore.pages[idx] = {
      ...cmsStore.pages[idx],
      ...req.body,
      last_reviewed: new Date().toISOString().split("T")[0],
    };
    siteData.pages = cmsStore.pages;
    cmsStore.activity_log.unshift({
      id: "act-" + Date.now(),
      timestamp: new Date().toISOString().replace("T", " ").substring(0, 16),
      user: user.name || "Admin",
      action: "Updated Page",
      target: cmsStore.pages[idx].slug,
      details: `Saved changes to "${cmsStore.pages[idx].title}"`,
    });
    return res.json({ success: true, page: cmsStore.pages[idx] });
  }
  res.status(404).json({ detail: "Page not found" });
});

app.post("/api/cms/pages/:id/duplicate", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role !== "admin") return res.status(403).json({ detail: "Access denied." });
  const page = cmsStore.pages.find((p) => p.id === req.params.id);
  if (!page) return res.status(404).json({ detail: "Page not found" });
  const dup: any = {
    ...JSON.parse(JSON.stringify(page)),
    id: "p-" + Date.now(),
    title: `${page.title} (Copy)`,
    slug: `${page.slug}-copy`,
    status: "draft",
    canonical_url: `https://oaksphereconnect.com${page.slug}-copy`,
    last_reviewed: new Date().toISOString().split("T")[0],
  };
  cmsStore.pages.push(dup);
  siteData.pages = cmsStore.pages;
  res.json(dup);
});

app.delete("/api/cms/pages/:id", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role !== "admin") return res.status(403).json({ detail: "Access denied." });
  const page = cmsStore.pages.find((p) => p.id === req.params.id);
  if (page && page.slug === "/") {
    return res.status(400).json({ detail: "Cannot delete the primary homepage." });
  }
  cmsStore.pages = cmsStore.pages.filter((p) => p.id !== req.params.id);
  siteData.pages = cmsStore.pages;
  res.json({ success: true });
});

// 5. Job CMS with Google Job Search Readiness & Expired Job Handling
app.get("/api/cms/jobs", (_req: Request, res: Response) => {
  res.json(jobs);
});

app.post("/api/cms/jobs", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role !== "admin") return res.status(403).json({ detail: "Access denied." });
  const title = req.body.title || "New Job";
  const slug = (req.body.slug || title).toLowerCase().replace(/[^a-z0-9]+/g, "-");
  const newJob: any = {
    id: "j" + (jobs.length + 1),
    slug,
    title,
    client_id: req.body.client_id || "c1",
    client_name: req.body.client_name || "Enterprise Client",
    location: req.body.location || "Pune, India (Hybrid)",
    experience: req.body.experience || "2-5 years",
    salary_range: req.body.salary_range || "Competitive",
    positions: Number(req.body.positions) || 1,
    status: req.body.status || "Active",
    category: req.body.category || "IT / Software",
    industry: req.body.industry || "Information Technology",
    description: req.body.description || "Exciting opportunity to work with leading enterprise teams.",
    requirements: req.body.requirements || ["Strong communication", "Relevant domain experience"],
    created_at: new Date().toISOString(),
    valid_through: req.body.valid_through || new Date(Date.now() + 60 * 24 * 60 * 60 * 1000).toISOString(),
    employment_type: req.body.employment_type || "FULL_TIME",
    direct_apply_url: req.body.direct_apply_url || "",
  };
  jobs.unshift(newJob);
  cmsStore.activity_log.unshift({
    id: "act-" + Date.now(),
    timestamp: new Date().toISOString().replace("T", " ").substring(0, 16),
    user: user.name || "Admin",
    action: "Created Job Vacancy",
    target: `/jobs/${newJob.slug}`,
    details: `Job "${newJob.title}" added with JobPosting schema`,
  });
  res.json(newJob);
});

app.patch("/api/cms/jobs/:id", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role !== "admin") return res.status(403).json({ detail: "Access denied." });
  const idx = jobs.findIndex((j) => j.id === req.params.id);
  if (idx !== -1) {
    jobs[idx] = { ...jobs[idx], ...req.body };
    res.json(jobs[idx]);
  } else {
    res.status(404).json({ detail: "Job not found" });
  }
});

// Expire Job Endpoint (Google-compliant expired vacancy automation)
app.post("/api/cms/jobs/:id/expire", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role !== "admin") return res.status(403).json({ detail: "Access denied." });
  const job: any = jobs.find((j) => j.id === req.params.id);
  if (job) {
    job.status = "Expired";
    // Set valid_through to yesterday per Google Job Search guidelines
    job.valid_through = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
    cmsStore.activity_log.unshift({
      id: "act-" + Date.now(),
      timestamp: new Date().toISOString().replace("T", " ").substring(0, 16),
      user: user.name || "Admin",
      action: "Expired Job Vacancy",
      target: `/jobs/${job.slug}`,
      details: "Set valid_through to past date to signal Google Job Search removal",
    });
    return res.json({
      success: true,
      job,
      message: "Job marked Expired. Schema validThrough set in past and removal signal sent to search crawlers.",
    });
  }
  res.status(404).json({ detail: "Job not found" });
});

app.post("/api/cms/jobs/:id/duplicate", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role !== "admin") return res.status(403).json({ detail: "Access denied." });
  const job = jobs.find((j) => j.id === req.params.id);
  if (job) {
    const dup: any = {
      ...job,
      id: "j" + (jobs.length + 1),
      title: `${job.title} (Copy)`,
      slug: `${job.slug}-copy`,
      status: "Draft",
      created_at: new Date().toISOString(),
    };
    jobs.unshift(dup);
    return res.json(dup);
  }
  res.status(404).json({ detail: "Job not found" });
});

app.delete("/api/cms/jobs/:id", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role !== "admin") return res.status(403).json({ detail: "Access denied." });
  jobs = jobs.filter((j) => j.id !== req.params.id);
  res.json({ success: true });
});

// 6. Job Location Manager (Mumbai, Navi Mumbai, Pune, Thane, Nagpur, etc.)
app.get("/api/cms/locations", (_req: Request, res: Response) => {
  res.json(cmsStore.locations);
});

app.post("/api/cms/locations", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role !== "admin") return res.status(403).json({ detail: "Access denied." });
  const slug = (req.body.slug || req.body.name || "").toLowerCase().replace(/[^a-z0-9]+/g, "-");
  const newLoc: any = {
    id: "loc-" + Date.now(),
    name: req.body.name || "New City",
    slug,
    state: req.body.state || "Maharashtra",
    address: req.body.address || "",
    pincodes: req.body.pincodes || "",
    landmark: req.body.landmark || "",
    phone: req.body.phone || cmsStore.settings.contact.phone,
    email: req.body.email || cmsStore.settings.contact.email,
    lat: Number(req.body.lat) || 18.5204,
    lng: Number(req.body.lng) || 73.8567,
    hiring_focus: req.body.hiring_focus || ["IT & Software", "BFSI"],
    active_jobs_count: 0,
    meta_title: req.body.meta_title || `Jobs in ${req.body.name} 2026 | Top Vacancies | OAKSphere Connect`,
    meta_description: req.body.meta_description || `Find verified job openings in ${req.body.name}. Connect with top employers through OAKSphere Connect.`,
    h1: req.body.h1 || `Recruitment Agency in ${req.body.name}`,
    intro_content: req.body.intro_content || `Leading talent acquisition partner in ${req.body.name}.`,
    geo_radius_km: 30,
  };
  cmsStore.locations.push(newLoc);
  siteData.locations = cmsStore.locations;
  res.json(newLoc);
});

app.patch("/api/cms/locations/:id", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role !== "admin") return res.status(403).json({ detail: "Access denied." });
  const idx = cmsStore.locations.findIndex((l) => l.id === req.params.id);
  if (idx !== -1) {
    cmsStore.locations[idx] = { ...cmsStore.locations[idx], ...req.body };
    siteData.locations = cmsStore.locations;
    return res.json(cmsStore.locations[idx]);
  }
  res.status(404).json({ detail: "Location not found" });
});

app.delete("/api/cms/locations/:id", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role !== "admin") return res.status(403).json({ detail: "Access denied." });
  cmsStore.locations = cmsStore.locations.filter((l) => l.id !== req.params.id);
  siteData.locations = cmsStore.locations;
  res.json({ success: true });
});

// 7. Services CMS
app.get("/api/cms/services", (_req: Request, res: Response) => {
  res.json(cmsStore.services);
});

app.post("/api/cms/services", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role !== "admin") return res.status(403).json({ detail: "Access denied." });
  const slug = (req.body.slug || req.body.name || "").toLowerCase().replace(/[^a-z0-9]+/g, "-");
  const newService: any = {
    id: "srv-" + Date.now(),
    name: req.body.name || "New Service",
    slug,
    category: req.body.category || "Staffing",
    icon: req.body.icon || "Briefcase",
    short_desc: req.body.short_desc || "",
    full_desc: req.body.full_desc || "",
    deliverables: req.body.deliverables || ["Pre-screened candidates", "48h SLA"],
    turnaround: req.body.turnaround || "48 Hours",
    commercial_model: req.body.commercial_model || "Contingency",
    roles_covered: req.body.roles_covered || [],
    meta_title: req.body.meta_title || `${req.body.name} | OAKSphere Connect`,
    meta_description: req.body.meta_description || "",
    h1: req.body.h1 || req.body.name,
    active: true,
  };
  cmsStore.services.push(newService);
  siteData.services = cmsStore.services;
  res.json(newService);
});

app.patch("/api/cms/services/:id", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role !== "admin") return res.status(403).json({ detail: "Access denied." });
  const idx = cmsStore.services.findIndex((s) => s.id === req.params.id);
  if (idx !== -1) {
    cmsStore.services[idx] = { ...cmsStore.services[idx], ...req.body };
    siteData.services = cmsStore.services;
    return res.json(cmsStore.services[idx]);
  }
  res.status(404).json({ detail: "Service not found" });
});

app.delete("/api/cms/services/:id", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role !== "admin") return res.status(403).json({ detail: "Access denied." });
  cmsStore.services = cmsStore.services.filter((s) => s.id !== req.params.id);
  siteData.services = cmsStore.services;
  res.json({ success: true });
});

// 8. Media Library
app.get("/api/cms/media", (_req: Request, res: Response) => {
  res.json(cmsStore.media);
});

app.post("/api/cms/media", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role !== "admin") return res.status(403).json({ detail: "Access denied." });
  const item: any = {
    id: "med-" + Date.now(),
    name: req.body.name || "uploaded-image.jpg",
    url: req.body.url || "https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=800&q=80",
    file_type: req.body.file_type || "image",
    size_kb: req.body.size_kb || 85,
    alt_text: req.body.alt_text || "OAKSphere Connect image",
    caption: req.body.caption || "",
    folder: req.body.folder || "general",
    uploaded_at: new Date().toISOString().split("T")[0],
  };
  cmsStore.media.unshift(item);
  res.json(item);
});

app.patch("/api/cms/media/:id", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role !== "admin") return res.status(403).json({ detail: "Access denied." });
  const idx = cmsStore.media.findIndex((m) => m.id === req.params.id);
  if (idx !== -1) {
    cmsStore.media[idx] = { ...cmsStore.media[idx], ...req.body };
    return res.json(cmsStore.media[idx]);
  }
  res.status(404).json({ detail: "Media item not found" });
});

app.delete("/api/cms/media/:id", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role !== "admin") return res.status(403).json({ detail: "Access denied." });
  cmsStore.media = cmsStore.media.filter((m) => m.id !== req.params.id);
  res.json({ success: true });
});

// 9. Forms Manager
app.get("/api/cms/forms", (_req: Request, res: Response) => {
  res.json(cmsStore.forms);
});

app.post("/api/cms/forms", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role !== "admin") return res.status(403).json({ detail: "Access denied." });
  const newForm: any = {
    id: "frm-" + Date.now(),
    title: req.body.title || "Custom Form",
    description: req.body.description || "",
    slug: (req.body.slug || req.body.title || "form").toLowerCase().replace(/[^a-z0-9]+/g, "-"),
    email_notifications: req.body.email_notifications || ["contact@oaksphereconnect.com"],
    crm_auto_lead: req.body.crm_auto_lead ?? true,
    success_message: req.body.success_message || "Thank you for submitting!",
    fields: req.body.fields || [],
    submissions_count: 0,
  };
  cmsStore.forms.push(newForm);
  res.json(newForm);
});

app.patch("/api/cms/forms/:id", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role !== "admin") return res.status(403).json({ detail: "Access denied." });
  const idx = cmsStore.forms.findIndex((f) => f.id === req.params.id);
  if (idx !== -1) {
    cmsStore.forms[idx] = { ...cmsStore.forms[idx], ...req.body };
    return res.json(cmsStore.forms[idx]);
  }
  res.status(404).json({ detail: "Form not found" });
});

// Form Public Submission Endpoint (automatically maps to CRM leads)
app.post("/api/cms/forms/:slug/submit", (req: Request, res: Response) => {
  const form = cmsStore.forms.find((f) => f.slug === req.params.slug);
  if (form) {
    form.submissions_count = (form.submissions_count || 0) + 1;
    if (form.crm_auto_lead && req.body.name) {
      leads.unshift({
        id: "lead-" + Date.now(),
        name: req.body.name || "Website Lead",
        phone: req.body.phone || "+91 98000 00000",
        email: req.body.email || "lead@website.com",
        city: req.body.city || "Pune",
        source: `Website Form: ${form.title}`,
        status: "New",
        role_applied: req.body.role || req.body.hiring_domain || "General Inquiry",
        experience: req.body.experience || "Not specified",
        created_at: new Date().toISOString(),
        notes: req.body.message || req.body.job_details || "",
      } as any);
    }
    return res.json({ success: true, message: form.success_message });
  }
  res.json({ success: true, message: "Submission received. We will contact you soon." });
});

// 10. Modular Content Blocks (Testimonials, Clients, FAQs, Team, Statistics)
app.get("/api/cms/blocks", (_req: Request, res: Response) => {
  res.json(cmsStore.content_blocks);
});

app.patch("/api/cms/blocks", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role !== "admin") return res.status(403).json({ detail: "Access denied." });
  cmsStore.content_blocks = { ...cmsStore.content_blocks, ...req.body };
  siteData.content_blocks = cmsStore.content_blocks;
  res.json({ success: true, blocks: cmsStore.content_blocks });
});

// 11. Redirects Manager (301, 302, 410)
app.get("/api/cms/redirects", (_req: Request, res: Response) => {
  res.json(cmsStore.redirects);
});

app.post("/api/cms/redirects", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role !== "admin") return res.status(403).json({ detail: "Access denied." });
  const rule: any = {
    id: "red-" + Date.now(),
    from_path: req.body.from_path?.startsWith("/") ? req.body.from_path : `/${req.body.from_path}`,
    to_path: req.body.to_path,
    status_code: Number(req.body.status_code) || 301,
    hits: 0,
    active: req.body.active ?? true,
    note: req.body.note || "",
  };
  cmsStore.redirects.unshift(rule);
  res.json(rule);
});

app.patch("/api/cms/redirects/:id", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role !== "admin") return res.status(403).json({ detail: "Access denied." });
  const idx = cmsStore.redirects.findIndex((r) => r.id === req.params.id);
  if (idx !== -1) {
    cmsStore.redirects[idx] = { ...cmsStore.redirects[idx], ...req.body };
    return res.json(cmsStore.redirects[idx]);
  }
  res.status(404).json({ detail: "Redirect rule not found" });
});

app.delete("/api/cms/redirects/:id", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role !== "admin") return res.status(403).json({ detail: "Access denied." });
  cmsStore.redirects = cmsStore.redirects.filter((r) => r.id !== req.params.id);
  res.json({ success: true });
});

// 12. AI & Search Crawler Manager (Googlebot, Bingbot, OAI-SearchBot, GPTBot, ClaudeBot, PerplexityBot)
app.get("/api/cms/crawlers", (_req: Request, res: Response) => {
  res.json({
    crawlers: cmsStore.crawlers,
    custom_directives: cmsStore.rules_engine.custom_robots_directives,
    preview_robots_txt: generateRobotsTxtContent(),
  });
});

app.patch("/api/cms/crawlers", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role !== "admin") return res.status(403).json({ detail: "Access denied." });
  if (req.body.crawlers) cmsStore.crawlers = req.body.crawlers;
  if (req.body.custom_directives) cmsStore.rules_engine.custom_robots_directives = req.body.custom_directives;
  cmsStore.activity_log.unshift({
    id: "act-" + Date.now(),
    timestamp: new Date().toISOString().replace("T", " ").substring(0, 16),
    user: user.name || "Admin",
    action: "Updated Crawler Directives",
    target: "/robots.txt",
    details: "Configured search & AI crawler permissions (OAI-SearchBot, Googlebot, etc.)",
  });
  res.json({
    success: true,
    crawlers: cmsStore.crawlers,
    preview_robots_txt: generateRobotsTxtContent(),
  });
});

// 13. Deep SEO Audit & 11-Point Search & AI Readiness Engine
app.get(["/api/cms/seo", "/api/cms/seo/audit"], (_req: Request, res: Response) => {
  const audit = runFullSeoAudit(jobs, blogs);
  res.json(audit);
});

app.post("/api/cms/seo/audit/run", (_req: Request, res: Response) => {
  const audit = runFullSeoAudit(jobs, blogs);
  cmsStore.activity_log.unshift({
    id: "act-" + Date.now(),
    timestamp: new Date().toISOString().replace("T", " ").substring(0, 16),
    user: "Admin User",
    action: "Run Deep SEO Audit",
    target: `All ${audit.total_pages_audited} Pages & Vacancies`,
    details: `Computed overall score ${audit.overall_score}/100 with ${audit.critical_count} critical issues`,
  });
  res.json({ success: true, audit });
});

// Search & AI Readiness Scorecard (11 checks per page as requested)
const handleReadinessRequest = (_req: Request, res: Response) => {
  const readiness = calculateSearchAiReadiness(jobs, blogs);
  res.json({
    total_pages: readiness.length,
    average_score: Math.round(readiness.reduce((acc, r) => acc + r.readiness_score, 0) / readiness.length),
    last_audit_date: new Date().toISOString().split("T")[0],
    criteria_definitions: [
      { id: "google_seo", name: "Google SEO", note: "Title, meta description, H1, and mobile indexability" },
      { id: "google_job_search", name: "Google Job Search", note: "JobPosting schema with validThrough, hiringOrganization, baseSalary" },
      { id: "local_seo", name: "Local SEO", note: "City keywords, LocalBusiness schema, branch NAP consistency" },
      { id: "structured_data", name: "Structured Data", note: "Valid JSON-LD markup adhering to Schema.org standards" },
      { id: "bing_indexnow", name: "Bing / IndexNow", note: "IndexNow API key and instant sitemap ping compatibility" },
      { id: "chatgpt_search_crawl", name: "ChatGPT Search Crawl", note: "OAI-SearchBot permitted in robots.txt rules" },
      { id: "canonical", name: "Canonical Tag", note: "Self-referencing absolute canonical URL" },
      { id: "sitemap", name: "XML Sitemap", note: "Included in automated /sitemap.xml with priority" },
      { id: "mobile", name: "Mobile Responsive", note: "Viewport and responsive layout verified" },
      { id: "performance", name: "Performance & Vitals", note: "Lazy loading, lightweight CSS, clean scripts" },
      { id: "ai_readable_content", name: "AI-Readable Content", note: "AEO concise answer blocks, definitions, structured entity facts" },
    ],
    items: readiness,
  });
};
app.get("/api/cms/seo/readiness", handleReadinessRequest);
app.get("/api/cms/readiness", handleReadinessRequest);

// 14. Search & AI Rules Engine
app.get("/api/cms/rules", (_req: Request, res: Response) => {
  res.json(cmsStore.rules_engine);
});

app.patch("/api/cms/rules", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role !== "admin") return res.status(403).json({ detail: "Access denied." });
  cmsStore.rules_engine = { ...cmsStore.rules_engine, ...req.body };
  cmsStore.activity_log.unshift({
    id: "act-" + Date.now(),
    timestamp: new Date().toISOString().replace("T", " ").substring(0, 16),
    user: user.name || "Admin",
    action: "Updated Search & AI Rules",
    target: "Search & AI Rules Engine",
    details: "Configured metadata templates, schema defaults, or expiry rules",
  });
  res.json({ success: true, rules: cmsStore.rules_engine });
});

// 15. IndexNow & Search Engine Submission Center
app.post("/api/cms/indexnow/submit", (req: Request, res: Response) => {
  const baseUrl = cmsStore.settings.site_url || "https://oaksphereconnect.com";
  const urlList = req.body.urls || [
    `${baseUrl}/`,
    `${baseUrl}/jobs`,
    `${baseUrl}/employers`,
    `${baseUrl}/candidates`,
    `${baseUrl}/jobs-in-mumbai`,
    `${baseUrl}/bpo-jobs-navi-mumbai`,
    `${baseUrl}/bulk-hiring-india`,
  ];
  cmsStore.activity_log.unshift({
    id: "act-" + Date.now(),
    timestamp: new Date().toISOString().replace("T", " ").substring(0, 16),
    user: "Admin User",
    action: "IndexNow & Sitemap Ping",
    target: "Bing, Yandex, Seznam & Google",
    details: `Submitted ${urlList.length} URLs to IndexNow and pinged Googlebot`,
  });
  res.json({
    success: true,
    submitted_urls_count: urlList.length,
    timestamp: new Date().toISOString(),
    engine_responses: [
      { engine: "IndexNow (Bing & Copilot Search)", status: 200, message: "OK - URLs queued for fast re-crawl" },
      { engine: "IndexNow (Yandex)", status: 200, message: "OK - URLs accepted" },
      { engine: "Google Search Console Sitemap Ping", status: 200, message: "HTTP 200 - Sitemap fetched by Googlebot" },
    ],
  });
});

// 16. Analytics Center Data
app.get("/api/cms/analytics", (_req: Request, res: Response) => {
  res.json({
    total_impressions: 48920,
    organic_clicks: 12480,
    average_ctr: "25.5%",
    average_position: 3.4,
    applications_submitted: 184,
    conversion_rate: "14.7%",
    ai_crawler_hits_30d: {
      "OAI-SearchBot (ChatGPT Search)": 1420,
      "PerplexityBot": 880,
      "Googlebot": 5600,
      "Bingbot": 2100,
      "Applebot": 340,
    },
    top_landing_pages: [
      { path: "/", title: "Homepage", clicks: 4200, impressions: 16500, ctr: "25.4%" },
      { path: "/jobs-in-mumbai", title: "Jobs in Mumbai", clicks: 2310, impressions: 8400, ctr: "27.5%" },
      { path: "/bpo-jobs-navi-mumbai", title: "BPO Jobs Navi Mumbai", clicks: 1850, impressions: 6900, ctr: "26.8%" },
      { path: "/bulk-hiring-india", title: "Bulk Hiring India", clicks: 1420, impressions: 5100, ctr: "27.8%" },
      { path: "/location/pune", title: "Jobs in Pune", clicks: 1390, impressions: 4800, ctr: "28.9%" },
    ],
    top_search_queries: [
      { query: "recruitment agency in pune", clicks: 820, impressions: 2400, position: 1.8 },
      { query: "bpo jobs navi mumbai airoli", clicks: 640, impressions: 1850, position: 2.1 },
      { query: "it staffing company kharadi", clicks: 510, impressions: 1540, position: 1.4 },
      { query: "jobs in bkc mumbai", clicks: 430, impressions: 1290, position: 2.4 },
      { query: "bulk recruitment agency india", clicks: 390, impressions: 1100, position: 3.1 },
    ],
  });
});

// 17. Backup & Restore CMS System
app.get("/api/cms/backup", (_req: Request, res: Response) => {
  res.json({
    version: "2026.09.1",
    exported_at: new Date().toISOString(),
    cms_store: cmsStore,
    jobs_count: jobs.length,
    blogs_count: blogs.length,
  });
});

app.post("/api/cms/restore", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  if (user.role !== "admin") return res.status(403).json({ detail: "Access denied." });
  if (req.body.cms_store) {
    Object.assign(cmsStore, req.body.cms_store);
    siteData.settings = cmsStore.settings;
    siteData.menus = cmsStore.menus;
    siteData.pages = cmsStore.pages;
    siteData.locations = cmsStore.locations;
    siteData.services = cmsStore.services;
    siteData.content_blocks = cmsStore.content_blocks;
    cmsStore.activity_log.unshift({
      id: "act-" + Date.now(),
      timestamp: new Date().toISOString().replace("T", " ").substring(0, 16),
      user: user.name || "Admin",
      action: "Restored CMS Snapshot",
      target: "All Website Configuration",
      details: "Full JSON snapshot restored successfully",
    });
    return res.json({ success: true, message: "CMS configuration restored successfully." });
  }
  res.status(400).json({ detail: "Invalid backup JSON format." });
});

// 18. Blog CMS
app.get("/api/cms/blog", (_req: Request, res: Response) => {
  res.json(blogs || []);
});

app.post("/api/cms/blog", (req: Request, res: Response) => {
  const blog = {
    id: "b_" + Date.now(),
    slug: (req.body.title || "post").toLowerCase().replace(/[^a-z0-9]+/g, "-"),
    date: new Date().toISOString().split("T")[0],
    read_time: req.body.read_time || "5 min read",
    author: req.body.author || "OAKSphere Research Team",
    category: req.body.category || "Hiring Trends",
    tags: req.body.tags || ["Recruitment", "India Careers"],
    ...req.body,
  };
  blogs.unshift(blog);
  res.json(blog);
});

app.patch("/api/cms/blog/:id", (req: Request, res: Response) => {
  const idx = blogs.findIndex((b) => b.id === req.params.id);
  if (idx !== -1) {
    blogs[idx] = { ...blogs[idx], ...req.body };
    res.json(blogs[idx]);
  } else {
    res.status(404).json({ detail: "Blog post not found" });
  }
});

app.delete("/api/cms/blog/:id", (req: Request, res: Response) => {
  blogs = blogs.filter((b) => b.id !== req.params.id);
  res.json({ success: true });
});

// Categories & Industries for Taxonomies
app.get("/api/cms/categories", (_req: Request, res: Response) => {
  res.json(siteData.categories || []);
});

app.post("/api/cms/categories", (req: Request, res: Response) => {
  siteData.categories = siteData.categories || [];
  const cat = { id: "cat_" + Date.now(), slug: (req.body.name || "").toLowerCase().replace(/\s+/g, "-"), ...req.body };
  siteData.categories.push(cat);
  res.json(cat);
});

app.delete("/api/cms/categories/:id", (req: Request, res: Response) => {
  siteData.categories = (siteData.categories || []).filter((c: any) => c.id !== req.params.id && c.slug !== req.params.id);
  res.json({ success: true });
});

app.get("/api/cms/industries", (_req: Request, res: Response) => {
  res.json(siteData.industries || []);
});

app.post("/api/cms/industries", (req: Request, res: Response) => {
  siteData.industries = siteData.industries || [];
  const ind = { id: "ind_" + Date.now(), slug: (req.body.name || "").toLowerCase().replace(/\s+/g, "-"), ...req.body };
  siteData.industries.push(ind);
  res.json(ind);
});

app.delete("/api/cms/industries/:id", (req: Request, res: Response) => {
  siteData.industries = (siteData.industries || []).filter((i: any) => i.id !== req.params.id && i.slug !== req.params.id);
  res.json({ success: true });
});

app.get("/api/cms/faqs", (_req: Request, res: Response) => {
  res.json(cmsStore.content_blocks.faqs || faqs || []);
});

app.post("/api/cms/faqs", (req: Request, res: Response) => {
  const faq = { id: "faq_" + Date.now(), ...req.body };
  cmsStore.content_blocks.faqs = cmsStore.content_blocks.faqs || [];
  cmsStore.content_blocks.faqs.push(faq);
  faqs.push(faq);
  res.json(faq);
});

app.patch("/api/cms/faqs/:id", (req: Request, res: Response) => {
  const idx = (cmsStore.content_blocks.faqs || []).findIndex((f: any) => f.id === req.params.id);
  if (idx !== -1) {
    cmsStore.content_blocks.faqs[idx] = { ...cmsStore.content_blocks.faqs[idx], ...req.body };
    return res.json(cmsStore.content_blocks.faqs[idx]);
  }
  res.status(404).json({ detail: "FAQ not found" });
});

app.delete("/api/cms/faqs/:id", (req: Request, res: Response) => {
  cmsStore.content_blocks.faqs = (cmsStore.content_blocks.faqs || []).filter((f: any) => f.id !== req.params.id);
  faqs = faqs.filter((f) => f.id !== req.params.id);
  res.json({ success: true });
});

// AI Copy Generator for CMS
app.post("/api/ai/generate", (req: Request, res: Response) => {
  const { prompt, type } = req.body;
  let generated = "Experienced professional seeking new growth opportunities in dynamic environments.";

  if (type === "job_description") {
    generated = `We are looking for a dedicated and skilled candidate to join our high-performing team.
Key Responsibilities:
- Execute daily objectives and collaborate across cross-functional departments
- Maintain quality benchmarks and adhere to compliance standards
- Identify process enhancements and contribute to company growth

Requirements:
- Bachelor's degree or equivalent practical experience
- Proven track record of strong communication and problem-solving skills
- Proficiency in industry-standard software and tools`;
  } else if (type === "seo_description") {
    generated = `Discover verified opportunities with OAKsphere Connect. Pre-screened candidates, top employers, and dedicated talent solutions across India.`;
  }

  res.json({ success: true, text: generated, prompt });
});

// ---------------- REPORTS & ANALYTICS ----------------
app.get("/api/reports/missed-followups", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  let list = leads.filter((l) => l.next_followup_date);
  if (user.role === "recruiter") {
    list = list.filter((l) => l.assigned_recruiter_id === user.id);
  }

  const todayStr = new Date().toISOString().split("T")[0];
  const missed = list
    .filter((l) => l.next_followup_date && l.next_followup_date < todayStr)
    .map((l) => ({
      id: "mf_" + l.id,
      lead_name: l.name,
      phone: l.phone,
      due_date: l.next_followup_date,
      overdue_by: "36 hours",
      recruiter_name: l.assigned_recruiter_name || "Harshika Sharma",
    }));

  res.json(missed);
});

app.get("/api/reports/leads-by-source", (_req: Request, res: Response) => {
  res.json([
    { source: "LinkedIn", count: 32, converted: 12 },
    { source: "Website", count: 28, converted: 9 },
    { source: "WhatsApp", count: 22, converted: 8 },
    { source: "Naukri", count: 18, converted: 5 },
    { source: "Referral", count: 14, converted: 6 },
    { source: "Manual", count: 6, converted: 2 },
  ]);
});

// ---------------- INTEGRATIONS ----------------
const initialIntegrations = [
  { id: "whatsapp", name: "WhatsApp Business API", connected: true, status: "Connected", account: "+91 98605 00768", last_synced: "Just now" },
  { id: "email", name: "Google Workspace / Gmail", connected: true, status: "Connected", account: "talent@oaksphere.com", last_synced: "10 mins ago" },
  { id: "naukri", name: "Naukri Enterprise Hub", connected: false, status: "Ready to Connect", account: null, last_synced: null },
  { id: "linkedin", name: "LinkedIn Recruiter Lite", connected: false, status: "Ready to Connect", account: null, last_synced: null },
];

app.get("/api/cms/integrations", (_req: Request, res: Response) => {
  res.json(initialIntegrations);
});

app.post("/api/cms/integrations/:id/test", (req: Request, res: Response) => {
  res.json({ success: true, message: `Tested integration ${req.params.id} successfully.` });
});

app.post("/api/cms/integrations/:id/disconnect", (req: Request, res: Response) => {
  const found = initialIntegrations.find((i) => i.id === req.params.id);
  if (found) {
    found.connected = false;
    found.status = "Disconnected";
  }
  res.json({ success: true, message: "Disconnected successfully" });
});

// ---------------- LEAD IMPORTS ----------------
app.get("/api/imports/leads/template.xlsx", (_req: Request, res: Response) => {
  res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
  res.setHeader("Content-Disposition", "attachment; filename=OakSphere_Leads_Template.xlsx");
  res.send(Buffer.from("OakSphere Candidate Leads Template - Name, Phone, Email, Role, City"));
});

app.post("/api/imports/leads/preview", (_req: Request, res: Response) => {
  res.json({
    valid: true,
    total_rows: 5,
    preview_count: 5,
    headers: ["name", "phone", "email", "job_title", "city"],
    sample_rows: [
      { name: "Rahul Deshmukh", phone: "+91 98220 11223", email: "rahul.d@gmail.com", job_title: "Java Architect", city: "Pune" },
      { name: "Sneha Nair", phone: "+91 98220 44556", email: "sneha.n@gmail.com", job_title: "Data Analyst", city: "Bengaluru" },
      { name: "Amit Kulkarni", phone: "+91 98220 77889", email: "amit.k@gmail.com", job_title: "Fullstack Lead", city: "Mumbai" },
    ],
  });
});

app.post("/api/imports/leads/commit", (req: Request, res: Response) => {
  const user = getAuthUser(req);
  res.json({
    success: true,
    imported: 5,
    skipped: 0,
    duplicates: 0,
    assigned_to: user.name,
  });
});

// Safe fallback for unmapped API endpoints
app.all("/api/*", (_req: Request, res: Response) => {
  res.json({ items: [], total: 0, success: true });
});

// ---------------- VITE MIDDLEWARE / STATIC ASSETS ----------------
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req: Request, res: Response) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
